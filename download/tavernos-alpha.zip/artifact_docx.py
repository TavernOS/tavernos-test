"""
tavernos/artifact_docx.py — branded Word document generator.

Shipped as part of Phase 2 (artifact generation), sibling to artifact_xlsx.py.
Follows the same "domain module next to norm.py" pattern. Same sentinel-line
contract with norm.py's tool dispatcher so the CLI banner renders identically.

Architecture notes
------------------
Agent handoff is via a first-party tool call (`generate_docx_report`)
registered into norm.py's existing tool-use loop. Woody calls the tool with a
JSON spec, the tool writes the .docx, returns the saved path. Same fabrication
gap closure as artifact_xlsx — a tool_result is authoritative.

Builder scope
-------------
Three templates ship in this module:

  - `client_proposal` (Phase 2, Woody / Pack 2 — Content Operations): the
    canonical sales proposal.
  - `operational_audit` (Phase 4B, Lilith / Pack 1 — Implementation
    Consulting): the $3K client-facing audit deliverable. Structured around
    the `operational_audit` rubric — exec summary with a headline number,
    ranked priority stack with per-finding evidence and ROI math, Month 1
    plan, assumptions + uncertainty block.
  - `research_report` (Phase 4C, Cliff / Pack 3 — Research Reports): the
    external-research memo deliverable. Structured around the
    `research_report` rubric — research question up top, direct-answer
    headline with confidence level, 3-5 numbered key findings, cross-source
    synthesis block (where sources agree / disagree / our read), per-finding
    detail with structured citations (source + publisher + date required —
    source_quality has a 4.0 hard floor), limitations block, sources
    consulted list, methodology note.

Tool ALLOWED_AGENTS is accordingly {"woody", "lilith", "cliff"}.

All sections in every template are optional in the spec so the grounding
discipline's BOUND path can pass sparse data and get back a skeleton with
[TBD — ...] placeholders rather than fabricated content.

Additional templates (brief, PRD, case-study) plug in by adding a function
to BUILDERS.

Brand tokens mirror the strategy-doc stack: teal #009688, navy #0F2236, Arial
body, Consolas mono, US Letter 1" margins.

Fabrication posture
-------------------
This module does NOT inject placeholder prose. If the spec omits a section,
the section is omitted. If the spec omits a section's rows (e.g. no pricing
line items), the section renders its heading and a single "[TBD — ...]"
paragraph the user asked the agent to leave. The agent is responsible for
the placeholder text — the builder never invents.
"""

from __future__ import annotations

import json
import re
import traceback
from datetime import datetime
from pathlib import Path
from typing import Any

# ═══════════════════════════════════════════════════════════════════════════════
#  PYTHON-DOCX IMPORT — hard dependency for this module. Missing = clean
#  ImportError callers can catch (same contract as artifact_xlsx / openpyxl).
# ═══════════════════════════════════════════════════════════════════════════════

from docx import Document
from docx.document import Document as DocumentType
from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from docx.shared import Inches, Pt, RGBColor


# ═══════════════════════════════════════════════════════════════════════════════
#  BRAND TOKENS — consolidated so one edit re-brands every document. Parity
#  with artifact_xlsx.py's TEAL/NAVY/FONT_BODY/FONT_MONO values.
# ═══════════════════════════════════════════════════════════════════════════════

TEAL = RGBColor(0x00, 0x96, 0x88)      # accent bar, section rules, link color
NAVY = RGBColor(0x0F, 0x22, 0x36)      # primary — titles, headings, strong text
INK = RGBColor(0x0F, 0x22, 0x36)       # body text (same hex as navy — cohesive)
SUBTLE = RGBColor(0xE8, 0xEE, 0xF1)    # table header fill
GREY = RGBColor(0x6B, 0x7A, 0x88)      # metadata strip, captions

FONT_BODY = "Arial"
FONT_MONO = "Consolas"

# Hex strings for openxml shading (w:shd). RGBColor doesn't accept hex cleanly.
TEAL_HEX = "009688"
NAVY_HEX = "0F2236"
SUBTLE_HEX = "E8EEF1"


# ═══════════════════════════════════════════════════════════════════════════════
#  SPEC VALIDATION — same posture as artifact_xlsx: fail loudly and early; the
#  agent sees the error verbatim in the tool_result and can self-correct.
# ═══════════════════════════════════════════════════════════════════════════════

class DocxSpecError(ValueError):
    """Raised when a spec fails validation. Message is surfaced to the agent
    verbatim via tool_result — keep messages actionable and specific."""


_FILENAME_SAFE = re.compile(r"[^A-Za-z0-9._-]")

def _sanitize_filename(name: str) -> str:
    """Strip path separators and exotic chars; ensure .docx extension."""
    if not name or not isinstance(name, str):
        raise DocxSpecError("filename must be a non-empty string")
    name = name.strip()
    if ".." in name or "/" in name or "\\" in name:
        raise DocxSpecError("filename must not contain path separators or '..'")
    if name.lower().endswith(".docx"):
        name = name[:-5]
    name = _FILENAME_SAFE.sub("-", name).strip("-")
    if not name:
        raise DocxSpecError("filename reduces to empty after sanitization")
    return name + ".docx"


def _validate_spec(spec: Any) -> None:
    """Structural check. Raises DocxSpecError on the first problem.
    Sections are all optional — BOUND-path calls with mostly-empty specs
    should pass validation and produce a skeleton."""
    if not isinstance(spec, dict):
        raise DocxSpecError("spec must be a JSON object")
    if spec.get("artifact") != "docx":
        raise DocxSpecError("spec.artifact must equal 'docx'")
    template = spec.get("template")
    if template not in BUILDERS:
        valid = ", ".join(sorted(BUILDERS.keys()))
        raise DocxSpecError(
            f"spec.template must be one of: {valid}. Got: {template!r}"
        )
    if not spec.get("filename"):
        raise DocxSpecError("spec.filename is required")


# ═══════════════════════════════════════════════════════════════════════════════
#  LOW-LEVEL HELPERS — page setup, shading, run styling. python-docx's object
#  model is verbose; these factor out the repetition so builders read cleanly.
# ═══════════════════════════════════════════════════════════════════════════════

def _set_page(doc: DocumentType) -> None:
    """US Letter, 1" margins. Mirrors the strategy-doc stack."""
    section = doc.sections[0]
    section.page_height = Inches(11)
    section.page_width = Inches(8.5)
    section.top_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.right_margin = Inches(1)


def _set_base_style(doc: DocumentType) -> None:
    """Set Normal style font/size once so every paragraph inherits it."""
    normal = doc.styles["Normal"]
    normal.font.name = FONT_BODY
    normal.font.size = Pt(11)
    normal.font.color.rgb = INK
    # Also set the East-Asian font slot so Word doesn't substitute a fallback
    rpr = normal.element.get_or_add_rPr()
    r_fonts = rpr.find(qn("w:rFonts"))
    if r_fonts is None:
        r_fonts = OxmlElement("w:rFonts")
        rpr.append(r_fonts)
    r_fonts.set(qn("w:ascii"), FONT_BODY)
    r_fonts.set(qn("w:hAnsi"), FONT_BODY)
    r_fonts.set(qn("w:cs"), FONT_BODY)


def _shade_cell(cell, hex_color: str) -> None:
    """Apply a solid-fill shading to a table cell via direct OOXML — python-docx
    has no public API for this. Takes hex without the leading '#'."""
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_color)
    tc_pr.append(shd)


def _set_cell_border(cell, hex_color: str = TEAL_HEX, sz: str = "4") -> None:
    """Set a thin colored border on all four sides of a cell. sz is in eighths
    of a point (4 = 0.5pt, 8 = 1pt)."""
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_borders = OxmlElement("w:tcBorders")
    for edge in ("top", "left", "bottom", "right"):
        b = OxmlElement(f"w:{edge}")
        b.set(qn("w:val"), "single")
        b.set(qn("w:sz"), sz)
        b.set(qn("w:color"), hex_color)
        tc_borders.append(b)
    tc_pr.append(tc_borders)


def _run(paragraph, text: str, *, bold: bool = False, italic: bool = False,
         size: int = 11, color: RGBColor = INK, font: str = FONT_BODY):
    """Append a styled run to a paragraph and return it."""
    r = paragraph.add_run(text)
    r.bold = bold
    r.italic = italic
    r.font.name = font
    r.font.size = Pt(size)
    r.font.color.rgb = color
    return r


def _para(doc: DocumentType, text: str = "", *, style: str | None = None,
          align: int | None = None, space_before: int = 0, space_after: int = 6):
    """Add a paragraph with spacing controls. Returns the paragraph so callers
    can append additional runs for mixed formatting."""
    p = doc.add_paragraph(style=style) if style else doc.add_paragraph()
    if align is not None:
        p.alignment = align
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.space_after = Pt(space_after)
    if text:
        _run(p, text)
    return p


def _h1(doc: DocumentType, text: str) -> None:
    """Section heading. Navy, bold, 16pt, small teal rule below via bottom
    border on the paragraph."""
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(18)
    p.paragraph_format.space_after = Pt(6)
    _run(p, text, bold=True, size=16, color=NAVY)
    # Bottom border on the paragraph — drops a teal rule under the heading
    p_pr = p._p.get_or_add_pPr()
    p_borders = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "8")       # 1pt
    bottom.set(qn("w:space"), "2")
    bottom.set(qn("w:color"), TEAL_HEX)
    p_borders.append(bottom)
    p_pr.append(p_borders)


def _h2(doc: DocumentType, text: str) -> None:
    """Subheading. Teal, bold, 12pt."""
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(10)
    p.paragraph_format.space_after = Pt(4)
    _run(p, text, bold=True, size=12, color=TEAL)


def _bullet(doc: DocumentType, text: str) -> None:
    """One bulleted item using python-docx's built-in List Bullet style."""
    p = doc.add_paragraph(style="List Bullet")
    p.paragraph_format.space_after = Pt(2)
    # Override the run to use our body font/color (List Bullet style pulls from
    # a separate style stack that we haven't rebranded)
    for run in p.runs:
        run.text = ""
    _run(p, text)


def _tbd(doc: DocumentType, what_needed: str) -> None:
    """Render a TBD placeholder paragraph. Used by builders when a section
    heading is present in the spec but the content payload is empty — keeps
    the doc structurally intact without fabricating prose."""
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6)
    _run(p, f"[TBD — {what_needed}]", italic=True, color=GREY)


# ─── Builder type-guard helpers (Goal A session 3, Apr 23 2026) ────────────
#
# These convert "spec subfield has the wrong type" from a crash into a
# TBD-rendered placeholder + a side-channel warning string. The bypass path
# in _tool_handler was designed around "save with warnings" semantics;
# session 2's live run surfaced that the builders weren't robust enough for
# that design to hold. Session 3 adds these guards on the operational_audit
# path; client_proposal and research_report follow in the rollout sessions.
#
# Contract: each helper returns a value of the expected type. If coercion
# was needed because the input was the wrong type (dict where list expected,
# etc.), a string is appended to the `warnings` list so the side-channel
# signal reaches the agent + post-save evaluator via the _tool_handler
# output. None inputs DO NOT warn — None is the legitimate "agent acknowledged
# the section but has no content" signal, indistinguishable from empty
# string / list / dict at the visible output layer.
#
# Warning shape (pinned by test_builder_warning_shape_is_parseable in the
# Tier 0 suite): "builder: <field-path> is <actual-type>, expected <expected>"


def _as_dict(value: Any, warnings: list[str] | None, context: str) -> dict:
    """Return value if it's a dict; else log a builder-warning and return {}.
    None passes through as {} silently — legitimate 'field absent' semantics.
    `context` is the dotted field path used in the warning string."""
    if value is None:
        return {}
    if isinstance(value, dict):
        return value
    if warnings is not None:
        warnings.append(
            f"builder: {context} is {type(value).__name__}, "
            f"expected dict — rendered as TBD placeholder"
        )
    return {}


def _as_list(value: Any, warnings: list[str] | None, context: str) -> list:
    """Return value if it's a list or tuple; else log a builder-warning and
    return []. None passes through as [] silently. Strings are explicitly
    rejected even though they're iterable — iterating a string yields
    characters, which is never what a spec author intends."""
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, tuple):
        return list(value)
    if warnings is not None:
        warnings.append(
            f"builder: {context} is {type(value).__name__}, "
            f"expected list — rendered as TBD placeholder"
        )
    return []


def _as_str(value: Any, warnings: list[str] | None, context: str) -> str:
    """Return value.strip() if it's a string; else log a builder-warning and
    return ''. None and empty string both pass through as '' silently —
    legitimate 'field present but empty' semantics that the existing
    builder logic treats as a TBD trigger."""
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if warnings is not None:
        warnings.append(
            f"builder: {context} is {type(value).__name__}, "
            f"expected str — rendered as TBD placeholder"
        )
    return ""


# ─── Audit + research shared domain helpers ────────────────────────────────
#
# Originally audit-specific, now also used by _build_research_report. The
# reuse is intentional — visual parity across Pack deliverables means the
# same headline callout, meta strip, and bold-label treatment read as
# consistent stationery. Helpers exclusive to audit (_evidence_bullet,
# _roi_math_table, _format_roi_value, _numbered_list) stay audit-only.

def _headline_callout(doc: DocumentType, text: str) -> None:
    """Render the executive-summary headline number as an italicized,
    centered pull-quote bracketed by teal rules. Direct anchor for the
    operational_audit rubric's exec_summary dim — 'names top findings with
    numbers' wants a visually distinct number the reader can't miss."""
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(10)
    p.paragraph_format.space_after = Pt(10)
    p.paragraph_format.left_indent = Inches(0.5)
    p.paragraph_format.right_indent = Inches(0.5)
    _run(p, text, italic=True, size=13, color=NAVY)
    # Top + bottom teal rules on the paragraph to make the callout pop.
    p_pr = p._p.get_or_add_pPr()
    p_borders = OxmlElement("w:pBdr")
    for edge in ("top", "bottom"):
        b = OxmlElement(f"w:{edge}")
        b.set(qn("w:val"), "single")
        b.set(qn("w:sz"), "12")       # ~1.5pt
        b.set(qn("w:space"), "6")
        b.set(qn("w:color"), TEAL_HEX)
        p_borders.append(b)
    p_pr.append(p_borders)


def _meta_strip(doc: DocumentType, pairs: list[tuple[str, str]]) -> None:
    """Render a per-priority metadata line like:
        Hours/wk lost: 6-8  ·  Who feels it: Alex Rivera (COO)
    Renders the label in bold navy, value in body ink, joined with middle
    dots. One-line, tight space_after so the following content hugs it."""
    if not pairs:
        return
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(4)
    for i, (label, value) in enumerate(pairs):
        if i > 0:
            _run(p, "  ·  ", size=10, color=GREY)
        _run(p, f"{label}: ", bold=True, size=10, color=NAVY)
        _run(p, str(value), size=10)


def _bold_label(doc: DocumentType, label: str, body: str,
                space_after: int = 6) -> None:
    """Render a 'Label:' in bold navy followed by body prose on the same
    paragraph. For the 'Root cause: ...', 'Current state: ...' etc. lines
    inside each priority stack entry."""
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(space_after)
    _run(p, f"{label}: ", bold=True, color=NAVY)
    _run(p, body)


def _evidence_bullet(doc: DocumentType, source: str, detail: str) -> None:
    """One evidence bullet with the source in italics + detail in body ink.
    The rubric's evidence_density dim wants 'every finding cites a specific
    source' — this formatting makes the citation lexically obvious to the
    evaluator's text extractor ('source:' marker survives the flatten)."""
    p = doc.add_paragraph(style="List Bullet")
    p.paragraph_format.space_after = Pt(2)
    # Clear default run
    for run in p.runs:
        run.text = ""
    _run(p, f"{source}", italic=True, size=10, color=NAVY)
    _run(p, f" — {detail}", size=10)


def _roi_math_table(doc: DocumentType, roi: Any,
                    warnings: list[str] | None = None,
                    context: str = "roi_math") -> None:
    """Render a 2-column Metric | Value table for a single priority's ROI
    math. Value column is right-aligned and mono-fonted for number legibility.
    Skips rows where the value is None so sparse specs render cleanly.

    Expected keys (all optional): hours_saved_week, hours_saved_year,
    blended_rate_usd, annual_value_usd, build_cost_usd, payback_months,
    rate_methodology.

    `roi` is type-guarded via _as_dict — non-dict inputs render a TBD line
    and log a builder-warning via the `warnings` channel. `context` is the
    dotted field path (e.g. 'priority_stack[2].roi_math') used in warnings.
    """
    roi = _as_dict(roi, warnings, context)
    # Order matters — this is how the table reads top to bottom.
    label_map = [
        ("hours_saved_week",  "Hours saved / week"),
        ("hours_saved_year",  "Hours saved / year"),
        ("blended_rate_usd",  "Blended hourly rate (assumed)"),
        ("annual_value_usd",  "Annual value created"),
        ("build_cost_usd",    "One-time build cost"),
        ("payback_months",    "Payback period"),
    ]
    rows = []
    for key, label in label_map:
        val = roi.get(key)
        if val is None:
            continue
        rows.append((label, _format_roi_value(key, val)))
    if not rows:
        _tbd(doc, "ROI math (hours saved, rate, annual value, build cost, payback)")
        return

    table = doc.add_table(rows=1, cols=2)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    _write_table_header(table, ("Metric", "Value"))
    for label, value in rows:
        cells = table.add_row().cells
        _set_cell_border(cells[0])
        _set_cell_border(cells[1])
        cells[0].text = ""
        cells[1].text = ""
        lp = cells[0].paragraphs[0]
        lp.paragraph_format.space_before = Pt(2)
        lp.paragraph_format.space_after = Pt(2)
        _run(lp, label, size=10)
        vp = cells[1].paragraphs[0]
        vp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        vp.paragraph_format.space_before = Pt(2)
        vp.paragraph_format.space_after = Pt(2)
        _run(vp, value, size=10, font=FONT_MONO)

    # Methodology line directly beneath the table — italicized, grey, small.
    # Keeps the table clean while still letting a CFO trace the math.
    methodology = _as_str(
        roi.get("rate_methodology"), warnings, f"{context}.rate_methodology"
    )
    if methodology:
        m = doc.add_paragraph()
        m.paragraph_format.space_before = Pt(2)
        m.paragraph_format.space_after = Pt(6)
        _run(m, f"Rate basis: {methodology}", italic=True, size=9, color=GREY)
    else:
        # Breathing room after the table if no methodology follows.
        doc.add_paragraph()


def _format_roi_value(key: str, value: Any) -> str:
    """Format an ROI-math value according to its key semantics. Money keys
    get dollar signs + thousands separators; hour keys get the raw number;
    payback gets 'N.N months' suffix. Non-numeric values pass through as
    str(value) so the spec can pass ranges like '6-8' without blowing up."""
    if isinstance(value, (int, float)):
        if key in ("blended_rate_usd", "annual_value_usd", "build_cost_usd"):
            return f"${value:,.0f}"
        if key == "payback_months":
            return f"{value:.1f} months"
        if key == "hours_saved_year":
            return f"{value:,.0f}"
        if key == "hours_saved_week":
            return f"{value:g}"
        return f"{value:g}"
    return str(value)


def _numbered_list(doc: DocumentType, items: list[str]) -> None:
    """A numbered list using python-docx's built-in List Number style. Used
    for the recommended build sequence. Same body-font override pattern as
    _bullet."""
    for item in items:
        p = doc.add_paragraph(style="List Number")
        p.paragraph_format.space_after = Pt(2)
        for run in p.runs:
            run.text = ""
        _run(p, item)


# ═══════════════════════════════════════════════════════════════════════════════
#  BUILDER — client_proposal. Sections are optional; missing sections are
#  omitted entirely. Sections that are present but empty render a TBD line.
# ═══════════════════════════════════════════════════════════════════════════════

def _build_client_proposal(spec: dict,
                           warnings: list[str] | None = None) -> DocumentType:
    """Render a client proposal per the spec. Spec shape:

    {
      "artifact": "docx",
      "template": "client_proposal",
      "filename": "proposal-example-q2.docx",
      "category": "content" | "reports" | "audits" | "blueprints",
      "meta": {
        "title":       "Operations Audit Proposal",
        "client_name": "Example Co.",
        "prepared_by": "[Your Name], TavernOS",
        "date":        "April 21, 2026",
      },
      "executive_summary": "1–3 paragraphs of prose",
      "situation":         "1–3 paragraphs of prose",
      "approach": [
        {"phase": "Discover", "detail": "..."},
        {"phase": "Design",   "detail": "..."},
      ],
      "scope": {
        "in_scope":  ["...", "..."],
        "out_of_scope": ["...", "..."],
      },
      "timeline": [
        {"phase": "...", "duration": "2 weeks", "deliverables": "..."},
      ],
      "pricing": {
        "rows": [
          {"item": "Audit", "amount": "$3,000", "notes": "fixed fee"},
        ],
        "total": "$3,000",
      },
      "next_steps": ["...", "..."],
    }

    Every top-level section key is optional. A missing key omits the section
    entirely; a present-but-empty value renders a TBD placeholder.

    `warnings` (session 4): optional list that builder type-guards append to
    when a spec subfield has the wrong type. Appended strings follow the
    shape "builder: <field-path> is <actual-type>, expected <type> — ...".
    Callers (build_from_spec) surface these to the agent + post-save
    evaluator via the _tool_handler output. None = discard warnings.
    Pattern mirrors _build_operational_audit (session 3 reference impl)."""
    doc = Document()
    _set_page(doc)
    _set_base_style(doc)

    meta = _as_dict(spec.get("meta"), warnings, "meta")
    title = _as_str(meta.get("title"), warnings, "meta.title") or "Proposal"
    client_name = _as_str(meta.get("client_name"), warnings, "meta.client_name")
    prepared_by = _as_str(meta.get("prepared_by"), warnings, "meta.prepared_by")
    date = _as_str(meta.get("date"), warnings, "meta.date") \
        or datetime.now().strftime("%B %d, %Y")

    # ── Title bar — navy block with teal accent line below ──────────────────
    title_p = doc.add_paragraph()
    title_p.paragraph_format.space_before = Pt(0)
    title_p.paragraph_format.space_after = Pt(4)
    _run(title_p, title, bold=True, size=22, color=NAVY)

    # Teal accent rule under the title (bottom border on a thin paragraph)
    rule_p = doc.add_paragraph()
    rule_p.paragraph_format.space_before = Pt(0)
    rule_p.paragraph_format.space_after = Pt(8)
    rule_pr = rule_p._p.get_or_add_pPr()
    rule_borders = OxmlElement("w:pBdr")
    rule_bottom = OxmlElement("w:bottom")
    rule_bottom.set(qn("w:val"), "single")
    rule_bottom.set(qn("w:sz"), "18")   # ~2.25pt — visible accent
    rule_bottom.set(qn("w:space"), "1")
    rule_bottom.set(qn("w:color"), TEAL_HEX)
    rule_borders.append(rule_bottom)
    rule_pr.append(rule_borders)

    # Metadata strip — grey, small, single line combining client / date / by
    meta_bits = []
    if client_name: meta_bits.append(f"Prepared for {client_name}")
    if prepared_by: meta_bits.append(f"by {prepared_by}")
    if date:        meta_bits.append(date)
    if meta_bits:
        meta_p = doc.add_paragraph()
        meta_p.paragraph_format.space_after = Pt(18)
        _run(meta_p, " · ".join(meta_bits), size=10, color=GREY)

    # ── Executive summary ───────────────────────────────────────────────────
    if "executive_summary" in spec:
        _h1(doc, "Executive Summary")
        body = _as_str(spec.get("executive_summary"), warnings,
                       "executive_summary")
        if body:
            for para in body.split("\n\n"):
                _para(doc, para.strip(), space_after=8)
        else:
            _tbd(doc, "2–3 sentence executive summary")

    # ── Situation ───────────────────────────────────────────────────────────
    if "situation" in spec:
        _h1(doc, "Situation")
        body = _as_str(spec.get("situation"), warnings, "situation")
        if body:
            for para in body.split("\n\n"):
                _para(doc, para.strip(), space_after=8)
        else:
            _tbd(doc, "situation summary — what's going on at the client")

    # ── Approach ────────────────────────────────────────────────────────────
    if "approach" in spec:
        _h1(doc, "Approach")
        phases = _as_list(spec.get("approach"), warnings, "approach")
        if phases:
            for ph_idx, ph in enumerate(phases):
                ph = _as_dict(ph, warnings, f"approach[{ph_idx}]")
                phase_name = _as_str(ph.get("phase"), warnings,
                                     f"approach[{ph_idx}].phase")
                detail = _as_str(ph.get("detail"), warnings,
                                 f"approach[{ph_idx}].detail")
                if phase_name:
                    _h2(doc, phase_name)
                if detail:
                    _para(doc, detail, space_after=6)
                elif phase_name:
                    _tbd(doc, f"detail for phase '{phase_name}'")
        else:
            _tbd(doc, "approach phases — each with a name and a detail")

    # ── Scope (in / out table) ──────────────────────────────────────────────
    if "scope" in spec:
        _h1(doc, "Scope")
        scope = _as_dict(spec.get("scope"), warnings, "scope")
        in_scope = _as_list(scope.get("in_scope"), warnings, "scope.in_scope")
        out_scope = _as_list(scope.get("out_of_scope"), warnings,
                             "scope.out_of_scope")
        if in_scope or out_scope:
            table = doc.add_table(rows=1, cols=2)
            table.alignment = WD_TABLE_ALIGNMENT.CENTER
            hdr = table.rows[0].cells
            for i, label in enumerate(("In scope", "Out of scope")):
                hdr[i].text = ""
                _shade_cell(hdr[i], TEAL_HEX)
                _set_cell_border(hdr[i])
                p = hdr[i].paragraphs[0]
                p.paragraph_format.space_before = Pt(2)
                p.paragraph_format.space_after = Pt(2)
                _run(p, label, bold=True, size=11, color=RGBColor(0xFF, 0xFF, 0xFF))
            # Single row, each cell holds a bullet list. Zip to max length.
            max_len = max(len(in_scope), len(out_scope))
            body_row = table.add_row().cells
            for col, items in enumerate((in_scope, out_scope)):
                cell = body_row[col]
                _set_cell_border(cell)
                cell.vertical_alignment = WD_ALIGN_VERTICAL.TOP
                # Clear the default empty paragraph
                cell.text = ""
                if not items:
                    p = cell.paragraphs[0]
                    _run(p, "[TBD]", italic=True, color=GREY, size=10)
                    continue
                for i, item in enumerate(items):
                    if i == 0:
                        p = cell.paragraphs[0]
                    else:
                        p = cell.add_paragraph()
                    p.paragraph_format.space_after = Pt(2)
                    _run(p, f"• {item}", size=10)
            _ = max_len  # silence unused — kept for clarity of intent above
            doc.add_paragraph()  # breathing room after table
        else:
            _tbd(doc, "in-scope and out-of-scope items")

    # ── Timeline (table) ────────────────────────────────────────────────────
    if "timeline" in spec:
        _h1(doc, "Timeline")
        rows = _as_list(spec.get("timeline"), warnings, "timeline")
        if rows:
            table = doc.add_table(rows=1, cols=3)
            table.alignment = WD_TABLE_ALIGNMENT.CENTER
            _write_table_header(table, ("Phase", "Duration", "Deliverables"))
            for r_idx, r in enumerate(rows):
                r = _as_dict(r, warnings, f"timeline[{r_idx}]")
                cells = table.add_row().cells
                for i, key in enumerate(("phase", "duration", "deliverables")):
                    _set_cell_border(cells[i])
                    cells[i].text = ""
                    p = cells[i].paragraphs[0]
                    p.paragraph_format.space_before = Pt(2)
                    p.paragraph_format.space_after = Pt(2)
                    _run(p, str(r.get(key) or ""), size=10)
            doc.add_paragraph()
        else:
            _tbd(doc, "timeline rows (phase / duration / deliverables)")

    # ── Pricing (table + total) ─────────────────────────────────────────────
    if "pricing" in spec:
        _h1(doc, "Pricing")
        pricing = _as_dict(spec.get("pricing"), warnings, "pricing")
        rows = _as_list(pricing.get("rows"), warnings, "pricing.rows")
        total = _as_str(pricing.get("total"), warnings, "pricing.total")
        if rows:
            table = doc.add_table(rows=1, cols=3)
            table.alignment = WD_TABLE_ALIGNMENT.CENTER
            _write_table_header(table, ("Item", "Amount", "Notes"))
            for r_idx, r in enumerate(rows):
                r = _as_dict(r, warnings, f"pricing.rows[{r_idx}]")
                cells = table.add_row().cells
                for i, key in enumerate(("item", "amount", "notes")):
                    _set_cell_border(cells[i])
                    cells[i].text = ""
                    p = cells[i].paragraphs[0]
                    p.paragraph_format.space_before = Pt(2)
                    p.paragraph_format.space_after = Pt(2)
                    # Amount column: mono font, right-aligned
                    if key == "amount":
                        p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
                        _run(p, str(r.get(key) or ""), size=10, font=FONT_MONO)
                    else:
                        _run(p, str(r.get(key) or ""), size=10)
            if total:
                total_cells = table.add_row().cells
                for i, (val, align, bold) in enumerate((
                    ("Total", WD_ALIGN_PARAGRAPH.LEFT, True),
                    (total, WD_ALIGN_PARAGRAPH.RIGHT, True),
                    ("", WD_ALIGN_PARAGRAPH.LEFT, False),
                )):
                    _shade_cell(total_cells[i], SUBTLE_HEX)
                    _set_cell_border(total_cells[i])
                    total_cells[i].text = ""
                    p = total_cells[i].paragraphs[0]
                    p.alignment = align
                    p.paragraph_format.space_before = Pt(2)
                    p.paragraph_format.space_after = Pt(2)
                    font = FONT_MONO if i == 1 else FONT_BODY
                    _run(p, val, bold=bold, size=10, color=NAVY, font=font)
            doc.add_paragraph()
        else:
            _tbd(doc, "pricing line items and total")

    # ── Next steps ──────────────────────────────────────────────────────────
    if "next_steps" in spec:
        _h1(doc, "Next Steps")
        steps = _as_list(spec.get("next_steps"), warnings, "next_steps")
        if steps:
            for step in steps:
                _bullet(doc, str(step))
        else:
            _tbd(doc, "next-step bullets")

    return doc


def _write_table_header(table, labels: tuple[str, ...]) -> None:
    """Style the first row of `table` as a teal header with white bold text."""
    hdr = table.rows[0].cells
    for i, label in enumerate(labels):
        _shade_cell(hdr[i], TEAL_HEX)
        _set_cell_border(hdr[i])
        hdr[i].text = ""
        p = hdr[i].paragraphs[0]
        p.paragraph_format.space_before = Pt(2)
        p.paragraph_format.space_after = Pt(2)
        _run(p, label, bold=True, size=11, color=RGBColor(0xFF, 0xFF, 0xFF))


# ═══════════════════════════════════════════════════════════════════════════════
#  BUILDER — operational_audit. Lilith's $3K client-facing deliverable
#  (Pack 1 — Implementation Consulting).
#
#  Shape is derived directly from the operational_audit rubric anchors:
#    exec_summary     → executive_summary.prose + headline_number + top_findings
#    evidence_density → priority_stack[i].evidence (≥2 per finding, enforced
#                        in preflight; rubric hard-floor 3.5 means below-threshold
#                        evidence is the top regen trigger)
#    prioritization_quality → priority_stack ordering + build_sequence + rationale
#    roi_math_transparency  → priority_stack[i].roi_math (rendered as 2-col table)
#    actionability    → success_signal_30d per priority + month_1_plan + next_step
#    honesty_about_uncertainty → uncertainty_notes + assumptions blocks
#
#  Every section is optional in the spec. Missing → omitted. Empty → [TBD].
# ═══════════════════════════════════════════════════════════════════════════════

def _build_operational_audit(spec: dict,
                             warnings: list[str] | None = None) -> DocumentType:
    """Render an operational audit per the spec. Spec shape:

    {
      "artifact": "docx",
      "template": "operational_audit",
      "filename": "example-ops-audit.docx",
      "category": "audits",
      "meta": {
        "title":       "Operational Audit — Example Co.",
        "client_name": "Example Co.",
        "prepared_by": "[Your Name], TavernOS",
        "date":        "April 28, 2026",
      },
      "executive_summary": {
        "prose":           "3-5 sentences of diagnosis narrative",
        "headline_number": "Example Client is bleeding ~15 hrs/wk of senior time…",
        "top_findings":    ["finding 1 with number", "finding 2", "finding 3"],
      },
      "diagnosis": "one-page prose — operational character of the business",
      "priority_stack": [
        {
          "rank":                 1,
          "workflow":             "Monthly ops review reconciliation",
          "hours_per_week_lost":  "6-8",
          "who_feels_it":         "Alex Rivera (COO) + exec team",
          "root_cause":           "one sentence — not a symptom",
          "current_state":        "paragraph",
          "proposed_system":      "paragraph — names tools from existing stack",
          "evidence": [
            {"source": "MBR Summary sheet", "detail": "March variance $305K vs plan $340K"},
            {"source": "Discovery call, Apr 16", "detail": "Maya: 'quote here'"},
          ],
          "roi_math": {
            "hours_saved_week":  7,
            "hours_saved_year":  350,
            "blended_rate_usd":  95,
            "annual_value_usd":  33250,
            "build_cost_usd":    3500,
            "payback_months":    1.3,
            "rate_methodology":  "60% exec ($120) + 40% analyst ($60)",
          },
          "build_effort": "16-24 hours; credentials for 3 tools",
          "risks":         ["dep on X being available", "…"],
          "success_signal_30d": "monthly ops review starts with the number",
        },
        # 3-5 total
      ],
      "build_sequence": [
        {"weeks": "1-2", "priority_rank": 1, "rationale": "…"},
        {"weeks": "3-4", "priority_rank": 2, "rationale": "…"},
      ],
      "build_sequence_rationale": "paragraph — why this order, not ROI-rank",
      "month_1_plan": [
        {"week": 1, "focus": "…", "deliverable": "…", "client_involvement": "…"},
      ],
      "not_in_scope": "paragraph — what we are not fixing this quarter",
      "uncertainty_notes": ["hours estimate for #3 is wide because…"],
      "assumptions":       ["$85 blended rate assumes…"],
      "next_step":         "single concrete action the client can reply yes to",
    }

    All top-level keys are optional. A missing key omits the section entirely;
    a present-but-empty value renders a TBD placeholder. Priority stack
    entries behave the same — missing sub-fields are skipped, empty sub-fields
    render TBD.

    `warnings` (session 3): optional list that builder type-guards append to
    when a spec subfield has the wrong type. Appended strings follow the
    shape "builder: <field-path> is <actual-type>, expected <type> — ...".
    Callers (build_from_spec) surface these to the agent + post-save
    evaluator via the _tool_handler output. None = discard warnings.
    """
    doc = Document()
    _set_page(doc)
    _set_base_style(doc)

    meta = _as_dict(spec.get("meta"), warnings, "meta")
    title = _as_str(meta.get("title"), warnings, "meta.title") \
        or "Operational Audit"
    client_name = _as_str(meta.get("client_name"), warnings, "meta.client_name")
    prepared_by = _as_str(meta.get("prepared_by"), warnings, "meta.prepared_by")
    date = _as_str(meta.get("date"), warnings, "meta.date") \
        or datetime.now().strftime("%B %d, %Y")

    # ── Title bar — same navy/teal pattern as client_proposal. Parity is
    #    intentional: both deliverables ship from the same operator identity
    #    so they should feel like the same stationery.
    title_p = doc.add_paragraph()
    title_p.paragraph_format.space_before = Pt(0)
    title_p.paragraph_format.space_after = Pt(4)
    _run(title_p, title, bold=True, size=22, color=NAVY)

    rule_p = doc.add_paragraph()
    rule_p.paragraph_format.space_before = Pt(0)
    rule_p.paragraph_format.space_after = Pt(8)
    rule_pr = rule_p._p.get_or_add_pPr()
    rule_borders = OxmlElement("w:pBdr")
    rule_bottom = OxmlElement("w:bottom")
    rule_bottom.set(qn("w:val"), "single")
    rule_bottom.set(qn("w:sz"), "18")
    rule_bottom.set(qn("w:space"), "1")
    rule_bottom.set(qn("w:color"), TEAL_HEX)
    rule_borders.append(rule_bottom)
    rule_pr.append(rule_borders)

    meta_bits = []
    if client_name: meta_bits.append(f"Prepared for {client_name}")
    if prepared_by: meta_bits.append(f"by {prepared_by}")
    if date:        meta_bits.append(date)
    if meta_bits:
        meta_p = doc.add_paragraph()
        meta_p.paragraph_format.space_after = Pt(18)
        _run(meta_p, " · ".join(meta_bits), size=10, color=GREY)

    # ── Executive summary ───────────────────────────────────────────────────
    # Rubric dim: exec_summary (0.10). Anchor-5: "dense, names top findings
    # with numbers." Structure: prose → headline callout → top-findings list.
    if "executive_summary" in spec:
        _h1(doc, "Executive Summary")
        es = _as_dict(spec.get("executive_summary"), warnings,
                      "executive_summary")
        prose = _as_str(es.get("prose"), warnings, "executive_summary.prose")
        headline = _as_str(es.get("headline_number"), warnings,
                           "executive_summary.headline_number")
        top_raw = es.get("top_findings")
        top = _as_list(top_raw, warnings, "executive_summary.top_findings")

        if prose:
            for para in prose.split("\n\n"):
                _para(doc, para.strip(), space_after=8)
        else:
            _tbd(doc, "3-5 sentence executive summary prose")

        if headline:
            _headline_callout(doc, headline)
        else:
            _tbd(doc, "one-sentence headline number naming the total loss")

        if top:
            _h2(doc, "Top findings")
            for item in top:
                _bullet(doc, str(item))
        elif top_raw is not None:
            # Present but empty (or coerced to empty) — render TBD so the
            # scorer sees the slot. `top_raw is not None` preserves the
            # original "elif top == []" semantics while also firing when
            # _as_list coerced a bad type down to [] (warning already logged).
            _h2(doc, "Top findings")
            _tbd(doc, "3 bulleted findings, each with a number")

    # ── Diagnosis (one-page narrative) ──────────────────────────────────────
    if "diagnosis" in spec:
        _h1(doc, "The Diagnosis")
        body = _as_str(spec.get("diagnosis"), warnings, "diagnosis")
        if body:
            for para in body.split("\n\n"):
                _para(doc, para.strip(), space_after=8)
        else:
            _tbd(doc, "one-page diagnostic narrative — operational character")

    # ── Priority stack — core of the deliverable ────────────────────────────
    # Every rubric dim except exec_summary anchors in this section. Each
    # priority entry is a self-contained unit the reader can skim.
    if "priority_stack" in spec:
        _h1(doc, "The Priority Stack")
        priorities = _as_list(spec.get("priority_stack"), warnings,
                              "priority_stack")
        if not priorities:
            _tbd(doc, "ranked list of 3-5 priority workflows, each with "
                      "evidence, root cause, ROI math, and success signal")
        else:
            for idx, item in enumerate(priorities):
                _render_priority(doc, idx, item, warnings)

    # ── Recommended build sequence ──────────────────────────────────────────
    if "build_sequence" in spec or "build_sequence_rationale" in spec:
        _h1(doc, "Recommended Build Sequence")
        seq = _as_list(spec.get("build_sequence"), warnings, "build_sequence")
        if seq:
            items = []
            for row_idx, row in enumerate(seq):
                row = _as_dict(row, warnings,
                               f"build_sequence[{row_idx}]")
                weeks = _as_str(row.get("weeks"), warnings,
                                f"build_sequence[{row_idx}].weeks")
                rank = row.get("priority_rank")
                rationale = _as_str(row.get("rationale"), warnings,
                                    f"build_sequence[{row_idx}].rationale")
                line_parts = []
                if weeks:
                    line_parts.append(f"Week {weeks}")
                if rank is not None:
                    line_parts.append(f"Priority #{rank}")
                line = " — ".join(line_parts) if line_parts else "(unspecified phase)"
                if rationale:
                    line = f"{line}. {rationale}"
                items.append(line)
            _numbered_list(doc, items)
        else:
            _tbd(doc, "ordered build sequence (weeks + priority rank + rationale)")

        rationale = _as_str(spec.get("build_sequence_rationale"), warnings,
                            "build_sequence_rationale")
        if rationale:
            _para(doc, rationale, space_before=6, space_after=6)

    # ── Month 1 plan (table) ────────────────────────────────────────────────
    if "month_1_plan" in spec:
        _h1(doc, "Month 1 Plan")
        rows = _as_list(spec.get("month_1_plan"), warnings, "month_1_plan")
        if rows:
            table = doc.add_table(rows=1, cols=4)
            table.alignment = WD_TABLE_ALIGNMENT.CENTER
            _write_table_header(
                table, ("Week", "Focus", "Deliverable", "Client involvement")
            )
            for r_idx, r in enumerate(rows):
                r = _as_dict(r, warnings, f"month_1_plan[{r_idx}]")
                cells = table.add_row().cells
                for i, key in enumerate(
                    ("week", "focus", "deliverable", "client_involvement")
                ):
                    _set_cell_border(cells[i])
                    cells[i].text = ""
                    p = cells[i].paragraphs[0]
                    p.paragraph_format.space_before = Pt(2)
                    p.paragraph_format.space_after = Pt(2)
                    val = r.get(key)
                    if key == "week" and val is not None:
                        val = str(val)
                        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    _run(p, str(val or ""), size=10)
            doc.add_paragraph()
        else:
            _tbd(doc, "week-by-week plan (week, focus, deliverable, involvement)")

    # ── Not in scope ────────────────────────────────────────────────────────
    # Discipline signal — rubric doesn't score this directly, but the
    # prioritization_quality anchor-3 fallback ("priorities listed but rationale
    # weak") is partially about showing you considered and rejected things.
    if "not_in_scope" in spec:
        _h1(doc, "What's Not in This Audit")
        body = _as_str(spec.get("not_in_scope"), warnings, "not_in_scope")
        if body:
            for para in body.split("\n\n"):
                _para(doc, para.strip(), space_after=8)
        else:
            _tbd(doc, "paragraph — what we're deferring this quarter, and why")

    # ── Assumptions + uncertainty ───────────────────────────────────────────
    # Rubric dim: honesty_about_uncertainty (0.05). Anchor-5: "uncertainty
    # called out explicitly in 2+ places." Two separate lists make the
    # "2+ places" signal mechanically visible. Both lists pass items through
    # str() so their element types aren't checked — a list of dicts still
    # renders (as dict repr) rather than crashing.
    has_assumptions = "assumptions" in spec
    has_uncertainty = "uncertainty_notes" in spec
    if has_assumptions or has_uncertainty:
        _h1(doc, "Assumptions & Uncertainty")

        if has_uncertainty:
            _h2(doc, "Where evidence is thin")
            notes = _as_list(spec.get("uncertainty_notes"), warnings,
                             "uncertainty_notes")
            if notes:
                for note in notes:
                    _bullet(doc, str(note))
            else:
                _tbd(doc, "at least one note on where the analysis is tentative")

        if has_assumptions:
            _h2(doc, "Assumptions")
            assumptions = _as_list(spec.get("assumptions"), warnings,
                                   "assumptions")
            if assumptions:
                for a in assumptions:
                    _bullet(doc, str(a))
            else:
                _tbd(doc, "bulleted assumptions — rates, volumes, availability")

    # ── Next step ───────────────────────────────────────────────────────────
    if "next_step" in spec:
        _h1(doc, "Next Step")
        body = _as_str(spec.get("next_step"), warnings, "next_step")
        if body:
            _para(doc, body, space_after=6)
        else:
            _tbd(doc, "single concrete action the client can reply yes to")

    return doc


def _render_priority(doc: DocumentType, index: int, item: Any,
                     warnings: list[str] | None = None) -> None:
    """Render a single priority-stack entry. Factored out because each entry
    has 8+ fields and inlining bloats _build_operational_audit past readability.
    `index` is 0-based; display rank falls back to (index+1) if spec didn't
    supply `rank`.

    Type-guarded (session 3): if `item` is not a dict, renders a minimal
    "(malformed entry)" heading + builder-warning and returns. Individual
    field values are normalized via _as_str / _as_list / _as_dict so wrong
    types render as TBD placeholders instead of crashing.
    """
    context = f"priority_stack[{index}]"
    if not isinstance(item, dict):
        if warnings is not None:
            warnings.append(
                f"builder: {context} is {type(item).__name__}, "
                f"expected dict — rendered as TBD heading"
            )
        _h2(doc, f"Priority {index + 1} — (malformed entry)")
        _tbd(doc, "priority entry was not a structured object; spec the "
                  "workflow, evidence, ROI math, and success signal as a dict")
        return

    rank = item.get("rank") if item.get("rank") is not None else (index + 1)
    workflow = _as_str(item.get("workflow"), warnings,
                       f"{context}.workflow") or "(unnamed workflow)"
    _h2(doc, f"Priority {rank} — {workflow}")

    # Meta strip: hours lost + pain owner, inline right under the subheading.
    # hours_per_week_lost is always str()-coerced so any type is safe here.
    # who_feels_it is a prose field — guard via _as_str.
    strip_pairs = []
    if item.get("hours_per_week_lost") not in (None, ""):
        strip_pairs.append(("Hours/wk lost", str(item["hours_per_week_lost"])))
    who_feels_it = _as_str(item.get("who_feels_it"), warnings,
                           f"{context}.who_feels_it")
    if who_feels_it:
        strip_pairs.append(("Who feels it", who_feels_it))
    if strip_pairs:
        _meta_strip(doc, strip_pairs)

    # Prose labels — root cause / current state / proposed system.
    for key, label, tbd_hint in (
        ("root_cause",      "Root cause",
            "one sentence — the cause, not the symptom"),
        ("current_state",   "Current state",
            "paragraph — how the workflow runs today"),
        ("proposed_system", "Proposed system",
            "paragraph — how it should run; name tools from existing stack"),
    ):
        if key in item:
            body = _as_str(item.get(key), warnings, f"{context}.{key}")
            if body:
                _bold_label(doc, label, body)
            else:
                _bold_label(doc, label, f"[TBD — {tbd_hint}]")

    # Evidence list — rubric-critical. Missing or empty evidence is the
    # fastest path below the evidence_density hard floor of 3.5.
    if "evidence" in item:
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(4)
        p.paragraph_format.space_after = Pt(2)
        _run(p, "Evidence:", bold=True, color=NAVY)
        evidence = _as_list(item.get("evidence"), warnings,
                            f"{context}.evidence")
        if evidence:
            for ev_idx, ev in enumerate(evidence):
                # Accept both {"source","detail"} and plain-string evidence.
                # Plain strings get no italic source — the evaluator still
                # sees them but the scoring will likely notch down.
                if isinstance(ev, dict):
                    ev_ctx = f"{context}.evidence[{ev_idx}]"
                    source = _as_str(ev.get("source"), warnings,
                                     f"{ev_ctx}.source")
                    detail = _as_str(ev.get("detail"), warnings,
                                     f"{ev_ctx}.detail")
                    if source and detail:
                        _evidence_bullet(doc, source, detail)
                    elif source:
                        _evidence_bullet(doc, source, "[TBD — detail]")
                    elif detail:
                        _bullet(doc, detail)
                elif isinstance(ev, str):
                    _bullet(doc, ev)
                else:
                    # Non-dict, non-string evidence entry — coerce + warn.
                    if warnings is not None:
                        warnings.append(
                            f"builder: {context}.evidence[{ev_idx}] is "
                            f"{type(ev).__name__}, expected dict or str — "
                            f"rendered via str() coercion"
                        )
                    _bullet(doc, str(ev))
        else:
            _tbd(doc, "at least 2 evidence citations (source + detail) "
                      "for this finding")

    # ROI math table.
    if "roi_math" in item:
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(6)
        p.paragraph_format.space_after = Pt(2)
        _run(p, "ROI math", bold=True, color=NAVY)
        _roi_math_table(doc, item.get("roi_math"), warnings,
                        f"{context}.roi_math")

    # Build effort — single prose line.
    if "build_effort" in item:
        be = _as_str(item.get("build_effort"), warnings,
                     f"{context}.build_effort")
        if be:
            _bold_label(doc, "Build effort", be)
        else:
            _bold_label(doc, "Build effort",
                        "[TBD — hours range + credentials/tools needed]")

    # Risks — bulleted list.
    if "risks" in item:
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(4)
        p.paragraph_format.space_after = Pt(2)
        _run(p, "Risks to the build:", bold=True, color=NAVY)
        risks = _as_list(item.get("risks"), warnings, f"{context}.risks")
        if risks:
            for r in risks:
                _bullet(doc, str(r))
        else:
            _tbd(doc, "risks to the build — dependencies, assumptions, "
                      "credentials not yet confirmed")

    # Success signal — italicized line, greyed meta treatment so it reads
    # as a kicker rather than a new section.
    if "success_signal_30d" in item:
        body = _as_str(item.get("success_signal_30d"), warnings,
                       f"{context}.success_signal_30d")
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(4)
        p.paragraph_format.space_after = Pt(10)
        _run(p, "Success signal at 30 days: ", bold=True, color=NAVY)
        if body:
            _run(p, body, italic=True)
        else:
            _run(p, "[TBD — one measurable thing that proves the fix worked]",
                 italic=True, color=GREY)


# ═══════════════════════════════════════════════════════════════════════════════
#  BUILDER — research_report. Cliff's external-research deliverable
#  (Pack 3 — Research Reports).
#
#  Shape is derived directly from the research_report rubric anchors:
#    answer_to_question        → research_question + executive_summary.headline
#                                 (direct answer up top, before findings)
#    key_points_extraction     → key_findings (3-5 numbered takeaways, each
#                                 with confidence + implication; preflight R2
#                                 enforces the 3-5 count)
#    synthesis_quality         → synthesis.narrative + points_of_agreement +
#                                 points_of_tension (anchor-5: "conflicts named
#                                 and resolved" — points_of_tension is the
#                                 structural slot for that)
#    source_quality            → findings_detail[i].supporting_evidence with
#                                 source + publisher + date REQUIRED on every
#                                 citation. Rubric hard-floor 4.0 (the only
#                                 4.0 hard floor in any rubric); preflight R4
#                                 enforces all three fields populated.
#    uncertainty_acknowledgment → executive_summary.confidence + limitations +
#                                  per-finding confidence levels
#    formatting_for_reuse      → sources_consulted (reference list), clear
#                                 section structure, methodology_note
#
#  Every section is optional in the spec. Missing → omitted. Empty → [TBD].
# ═══════════════════════════════════════════════════════════════════════════════

def _build_research_report(spec: dict,
                           warnings: list[str] | None = None) -> DocumentType:
    """Render a research report per the spec. Spec shape:

    {
      "artifact": "docx",
      "template": "research_report",
      "filename": "example-saas-ops-benchmarks.docx",
      "category": "reports",
      "meta": {
        "title":       "Series A SaaS Operational-Leverage Benchmarks",
        "client_name": "Example Co.",
        "prepared_by": "[Your Name], TavernOS",
        "date":        "April 28, 2026",
      },
      "research_question": "Where does Example Client sit vs. its cohort on…",
      "executive_summary": {
        "headline":   "one-sentence direct answer to the question",
        "confidence": "moderate — cohort definitions vary; see limitations",
        "context":    "1-2 sentences framing why this matters",
      },
      "key_findings": [
        {"finding":    "Finding headline claim with a number",
         "confidence": "high",
         "so_what":    "one-line implication for Example Client"},
        # 3-5 total
      ],
      "synthesis": {
        "narrative": "2-4 paragraphs making sense of sources together",
        "points_of_agreement": ["area where sources converge"],
        "points_of_tension": [
          {"topic":          "what the tension is about",
           "source_a_says":  "Source A claim",
           "source_b_says":  "Source B claim",
           "our_read":       "how we reconcile"},
        ],
      },
      "findings_detail": [
        {"finding_ref": 1,
         "analysis":    "paragraphs of analysis",
         "supporting_evidence": [
           {"source":    "Report name or article title",
            "publisher": "KeyBanc Capital Markets",
            "date":      "Oct 2025",
            "detail":    "what the source says",
            "url":       "https://..."},
           # >=2 per finding
         ]},
      ],
      "limitations": ["what this research couldn't determine"],
      "recommendations": ["optional — what to do with this"],
      "sources_consulted": [
        {"title":     "2025 Private SaaS Company Survey",
         "author":    "KeyBanc Capital Markets",
         "publisher": "KeyBanc",
         "date":      "October 2025",
         "url":       "https://...",
         "notes":     "cohort: $1M-$100M ARR, n=364"},
      ],
      "methodology_note": "one paragraph on search strategy + inclusion criteria",
    }

    All top-level keys are optional. A missing key omits the section entirely;
    a present-but-empty value renders a TBD placeholder. findings_detail
    entries behave the same — missing sub-fields are skipped, empty sub-fields
    render TBD.

    `warnings` (session 5): optional list that builder type-guards append to
    when a spec subfield has the wrong type. Appended strings follow the
    shape "builder: <field-path> is <actual-type>, expected <type> — ...".
    Callers (build_from_spec) surface these to the agent + post-save
    evaluator via the _tool_handler output. None = discard warnings.
    Pattern mirrors _build_operational_audit (session 3) and
    _build_client_proposal (session 4). research_report nests one level
    deeper than either — findings_detail[i].supporting_evidence[j].source
    is the deepest field-path the warning regex will see.
    """
    doc = Document()
    _set_page(doc)
    _set_base_style(doc)

    meta = _as_dict(spec.get("meta"), warnings, "meta")
    title = _as_str(meta.get("title"), warnings, "meta.title") \
        or "Research Report"
    client_name = _as_str(meta.get("client_name"), warnings, "meta.client_name")
    prepared_by = _as_str(meta.get("prepared_by"), warnings, "meta.prepared_by")
    date = _as_str(meta.get("date"), warnings, "meta.date") \
        or datetime.now().strftime("%B %d, %Y")

    # ── Title bar — same navy/teal pattern as proposal + audit. Intentional
    #    parity: all three Pack deliverables ship from the same operator
    #    identity so they read as the same stationery.
    title_p = doc.add_paragraph()
    title_p.paragraph_format.space_before = Pt(0)
    title_p.paragraph_format.space_after = Pt(4)
    _run(title_p, title, bold=True, size=22, color=NAVY)

    rule_p = doc.add_paragraph()
    rule_p.paragraph_format.space_before = Pt(0)
    rule_p.paragraph_format.space_after = Pt(8)
    rule_pr = rule_p._p.get_or_add_pPr()
    rule_borders = OxmlElement("w:pBdr")
    rule_bottom = OxmlElement("w:bottom")
    rule_bottom.set(qn("w:val"), "single")
    rule_bottom.set(qn("w:sz"), "18")
    rule_bottom.set(qn("w:space"), "1")
    rule_bottom.set(qn("w:color"), TEAL_HEX)
    rule_borders.append(rule_bottom)
    rule_pr.append(rule_borders)

    meta_bits = []
    if client_name: meta_bits.append(f"Prepared for {client_name}")
    if prepared_by: meta_bits.append(f"by {prepared_by}")
    if date:        meta_bits.append(date)
    if meta_bits:
        meta_p = doc.add_paragraph()
        meta_p.paragraph_format.space_after = Pt(18)
        _run(meta_p, " · ".join(meta_bits), size=10, color=GREY)

    # ── Research question ───────────────────────────────────────────────────
    # Rubric dim: answer_to_question (0.20). Anchor-5: "Directly answers the
    # question, acknowledges limits." Stating the question explicitly at the
    # top is the structural move that lets the evaluator verify the body
    # actually answered it. If the question isn't present, the report is
    # answering a self-chosen question — rubric anchor-3 territory.
    if "research_question" in spec:
        _h1(doc, "Research Question")
        q = _as_str(spec.get("research_question"), warnings, "research_question")
        if q:
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(4)
            p.paragraph_format.space_after = Pt(10)
            _run(p, q, bold=True, italic=True, color=NAVY)
        else:
            _tbd(doc, "the single question this report answers — one sentence")

    # ── Executive summary ───────────────────────────────────────────────────
    # Rubric dims: answer_to_question (0.20) + uncertainty_acknowledgment
    # (0.10). Headline callout for the direct answer; confidence statement
    # immediately beneath so the reader sees answer + certainty together.
    #
    # Note (session 5): executive_summary is a DICT in research_report
    # (CP's is a string). If the agent sends a string here, _as_dict coerces
    # to {} with a builder-warning AND preflight R5 fires with a semantic
    # explanation — both channels are intentional. Builder-warning names the
    # shape; R5 tells the agent which template's shape this was.
    if "executive_summary" in spec:
        _h1(doc, "Executive Summary")
        es = _as_dict(spec.get("executive_summary"), warnings,
                      "executive_summary")
        headline = _as_str(es.get("headline"), warnings,
                           "executive_summary.headline")
        confidence = _as_str(es.get("confidence"), warnings,
                             "executive_summary.confidence")
        context = _as_str(es.get("context"), warnings,
                          "executive_summary.context")

        if headline:
            _headline_callout(doc, headline)
        else:
            _tbd(doc, "one-sentence direct answer to the research question")

        if confidence:
            _bold_label(doc, "Confidence", confidence)
        else:
            _tbd(doc, "confidence level (high/moderate/low) with one-line reasoning")

        if context:
            _para(doc, context, space_after=8)
        elif "context" in es:
            _tbd(doc, "1-2 sentences framing why this matters to the client")

    # ── Key findings (numbered summary — stand-alone) ───────────────────────
    # Rubric dim: key_points_extraction (0.15). Anchor-5: "Clean numbered
    # findings summary up top — 3-5 takeaways." Preflight R2 enforces the
    # 3-5 count. Each finding carries confidence + implication inline so the
    # scorer sees both uncertainty_acknowledgment and answer_to_question
    # signals without leaving this section.
    if "key_findings" in spec:
        _h1(doc, "Key Findings")
        findings = _as_list(spec.get("key_findings"), warnings, "key_findings")
        if findings:
            for idx, f in enumerate(findings):
                _render_key_finding(doc, idx, f, warnings)
        else:
            _tbd(doc, "3-5 numbered findings, each with a claim, confidence, "
                      "and one-line implication")

    # ── Synthesis — cross-source story ──────────────────────────────────────
    # Rubric dim: synthesis_quality (0.25). Anchor-5: "coherent synthesis,
    # conflicts named and resolved." Narrative is the "coherent" part;
    # points_of_tension is the "conflicts named and resolved" part. Serial
    # source summaries score 3, not 5 — the points_of_tension block is what
    # differentiates 5 from 3 mechanically.
    if "synthesis" in spec:
        _h1(doc, "Synthesis")
        syn = _as_dict(spec.get("synthesis"), warnings, "synthesis")
        narrative = _as_str(syn.get("narrative"), warnings,
                            "synthesis.narrative")
        agreement = _as_list(syn.get("points_of_agreement"), warnings,
                             "synthesis.points_of_agreement")
        tension = _as_list(syn.get("points_of_tension"), warnings,
                           "synthesis.points_of_tension")

        if narrative:
            for para in narrative.split("\n\n"):
                _para(doc, para.strip(), space_after=8)
        elif "narrative" in syn:
            _tbd(doc, "2-4 paragraphs connecting sources into one story, "
                      "not summarizing them serially")

        if "points_of_agreement" in syn:
            _h2(doc, "Where sources agree")
            if agreement:
                for item in agreement:
                    _bullet(doc, str(item))
            else:
                _tbd(doc, "bulleted points of convergence across sources")

        if "points_of_tension" in syn:
            _h2(doc, "Where sources disagree")
            if tension:
                for t_idx, t in enumerate(tension):
                    _render_tension(
                        doc, t, warnings,
                        f"synthesis.points_of_tension[{t_idx}]",
                    )
            else:
                _tbd(doc, "at least one tension between sources with our "
                          "read on who's probably right")

    # ── Findings in detail (per-finding analysis + citations) ───────────────
    # Rubric dim: source_quality (0.25, 4.0 hard floor) + synthesis_quality.
    # This is where the source_quality evaluation lives — the evaluator reads
    # supporting_evidence citations and scores on primary-source preference,
    # recency, attribution completeness. Preflight R3 enforces >=2 citations
    # per detail; R4 enforces source+publisher+date completeness on each.
    if "findings_detail" in spec:
        _h1(doc, "Findings in Detail")
        details = _as_list(spec.get("findings_detail"), warnings,
                           "findings_detail")
        if details:
            for idx, d in enumerate(details):
                _render_finding_detail(doc, idx, d, warnings)
        else:
            _tbd(doc, "per-finding analysis with supporting evidence "
                      "(source + publisher + date required on each citation)")

    # ── Limitations ─────────────────────────────────────────────────────────
    # Rubric dim: uncertainty_acknowledgment (0.10). Anchor-5: "uncertainty
    # explicit, confidence levels stated." Per-finding confidence covers the
    # second half; limitations covers the first. Preflight R6 gates on at
    # least one of limitations / points_of_tension being populated.
    if "limitations" in spec:
        _h1(doc, "Limitations & What We Don't Know")
        limits = _as_list(spec.get("limitations"), warnings, "limitations")
        if limits:
            for item in limits:
                _bullet(doc, str(item))
        else:
            _tbd(doc, "at least one note on what this research could not "
                      "determine and why")

    # ── Recommendations (optional) ──────────────────────────────────────────
    # Not a rubric dimension on its own — Cliff's persona is "research, not
    # prescription," so this section is optional. When present it's bulleted,
    # not prose, to signal advice rather than directive.
    if "recommendations" in spec:
        _h1(doc, "Recommendations")
        recs = _as_list(spec.get("recommendations"), warnings, "recommendations")
        if recs:
            for item in recs:
                _bullet(doc, str(item))
        else:
            _tbd(doc, "recommendations — what to do with this research")

    # ── Sources consulted (reference list) ──────────────────────────────────
    # Rubric dims: source_quality + formatting_for_reuse. A trailing reference
    # list lets the reader verify attribution in one place and lets the
    # operator reuse citations elsewhere. Anchor-5 for source_quality wants
    # "all attributed" — a consolidated list makes that mechanically visible.
    if "sources_consulted" in spec:
        _h1(doc, "Sources Consulted")
        sources = _as_list(spec.get("sources_consulted"), warnings,
                           "sources_consulted")
        if sources:
            for s_idx, s in enumerate(sources):
                _render_source_citation(
                    doc, s, warnings, f"sources_consulted[{s_idx}]",
                )
        else:
            _tbd(doc, "full citation list — title, author, publisher, date, URL")

    # ── Methodology note ────────────────────────────────────────────────────
    # Rubric dim: formatting_for_reuse (0.05). Low weight but signals the
    # research was done with a method, not assembled from vibes. A single
    # paragraph is enough — search strategy, inclusion criteria, date range.
    if "methodology_note" in spec:
        _h1(doc, "Methodology")
        body = _as_str(spec.get("methodology_note"), warnings,
                       "methodology_note")
        if body:
            for para in body.split("\n\n"):
                _para(doc, para.strip(), space_after=8)
        else:
            _tbd(doc, "one paragraph on how this research was conducted — "
                      "search strategy, inclusion criteria, date range")

    return doc


def _render_key_finding(doc: DocumentType, index: int, item: Any,
                        warnings: list[str] | None = None) -> None:
    """Render a single key_findings entry — numbered claim, confidence chip,
    implication. Factored out because each entry has 3 fields and inlining
    bloats the builder. `index` is 0-based; display number is index+1.

    Type-guarded (session 5): if `item` is not a dict, renders a minimal
    "(malformed entry)" numbered line + builder-warning and returns. Mirrors
    _render_priority's session-3 contract."""
    num = index + 1
    context = f"key_findings[{index}]"
    if not isinstance(item, dict):
        if warnings is not None:
            warnings.append(
                f"builder: {context} is {type(item).__name__}, "
                f"expected dict — rendered as TBD numbered line"
            )
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(8)
        p.paragraph_format.space_after = Pt(2)
        _run(p, f"{num}. ", bold=True, size=12, color=NAVY)
        _run(p, "[TBD — finding claim]", italic=True, color=GREY)
        return

    finding = _as_str(item.get("finding"), warnings, f"{context}.finding")
    confidence = _as_str(item.get("confidence"), warnings,
                         f"{context}.confidence")
    so_what = _as_str(item.get("so_what"), warnings, f"{context}.so_what")

    # Numbered bold finding line
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8)
    p.paragraph_format.space_after = Pt(2)
    _run(p, f"{num}. ", bold=True, size=12, color=NAVY)
    if finding:
        _run(p, finding, bold=True, size=12, color=NAVY)
    else:
        _run(p, "[TBD — finding claim]", italic=True, color=GREY)

    # Confidence meta-strip — reuses the audit's _meta_strip pattern for
    # visual parity across pack deliverables.
    if confidence:
        _meta_strip(doc, [("Confidence", confidence)])
    elif "confidence" in item:
        _meta_strip(doc, [("Confidence", "[TBD]")])

    # Implication line
    if so_what:
        _bold_label(doc, "Implication", so_what, space_after=6)
    elif "so_what" in item:
        _bold_label(doc, "Implication",
                    "[TBD — one-line implication for the client]",
                    space_after=6)


def _render_tension(doc: DocumentType, t: Any,
                    warnings: list[str] | None = None,
                    context: str = "synthesis.points_of_tension[?]") -> None:
    """Render one points_of_tension entry — the topic, each source's position,
    and 'our read'. Visually differentiates source quotes (indented, teal
    labels) from the reconciling read (_bold_label treatment). This is the
    synthesis_quality anchor-5 machinery — 'conflicts named and resolved'
    renders as a structural block the evaluator can't miss.

    Type-guarded (session 5): non-dict input now emits a builder-warning
    before falling back to a str() bullet. `context` is the dotted field
    path used in warnings (e.g. 'synthesis.points_of_tension[2]')."""
    if not isinstance(t, dict):
        if warnings is not None:
            warnings.append(
                f"builder: {context} is {type(t).__name__}, "
                f"expected dict — rendered via str() coercion"
            )
        _bullet(doc, str(t))
        return
    topic = _as_str(t.get("topic"), warnings, f"{context}.topic")
    a = _as_str(t.get("source_a_says"), warnings, f"{context}.source_a_says")
    b = _as_str(t.get("source_b_says"), warnings, f"{context}.source_b_says")
    read = _as_str(t.get("our_read"), warnings, f"{context}.our_read")

    if topic:
        _bold_label(doc, "Topic", topic, space_after=2)
    elif "topic" in t:
        _bold_label(doc, "Topic", "[TBD — what the tension is about]",
                    space_after=2)

    for label, body, key in (
        ("Source A says", a, "source_a_says"),
        ("Source B says", b, "source_b_says"),
    ):
        if body or key in t:
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Inches(0.3)
            p.paragraph_format.space_before = Pt(1)
            p.paragraph_format.space_after = Pt(1)
            _run(p, f"{label}: ", bold=True, size=10, color=TEAL)
            if body:
                _run(p, body, size=10)
            else:
                _run(p, "[TBD]", italic=True, size=10, color=GREY)

    if read:
        _bold_label(doc, "Our read", read, space_after=10)
    elif "our_read" in t:
        _bold_label(doc, "Our read",
                    "[TBD — how we reconcile the conflict]",
                    space_after=10)


def _render_finding_detail(doc: DocumentType, index: int, item: Any,
                           warnings: list[str] | None = None) -> None:
    """Render a single findings_detail entry — subheading + analysis prose +
    supporting_evidence list. Parallels _render_priority from the audit
    builder in structure (subheading, labeled sub-fields, citation list).
    `index` is 0-based; finding_ref defaults to index+1 if the spec didn't
    supply one.

    Type-guarded (session 5): non-dict entries render a "(malformed entry)"
    heading + builder-warning. finding_ref is intentionally left unguarded —
    the existing int-vs-other branch at the heading site already renders
    safely on any str()-coercible value."""
    context = f"findings_detail[{index}]"
    if not isinstance(item, dict):
        if warnings is not None:
            warnings.append(
                f"builder: {context} is {type(item).__name__}, "
                f"expected dict — rendered as TBD heading"
            )
        _h2(doc, f"Finding {index + 1} — (malformed entry)")
        _tbd(doc, "finding entry was not a structured object; spec the "
                  "analysis and supporting_evidence as a dict")
        return

    finding_ref = item.get("finding_ref")
    if finding_ref is None:
        finding_ref = index + 1

    # Heading construction — integer refs get "Finding N" treatment, strings
    # get rendered as-is so the agent can supply a short title instead.
    if isinstance(finding_ref, int):
        heading = f"Finding {finding_ref} — detail"
    else:
        heading = f"Finding: {finding_ref}"
    _h2(doc, heading)

    analysis = _as_str(item.get("analysis"), warnings, f"{context}.analysis")
    if analysis:
        for para in analysis.split("\n\n"):
            _para(doc, para.strip(), space_after=6)
    elif "analysis" in item:
        _tbd(doc, "paragraphs of analysis for this finding")

    # Supporting evidence — rubric-critical. Missing source/publisher/date
    # is the fastest path below the source_quality 4.0 hard floor.
    if "supporting_evidence" in item:
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(4)
        p.paragraph_format.space_after = Pt(2)
        _run(p, "Supporting evidence:", bold=True, color=NAVY)
        evidence = _as_list(item.get("supporting_evidence"), warnings,
                            f"{context}.supporting_evidence")
        if evidence:
            for ev_idx, ev in enumerate(evidence):
                _render_source_evidence(
                    doc, ev, warnings,
                    f"{context}.supporting_evidence[{ev_idx}]",
                )
        else:
            _tbd(doc, "at least 2 citations, each with source, publisher, "
                      "and date (source_quality has a 4.0 hard floor)")


def _render_source_evidence(doc: DocumentType, ev: Any,
                            warnings: list[str] | None = None,
                            context: str =
                                "findings_detail[?].supporting_evidence[?]"
                            ) -> None:
    """Research-evidence bullet: source in italic navy, publisher+date in a
    grey parenthetical, detail in body ink, URL as a trailing grey reference.

    Deliberately distinct from audit's _evidence_bullet — research citations
    are scored on primary-source preference, recency, attribution, which
    means publisher + date need to be lexically visible, not just 'source +
    detail' like the audit. The parenthetical (publisher, date) is the
    structural signal to the evaluator.

    Type-guarded (session 5): non-dict input emits a builder-warning before
    the str() fallback bullet. `context` is the dotted field path
    (e.g. 'findings_detail[0].supporting_evidence[1]') — this is the
    deepest-nesting warning path in the module."""
    if not isinstance(ev, dict):
        if warnings is not None:
            warnings.append(
                f"builder: {context} is {type(ev).__name__}, "
                f"expected dict — rendered via str() coercion"
            )
        _bullet(doc, str(ev))
        return

    source = _as_str(ev.get("source"), warnings, f"{context}.source")
    publisher = _as_str(ev.get("publisher"), warnings, f"{context}.publisher")
    date = _as_str(ev.get("date"), warnings, f"{context}.date")
    detail = _as_str(ev.get("detail"), warnings, f"{context}.detail")
    url = _as_str(ev.get("url"), warnings, f"{context}.url")

    p = doc.add_paragraph(style="List Bullet")
    p.paragraph_format.space_after = Pt(2)
    for run in p.runs:
        run.text = ""

    if source:
        _run(p, source, italic=True, size=10, color=NAVY)
    else:
        _run(p, "[TBD — source title]", italic=True, size=10, color=GREY)

    # (publisher, date) parenthetical — both lexically visible to the scorer.
    parens = []
    if publisher:
        parens.append(publisher)
    if date:
        parens.append(date)
    if parens:
        _run(p, f" ({', '.join(parens)})", size=10, color=GREY)

    if detail:
        _run(p, f" — {detail}", size=10)

    if url:
        _run(p, f"  [{url}]", size=9, color=GREY)


def _render_source_citation(doc: DocumentType, s: Any,
                            warnings: list[str] | None = None,
                            context: str = "sources_consulted[?]") -> None:
    """Full reference-list citation. More verbose than _render_source_evidence
    because this is the trailing sources_consulted list — readers scan it to
    verify attribution and to reuse citations. Format: title (bold navy) —
    author, (publisher, date), URL on its own line, italicized notes beneath.

    Type-guarded (session 5): non-dict input emits a builder-warning before
    the str() fallback bullet."""
    if not isinstance(s, dict):
        if warnings is not None:
            warnings.append(
                f"builder: {context} is {type(s).__name__}, "
                f"expected dict — rendered via str() coercion"
            )
        _bullet(doc, str(s))
        return

    title = _as_str(s.get("title"), warnings, f"{context}.title")
    author = _as_str(s.get("author"), warnings, f"{context}.author")
    publisher = _as_str(s.get("publisher"), warnings, f"{context}.publisher")
    date = _as_str(s.get("date"), warnings, f"{context}.date")
    url = _as_str(s.get("url"), warnings, f"{context}.url")
    notes = _as_str(s.get("notes"), warnings, f"{context}.notes")

    p = doc.add_paragraph(style="List Bullet")
    p.paragraph_format.space_after = Pt(2)
    for run in p.runs:
        run.text = ""

    if title:
        _run(p, title, bold=True, color=NAVY)
    else:
        _run(p, "[TBD — title]", italic=True, color=GREY)

    if author:
        _run(p, f" — {author}")

    parens = []
    if publisher:
        parens.append(publisher)
    if date:
        parens.append(date)
    if parens:
        _run(p, f" ({', '.join(parens)})", size=10, color=GREY)

    # URL on its own sub-line, indented under the bullet
    if url:
        up = doc.add_paragraph()
        up.paragraph_format.left_indent = Inches(0.5)
        up.paragraph_format.space_before = Pt(0)
        up.paragraph_format.space_after = Pt(1)
        _run(up, url, size=9, color=GREY)

    # Notes — italicized sub-line for cohort definitions, methodology hints
    if notes:
        np = doc.add_paragraph()
        np.paragraph_format.left_indent = Inches(0.5)
        np.paragraph_format.space_before = Pt(0)
        np.paragraph_format.space_after = Pt(4)
        _run(np, notes, italic=True, size=9, color=GREY)


# ═══════════════════════════════════════════════════════════════════════════════
#  BUILDER REGISTRY
# ═══════════════════════════════════════════════════════════════════════════════

BUILDERS: dict[str, Any] = {
    "client_proposal":    _build_client_proposal,
    "operational_audit":  _build_operational_audit,
    "research_report":    _build_research_report,
}


# ═══════════════════════════════════════════════════════════════════════════════
#  PATH RESOLUTION — injected resolver, same pattern as artifact_xlsx. Avoids
#  a hard import on norm.py's path helpers and keeps test-mode viable.
# ═══════════════════════════════════════════════════════════════════════════════

_PATH_RESOLVER = None

def set_path_resolver(resolver) -> None:
    """norm.py calls this once at import, passing a callable
        (slug_or_None) -> Path of <active_client>/deliverables/"""
    global _PATH_RESOLVER
    _PATH_RESOLVER = resolver


def _resolve_output_path(client_slug: str | None, category: str,
                         filename: str) -> Path:
    """Return the sandboxed absolute path for the docx. Raises DocxSpecError
    on invalid category or sandbox escape."""
    if category not in {"reports", "audits", "blueprints", "content"}:
        raise DocxSpecError(
            f"invalid category {category!r}; must be one of "
            "reports, audits, blueprints, content"
        )
    safe_name = _sanitize_filename(filename)
    if _PATH_RESOLVER is None:
        base = (
            Path.home() / ".tavernos" / "clients"
            / (client_slug or "_self") / "deliverables"
        )
    else:
        base = _PATH_RESOLVER(client_slug)
    base = base.resolve()
    final = (base / category / safe_name).resolve()
    try:
        final.relative_to(base)
    except ValueError:
        raise DocxSpecError("path escaped client sandbox")
    return final


# ═══════════════════════════════════════════════════════════════════════════════
#  MAIN ENTRY — build_from_spec. Mirrors artifact_xlsx.build_from_spec exactly
#  in shape so norm.py's dispatcher doesn't need to special-case.
# ═══════════════════════════════════════════════════════════════════════════════

def build_from_spec(spec: dict, client_slug: str | None = None) -> dict:
    """Validate spec, run the matching builder, write the document + a sidecar
    .spec.json for Phase 3 evaluation. Returns the deliverable-shaped dict
    matching artifact_xlsx's contract:

        {
          "ok":       True,
          "filename": "proposal-example-q2.docx",
          "path":     "clients/example/deliverables/content/...",
          "abs_path": "/home/dan/.tavernos/clients/.../content/...",
          "category": "content",
          "template": "client_proposal",
          "bytes":    12345,
          "warnings": [],  # builder-warnings from type-guards (session 3);
                           # operational_audit populates, others empty for now
        }

    `warnings` (session 3): populated by builders that opt into the type-guard
    protocol by accepting a `warnings` kwarg. Currently only
    _build_operational_audit does; client_proposal and research_report follow
    in the per-template rollout sessions.

    On validation failure, raises DocxSpecError. Callers should catch and
    return the message as a tool_result error."""
    _validate_spec(spec)
    template = spec["template"]
    builder = BUILDERS[template]
    # Default category for Woody's work is "content" (Pack 2). xlsx defaults
    # to "reports" — different deliverable class, different default.
    category = spec.get("category", "content")

    # Builders that accept a warnings list opt into the type-guard protocol.
    # Branching here (rather than try/except on TypeError) keeps the opt-in
    # explicit — adding a new gated template is a one-line change to this set.
    # Session 3: operational_audit. Session 4: client_proposal added.
    # Session 5: research_report added.
    builder_warnings: list[str] = []
    if template in ("operational_audit", "client_proposal", "research_report"):
        doc = builder(spec, builder_warnings)
    else:
        doc = builder(spec)

    final_path = _resolve_output_path(client_slug, category, spec["filename"])
    final_path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(final_path))

    # Sidecar spec for Phase 3 eval + regeneration
    spec_copy = dict(spec)
    spec_copy["_generated_at"] = datetime.now().isoformat(timespec="seconds")
    spec_path = final_path.with_suffix(".spec.json")
    spec_path.write_text(
        json.dumps(spec_copy, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    user_dir = Path.home() / ".tavernos"
    try:
        rel = final_path.relative_to(user_dir).as_posix()
    except ValueError:
        rel = final_path.as_posix()

    return {
        "ok":       True,
        "filename": final_path.name,
        "path":     rel,
        "abs_path": str(final_path),
        "category": category,
        "template": template,
        "bytes":    final_path.stat().st_size,
        "warnings": builder_warnings,
    }


# ═══════════════════════════════════════════════════════════════════════════════
#  PRE-FLIGHT — Phase 3 addition. Mirrors artifact_xlsx.preflight. Catches
#  dumb structural failures before the evaluator rubric LLM call.
# ═══════════════════════════════════════════════════════════════════════════════

def preflight(spec: dict, result: dict | None = None) -> list[str]:
    """Mechanical sanity checks for docx deliverables. Returns a list of
    issue strings, empty if all clear. Never raises.

    Shared checks:
      P1. Template key recognized
      P4. File size sanity — a docx under 5KB is likely a shell

    client_proposal checks:
      P2. client_proposal has at least one non-empty section OR meta.title
          (otherwise the doc is just a styled title bar)
      P3. Pricing section present but 'total' missing AND no rows is a
          common regen trigger — flag it
      P5. At least three sections rendered (based on spec keys present)

    operational_audit checks (Phase 4B — directly anchored in rubric):
      A2. priority_stack has at least 3 entries (rubric anchor-5: "top 3
          defensibly the biggest issues")
      A3. Every priority_stack entry has ≥ 2 evidence items (evidence_density
          has a hard floor of 3.5 — empty evidence is the single fastest
          path below threshold, so this is a hard preflight)
      A4. Every priority_stack entry with a roi_math block has all 6 core
          numeric keys populated, OR no roi_math block at all (partial ROI
          math is a regen trigger for roi_math_transparency)
      A5. executive_summary has both prose AND headline_number (exec_summary
          anchor-5: "dense, names top findings with numbers")
      A6. At least one of uncertainty_notes or assumptions has content
          (honesty_about_uncertainty anchor-5: "2+ places")
      A7. File size > 15KB — audit is 6-10 pages, a thinner file is a
          skeleton (stricter than P4's 5KB shared floor)

    research_report checks (Phase 4C — directly anchored in rubric):
      R2. key_findings has 3-5 entries (key_points_extraction anchor-5:
          "Clean numbered findings summary — 3-5 takeaways")
      R3. findings_detail non-empty AND every entry has ≥ 2
          supporting_evidence items (evidence-per-finding floor; both
          synthesis_quality and source_quality depend on this)
      R4. Every supporting_evidence item has non-empty source + publisher +
          date. Strictest gate in the module — source_quality has the only
          4.0 hard floor in any rubric; anchor-5 demands "dates and authors
          present"
      R5. executive_summary has both headline AND confidence
          (answer_to_question + uncertainty_acknowledgment anchors)
      R6. At least one of limitations or synthesis.points_of_tension has
          content (uncertainty_acknowledgment anchor-5: "uncertainty explicit")
      R7. File size > 30KB — research report is 6-10 pages like the audit"""
    issues = []
    try:
        if not isinstance(spec, dict):
            issues.append("preflight: spec is not a dict")
            return issues
        template = spec.get("template")
        if template not in BUILDERS:
            issues.append(f"preflight P1: unknown template {template!r}")

        # ── client_proposal branch ──────────────────────────────────────────
        if template == "client_proposal":
            section_keys = [k for k in ("executive_summary", "situation", "approach",
                                        "scope", "timeline", "pricing", "next_steps")
                            if k in spec]
            non_empty = [k for k in section_keys
                         if spec.get(k) not in (None, "", [], {})]
            if not non_empty and not (spec.get("meta") or {}).get("title"):
                issues.append("preflight P2: proposal has no populated sections "
                              "and no meta.title — result will be blank")
            if "pricing" in spec:
                pricing = spec.get("pricing") or {}
                if not pricing.get("rows") and not pricing.get("total"):
                    issues.append("preflight P3: pricing section present but "
                                  "both rows and total are empty")
            if len(non_empty) < 3 and non_empty:
                issues.append(f"preflight P5: only {len(non_empty)} of 7 sections "
                              f"have content — deliverable may feel thin")

        # ── operational_audit branch ────────────────────────────────────────
        if template == "operational_audit":
            priorities = spec.get("priority_stack") or []
            if len(priorities) < 3:
                issues.append(
                    f"preflight A2: priority_stack has {len(priorities)} "
                    "entries; rubric prioritization_quality anchor-5 requires "
                    "'top 3 defensibly the biggest' — need at least 3"
                )

            for idx, p in enumerate(priorities):
                ev = p.get("evidence") or []
                if len(ev) < 2:
                    wf = (p.get("workflow") or f"#{idx+1}").strip()
                    issues.append(
                        f"preflight A3: priority '{wf}' has {len(ev)} "
                        "evidence items; evidence_density hard floor is 3.5 — "
                        "every finding needs at least 2 citations"
                    )

                roi = p.get("roi_math")
                if roi is not None and isinstance(roi, dict) and roi:
                    required = {"hours_saved_week", "hours_saved_year",
                                "blended_rate_usd", "annual_value_usd",
                                "build_cost_usd", "payback_months"}
                    missing = [k for k in required
                               if roi.get(k) in (None, "")]
                    if missing:
                        wf = (p.get("workflow") or f"#{idx+1}").strip()
                        issues.append(
                            f"preflight A4: priority '{wf}' roi_math missing "
                            f"keys: {', '.join(sorted(missing))} — partial "
                            "ROI math fails roi_math_transparency"
                        )

            es = spec.get("executive_summary") or {}
            if isinstance(es, dict):
                if not (es.get("prose") or "").strip():
                    issues.append("preflight A5: executive_summary.prose missing "
                                  "or empty — exec_summary dim needs 3-5 "
                                  "narrative sentences")
                if not (es.get("headline_number") or "").strip():
                    issues.append("preflight A5: executive_summary.headline_number "
                                  "missing or empty — rubric anchor-5 requires "
                                  "'names top findings with numbers'")
            elif "executive_summary" in spec:
                issues.append("preflight A5: executive_summary must be a dict "
                              "with prose + headline_number + top_findings")

            has_uncertainty = bool(spec.get("uncertainty_notes"))
            has_assumptions = bool(spec.get("assumptions"))
            if not (has_uncertainty or has_assumptions):
                issues.append("preflight A6: neither uncertainty_notes nor "
                              "assumptions populated — honesty_about_uncertainty "
                              "anchor-5 wants both, need at least one")

            if result is not None:
                size = result.get("bytes", 0)
                if size and size < 30000:
                    issues.append(
                        f"preflight A7: audit is only {size} bytes — "
                        "expected 30KB+ for a well-formed audit (empty "
                        "docx baseline is ~37KB, so under 30KB means a "
                        "catastrophic build failure, not just a thin draft)"
                    )

        # ── research_report branch ──────────────────────────────────────────
        # Parallels the audit branch — template-specific R-prefix gates,
        # each anchored to a rubric dimension. R4 is the strictest because
        # source_quality is the only 4.0 hard-floor dimension in any rubric.
        if template == "research_report":
            # R2: key_findings has 3-5 entries (key_points_extraction
            # anchor-5: "Clean numbered findings summary — 3-5 takeaways")
            key_findings = spec.get("key_findings") or []
            if len(key_findings) < 3 or len(key_findings) > 5:
                issues.append(
                    f"preflight R2: key_findings has {len(key_findings)} "
                    "entries; rubric key_points_extraction anchor-5 requires "
                    "3-5 numbered takeaways"
                )

            # R3: findings_detail non-empty AND every entry has ≥ 2
            # supporting_evidence items (evidence-per-finding floor —
            # synthesis_quality and source_quality both depend on this)
            details = spec.get("findings_detail") or []
            if "findings_detail" in spec and not details:
                issues.append(
                    "preflight R3: findings_detail is empty — rubric "
                    "synthesis_quality and source_quality both need "
                    "per-finding evidence; need at least 3 detailed findings"
                )
            for idx, d in enumerate(details):
                ev = d.get("supporting_evidence") or []
                ref = d.get("finding_ref", idx + 1)
                if len(ev) < 2:
                    issues.append(
                        f"preflight R3: findings_detail '{ref}' has "
                        f"{len(ev)} supporting_evidence items; "
                        "synthesis_quality and source_quality both want >=2 "
                        "citations per finding"
                    )

            # R4: every supporting_evidence item has non-empty source,
            # publisher, AND date. This is the source_quality 4.0 hard-floor
            # gate — the single strictest preflight in the whole module,
            # because source_quality is the only dimension with a 4.0 floor
            # (not 3.5 like evidence_density). Anchor-5 demands "dates and
            # authors present" — if any citation is missing its date or
            # publisher, the rubric scorer will notch the dim below 4.0
            # and the weighted avg fails via the hard-floor mechanic.
            for idx, d in enumerate(details):
                ev_list = d.get("supporting_evidence") or []
                ref = d.get("finding_ref", idx + 1)
                for ev_idx, ev in enumerate(ev_list):
                    if not isinstance(ev, dict):
                        issues.append(
                            f"preflight R4: findings_detail '{ref}' "
                            f"evidence #{ev_idx+1} is not a structured "
                            "citation — source_quality 4.0 hard floor "
                            "requires source+publisher+date per citation"
                        )
                        continue
                    missing = [k for k in ("source", "publisher", "date")
                               if not (ev.get(k) or "").strip()]
                    if missing:
                        issues.append(
                            f"preflight R4: findings_detail '{ref}' "
                            f"evidence #{ev_idx+1} missing "
                            f"{', '.join(missing)} — source_quality has a "
                            "4.0 hard floor; anchor-5 demands 'dates and "
                            "authors present'"
                        )

            # R5: executive_summary has both headline AND confidence
            # (answer_to_question anchor-5 + uncertainty_acknowledgment
            # anchor-5: "confidence levels stated")
            es = spec.get("executive_summary") or {}
            if isinstance(es, dict):
                if not (es.get("headline") or "").strip():
                    issues.append(
                        "preflight R5: executive_summary.headline missing "
                        "or empty — answer_to_question anchor-5 wants a "
                        "direct one-sentence answer to the research question"
                    )
                if not (es.get("confidence") or "").strip():
                    issues.append(
                        "preflight R5: executive_summary.confidence missing "
                        "or empty — uncertainty_acknowledgment anchor-5 "
                        "requires 'confidence levels stated'"
                    )
            elif "executive_summary" in spec:
                issues.append(
                    "preflight R5: executive_summary for research_report "
                    "must be a dict with headline + confidence + context; "
                    "string-form exec summary is only valid for client_proposal"
                )

            # R6: at least one of limitations or synthesis.points_of_tension
            # has content (uncertainty_acknowledgment anchor-5:
            # "uncertainty explicit" — can be via named limits OR via
            # surfaced source disagreements)
            has_limitations = bool(spec.get("limitations"))
            synthesis = spec.get("synthesis") or {}
            has_tension = (
                isinstance(synthesis, dict)
                and bool(synthesis.get("points_of_tension"))
            )
            if not (has_limitations or has_tension):
                issues.append(
                    "preflight R6: neither limitations nor "
                    "synthesis.points_of_tension populated — "
                    "uncertainty_acknowledgment anchor-5 wants uncertainty "
                    "explicit; need at least one"
                )

            # R7: file size > 30KB — research report is 6-10 pages like the
            # audit, same floor applies
            if result is not None:
                size = result.get("bytes", 0)
                if size and size < 30000:
                    issues.append(
                        f"preflight R7: research_report is only {size} "
                        "bytes — expected 30KB+ for a 6-10 page report "
                        "(empty docx baseline is ~37KB, so under 30KB "
                        "means a catastrophic build failure, not a thin draft)"
                    )

        # Shared size check (lower floor than A7/R7 — catches total failures).
        if result is not None:
            if result.get("bytes", 0) < 5000:
                issues.append(f"preflight P4: docx is only {result.get('bytes', 0)} "
                              "bytes — likely a shell")
    except Exception as e:
        issues.append(f"preflight crashed: {type(e).__name__}: {e}")
    return issues


# ═══════════════════════════════════════════════════════════════════════════════
#  RUBRIC-CRITICAL PREFLIGHT GATE (Goal A Layer 1 — session 2, Apr 23 2026)
# ═══════════════════════════════════════════════════════════════════════════════
#  _tool_handler consults this gate before calling build_from_spec. When a
#  spec fails rubric-critical preflight checks for its template, the handler
#  returns a REJECTED_SENTINEL-prefixed message instead of building. norm.py's
#  dispatcher detects the sentinel and surfaces the result as is_error=True
#  so the agent can retry with a complete spec.
#
#  Only operational_audit is gated in this iteration. client_proposal (P-prefix)
#  and research_report (R-prefix) follow in session 3 once the pattern is
#  validated on Lilith.
#
#  Rubric-critical preflight prefixes map to evaluator.RUBRIC_OPERATIONAL_AUDIT
#  dimensions (weights total 0.85 of the rubric):
#    A2 → prioritization_quality    (0.20)
#    A3 → evidence_density          (0.30, hard floor 3.5)
#    A4 → roi_math_transparency     (0.20)
#    A5 → exec_summary              (0.10)
#    A6 → honesty_about_uncertainty (0.05)
#
#  A7 (file-size) is intentionally NOT gated here — it fires only after build
#  and this gate runs pre-build. Post-build quality checks remain the
#  post-save evaluator's job per its non-blocking contract.
#
#  Known gap accepted for this iteration: A4 is conditional — it only fires
#  when roi_math is present-but-partial. A stub with no roi_math block at all
#  passes A4 but still fails the spirit of roi_math_transparency. Closing
#  that gap needs a new "A4b: priority entries expected to include roi_math"
#  check; session 3 backlog.
# ─────────────────────────────────────────────────────────────────────────────

REJECTED_SENTINEL = "__TAVERNOS_REJECTED__"

_RUBRIC_CRITICAL_PREFLIGHT: dict[str, tuple[str, ...]] = {
    "operational_audit": (
        "preflight A2",
        "preflight A3",
        "preflight A4",
        "preflight A5",
        "preflight A6",
    ),
    # Session 4: client_proposal gate set.
    #   P2 — no populated sections AND no meta.title (document-level
    #        invariant; a blank doc can't be scored on any dimension).
    #   P3 — pricing section present but both rows and total empty
    #        (direct mapping to pricing_transparency dim, weight 0.15,
    #        regen_trigger "Regenerate with specific prices, payment
    #        terms, and inclusion/exclusion list. No 'contact us'.").
    #   P5 — fewer than 3 of 7 sections populated (thinness proxy;
    #        specificity (0.25), problem_framing (0.20), scope_clarity
    #        (0.20) all need content to clear anchor-1).
    #   P1 and P4 excluded: P1 is infrastructure (raises DocxSpecError
    #   upstream anyway); P4 is a post-build result check, not a
    #   preflight-time gate.
    "client_proposal": (
        "preflight P2",
        "preflight P3",
        "preflight P5",
    ),
    # Session 5: research_report gate set.
    #   R2 — key_findings count outside 3-5 (key_points_extraction dim,
    #        weight 0.15, regen_trigger "Regenerate with a numbered
    #        findings summary at the top — 3-5 takeaways that stand alone").
    #   R3 — findings_detail missing or any entry with <2 supporting_evidence
    #        items (maps to BOTH synthesis_quality (0.25, regen) AND
    #        source_quality (0.25, regen, 4.0 HARD FLOOR) — strongest
    #        rubric-weight concentration of any single R-check).
    #   R4 — any supporting_evidence item missing source, publisher, OR date
    #        (source_quality 4.0 hard-floor gate — THE strictest preflight
    #        in the module; source_quality is the only dimension in any
    #        rubric with a 4.0 hard floor, so a partial citation sinks the
    #        whole evaluation via hard-floor mechanics regardless of
    #        weighted average).
    #   R5 — executive_summary missing headline OR confidence
    #        (answer_to_question 0.20 regen + uncertainty_acknowledgment
    #        0.10).
    #   R6 — neither limitations nor synthesis.points_of_tension populated
    #        (uncertainty_acknowledgment anchor-5 — parallels A6 inclusion
    #        logic from session 2; structural minimum, no regen trigger
    #        on the dim itself but the check is a direct rubric anchor).
    #   R1 does not exist as its own check — shared P1 covers template
    #   recognition for all templates. R7 excluded — post-build file-size
    #   result check, not a preflight-time gate (same exclusion logic as
    #   A7 and P4).
    "research_report": (
        "preflight R2",
        "preflight R3",
        "preflight R4",
        "preflight R5",
        "preflight R6",
    ),
}

_REQUIRED_SECTION_HINTS: dict[str, tuple[str, ...]] = {
    "operational_audit": (
        "executive_summary: {prose (3-5 sentences), headline_number, top_findings}",
        "priority_stack: at least 3 entries, each with workflow, "
        "evidence (>= 2 items), recommendation, and roi_math "
        "(all 6 numeric keys populated)",
        "uncertainty_notes or assumptions: at least one populated",
    ),
    "client_proposal": (
        "meta.title: proposal title",
        "executive_summary: 1-3 paragraphs of prose",
        "situation: 1-3 paragraphs framing the prospect's problem in their voice",
        "approach: list of phases, each with {phase, detail}",
        "scope: {in_scope: [...], out_of_scope: [...]} — named artifacts, "
        "not service categories",
        "timeline: rows with {phase, duration, deliverables}",
        "pricing: {rows: [{item, amount, notes}], total} — concrete "
        "numbers, no 'contact us for pricing'",
        "next_steps: one concrete action the prospect can reply yes to",
        "At least 3 of the 7 section keys must have content for the "
        "proposal to not feel thin (pricing counts as content only if "
        "rows or total is populated).",
    ),
    "research_report": (
        "key_findings: 3-5 entries, each with {finding, confidence, so_what} — "
        "this is the numbered summary up top that stands alone",
        "executive_summary: {headline (one-sentence direct answer), "
        "confidence (high/moderate/low + one-line reasoning), context}",
        "findings_detail: list of entries, each with {finding_ref, analysis, "
        "supporting_evidence: [>= 2 citations]}",
        "supporting_evidence items: each {source, publisher, date} must be "
        "populated — source_quality has a 4.0 hard floor in the rubric, "
        "this is the single strictest requirement in the module",
        "limitations OR synthesis.points_of_tension: at least one populated "
        "(uncertainty must be visible somewhere)",
    ),
}


def _rubric_critical_issues(spec: Any) -> list[str]:
    """Filter preflight issues down to the template's rubric-critical set.
    Returns [] when the spec is non-gated, has no critical issues, or when
    preflight itself would not run (non-dict spec, unknown template).
    Never raises — preflight() itself has the same contract."""
    if not isinstance(spec, dict):
        return []
    template = spec.get("template")
    prefixes = _RUBRIC_CRITICAL_PREFLIGHT.get(template)
    if not prefixes:
        return []
    try:
        issues = preflight(spec)
    except Exception:
        # Defensive — preflight() is documented as never-raises, but if a
        # future addition breaks that we'd rather fall through to the
        # builder's own validation than wedge the gate permanently.
        return []
    return [i for i in issues if i.startswith(prefixes)]


def _format_rejection_message(template: str, critical_issues: list[str]) -> str:
    """Structured retry guidance surfaced to the agent as is_error=True.

    Three design choices:
      1. Reuse preflight() issue strings verbatim — they're already
         rubric-anchored and specific; paraphrasing would lose that.
      2. Name what's needed (required_sections), not only what's missing.
         Agents retry better with an explicit target state.
      3. End with "don't restart, just extend" — session-1 failure mode
         included agents re-classifying rather than extending on retry."""
    required_sections = _REQUIRED_SECTION_HINTS.get(template, ())
    lines = [
        REJECTED_SENTINEL,
        f"Spec rejected — {template} cannot be saved with rubric-critical",
        "sections missing. The following preflight checks failed:",
        "",
    ]
    lines.extend(f"  - {i}" for i in critical_issues)
    lines.append("")
    lines.append(
        f"Retry by calling {TOOL_NAME} again with a complete spec. "
        f"Required sections for {template}:"
    )
    lines.extend(f"  - {hint}" for hint in required_sections)
    lines.append("")
    lines.append(
        "The sections you already drafted do not need to be thrown away — "
        "extend your spec with the missing sections and call the tool again."
    )
    return "\n".join(lines)


def _format_bypass_warning_lines(critical_issues: list[str]) -> list[str]:
    """Warning lines prepended to a successful save when the gate is
    bypassed after N rejections. The file still saves (honoring the
    post-save evaluator's 'scores are signals, not verdicts' contract)
    but the agent — and the post-save evaluator — see that critical
    issues remained unresolved."""
    out = [
        "Preflight gate bypassed after repeated rejections. The deliverable",
        "was saved but the following rubric-critical issues remain and will",
        "be graded by the post-save evaluator:",
    ]
    out.extend(f"  - {i}" for i in critical_issues)
    out.append("")
    return out


def _format_builder_warning_lines(builder_warnings: list[str]) -> list[str]:
    """Warning lines prepended to a successful save when the builder type-
    guards had to coerce wrong-typed spec fields. Parallel to
    _format_bypass_warning_lines but fires on the build-time channel rather
    than the preflight channel — bypass-warnings describe what preflight
    caught, builder-warnings describe what the builder caught that preflight
    didn't (or couldn't, if preflight itself crashed silently on the same
    bad types).

    Placed BETWEEN the bypass-warning block (if any) and the "Document
    saved." trailer in _tool_handler's output. The agent reads top-down,
    so bypass→builder ordering matches chronological order: preflight-time
    issues first, build-time issues second."""
    out = [
        "The following fields in the spec were malformed and rendered as",
        "TBD placeholders; the deliverable saved but these fields need",
        "corrected types on the next call to replace the placeholders:",
    ]
    out.extend(f"  - {w}" for w in builder_warnings)
    out.append("")
    return out


# ═══════════════════════════════════════════════════════════════════════════════
#  TOOL REGISTRATION — the Anthropic tool schema + handler surface that
#  norm.py picks up via get_tool_registration().
# ═══════════════════════════════════════════════════════════════════════════════

TOOL_NAME = "generate_docx_report"
ALLOWED_AGENTS = {"woody", "lilith", "cliff"}

TOOL_SCHEMA = {
    "name": TOOL_NAME,
    "description": (
        "Generate a branded Microsoft Word (.docx) deliverable — proposals, "
        "briefs, operational audits, research reports, one-pagers — saved "
        "into the active client's workspace. Use this when the user asks "
        "for any substantive written deliverable that would normally be a "
        "Word document. All sections are optional: when the user has not "
        "supplied the material for a section (per the grounding discipline "
        "in the system prompt), OMIT the section from the spec rather than "
        "fabricating content. The builder renders a clean [TBD — ...] "
        "placeholder only when a section key is present with empty content — "
        "for BOUND-path output, you can pass empty strings/arrays for "
        "sections the user genuinely asked about but didn't supply material "
        "for. Select the `template` field based on your role: Woody uses "
        "`client_proposal`, Lilith uses `operational_audit`, Cliff uses "
        "`research_report`."
    ),
    "input_schema": {
        "type": "object",
        "required": ["artifact", "template", "filename"],
        "properties": {
            "artifact": {
                "type": "string",
                "enum": ["docx"],
                "description": "Must be 'docx'.",
            },
            "template": {
                "type": "string",
                "enum": list(BUILDERS.keys()),
                "description": (
                    "Template key. Ships with 'client_proposal' (Woody), "
                    "'operational_audit' (Lilith), and 'research_report' "
                    "(Cliff). Additional templates may be registered — "
                    "check this enum list."
                ),
            },
            "filename": {
                "type": "string",
                "description": (
                    "Kebab-case filename. The .docx extension is added "
                    "automatically if omitted."
                ),
            },
            "category": {
                "type": "string",
                "enum": ["content", "reports", "audits", "blueprints"],
                "description": (
                    "Which deliverables subfolder to write into. Defaults "
                    "to 'content' for Woody's output; set to 'audits' for "
                    "Lilith's operational_audit output; set to 'reports' "
                    "for Cliff's research_report output."
                ),
            },
            "meta": {
                "type": "object",
                "properties": {
                    "title":       {"type": "string"},
                    "client_name": {"type": "string"},
                    "prepared_by": {"type": "string"},
                    "date":        {"type": "string"},
                },
            },

            # ── client_proposal fields ──────────────────────────────────────
            # `executive_summary` is used by all three templates with different
            # shapes: proposal = string prose, audit = object with prose +
            # headline_number + top_findings, research = object with headline
            # + confidence + context. oneOf dispatches on shape; the builder
            # pulls the right keys for its template.
            "executive_summary": {
                "oneOf": [
                    {"type": "string"},
                    {
                        "type": "object",
                        "properties": {
                            "prose":           {"type": "string"},
                            "headline_number": {"type": "string"},
                            "top_findings": {
                                "type": "array",
                                "items": {"type": "string"},
                            },
                        },
                    },
                    {
                        "type": "object",
                        "properties": {
                            "headline":   {"type": "string"},
                            "confidence": {"type": "string"},
                            "context":    {"type": "string"},
                        },
                    },
                ],
                "description": (
                    "For client_proposal: string prose. For "
                    "operational_audit: object with prose (3-5 sentences), "
                    "headline_number (single-sentence number-anchored "
                    "diagnosis), and top_findings (3 bullets, each naming "
                    "a number). For research_report: object with headline "
                    "(one-sentence direct answer to the research question), "
                    "confidence (high/moderate/low with reasoning), and "
                    "context (1-2 sentences framing why this matters)."
                ),
            },
            "situation":         {"type": "string"},
            "approach": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "phase":  {"type": "string"},
                        "detail": {"type": "string"},
                    },
                },
            },
            "scope": {
                "type": "object",
                "properties": {
                    "in_scope":     {"type": "array", "items": {"type": "string"}},
                    "out_of_scope": {"type": "array", "items": {"type": "string"}},
                },
            },
            "timeline": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "phase":        {"type": "string"},
                        "duration":     {"type": "string"},
                        "deliverables": {"type": "string"},
                    },
                },
            },
            "pricing": {
                "type": "object",
                "properties": {
                    "rows": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "item":   {"type": "string"},
                                "amount": {"type": "string"},
                                "notes":  {"type": "string"},
                            },
                        },
                    },
                    "total": {"type": "string"},
                },
            },
            "next_steps": {
                "type": "array",
                "items": {"type": "string"},
            },

            # ── operational_audit fields ────────────────────────────────────
            "diagnosis": {
                "type": "string",
                "description": (
                    "One-page narrative: what kind of business this is "
                    "operationally, healthy vs brittle patterns. Paragraphs "
                    "separated by blank lines."
                ),
            },
            "priority_stack": {
                "type": "array",
                "description": (
                    "Ranked list of 3-5 priority workflows. Each entry "
                    "needs evidence (≥2 citations) + ROI math or the "
                    "deliverable will fail evidence_density hard floor."
                ),
                "items": {
                    "type": "object",
                    "properties": {
                        "rank":                {"type": "integer"},
                        "workflow":            {"type": "string"},
                        "hours_per_week_lost": {"type": "string"},
                        "who_feels_it":        {"type": "string"},
                        "root_cause":          {"type": "string"},
                        "current_state":       {"type": "string"},
                        "proposed_system":     {"type": "string"},
                        "evidence": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "source": {"type": "string"},
                                    "detail": {"type": "string"},
                                },
                            },
                        },
                        "roi_math": {
                            "type": "object",
                            "properties": {
                                "hours_saved_week":  {"type": "number"},
                                "hours_saved_year":  {"type": "number"},
                                "blended_rate_usd":  {"type": "number"},
                                "annual_value_usd":  {"type": "number"},
                                "build_cost_usd":    {"type": "number"},
                                "payback_months":    {"type": "number"},
                                "rate_methodology":  {"type": "string"},
                            },
                        },
                        "build_effort":         {"type": "string"},
                        "risks":                {"type": "array",
                                                 "items": {"type": "string"}},
                        "success_signal_30d":   {"type": "string"},
                    },
                },
            },
            "build_sequence": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "weeks":         {"type": "string"},
                        "priority_rank": {"type": "integer"},
                        "rationale":     {"type": "string"},
                    },
                },
            },
            "build_sequence_rationale": {"type": "string"},
            "month_1_plan": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "week":               {"type": ["integer", "string"]},
                        "focus":              {"type": "string"},
                        "deliverable":        {"type": "string"},
                        "client_involvement": {"type": "string"},
                    },
                },
            },
            "not_in_scope":      {"type": "string"},
            "uncertainty_notes": {"type": "array", "items": {"type": "string"}},
            "assumptions":       {"type": "array", "items": {"type": "string"}},
            "next_step":         {"type": "string"},

            # ── research_report fields ──────────────────────────────────────
            # All unique to research_report — no collisions with proposal or
            # audit keys. Shape parallels audit: a couple of structured
            # arrays (key_findings, findings_detail, sources_consulted) do
            # the heavy lifting, a synthesis object holds the cross-source
            # story, and string fields bookend (question + methodology).
            "research_question": {
                "type": "string",
                "description": (
                    "The single question this report answers. State it "
                    "plainly — one sentence. Answers to this question "
                    "should be findable in executive_summary.headline."
                ),
            },
            "key_findings": {
                "type": "array",
                "description": (
                    "3-5 numbered findings (preflight R2 enforces the count). "
                    "Each entry is the headline claim + confidence level + "
                    "one-line implication. This is the 'stand-alone summary' "
                    "a reader can pull out of the report and use anywhere."
                ),
                "items": {
                    "type": "object",
                    "properties": {
                        "finding": {
                            "type": "string",
                            "description": "The claim, ideally with a number.",
                        },
                        "confidence": {
                            "type": "string",
                            "enum": ["high", "moderate", "low"],
                            "description": (
                                "Confidence level for this specific finding. "
                                "Per-finding confidence is the structural "
                                "signal for uncertainty_acknowledgment."
                            ),
                        },
                        "so_what": {
                            "type": "string",
                            "description": (
                                "One-line implication for the client — why "
                                "this finding matters to them specifically."
                            ),
                        },
                    },
                },
            },
            "synthesis": {
                "type": "object",
                "description": (
                    "Cross-source synthesis. narrative is required for "
                    "synthesis_quality >= 4. points_of_tension is where "
                    "sources disagree — the anchor-5 slot of the rubric "
                    "('conflicts named and resolved'). Serial summaries "
                    "without this block score 3, not 5."
                ),
                "properties": {
                    "narrative": {
                        "type": "string",
                        "description": (
                            "2-4 paragraphs connecting sources into one "
                            "story. Synthesize — don't summarize serially."
                        ),
                    },
                    "points_of_agreement": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": (
                            "Bulleted list of convergence points across "
                            "sources."
                        ),
                    },
                    "points_of_tension": {
                        "type": "array",
                        "description": (
                            "Each entry is a source disagreement with the "
                            "author's read on who's probably right. This is "
                            "the mechanical anchor for synthesis_quality "
                            "anchor-5."
                        ),
                        "items": {
                            "type": "object",
                            "properties": {
                                "topic":          {"type": "string"},
                                "source_a_says":  {"type": "string"},
                                "source_b_says":  {"type": "string"},
                                "our_read":       {"type": "string"},
                            },
                        },
                    },
                },
            },
            "findings_detail": {
                "type": "array",
                "description": (
                    "Per-finding deep-dive. One entry per key_finding "
                    "(preflight R3 requires >=3 total and >=2 citations "
                    "per entry). Every supporting_evidence item MUST have "
                    "source + publisher + date populated (preflight R4 — "
                    "source_quality has a 4.0 hard floor, strictest gate "
                    "in the module)."
                ),
                "items": {
                    "type": "object",
                    "properties": {
                        "finding_ref": {
                            "type": ["integer", "string"],
                            "description": (
                                "Which key_finding this elaborates. Integer "
                                "(1-5) refers to key_findings index; string "
                                "is a short title."
                            ),
                        },
                        "analysis": {
                            "type": "string",
                            "description": "Paragraphs of analysis.",
                        },
                        "supporting_evidence": {
                            "type": "array",
                            "description": (
                                ">=2 citations per finding. EVERY citation "
                                "needs source + publisher + date — this is "
                                "the source_quality hard-floor gate."
                            ),
                            "items": {
                                "type": "object",
                                "properties": {
                                    "source":    {"type": "string"},
                                    "publisher": {"type": "string"},
                                    "date":      {"type": "string"},
                                    "detail":    {"type": "string"},
                                    "url":       {"type": "string"},
                                },
                            },
                        },
                    },
                },
            },
            "limitations": {
                "type": "array",
                "items": {"type": "string"},
                "description": (
                    "Where data was thin, what this research could not "
                    "determine. >=1 entry required by preflight R6 unless "
                    "synthesis.points_of_tension is populated."
                ),
            },
            "recommendations": {
                "type": "array",
                "items": {"type": "string"},
                "description": (
                    "Optional — what to do with this research. Cliff's "
                    "persona is 'research, not prescription' so this "
                    "section is genuinely optional; skip when the research "
                    "is decision-support rather than directive."
                ),
            },
            "sources_consulted": {
                "type": "array",
                "description": (
                    "Reference list — full citation per source. Required "
                    "fields per entry: title, publisher, date. The trailing "
                    "list makes attribution mechanically visible for "
                    "source_quality anchor-5 ('all attributed')."
                ),
                "items": {
                    "type": "object",
                    "properties": {
                        "title":     {"type": "string"},
                        "author":    {"type": "string"},
                        "publisher": {"type": "string"},
                        "date":      {"type": "string"},
                        "url":       {"type": "string"},
                        "notes":     {"type": "string"},
                    },
                },
            },
            "methodology_note": {
                "type": "string",
                "description": (
                    "One paragraph on how this research was done — search "
                    "strategy, inclusion criteria, date range. Signals "
                    "method over vibes; feeds formatting_for_reuse."
                ),
            },
        },
    },
}


def get_tool_registration() -> dict:
    """Return the dict norm.py registers into its first-party tool registry."""
    return {
        "name":           TOOL_NAME,
        "schema":         TOOL_SCHEMA,
        "allowed_agents": ALLOWED_AGENTS,
        "handler":        _tool_handler,
    }


def _tool_handler(tool_args: dict, agent_name: str,
                  client_slug: str | None,
                  skip_preflight_gate: bool = False) -> str:
    """Tool dispatcher. Returns a plain-text tool_result payload.

    Success paths start with the __TAVERNOS_DELIVERABLE__ sentinel line that
    norm.py's dispatcher parses + strips before passing the rest back to the
    agent. Rubric-critical rejections start with __TAVERNOS_REJECTED__; the
    dispatcher surfaces those as is_error=True tool_results so the agent can
    retry with a complete spec.

    skip_preflight_gate
        When True, the rubric-critical gate is bypassed and the deliverable
        saves even with critical issues present. The returned text includes a
        warning preamble listing the unresolved issues. The tool-use loop in
        norm.py sets this flag after N=2 rejections to prevent runaway retry
        loops; the post-save evaluator then picks up whatever quality issues
        remain (matching the rubric philosophy 'scores are signals, not
        verdicts')."""
    # ── Rubric-critical preflight gate ──────────────────────────────────────
    # Runs before build_from_spec so an incomplete spec never writes a stub
    # file. See the RUBRIC-CRITICAL PREFLIGHT GATE section above for scope
    # and rubric-weight mapping.
    critical = _rubric_critical_issues(tool_args)
    if critical and not skip_preflight_gate:
        template = (tool_args or {}).get("template", "") if isinstance(tool_args, dict) else ""
        return _format_rejection_message(template, critical)

    try:
        result = build_from_spec(tool_args, client_slug=client_slug)
    except DocxSpecError as e:
        return f"Spec error: {e}"
    except Exception as e:
        return (
            "Unexpected error while generating document: "
            f"{type(e).__name__}: {e}\n"
            + traceback.format_exc(limit=3)
        )

    lines = [
        # Sentinel — shared contract with artifact_xlsx; norm.py's dispatcher
        # parses the tab-delimited header for the "✓ Deliverable saved" banner.
        # Format: __TAVERNOS_DELIVERABLE__\t<filename>\t<path>\t<bytes>
        f"__TAVERNOS_DELIVERABLE__\t{result['filename']}\t{result['path']}"
        f"\t{result['bytes']}",
    ]
    # Bypass-mode preamble — gate was skipped but issues were present. The
    # agent sees the warning before the success banner so it knows the save
    # succeeded despite rubric-critical gaps.
    if critical and skip_preflight_gate:
        lines.extend(_format_bypass_warning_lines(critical))
    # Builder-warning preamble — type-guards fired on malformed subfields.
    # Surfaces via result["warnings"] (populated by build_from_spec for
    # opt-in templates; currently only operational_audit). Placed AFTER
    # bypass-warnings so preflight-channel signal reads first, builder-
    # channel signal reads second — matches chronological order.
    builder_warnings = result.get("warnings") or []
    if builder_warnings:
        lines.extend(_format_builder_warning_lines(builder_warnings))
    lines.extend([
        "Document saved.",
        f"Filename: {result['filename']}",
        f"Path:     {result['path']}",
        f"Template: {result['template']}",
        f"Size:     {result['bytes']} bytes",
    ])
    return "\n".join(lines)