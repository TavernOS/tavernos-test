# diagnose-sanitize.ps1
# Confirms the 6 Step 1 patches actually applied (ignoring the misleading messages)
# AND shows the context around the 4 new Brightwave leaks.
# ASCII-only, PowerShell 5 compatible.

$ErrorActionPreference = "Continue"
$repo = "C:\TavernOS\tavernos"
Set-Location $repo

function Show-Lines {
    param([string]$Path, [int]$From, [int]$To, [string]$Label)
    Write-Host ""
    Write-Host ("=== " + $Label + " ===") -ForegroundColor Cyan
    if (-not (Test-Path $Path)) { Write-Host "  (file not found)" -ForegroundColor Yellow; return }
    $lines = Get-Content $Path -Encoding UTF8
    $max = $lines.Count - 1
    $a = [Math]::Max(0, $From - 1)
    $b = [Math]::Min($max, $To - 1)
    for ($i = $a; $i -le $b; $i++) {
        Write-Host (("{0,5}: " -f ($i + 1)) + $lines[$i])
    }
}

Write-Host "=== PART A: Confirm Step 1 patches actually applied ===" -ForegroundColor Green

# norm.py: should show 'proposal-northstar-q2.md', NOT 'proposal-hypothetica-q2.md'
Show-Lines -Path "$repo\norm.py" -From 3328 -To 3335 -Label "norm.py around line 3331 (expect 'northstar')"

# rebecca skill: should show 'example-mbr' and 'Example Client'
Show-Lines -Path "$repo\skills\rebecca-monthly-business-review.skill.md" -From 33 -To 45 -Label "rebecca skill around lines 37/40 (expect 'example-mbr' and 'Example Client')"

# lead-intel skill: should show 'Alex Rivera' and 'Example Co.'
Show-Lines -Path "$repo\skills\lead-intel-weekly-batch.skill.md" -From 155 -To 165 -Label "lead-intel-weekly-batch around line 160 (expect 'Alex Rivera' and 'Example Co.')"

# handover skill: should show '@alex'
Show-Lines -Path "$repo\skills\internal-ops-handover.skill.md" -From 82 -To 90 -Label "handover around line 86 (expect '@alex')"


Write-Host ""
Write-Host "=== PART B: Context around the 4 new Brightwave leaks ===" -ForegroundColor Green

Show-Lines -Path "$repo\skills\internal-ops-monthly-report.skill.md" -From 195 -To 215 -Label "internal-ops-monthly-report around line 207"
Show-Lines -Path "$repo\skills\lead-intel-approval.skill.md"        -From 50  -To 70  -Label "lead-intel-approval around line 60"
Show-Lines -Path "$repo\skills\proposal-writer.skill.md"            -From 210 -To 230 -Label "proposal-writer around line 219"
Show-Lines -Path "$repo\skills\support-monthly-report.skill.md"     -From 175 -To 200 -Label "support-monthly-report around line 188"


Write-Host ""
Write-Host "=== PART C: Broader leak scan (more patterns) ===" -ForegroundColor Green
Write-Host "Looking for any other fictional-client leaks I might have missed..."

$broadPatterns = @(
    'hypothetica','brightwave','zephyr','foldco',
    'maya chen','maya rodriguez','jamie patel','meridian',
    'maria','sarah','dan cobb','dan cooper','danco',
    'hubspot','calendly','arkansas'
)

$hits = Get-ChildItem -Path agents,skills -Recurse -Include *.json,*.md,*.txt,*.py -ErrorAction SilentlyContinue |
    Select-String -Pattern $broadPatterns
if ($hits) {
    Write-Host ("  " + $hits.Count + " hits across agents/ and skills/:") -ForegroundColor Yellow
    $hits | ForEach-Object {
        $rel = $_.Path.Replace($repo + '\', '')
        $line = $_.Line.Trim()
        if ($line.Length -gt 140) { $line = $line.Substring(0, 137) + "..." }
        Write-Host ("  " + $rel + ":" + $_.LineNumber + "  " + $line)
    }
} else {
    Write-Host "  no hits" -ForegroundColor Green
}

Write-Host ""
Write-Host "=== DONE ===" -ForegroundColor Cyan
Write-Host "Paste this whole output back and I will write the final sanitize patch."
