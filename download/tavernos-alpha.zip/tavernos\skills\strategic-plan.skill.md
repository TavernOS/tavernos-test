---
name: Strategic Plan
agent: frasier
description: Builds strategic plans, frameworks, and structured thinking documents. Use when user mentions "strategy", "strategic plan", "how should we approach", "framework", "roadmap", or "big picture thinking".
triggers:
  - strategy
  - strategic plan
  - how should we approach
  - framework
  - roadmap
  - big picture
  - long term plan
  - go to market
  - positioning
chaining: true
version: 1.0.0
---

# Strategic Plan

## Output structure
1. **Situation assessment** — where we are now, what's true about the landscape
2. **Strategic question** — the core decision being addressed
3. **Options considered** — at least 3 approaches with pros/cons
4. **Recommended approach** — which option and why, clearly stated
5. **Key assumptions** — what must be true for this to work
6. **Risks and mitigations** — top 3 risks, one mitigation each
7. **Success metrics** — how we'll know it's working
8. **Phased roadmap** — what happens in 30/90/180 days
9. **Open questions** — what needs resolution before committing

## Frameworks applied as appropriate
- SWOT for situation assessment
- Jobs-to-be-done for customer strategy
- Porter's Five Forces for competitive analysis
- OKRs for goal-setting
- First principles for problem decomposition

## Guidelines
- Name the framework being used
- Challenge the premise if the question being asked is the wrong one
- Always present tradeoffs — strategy is about choices
- Never recommend "do all of the above"
- Chain to Cliff for research support
- Chain to Rebecca to visualize or present the strategy
- Chain to Woody for strategic narrative writing
