"""Hypothetica Co. — shared fictional prospect profile.

One fictional company, three deliverables. If the deliverables feel like
they're about different companies, that's a fabrication signal worth logging.

Discovery-call grounding: 30-min intro call with Maya Chen, COO, Thursday
April 16 2026. Maya volunteered three specific pain quotes that every
deliverable should reference — if Woody's proposal or Rebecca's deck
paraphrase them instead of quoting verbatim, that's a specificity regression.

All financials and dates are fictional. Numbers are internally consistent
across the three files (March variance narrative is the throughline).
"""

HYPOTHETICA = {
    "company":   "Hypothetica Co.",
    "industry":  "B2B SaaS — project management for creative agencies",
    "stage":     "Series A (closed Jul 2024)",
    "headcount": 42,
    "arr":       "$4.2M",
    "contact": {
        "name":  "Maya Chen",
        "title": "Chief Operating Officer",
        "email": "maya@hypothetica.example",
        "tenure": "6 months in role (joined Oct 2025)",
        "background": "ex-McKinsey (2019–2024, Boston office), previously Director of Ops at Foldco",
    },
    "discovery_call": {
        "date":    "Thursday, April 16, 2026",
        "length":  "30 minutes",
        "setting": "intro call from warm intro by Jamie Patel (Series A lead at Meridian Ventures)",
    },
    # Three quotes from Maya, verbatim. Every deliverable must reference at
    # least one of these by name, not a paraphrase.
    "pain_quotes": [
        "We spend the first hour of every monthly ops review arguing about which number is right.",
        "I have six dashboards and still can't tell you whether we're on plan this month.",
        "Our CS team is eight days behind on support tickets and I don't have a number for whether that's getting worse.",
    ],
    # Q1 2026 financials — used by the xlsx MBR. Numbers chosen so March
    # misses plan by a visible margin — that's the narrative hook.
    "q1_2026_financials": {
        "revenue": [
            {"month": "Jan 2026", "actual": 310000, "plan": 300000},
            {"month": "Feb 2026", "actual": 325000, "plan": 320000},
            {"month": "Mar 2026", "actual": 305000, "plan": 340000},
        ],
        "costs": [
            # OpEx is flat-ish; COGS scales with revenue; March plan assumed
            # higher COGS because plan expected higher revenue.
            {"month": "Jan 2026", "cogs": 108000, "opex": 175000,
             "plan_cogs": 105000, "plan_opex": 175000},
            {"month": "Feb 2026", "cogs": 113000, "opex": 178000,
             "plan_cogs": 112000, "plan_opex": 175000},
            {"month": "Mar 2026", "cogs": 107000, "opex": 182000,
             "plan_cogs": 119000, "plan_opex": 175000},
        ],
    },
    # Known drivers of the March revenue miss (used in deck table slide).
    "mar_variance_drivers": [
        {"driver": "Three deals slipped from Mar to Apr",
         "impact": "-$22K",
         "why": "legal review lag — same contract template caused all three"},
        {"driver": "Expansion ARR under-ran plan",
         "impact": "-$9K",
         "why": "CS team 8 days behind — no expansion motion firing"},
        {"driver": "One logo churned",
         "impact": "-$4K",
         "why": "agency acquired, consolidated onto acquirer's tooling"},
    ],
    # The pricing/scope Woody's proposal will actually offer. $3K audit
    # matches Pack 1 pricing from the transfer doc.
    "proposed_engagement": {
        "audit_fee":    "$3,000",
        "audit_length": "2 weeks",
        "start_date":   "April 28, 2026",
        "deliverables": [
            "Operations diagnostic memo (Word doc, 6–10 pages)",
            "Reconciliation sheet: the six dashboards → one source-of-truth model (Excel)",
            "Ops cadence redesign — monthly review + weekly ops touch (slide deck)",
            "30-day priority stack — top 5 fixes sequenced by impact",
        ],
        "call_to_action": "Reply to this proposal by Friday April 24 and we'll start April 28.",
    },
    # Operator identity — don't reintroduce the Dan Cooper error.
    "operator": {
        "name":    "Dan Cobb",
        "org":     "TavernOS",
        "email":   "dan@tavernos.ai",
    },
}
