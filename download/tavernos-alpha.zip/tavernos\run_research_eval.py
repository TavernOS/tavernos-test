"""run_research_eval.py — Phase 4C test-harness for Cliff's research_report.

Parallels run_audit_eval.py from 4B — same shape, swapped rubric and paths.
Loads the Hypothetica research-report fixture, builds the docx, extracts
text, runs the evaluator against the RUBRIC_RESEARCH_REPORT rubric, prints
scores + critiques, and writes a JSON log for baseline tracking.

Usage (from the repo root, Windows PowerShell):
    python run_research_eval.py
    python run_research_eval.py --dry-run        # preflight + build, no LLM call
    python run_research_eval.py --model claude-sonnet-4-6
    python run_research_eval.py --runs 3         # MBR pacing — 3 runs for variance

ASCII-only output (no emojis, no unicode box-drawing) per operator
environment spec. Requires ANTHROPIC_API_KEY env var for live eval runs.
"""

from __future__ import annotations

import argparse
import json
import os
import statistics
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path


# ═══════════════════════════════════════════════════════════════════════════════
#  PATHS — script sits AT the repo root (parallels run_audit_eval.py from 4B,
#  which also lives at C:\TavernOS\tavernos\run_audit_eval.py). Fixture spec
#  is a sibling; artifact_docx and evaluator are siblings too.
# ═══════════════════════════════════════════════════════════════════════════════

THIS_DIR = Path(__file__).resolve().parent
REPO_ROOT = THIS_DIR
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

LOG_DIR = THIS_DIR / "eval_logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)


def _now_stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


# ═══════════════════════════════════════════════════════════════════════════════
#  CLI
# ═══════════════════════════════════════════════════════════════════════════════

def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(
        description="Eval harness for Cliff's research_report template."
    )
    ap.add_argument(
        "--model", default="claude-opus-4-5",
        help="Evaluator model id (default: claude-opus-4-5 — matches 4B)",
    )
    ap.add_argument(
        "--runs", type=int, default=1,
        help="Number of eval runs (for MBR variance). Default 1.",
    )
    ap.add_argument(
        "--dry-run", action="store_true",
        help="Preflight + build + extract only. No LLM call. "
             "Use this to sanity-check the fixture before burning tokens.",
    )
    ap.add_argument(
        "--keep-docx", action="store_true",
        help="Keep the built docx after the run (default: write to a temp "
             "dir that gets cleaned up).",
    )
    return ap.parse_args()


# ═══════════════════════════════════════════════════════════════════════════════
#  CORE — preflight, build, extract, score
# ═══════════════════════════════════════════════════════════════════════════════

def run_preflight(spec: dict, bytes_written: int | None = None) -> list[str]:
    """Mechanical preflight — no LLM. Returns the issues list."""
    import artifact_docx
    result = {"bytes": bytes_written} if bytes_written is not None else None
    return artifact_docx.preflight(spec, result=result)


def build_docx(spec: dict, out_dir: Path) -> Path:
    """Build the docx into out_dir. Returns the final path."""
    import artifact_docx

    def resolver(slug):
        d = out_dir / (slug or "_self")
        d.mkdir(parents=True, exist_ok=True)
        return d

    artifact_docx.set_path_resolver(resolver)
    result = artifact_docx.build_from_spec(spec, client_slug="hypothetica")
    return Path(result["path"])


def extract_text(path: Path) -> str:
    """Run the same extractor the evaluator pipeline uses."""
    import evaluator
    return evaluator.extract_text_from_deliverable(path)


def run_single_eval(spec: dict, deliverable_text: str, model_id: str) -> dict:
    """One eval run. Returns a dict with scores / critiques / weighted_avg /
    pass_threshold / failing_dims / overall_critique / error."""
    import evaluator

    try:
        import anthropic
    except ImportError:
        print("  ERROR: anthropic SDK not installed. "
              "pip install anthropic --break-system-packages")
        return {"error": "anthropic_sdk_missing"}

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("  ERROR: ANTHROPIC_API_KEY not set.")
        return {"error": "no_api_key"}

    client = anthropic.Anthropic(api_key=api_key)

    result = evaluator.score_deliverable(
        client=client,
        provider="anthropic",
        evaluator_model_id=model_id,
        rubric=evaluator.RUBRIC_RESEARCH_REPORT,
        deliverable_text=deliverable_text,
        spec_context={
            "template":          spec.get("template"),
            "research_question": spec.get("research_question"),
            "key_findings_n":    len(spec.get("key_findings") or []),
            "sources_n":         len(spec.get("sources_consulted") or []),
        },
    )
    return {
        "scores":           result.scores,
        "critiques":        result.critiques,
        "weighted_avg":     result.weighted_avg,
        "pass_threshold":   result.pass_threshold,
        "failing_dims":     result.failing_dims,
        "overall_critique": result.overall_critique,
        "evaluator_model":  result.evaluator_model,
        "error":            result.error,
    }


# ═══════════════════════════════════════════════════════════════════════════════
#  OUTPUT FORMATTING
# ═══════════════════════════════════════════════════════════════════════════════

def print_preflight(issues: list[str]) -> None:
    if not issues:
        print("  preflight: clean (0 issues)")
        return
    print(f"  preflight: {len(issues)} issue(s)")
    for i in issues:
        print(f"    - {i}")


def print_eval_result(result: dict, rubric_avg_threshold: float = 4.0) -> None:
    if result.get("error"):
        print(f"  EVAL ERROR: {result['error']}")
        return
    scores = result.get("scores") or {}
    critiques = result.get("critiques") or {}
    print("  Scores (dim: score):")
    for dim_name, score in scores.items():
        marker = "  " if score >= 4.0 else "! " if score >= 3.0 else "X "
        print(f"    {marker}{dim_name:<30} {score:.2f}")
    print(f"  Weighted avg: {result.get('weighted_avg', 0.0):.3f} "
          f"(threshold {rubric_avg_threshold})")
    print(f"  Pass threshold: {result.get('pass_threshold')}")
    if result.get("failing_dims"):
        print(f"  Failing dims: {', '.join(result['failing_dims'])}")
    if result.get("overall_critique"):
        print(f"  Overall: {result['overall_critique']}")
    if critiques:
        print("  Per-dim critiques:")
        for dim_name, text in critiques.items():
            if text:
                wrapped = (text or "").strip().replace("\n", " ")
                print(f"    {dim_name}: {wrapped[:200]}")


def print_run_summary(all_runs: list[dict]) -> None:
    """MBR-style variance summary across multiple runs."""
    if len(all_runs) < 2:
        return
    print("")
    print("=" * 72)
    print(f"MBR summary — {len(all_runs)} runs")
    print("=" * 72)
    dim_names = list((all_runs[0].get("scores") or {}).keys())
    for dim in dim_names:
        vals = [r["scores"][dim] for r in all_runs
                if r.get("scores") and dim in r["scores"]]
        if not vals:
            continue
        mean = statistics.mean(vals)
        spread = max(vals) - min(vals)
        print(f"  {dim:<30} mean {mean:.2f}  range [{min(vals):.1f}-{max(vals):.1f}]  "
              f"spread {spread:.2f}")
    wavg = [r.get("weighted_avg", 0.0) for r in all_runs]
    if wavg:
        mid = statistics.mean(wavg)
        print(f"  weighted_avg                   mean {mid:.3f}  "
              f"range [{min(wavg):.2f}-{max(wavg):.2f}]  "
              f"spread {max(wavg) - min(wavg):.2f}")


# ═══════════════════════════════════════════════════════════════════════════════
#  MAIN
# ═══════════════════════════════════════════════════════════════════════════════

def main() -> int:
    args = parse_args()

    print(f"run_research_eval.py  [{_now_stamp()}]")
    print(f"Model: {args.model}  |  Runs: {args.runs}  |  "
          f"Dry-run: {args.dry_run}")
    print("-" * 72)

    # Import the fixture
    try:
        from hypothetica_research_report_spec import RESEARCH_REPORT_SPEC as spec
    except ImportError as e:
        print(f"ERROR: could not import fixture: {e}")
        return 2

    print(f"Fixture: {spec.get('filename')} ({spec.get('template')})")
    print(f"  question: {(spec.get('research_question') or '')[:80]}...")
    print(f"  key_findings: {len(spec.get('key_findings') or [])}")
    print(f"  findings_detail: {len(spec.get('findings_detail') or [])}")
    print(f"  sources: {len(spec.get('sources_consulted') or [])}")
    print("")

    # Preflight pre-build (catches spec issues even before bytes exist)
    print("Pre-build preflight:")
    pre_issues = run_preflight(spec, bytes_written=None)
    print_preflight(pre_issues)
    print("")

    # Build the docx
    if args.keep_docx:
        out_dir = THIS_DIR / "_eval_build" / _now_stamp()
        out_dir.mkdir(parents=True, exist_ok=True)
        cleanup_dir = None
    else:
        cleanup_dir = tempfile.mkdtemp(prefix="tavernos_eval_")
        out_dir = Path(cleanup_dir)

    print(f"Building docx into: {out_dir}")
    try:
        docx_path = build_docx(spec, out_dir)
        bytes_written = docx_path.stat().st_size
        print(f"  built: {docx_path.name} ({bytes_written:,} bytes)")
    except Exception as e:
        print(f"  BUILD FAILED: {type(e).__name__}: {e}")
        return 3
    print("")

    # Post-build preflight (catches size-related issues)
    print("Post-build preflight:")
    post_issues = run_preflight(spec, bytes_written=bytes_written)
    print_preflight(post_issues)
    print("")

    # Extract text (sanity check)
    text = extract_text(docx_path)
    print(f"Extracted text: {len(text):,} chars, "
          f"{len(text.splitlines())} non-blank lines")
    if len(text) < 1000:
        print(f"  WARNING: extracted text is unusually short; eval may misfire")
    print("")

    if args.dry_run:
        print("--dry-run: skipping LLM eval. Exit.")
        return 0

    # Run evaluator N times
    all_runs = []
    for i in range(args.runs):
        print(f"=== Run {i+1}/{args.runs} ===")
        result = run_single_eval(spec, text, args.model)
        print_eval_result(result)
        all_runs.append(result)
        print("")

    # MBR variance summary if >1 run
    print_run_summary(all_runs)

    # Write JSON log
    log_path = LOG_DIR / f"eval_{_now_stamp()}.json"
    log_path.write_text(json.dumps({
        "timestamp":        _now_stamp(),
        "model":            args.model,
        "runs":             args.runs,
        "filename":         spec.get("filename"),
        "template":         spec.get("template"),
        "bytes_written":    bytes_written,
        "pre_issues":       pre_issues,
        "post_issues":      post_issues,
        "extracted_chars":  len(text),
        "results":          all_runs,
    }, indent=2, default=str))
    print(f"Log written: {log_path}")

    # Clean up build dir if we made a temp one
    if cleanup_dir:
        import shutil
        shutil.rmtree(cleanup_dir, ignore_errors=True)

    # Exit code: 0 if any run passed threshold, 1 if none did
    any_pass = any(r.get("pass_threshold") for r in all_runs)
    return 0 if any_pass else 1


if __name__ == "__main__":
    sys.exit(main())
