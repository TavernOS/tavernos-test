# fix-beta-stderr-trap.ps1
# Session 35, Path A: replace the broken `2>&1 | Out-Null` pattern in the
# beta block of refresh-and-push.ps1 with an Invoke-GitQuiet helper that
# locally overrides $ErrorActionPreference around git invocations.
#
# Background (don't-reintroduce items 51, 52, 54):
#   - Item 51: PowerShell's `2>$null` and `2>&1 | Out-Null` do NOT suppress
#     the implicit error record created from a native-command stderr write
#     under $ErrorActionPreference = "Stop". The only reliable suppression
#     is locally setting $ErrorActionPreference = "Continue" around the call.
#   - Item 52: Stderr-class fixes must be tested against worst-case input,
#     specifically a first-touch unstaged file that triggers the autocrlf
#     warning.
#   - Item 54: The hash-locked patch pattern is operationalizable for
#     single-file edits.
#
# Safety net components (item 54):
#   1. Hash-lock against expected baseline (both LF and CRLF accepted, since
#      core.autocrlf=true on Windows produces a CRLF working tree but git
#      stores LF in the index)
#   2. Timestamped pre-edit backup
#   3. Unique-anchor verification (refuse if 0 or >1 matches per anchor)
#   4. Line-delta verification (refuse if delta differs from expected +8)
#   5. UTF-8 read/write without BOM, original line endings preserved
#   6. ASCII-only script source; non-ASCII (Greek beta U+03B2) composed at
#      runtime via [char]
#
# Run from any working directory:
#   powershell -ExecutionPolicy Bypass -File fix-beta-stderr-trap.ps1
#
# After success:
#   1. Run smoke S1-S5 (TESTING.md tier 1).
#   2. Per item 52, exercise worst-case: touch a fresh unstaged file in the
#      source repo (e.g. `Add-Content C:\TavernOS\tavernos\norm.py ""` then
#      revert), and run refresh-and-push.ps1 to confirm beta no longer
#      crashes on the autocrlf stderr warning.
#   3. Commit the patched refresh-and-push.ps1 in C:\TavernOS\.
#   4. Record the new refresh-and-push.ps1 hash for the next state-verify.

$ErrorActionPreference = "Stop"

# -- Configuration ---------------------------------------------------------
$Target           = "C:\TavernOS\refresh-and-push.ps1"
$ExpectedHashLf   = "0D18868A0386E3252F46D61F4EE2A9103D04BE0025510FF9C10705C66C11C0C1"
$ExpectedHashCrlf = "F0D8CC1B7FC3511A7DDF0C2BC8787A8BBBCAB7C24A08DAD4D4062E04E4703DBF"
$ExpectedDelta    = 8

# -- Helpers ---------------------------------------------------------------
function Write-Step($msg) { Write-Host ""; Write-Host "==> $msg" -ForegroundColor Cyan }
function Write-Ok($msg)   { Write-Host "  [ok] $msg"   -ForegroundColor Green }
function Write-Fail($msg) { Write-Host "  [fail] $msg" -ForegroundColor Red }

function Apply-Edit {
    param(
        [string]$Content,
        [string]$OldStr,
        [string]$NewStr,
        [string]$EditName,
        [string]$BackupPath
    )
    # Normalize the old/new strings to LF in case the script source was
    # re-saved with CRLF endings somewhere in transit.
    $OldStr = $OldStr -replace "`r`n", "`n"
    $NewStr = $NewStr -replace "`r`n", "`n"

    # Count occurrences of $OldStr in $Content; require exactly 1.
    $pattern = [regex]::Escape($OldStr)
    $count = ([regex]::Matches($Content, $pattern)).Count

    if ($count -ne 1) {
        Write-Fail "$EditName : anchor matched $count time(s) (expected 1)"
        Write-Fail "  Refusing to edit. Backup retained at: $BackupPath"
        exit 1
    }
    Write-Ok "$EditName : anchor unique"
    # String.Replace is ordinal/literal; safe for substitutions that contain
    # regex metacharacters or PowerShell substitution patterns ($1 etc).
    return $Content.Replace($OldStr, $NewStr)
}

# -- 1. Hash check ---------------------------------------------------------
Write-Step "Hash-locking against baseline"

if (-not (Test-Path $Target)) {
    Write-Fail "Target not found: $Target"
    exit 1
}

$actualHash = (Get-FileHash $Target -Algorithm SHA256).Hash
if ($actualHash -ne $ExpectedHashLf -and $actualHash -ne $ExpectedHashCrlf) {
    Write-Fail "Hash mismatch. Refusing to edit."
    Write-Fail "  Actual:          $actualHash"
    Write-Fail "  Expected (LF):   $ExpectedHashLf"
    Write-Fail "  Expected (CRLF): $ExpectedHashCrlf"
    Write-Fail ""
    Write-Fail "File has drifted from session-34 baseline. If you have committed"
    Write-Fail "intentional changes since session 34, update the expected hashes"
    Write-Fail "in this script. Otherwise, investigate the drift before patching."
    exit 1
}
Write-Ok "Hash matches baseline"

# -- 2. Pre-edit backup ----------------------------------------------------
$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backupPath = "$Target.bak.$stamp"
Copy-Item -Path $Target -Destination $backupPath -Force
Write-Ok "Backup created: $backupPath"

# -- 3. Read file as UTF-8 (no BOM), detect line endings -------------------
$rawBytes = [System.IO.File]::ReadAllBytes($Target)
$utf8NoBom = New-Object System.Text.UTF8Encoding $false
$content = $utf8NoBom.GetString($rawBytes)
$usesCrlf = $content.Contains("`r`n")
$origLineCount = ($content -split "`n").Count
$lineEndingLabel = if ($usesCrlf) { "CRLF" } else { "LF" }
Write-Ok "Read $($rawBytes.Length) bytes, $origLineCount lines, line endings: $lineEndingLabel"

# Normalize to LF for matching
$contentLf = $content -replace "`r`n", "`n"

# -- 4. Build runtime-composed Greek beta (item 54) ------------------------
# The OLD explainer block contains U+03B2 (Greek small letter beta).
# Composing at runtime keeps this script ASCII-only.
$beta = [char]0x03B2

# -- 5. Edit 1: insert Invoke-GitQuiet helper after Exit-WithPause ---------
$edit1Old = @'
    Read-Host "Press Enter to close" | Out-Null
    exit $code
}

# -- 1. Sanity checks ------------------------------------------------------
'@

$edit1New = @'
    Read-Host "Press Enter to close" | Out-Null
    exit $code
}
function Invoke-GitQuiet {
    # Path A (session 35), per items 51 + 54: locally override
    # $ErrorActionPreference = "Continue" around git invocations so PowerShell
    # doesn't treat native-command stderr writes (e.g. core.autocrlf LF/CRLF
    # warning on `git add` of an unstaged file) as terminating errors. Caller
    # checks $LASTEXITCODE for real failures.
    $savedPref = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    try {
        & git @args 2>$null
    } finally {
        $ErrorActionPreference = $savedPref
    }
}

# -- 1. Sanity checks ------------------------------------------------------
'@

$contentLf = Apply-Edit -Content $contentLf -OldStr $edit1Old -NewStr $edit1New `
    -EditName "Edit 1 (insert Invoke-GitQuiet)" -BackupPath $backupPath

# -- 6. Edit 2: replace the $allDirty status invocation --------------------
$edit2Old = '    $allDirty = git status --porcelain 2>&1'
$edit2New = '    $allDirty = Invoke-GitQuiet status --porcelain'

$contentLf = Apply-Edit -Content $contentLf -OldStr $edit2Old -NewStr $edit2New `
    -EditName "Edit 2 (replace status invocation)" -BackupPath $backupPath

# -- 7. Edit 3: replace explainer + 2 git calls (anchor contains beta) -----
$edit3OldPart1 = @'
        # Both git calls below use `2>&1 | Out-Null` (not `2>$null` or plain
        # `| Out-Null`) because $ErrorActionPreference = "Stop" treats native-
        # command stderr writes as terminating errors. On Windows with
        # core.autocrlf=true, `git add` of an LF file emits an LF/CRLF warning
        # to stderr on every call -- which terminates the script before commit.
        # Merging stderr into stdout neutralizes the error class; piping to
        # Out-Null discards. Discovered session 33; before this fix, 
'@

$edit3OldPart2 = @'
 would
        # stage the in-scope file but never commit it.
        foreach ($line in $inScope) {
            $path = $line.Substring(3).Trim('"')
            git add $path 2>&1 | Out-Null
        }
        git commit -m "snapshot: pre-deploy auto-commit $stamp" 2>&1 | Out-Null
'@

$edit3Old = $edit3OldPart1 + $beta + $edit3OldPart2

$edit3New = @'
        # Path A (session 35): use Invoke-GitQuiet to neutralize the
        # core.autocrlf=true LF/CRLF stderr trap on first-touch unstaged files.
        foreach ($line in $inScope) {
            $path = $line.Substring(3).Trim('"')
            Invoke-GitQuiet add $path | Out-Null
        }
        Invoke-GitQuiet commit -m "snapshot: pre-deploy auto-commit $stamp" | Out-Null
'@

$contentLf = Apply-Edit -Content $contentLf -OldStr $edit3Old -NewStr $edit3New `
    -EditName "Edit 3 (replace beta-block git calls)" -BackupPath $backupPath

# -- 8. Line-delta verification --------------------------------------------
Write-Step "Verifying line delta"

$newLineCount = ($contentLf -split "`n").Count
$actualDelta = $newLineCount - $origLineCount
if ($actualDelta -ne $ExpectedDelta) {
    Write-Fail "Line delta mismatch."
    Write-Fail "  Original:       $origLineCount lines"
    Write-Fail "  New:            $newLineCount lines"
    Write-Fail "  Actual delta:   $actualDelta"
    Write-Fail "  Expected delta: $ExpectedDelta"
    Write-Fail "Refusing to write. Backup retained at: $backupPath"
    exit 1
}
Write-Ok "Line delta: +$actualDelta (matches expected)"

# -- 9. Write back, preserving original line endings -----------------------
Write-Step "Writing patched file"

$contentOut = if ($usesCrlf) { $contentLf -replace "`n", "`r`n" } else { $contentLf }
$outBytes = $utf8NoBom.GetBytes($contentOut)
[System.IO.File]::WriteAllBytes($Target, $outBytes)
Write-Ok "Wrote $($outBytes.Length) bytes"

# -- 10. Verify post-edit hash differs from baseline -----------------------
$newHash = (Get-FileHash $Target -Algorithm SHA256).Hash
if ($newHash -eq $ExpectedHashLf -or $newHash -eq $ExpectedHashCrlf) {
    Write-Fail "Post-edit hash matches the baseline. Edit did not take effect."
    Write-Fail "Backup retained at: $backupPath"
    exit 1
}
Write-Ok "New hash: $newHash"

# -- Done ------------------------------------------------------------------
Write-Host ""
Write-Host "==> Patch applied successfully." -ForegroundColor Green
Write-Host "    File:   $Target"             -ForegroundColor Green
Write-Host "    Backup: $backupPath"          -ForegroundColor Green
Write-Host "    Delta:  +$actualDelta lines"  -ForegroundColor Green
Write-Host "    Hash:   $newHash"             -ForegroundColor Green
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Cyan
Write-Host "  1. Run smoke S1-S5 (TESTING.md tier 1)."
Write-Host "  2. Worst-case test (item 52): touch an unstaged file in the source"
Write-Host "     repo, run refresh-and-push.ps1, confirm beta does not crash."
Write-Host "  3. Commit the patched refresh-and-push.ps1 in C:\TavernOS\."
Write-Host "  4. Record the new hash for the next state-verify baseline."
Write-Host ""
