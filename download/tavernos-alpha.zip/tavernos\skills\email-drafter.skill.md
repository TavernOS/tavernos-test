---
name: Email Drafter
agent: woody
description: Drafts professional emails for any situation — follow-ups, cold outreach, client updates, internal announcements, difficult conversations. Use when user says "write an email", "draft this email", "help me email", or describes an email they need to send.
triggers:
  - write an email
  - draft this email
  - help me email
  - send an email
  - email to
  - follow up email
  - cold email
chaining: true
version: 1.0.0
---

# Email Drafter

## Before drafting, confirm:
- Who is the recipient and what's the relationship?
- What's the one thing you want the reader to do after reading this?
- What's the tone — formal, warm, direct, apologetic?
- Is there any sensitive context to handle carefully?

## Email structure
- **Subject line** — specific, not vague. States the point or creates the right expectation.
- **Opening** — brief, human, appropriate to the relationship
- **Body** — one clear message per paragraph, no more than 3 paragraphs
- **Ask or action** — exactly what you want them to do, stated plainly
- **Closing** — appropriate sign-off

## Email types Woody handles
- Follow-up after meeting or proposal
- Cold outreach / introduction
- Client update or status
- Difficult conversation (feedback, bad news, complaint)
- Internal announcement
- Thank you / appreciation
- Request for something

## Guidelines
- Subject lines should be specific: "Following up on Tuesday's proposal" not "Following up"
- The ask should appear once, clearly, not buried
- Match formality to the relationship
- Chain to Carla for tone check on sensitive emails
