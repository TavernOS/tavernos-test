"""Hypothetica Co. operational audit — spec for artifact_docx.py.

Phase 4B dogfood test deliverable. Lilith's $3K Pack 1 audit, grounded in:

  - `hypothetica.py` — the shared fictional prospect profile (Maya Chen's
    verbatim pain quotes, Q1 2026 financials, March variance drivers)
  - The MBR xlsx that already lives in `_self` (MBR 4.73 from Phase 4A)
  - The Woody proposal docx that already lives in `_self`
  - The Rebecca exec deck that already lives in `_self`

Internal consistency across deliverables is the point of the Hypothetica
profile — the March variance narrative runs through all four. If any of
these numbers contradict the MBR or the proposal, that's a bug in this
file, not a judgment call.

Voice: Lilith. Clinical, diagnostic. Never "leverage," "best-in-class,"
"low-hanging fruit," "at the end of the day." "The artifacts show" and
"observe" are preferred verbs.

Dates: audit is dated May 12, 2026 — two weeks after the April 28 engagement
start indicated in the proposal, i.e. the end of the 2-week audit sprint.
The audit's "next step" dates cascade forward from there.
"""

from hypothetica import HYPOTHETICA

# ───────────────────────────────────────────────────────────────────────────
# Dollar amounts referenced inline. Kept as module constants so the prose
# and the ROI tables can't drift. Every one of these either comes from
# hypothetica.py directly or is a derived number (with the derivation
# traceable in the methodology strings below).
# ───────────────────────────────────────────────────────────────────────────

_MAR_DEAL_SLIPPAGE = 22_000   # hypothetica.py mar_variance_drivers[0]
_MAR_EXPANSION_MISS = 9_000   # hypothetica.py mar_variance_drivers[1]
_MAR_CHURN = 4_000            # hypothetica.py mar_variance_drivers[2]
_MAR_TOTAL_MISS = 35_000      # MBR Revenue: 340K plan - 305K actual

_P1_ANNUAL_VALUE = 33_250     # 350 hrs × $95
_P2_ANNUAL_VALUE = 18_750     # 250 hrs × $75
_P3_ANNUAL_VALUE = 24_000     # 150 hrs × $160
_TOTAL_ANNUAL_VALUE = _P1_ANNUAL_VALUE + _P2_ANNUAL_VALUE + _P3_ANNUAL_VALUE

_P1_BUILD = 3_500
_P2_BUILD = 2_500
_P3_BUILD = 4_000
_TOTAL_BUILD = _P1_BUILD + _P2_BUILD + _P3_BUILD

_TOTAL_HOURS_WEEK = 15        # 7 + 5 + 3


# ───────────────────────────────────────────────────────────────────────────
# Per-priority ROI math blocks. Stated once, referenced twice (table + prose)
# so no divergence.
# ───────────────────────────────────────────────────────────────────────────

_P1_ROI = {
    "hours_saved_week": 7,
    "hours_saved_year": 350,
    "blended_rate_usd": 95,
    "annual_value_usd": _P1_ANNUAL_VALUE,
    "build_cost_usd":   _P1_BUILD,
    "payback_months":   1.3,
    "rate_methodology":
        "60% exec-level time ($120/hr loaded) + 40% analyst time ($60/hr). "
        "Hours-saved basis: (1 hr of exec argument × 6 execs × 1 monthly review) "
        "+ (4 hrs of analyst pre-reconciliation × monthly review) + "
        "~20 hrs/month of the same argument recurring in exec 1:1s and "
        "offsite prep = ~30 hrs/month = 7 hrs/wk weighted.",
}

_P2_ROI = {
    "hours_saved_week": 5,
    "hours_saved_year": 250,
    "blended_rate_usd": 75,
    "annual_value_usd": _P2_ANNUAL_VALUE,
    "build_cost_usd":   _P2_BUILD,
    "payback_months":   1.6,
    "rate_methodology":
        "40% CS lead ($90/hr loaded) + 60% CS rep ($65/hr). Hours-saved "
        "basis: 2.5 hrs/wk of CS-lead manual triage (30 min × 5 days) + "
        "~2 hrs/wk of status-ping overhead between Maya and the CS lead + "
        "~0.5 hrs/wk of rep context-switching on tickets that should have "
        "escalated earlier. Expansion-motion revenue recovery ($9K/mo) "
        "is tracked separately in uncertainty_notes, not counted here.",
}

_P3_ROI = {
    "hours_saved_week": 3,
    "hours_saved_year": 150,
    "blended_rate_usd": 160,
    "annual_value_usd": _P3_ANNUAL_VALUE,
    "build_cost_usd":   _P3_BUILD,
    "payback_months":   2.0,
    "rate_methodology":
        "60% GC/attorney time ($200/hr loaded — assumes in-house counsel or "
        "fixed-fee outside counsel; see assumptions) + 40% sales-lead time "
        "($100/hr). Hours-saved basis: ~15 hrs/month across sales + legal "
        "on the repeating March pattern (3 deals × ~5 legal-review-days each "
        "= 15 days of elapsed calendar, ~15 hrs of active work time). "
        "Revenue-timing benefit flagged separately in uncertainty_notes.",
}


# ───────────────────────────────────────────────────────────────────────────
# Priority stack. Ordered by build sequence, not by ROI-rank. Rationale for
# the specific order lives in build_sequence_rationale below.
# ───────────────────────────────────────────────────────────────────────────

_PRIORITY_1 = {
    "rank": 1,
    "workflow": "Financial reporting canonical-model gap",
    "hours_per_week_lost": "7-9",
    "who_feels_it": "Maya Chen (COO); exec team; finance analyst",
    "root_cause":
        "Six revenue dashboards run off three different source systems "
        "(HubSpot for sales, Stripe for billing, ChartMogul for ARR), "
        "with no dashboard declared canonical. Metric definitions diverge "
        "across the three tools — HubSpot fires 'closed-won' on contract "
        "signature, Stripe fires 'revenue' on first invoice paid, "
        "ChartMogul's MRR uses plan value. Monthly review starts with "
        "45-60 min of definitional argument because each VP comes in "
        "with a different number.",
    "current_state":
        "Monthly ops review runs the third Tuesday, agenda calls for "
        "30 min on performance but typically runs 90+ minutes. No shared "
        "pre-read, no variance memo. The analyst rebuilds a one-off "
        "reconciliation each month, which is thrown away the following "
        "week.",
    "proposed_system":
        "Declare the MBR model (the Q1 2026 workbook already in the "
        "engagement file) as the canonical monthly view. Add a standing "
        "variance commentary block — ≤150 words, updated monthly by the "
        "finance analyst, shipped 24 hours before the ops review. The six "
        "operational dashboards keep their purposes (HubSpot = pipeline "
        "velocity, Stripe = billing health, ChartMogul = cohort cuts) but "
        "stop competing on 'what's our revenue?' — that question resolves "
        "to one answer. Review opens with the analyst reading the variance "
        "memo aloud in under three minutes.",
    "evidence": [
        {"source": "Discovery call, Apr 16",
         "detail": "Maya: \"We spend the first hour of every monthly "
                   "ops review arguing about which number is right.\""},
        {"source": "Discovery call, Apr 16",
         "detail": "Maya: \"I have six dashboards and still can't tell "
                   "you whether we're on plan this month.\""},
        {"source": "MBR Summary sheet, Variance Commentary block",
         "detail": "March revenue actual $305K vs plan $340K "
                   "(-$35K / -10.3%); three drivers already isolated "
                   "in the commentary block but not surfaced to "
                   "leadership before month-end."},
        {"source": "MBR Costs sheet, March column",
         "detail": "COGS underran plan by $12K ($107K vs $119K plan) "
                   "— a favorable signal that none of the six dashboards "
                   "surfaced because COGS lives only in the finance model."},
        {"source": "Audit engagement proposal, deliverables scope",
         "detail": "Scope item 2 — \"Reconciliation sheet: the six "
                   "dashboards → one source-of-truth model (Excel)\". "
                   "The client has already named the gap; the build "
                   "resolves it."},
        {"source": "MBR Trend sheet, MoM \u0394 column",
         "detail": "Revenue MoM delta swung from +4.8% (Jan→Feb) to "
                   "-6.2% (Feb→Mar) without a single dashboard firing "
                   "a threshold alert during March. The trend data "
                   "existed; the alerting layer didn't."},
    ],
    "roi_math": _P1_ROI,
    "build_effort":
        "16-20 hours. Credentials: HubSpot (read), Stripe (read), "
        "ChartMogul (read), MBR spreadsheet (edit). The majority of the "
        "effort is writing the variance-memo SOP the analyst will own "
        "monthly — the dashboard-repointing conversations with the three "
        "VPs are ~30 min each.",
    "risks": [
        "The finance analyst role isn't confirmed as a staffed seat — if "
        "the variance memo has no owner at handoff, the cadence collapses "
        "inside two months. Confirm ownership at kickoff.",
        "The six dashboards are likely co-owned by 2-3 VPs who will not "
        "give them up voluntarily. Framing the change as 'dashboards "
        "keep their jobs, they just stop competing on one question' is "
        "the only version of this that lands.",
    ],
    "success_signal_30d":
        "The first monthly ops review run against the new cadence opens "
        "with the analyst reading the variance memo. Time-to-first-"
        "disagreement on the top-line revenue number: zero minutes.",
}

_PRIORITY_2 = {
    "rank": 2,
    "workflow": "CS queue telemetry + expansion-motion unfreeze",
    "hours_per_week_lost": "4-6",
    "who_feels_it": "Maya Chen (COO); the CS lead (name not captured "
                    "in discovery — confirm at kickoff)",
    "root_cause":
        "The support queue has no aging dashboard and no SLA alerts. "
        "Tickets older than five days are invisible to leadership unless "
        "the CS lead hand-surfaces them in weekly staff. Meanwhile, the "
        "expansion motion (account review → upsell conversation) has been "
        "paused for roughly six weeks because 'CS is drowning' — the March "
        "expansion miss ($9K) is the downstream symptom, not the cause. "
        "The cause is that expansion readiness and CS capacity are "
        "implicitly coupled with no mechanism to decouple them.",
    "current_state":
        "CS team manages tickets through their support tool (identity not "
        "confirmed in discovery — Intercom, Zendesk, or Help Scout are the "
        "stack-typical candidates). Ticket aging reviewed manually for "
        "~30 min/day by the CS lead. No queue-depth metric surfaced to "
        "Maya's Slack or inbox. Expansion pipeline frozen since roughly "
        "mid-February per the March variance commentary.",
    "proposed_system":
        "Queue-depth + aging-bucket dashboard piped daily to Slack "
        "(#ops-daily). Threshold alerts: any ticket aging past 5 days = "
        "yellow, past 8 days = red. Separate 15-min standing weekly call "
        "('expansion-readiness check') on Maya and the CS lead's "
        "calendars: does the queue state permit outbound expansion "
        "motion this week? Yes/no, recorded in a running log. This "
        "decouples the expansion motion from implicit CS-capacity reads "
        "— it stays paused when it should, and resumes the first week "
        "it can.",
    "evidence": [
        {"source": "Discovery call, Apr 16",
         "detail": "Maya: \"Our CS team is eight days behind on support "
                   "tickets and I don't have a number for whether "
                   "that's getting worse.\""},
        {"source": "MBR Summary sheet, Variance Commentary driver 2",
         "detail": "March expansion ARR under-ran plan by $9K; driver "
                   "captured as \"CS team 8 days behind — no expansion "
                   "motion firing.\""},
        {"source": "MBR Revenue sheet, March column",
         "detail": "$9K of the $35K March shortfall is directly "
                   "attributable to expansion under-run — the single "
                   "largest preventable driver."},
        {"source": "Proposal, deliverables scope item 3",
         "detail": "\"Ops cadence redesign — monthly review + weekly "
                   "ops touch (slide deck).\" The weekly cadence in "
                   "scope is the surface this priority builds onto."},
    ],
    "roi_math": _P2_ROI,
    "build_effort":
        "12-16 hours. Credentials: the support tool's API (identity "
        "to confirm at kickoff) and a Slack incoming webhook. Build "
        "time is dominated by the integration; the alert logic is "
        "trivial. The expansion-readiness call is a calendar invite, "
        "not a build.",
    "risks": [
        "Support tool identity unconfirmed. Intercom and Zendesk have "
        "clean APIs; Help Scout requires more plumbing; a homegrown "
        "ticketing system triples the build effort.",
        "The expansion-readiness call only works if Maya uses it to "
        "decouple the motion from the implicit read — not if it becomes "
        "another standing meeting the CS lead dreads. Frame it as "
        "Maya's diagnostic, not a status update.",
    ],
    "success_signal_30d":
        "Queue-depth number posted daily to #ops-daily. Maya can answer "
        "\"is CS getting worse this week?\" in under ten seconds, from "
        "Slack, without pinging the CS lead. First expansion-readiness "
        "call held; expansion motion either resumes or is explicitly "
        "held-for-one-more-week with reason logged.",
}

_PRIORITY_3 = {
    "rank": 3,
    "workflow": "Contract template clause + legal-review fallback library",
    "hours_per_week_lost": "3-4",
    "who_feels_it": "Sales lead (name not captured); General Counsel "
                    "or outside counsel (structure not confirmed); "
                    "any deal in late-stage negotiation",
    "root_cause":
        "A single recurring clause in the master contract template is "
        "repeatedly flagged by customer-side legal. Across three March "
        "deals, the same clause triggered the same back-and-forth pattern "
        "— customer legal edits it, Hypothetica's counsel reviews, sales "
        "pushes back, customer legal reviews again. Three round-trips is "
        "typical, costing roughly five business days per deal in elapsed "
        "time. The clause itself has never been revised, because no one "
        "owns the template; the deal desk inherits it, sales uses it, "
        "legal reviews exceptions, and nobody owns the asset.",
    "current_state":
        "Master template lives in the shared drive. Each customer-side "
        "edit escalates to counsel individually; no fallback clause "
        "library exists, so each negotiation reopens the same ground. "
        "Three March deals slipped Mar→Apr for this reason ($22K in "
        "timing impact).",
    "proposed_system":
        "Redraft the repeatedly-flagged clause using the three March "
        "customer edits as the signal for what language customer legal "
        "will accept. Add a 2-3 variant fallback library for the "
        "most-pushed-on provisions. Deal desk can self-serve from the "
        "library for anything in the pre-approved set, without a legal "
        "round-trip. Escalation path stays in place for anything novel. "
        "Template ownership assigned explicitly — sales ops as primary "
        "owner, counsel as reviewer, quarterly review cadence.",
    "evidence": [
        {"source": "MBR Summary sheet, Variance Commentary driver 1",
         "detail": "\"Three deals slipped Mar→Apr — legal review lag, "
                   "same contract template caused all three.\" The "
                   "pattern is already documented; this priority "
                   "closes the loop."},
        {"source": "MBR Revenue sheet, March column",
         "detail": "$22K of the March miss is deal-timing slippage, "
                   "not lost revenue. Recovered in April but on the "
                   "wrong side of the quarter line."},
        {"source": "Hypothetica mar_variance_drivers[0] (audit data)",
         "detail": "Captured root cause — \"legal review lag — same "
                   "contract template caused all three\" — confirms "
                   "the pattern is singular-cause, not three "
                   "independent deals."},
    ],
    "roi_math": _P3_ROI,
    "build_effort":
        "20-28 hours, mostly legal-review time. Credentials: shared "
        "drive (edit), plus scheduled review slot with GC or outside "
        "counsel. Calendar-gated: the build moves at the speed of "
        "legal's availability.",
    "risks": [
        "If Hypothetica uses outside counsel at $400+/hr, 20 hours "
        "of legal time is $8K — enough to flip the hours-only payback "
        "past four months. The revenue-timing benefit (see "
        "uncertainty_notes) becomes the primary case, not secondary.",
        "The three March deals might not generalize — the pattern "
        "is strong at n=3 but customer legal opinions vary. Validate "
        "the redraft against a fourth in-flight deal before "
        "shipping the fallback library.",
    ],
    "success_signal_30d":
        "At least one Q2 deal closes on the fallback-clause path with "
        "no legal round-trip. Time-to-signature on pre-approved "
        "language: under two business days.",
}


# ───────────────────────────────────────────────────────────────────────────
# Executive summary and diagnosis prose — stated once, kept explicit.
# ───────────────────────────────────────────────────────────────────────────

_EXEC_PROSE = (
    "Hypothetica is a $4.2M ARR B2B SaaS firm at the Series A inflection "
    "point — 42 people across product, sales, CS, and ops, with a new "
    "COO six months into the role inheriting an operational stack "
    "assembled incrementally by a much smaller team. The artifacts show "
    "a healthy revenue motion paired with a broken early-warning system. "
    "January and February 2026 tracked plan within 3%. March missed plan "
    "by 10.3% — $35K — and all three drivers were visible to the "
    "operational floor in advance, but none were visible to leadership "
    "until the month closed. The audit surfaces three workflows that "
    "together account for roughly 15 hours per week of preventable "
    "senior-staff friction and were each directly implicated in the "
    "March miss. The single most valuable first move is declaring a "
    "canonical monthly-review model — Priority #1 below — because it "
    "unblocks the conversations that make Priorities #2 and #3 "
    "resolvable."
)

_HEADLINE = (
    f"Hypothetica is bleeding ~{_TOTAL_HOURS_WEEK} hours of senior-staff "
    f"time per week across three workflows that together drove $35K of "
    f"the March revenue miss — addressable in 6-8 weeks for a combined "
    f"one-time build of ${_TOTAL_BUILD:,} against ${_TOTAL_ANNUAL_VALUE:,} "
    f"of annualized value."
)

_TOP_FINDINGS = [
    "#1 — Six competing revenue dashboards; 45-60 min of every monthly "
    "ops review is spent reconciling definitions. 7 hrs/wk, "
    f"${_P1_ANNUAL_VALUE:,}/yr value, 1.3-month payback.",

    "#2 — CS queue has no telemetry; expansion motion frozen for six "
    "weeks, cost $9K in March expansion ARR. 5 hrs/wk, "
    f"${_P2_ANNUAL_VALUE:,}/yr value, 1.6-month payback.",

    "#3 — One contract-template clause caused three March deal slippages "
    "($22K of revenue timing). 3 hrs/wk, "
    f"${_P3_ANNUAL_VALUE:,}/yr value, 2.0-month payback.",
]

_DIAGNOSIS = (
    "Hypothetica's operational character reads as a company whose "
    "revenue engine works and whose reporting spine does not. The "
    "Jan-Feb performance indicates the business itself operates within "
    "a tight plan band — variances under 3% two months running suggest "
    "a sales motion that forecasts reasonably well, a CS function that "
    "retains reasonably well, and a finance function that plans "
    "reasonably well. March was not a business failure. March was a "
    "visibility failure.\n\n"
    "The three March variance drivers were each observable on the "
    "operational floor in advance. The three deal slippages were "
    "visible in the sales team's daily standups, because the same "
    "clause had blocked two earlier deals in February. The expansion "
    "miss was visible to the CS lead because expansion motion had "
    "been paused since mid-February. The single churn was visible to "
    "the account-managing CSM two weeks before the contract ended, "
    "because the acquirer's tool consolidation had been telegraphed. "
    "None of these signals reached Maya before the month closed. The "
    "business observed three preventable misses in real-time and could "
    "not surface them.\n\n"
    "Three specific operational bones are brittle. First, six "
    "revenue-adjacent dashboards compete to answer the same question; "
    "none is canonical. Second, the CS queue runs without leadership-"
    "visible telemetry, which is why the $9K expansion miss arrived as "
    "a month-end surprise. Third, the contract-review workflow has a "
    "repeating legal-lag pattern ($22K of March slippage across three "
    "deals with the same root cause) that has never been closed because "
    "no one owns the template asset. All three share a common profile: "
    "the work is being done; the signal is being lost.\n\n"
    "The audit focused on these three. A fourth candidate — the monthly "
    "financial close cycle — surfaced during Q1 MBR review and dropped "
    "below the priority cutoff (see \"What's Not in This Audit\" below). "
    "The three in-scope priorities are internally consistent: they share "
    "Maya as the pain owner, they share the MBR as the shared evidence "
    "base, and they share a common fix pattern — declare one canonical "
    "signal, route it to one visible surface, assign one owner."
)


# ───────────────────────────────────────────────────────────────────────────
# Build sequence — ordered by dependency, not ROI rank.
# ───────────────────────────────────────────────────────────────────────────

_BUILD_SEQUENCE = [
    {"weeks": "1-2", "priority_rank": 1,
     "rationale": "Unblocks the other two. Until the canonical monthly "
                  "number is declared, the ROI conversations for #2 and "
                  "#3 get routed back through 'which number is "
                  "correct?' arguments. Also the fastest signal loop — "
                  "the first post-build monthly review tests whether "
                  "the fix holds."},
    {"weeks": "3-5", "priority_rank": 2,
     "rationale": "Highest strategic-unlock urgency. $9K/month of "
                  "expansion revenue is currently pocketed by the "
                  "implicit expansion freeze. Ship the dashboard in "
                  "week 3, tune thresholds against live data in "
                  "week 4, run the first expansion-readiness call "
                  "in week 5."},
    {"weeks": "6-8", "priority_rank": 3,
     "rationale": "Highest legal-review time requirement, and "
                  "calendar-gated on counsel availability. Pair the "
                  "template redraft with GC review in weeks 6-7 and "
                  "ship the fallback library in week 8. Revenue-"
                  "timing benefit shows up in the Q2 close, not "
                  "immediately."},
]

_BUILD_SEQUENCE_RATIONALE = (
    "The order is not ROI rank. Priority #1 runs first because it is "
    "a prerequisite for the other two — both depend on the MBR being "
    "the shared source of truth. Priority #2 runs second, not third, "
    "because the expansion signal is bleeding now and the build effort "
    "is smaller than Priority #3. Priority #3 runs last because the "
    "work is gated on counsel availability, not on our readiness — if "
    "counsel happens to be available earlier, parallelize #2 and #3 "
    "and re-baseline. The sequence assumes a single operator running "
    "the build; if Hypothetica wants to add internal capacity, #2 and "
    "#3 can be run concurrently from week 3."
)


# ───────────────────────────────────────────────────────────────────────────
# Month 1 plan table.
# ───────────────────────────────────────────────────────────────────────────

_MONTH_1_PLAN = [
    {"week": 1,
     "focus": "Priority #1 — declare canonical model; dashboard "
              "re-scoping conversations.",
     "deliverable": "MBR declared canonical in writing. 30-min "
                    "dashboard roadshow doc. Kickoff notes.",
     "client_involvement": "1 hr Maya. 30 min each with 3 VPs. Finance "
                           "analyst named as the memo owner."},
    {"week": 2,
     "focus": "Priority #1 — variance-memo SOP; first monthly review "
              "against new cadence.",
     "deliverable": "Variance-memo SOP (≤5 pages). First month's "
                    "variance memo (≤150 words). Updated ops review "
                    "agenda.",
     "client_involvement": "Finance analyst drafts memo; Maya reviews "
                           "SOP. VPs attend the new-cadence review."},
    {"week": 3,
     "focus": "Priority #2 — CS queue-depth dashboard build.",
     "deliverable": "Daily queue-depth post live in #ops-daily. Alert "
                    "thresholds configured (default values, not tuned).",
     "client_involvement": "CS lead confirms support-tool identity and "
                           "provides API access. 30 min for threshold "
                           "walkthrough."},
    {"week": 4,
     "focus": "Priority #2 — threshold tuning; expansion-readiness "
              "call booked.",
     "deliverable": "Tuned alert thresholds against 2 weeks of live "
                    "data. 15-min weekly standing call scheduled on "
                    "Maya's calendar.",
     "client_involvement": "CS lead co-tunes thresholds. Maya confirms "
                           "the 15-min slot."},
]


# ───────────────────────────────────────────────────────────────────────────
# Discipline sections.
# ───────────────────────────────────────────────────────────────────────────

_NOT_IN_SCOPE = (
    "A fourth candidate — the monthly financial close cycle — surfaced "
    "during review of the Q1 MBR artifacts. The close currently runs "
    "5-6 business days with finance, CS, and sales all feeding "
    "spreadsheets to a central model. The process is not elegant, but "
    "it closes on time and the posted numbers are firm. The inelegance "
    "is not currently costing material senior-staff hours, and "
    "rebuilding the close during the same quarter as Priority #1 — "
    "which also touches finance's weekly rhythm — would compound "
    "change fatigue on the same team. Revisit in Q3, likely as part "
    "of an FP&A or RevOps build-out rather than a point workflow fix. "
    "If Maya disagrees on timing, the close can swap in as Priority "
    "#4 and the contract-template work moves to Q3 — but that is a "
    "revenue-timing-vs-reporting-elegance tradeoff worth making "
    "together, not alone."
)

_UNCERTAINTY_NOTES = [
    "Priority #2's hours-saved estimate (5 hrs/wk) is the widest "
    "confidence interval in this audit. The direct manual-triage "
    "savings (~2.5 hrs/wk from the CS lead) are firm. The remaining "
    "~2.5 hrs — status-ping overhead between Maya and the CS lead, "
    "plus rep context-switching — are calibrated against similar-stage "
    "B2B SaaS teams we've observed, not against Hypothetica's specific "
    "time logs. Treat the 5 hrs as a point estimate within a 3-7 hr "
    "band.",

    "Priority #3's revenue-timing benefit ($7-10K/month if the March "
    "pattern recurs at even 1 deal/month) is deliberately excluded from "
    "the ROI math table because it depends on whether the pattern "
    "repeats. March might be an outlier. If Q2 shows a similar legal-"
    "lag pattern on even one deal per month, the math holds. If it "
    "doesn't recur, the build is worth less in timing terms — the "
    "hours-savings case still stands.",

    "Two specifics were not captured in the April 16 discovery-call "
    "notes: the CS lead's name and the identity of the support tool. "
    "Both are required for Priority #2 week-3 work. The kickoff meeting "
    "agenda includes both as explicit confirm-items.",
]

_ASSUMPTIONS = [
    "Blended hourly rates assumed: $120/hr VP-level; $95/hr director; "
    "$60/hr analyst; $200/hr GC or in-house counsel; $100/hr sales lead; "
    "$90/hr CS lead; $65/hr CS rep. All figures are fully-loaded "
    "estimates. If Hypothetica's actual loaded rates differ materially, "
    "each priority's annual-value number scales linearly — substitute "
    "and recompute.",

    "The current monthly ops review is assumed to run ~90 minutes. "
    "Target post-build is 30 minutes. If the current meeting is "
    "actually shorter, the hours-saved estimate on Priority #1 is "
    "overstated.",

    "The CS support tool is assumed to be Intercom, Zendesk, or Help "
    "Scout — the stack-typical candidates for a Series A SaaS at this "
    "headcount. If the tool is homegrown or a less-common SaaS, the "
    "Priority #2 build effort approximately triples and the 1.6-month "
    "payback shifts to ~4 months.",

    "General Counsel is assumed to be salaried or on fixed retainer. "
    "If Hypothetica uses outside counsel billed hourly at $400+/hr, "
    "Priority #3's hours-only payback extends to 4-5 months and the "
    "revenue-timing benefit becomes the primary case, not secondary.",

    "A 50-week year is used in all annualizations to allow for "
    "holidays and planned leave.",
]

_NEXT_STEP = (
    "Reply to this memo by Friday, May 15, 2026 with approval — or "
    "counter — on the build sequence above. Week 1 kickoff proposed "
    "for Monday, May 18, 2026. Within 48 hours of your reply, I'll "
    "send the detailed Week 1 agenda and the required-credentials "
    "list. If you want to swap the close-cycle work (see \"What's Not "
    "in This Audit\") into the priority stack, flag that in your "
    "reply and I'll re-sequence before kickoff."
)


# ───────────────────────────────────────────────────────────────────────────
# Final spec.
# ───────────────────────────────────────────────────────────────────────────

AUDIT_SPEC = {
    "artifact": "docx",
    "template": "operational_audit",
    "filename": "hypothetica-ops-audit",
    "category": "audits",
    "meta": {
        "title":       f"Operational Audit — {HYPOTHETICA['company']}",
        "client_name": HYPOTHETICA["company"],
        "prepared_by": f"{HYPOTHETICA['operator']['name']}, "
                       f"{HYPOTHETICA['operator']['org']}",
        "date":        "May 12, 2026",
    },
    "executive_summary": {
        "prose":           _EXEC_PROSE,
        "headline_number": _HEADLINE,
        "top_findings":    _TOP_FINDINGS,
    },
    "diagnosis":      _DIAGNOSIS,
    "priority_stack": [_PRIORITY_1, _PRIORITY_2, _PRIORITY_3],
    "build_sequence": _BUILD_SEQUENCE,
    "build_sequence_rationale": _BUILD_SEQUENCE_RATIONALE,
    "month_1_plan":   _MONTH_1_PLAN,
    "not_in_scope":   _NOT_IN_SCOPE,
    "uncertainty_notes": _UNCERTAINTY_NOTES,
    "assumptions":    _ASSUMPTIONS,
    "next_step":      _NEXT_STEP,
}


if __name__ == "__main__":
    # Quick sanity check — run when executed directly.
    import json
    print(f"Spec key count:     {len(AUDIT_SPEC)}")
    print(f"Priority count:     {len(AUDIT_SPEC['priority_stack'])}")
    total_evidence = sum(
        len(p["evidence"]) for p in AUDIT_SPEC["priority_stack"]
    )
    print(f"Total evidence:     {total_evidence} items")
    print(f"Uncertainty notes:  {len(AUDIT_SPEC['uncertainty_notes'])}")
    print(f"Assumptions:        {len(AUDIT_SPEC['assumptions'])}")
    print(f"Month 1 plan rows:  {len(AUDIT_SPEC['month_1_plan'])}")
    print(f"\nSpec JSON size:   "
          f"{len(json.dumps(AUDIT_SPEC, default=str))} bytes")
