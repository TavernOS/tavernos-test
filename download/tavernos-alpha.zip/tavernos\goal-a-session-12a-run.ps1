# goal-a-session-12a-run.ps1
# Session 12a — path-format bug fix. Matches session-12 run-script shape.

cd C:\TavernOS\tavernos

# Tier 0 — expect 114/114 (113 session-12 + 1 new Contract 19 test)
python .\test_layer1_mechanism.py --verbose

# Production-CLI spot-check (Rule 3). Same three scripts as session 12.
python .\test_lilith_ops_audit.py
python .\test_rebecca_deck.py
python .\test_rebecca_mbr.py

# Manifest inspection — all three latest_*_path values should start
# with 'deliverables\', NOT 'clients\'.
Get-Content $env:USERPROFILE\.tavernos\clients\_self\client.json | ConvertFrom-Json | Format-List latest_*_path
