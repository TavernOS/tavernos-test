"""
test_lilith_ops_audit.py — Pipeline regression test for Lilith's operational_audit.

Thin wrapper over test_harness.py. Edit this file to change Lilith's test
scenarios; the harness handles all the plumbing.

Run:
  python test_lilith_ops_audit.py                    # tier 1 only, n=1
  python test_lilith_ops_audit.py --tier 1 --n 3     # tier 1, 3 iterations
  python test_lilith_ops_audit.py --tier 2 --n 3     # tiers 2a + 2b
  python test_lilith_ops_audit.py --tier all --n 3   # all implemented tiers
  python test_lilith_ops_audit.py --verbose          # dump plans + tool captures

Baseline expectations (as of the Goal A session 1 handoff):
  Tier 1:  stable 100% — router patch (ROUTER_SYSTEM in norm.py) is solid.
  Tier 2a: stable ~100% CLARIFY — grounding discipline holds on thin input.
  Tier 2b: ~25% invocation on rich prompts — hits Haiku's conservatism
           ceiling. Variance is the main open problem, not a floor.
"""

from test_harness import AgentTestConfig, run_tests


# ═══════════════════════════════════════════════════════════════════════════════
#  TEST SCENARIOS — lilith + operational_audit
#
#  SHORT prompts (Mode 3 / CLARIFY target): under ~30 words, no named business
#  context. Expected: no tool invocation, substantive prose with questions.
#
#  RICH prompts (Mode 2 / BOUND target): 4-6 sentences naming company, size,
#  specific pain, tool stack. Expected: generate_docx_report call with
#  template=operational_audit, and a file saved to disk.
#
#  NEGATIVE prompts: must NOT route to Lilith. Guards against the router's
#  Lilith rule over-matching on non-audit requests.
# ═══════════════════════════════════════════════════════════════════════════════

SHORT_PROMPTS = [
    "help me audit operations at a 25-person cabinetry shop",
    "I need an operational audit of my business",
    "run an ops audit on Acme Manufacturing",
    "map the workflows at our 40-person law firm",
    "I want an operational diagnosis — where are the bottlenecks?",
]

RICH_PROMPTS = [
    # Cabinetry — job costing drift
    ("We're a 25-person custom cabinetry shop in Portland doing about $4M a "
     "year. 18 on the shop floor, 7 in the office. Our biggest pain is that "
     "estimated hours and actual hours on every job drift by 20-40%, and we "
     "only find out at month-end when the bookkeeper reconciles. By then the "
     "job is closed and we can't course-correct. We use QuickBooks for "
     "invoicing, a whiteboard for the shop schedule, and email for job specs. "
     "Can you run an operational audit focused on where the drift is happening "
     "and what it'd take to catch it earlier?"),

    # Law firm — intake pipeline leakage
    ("We're a 12-attorney boutique litigation firm in Atlanta. Our intake "
     "pipeline is leaking — prospects fill out the website form, our paralegal "
     "Priya copies them into Clio, and the managing partner Marcus is "
     "supposed to follow up within 48 hours. In practice ~30% of inquiries "
     "never get a response, and we've traced at least four qualified-lead "
     "losses in Q1 to the handoff gap. Our stack is the website form, Clio, "
     "and email. Run an ops audit on the intake-to-engagement flow — we want "
     "to understand where the leads are dying."),

    # Coffee roaster — inventory sync across three systems
    ("40-person specialty coffee roaster in Seattle, wholesale plus DTC, "
     "about $8M a year in revenue. Shopify handles DTC, QuickBooks handles "
     "the books, and since we roast-to-order our inventory lives in a shared "
     "Google Sheet that our production manager Angela updates manually after "
     "every roast. About once a month we either oversell on Shopify because "
     "the sheet was stale, or we roast a batch nobody ordered because the "
     "wholesale team forgot to pull from the sheet. Audit the ops around "
     "inventory sync between production, Shopify, and QuickBooks."),

    # Fitness chain — reconciliation ghosts between scheduling and billing
    ("80-person boutique fitness studio chain, 6 locations across the "
     "Midwest. Class scheduling runs in Mindbody, membership billing runs "
     "through Stripe, payroll is Gusto. Every month we carry $3-5K in "
     "reconciliation ghosts — Stripe payments that don't match any Mindbody "
     "membership, or memberships that show active but aren't being charged. "
     "Location managers chase these manually and the bookkeeper zeroes them "
     "out at quarter-end. Run an audit on the scheduling-to-billing "
     "reconciliation workflow."),
]

NEGATIVE_PROMPTS = [
    ("write me a client proposal for Example Co.",                "woody"),
    ("give me current market research on robotics startups",      "cliff"),
    ("build me a monthly business review spreadsheet for Q1",     "rebecca"),
]


CONFIG = AgentTestConfig(
    agent_name="lilith",
    tool_name="generate_docx_report",
    template_key="operational_audit",
    short_prompts=SHORT_PROMPTS,
    rich_prompts=RICH_PROMPTS,
    negative_prompts=NEGATIVE_PROMPTS,
)


if __name__ == "__main__":
    run_tests(CONFIG)
