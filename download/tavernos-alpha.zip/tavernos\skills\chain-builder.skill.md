---
name: Chain Builder
agent: sam
description: Connects multiple agents in sequence to complete a complex multi-part task. Use when a task clearly requires more than one specialist and output from one step feeds into the next.
triggers:
  - chain these together
  - do all of this
  - full workflow
  - end to end
  - from start to finish
chaining: true
version: 1.0.0
---

# Chain Builder

## What this skill does
Builds and executes a chain of agent calls where each step's output becomes context for the next step.

## Chain patterns

**Research → Write → Review**
Cliff researches → Woody drafts → Carla reviews

**Analyze → Visualize → Present**
Cliff extracts data → Rebecca builds charts → Rebecca builds deck

**Requirements → Strategy → Document**
Coach gathers requirements → Frasier designs approach → Coach writes PRD

**Investigate → Plan → Execute**
Cliff researches → Frasier strategizes → Woody writes deliverable

## Guidelines
- Pass the full output of each step as context to the next
- Label each step clearly in the output
- Give the user a checkpoint after each major step if the chain is long
- If any step fails or produces weak output, stop and flag it rather than continuing
