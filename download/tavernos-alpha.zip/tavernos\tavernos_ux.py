# tavernos_ux.py
# UX helpers for Norm — visual feedback during silent operations.
#
# Two primitives:
#   1. Spinner(msg)        — for startup phases (update check, skill load, etc.)
#   2. AgentThinking(slug) — for LLM API calls; clears on first streamed token
#
# Usage patterns at the bottom of this file.
# Drop this whole file next to norm.py and `from tavernos_ux import Spinner, AgentThinking`,
# OR paste the code directly into norm.py near the top (below your imports).

import sys
import threading
import time
import itertools


# ── Terminal capability detection ───────────────────────────────────────────

def _supports_unicode():
    """Detect if the terminal can handle Unicode spinner chars."""
    try:
        enc = (sys.stdout.encoding or "").lower()
        return enc.startswith("utf")
    except Exception:
        return False


_UNICODE = _supports_unicode()

# Braille spinner looks great in modern terminals (Windows Terminal, iTerm, macOS Terminal).
# ASCII fallback for older PowerShell / cmd.exe.
_SPINNER_FRAMES = (
    ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏']
    if _UNICODE else
    ['|', '/', '-', '\\']
)

_CHECK = '✓' if _UNICODE else '[ok]'
_WARN = '⚠' if _UNICODE else '[!]'
_ARROW = '›' if _UNICODE else '>'

# Animation frame rate. 0.08s feels lively without being distracting.
_FRAME_DELAY = 0.08


# ── Spinner ─────────────────────────────────────────────────────────────────

class Spinner:
    """Context manager that animates a spinner while a block runs.

    Basic usage:
        with Spinner("Checking for updates"):
            check_for_updates()

    Custom completion text (replaces the default ✓):
        with Spinner("Checking for updates") as s:
            result = check_for_updates()
            s.done(f"v{result['version']}" if result else "current")

    Output while running:   Checking for updates... ⠋
    Output on success:      Checking for updates... ✓
    Output with custom:     Checking for updates... v1.6.1
    Output on error:        Checking for updates... ⚠ failed
    """

    def __init__(self, msg, indent=2):
        self.msg = msg
        self.indent = " " * indent
        self._running = False
        self._thread = None
        self._result = _CHECK

    def done(self, text):
        """Override the default ✓ result with custom text."""
        self._result = text

    def __enter__(self):
        self._running = True
        self._thread = threading.Thread(target=self._spin, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self._running = False
        if self._thread:
            self._thread.join(timeout=0.5)

        # Overwrite the spinner line. 40 trailing spaces clear any residual
        # animation chars, then newline moves to the next line.
        if exc_type is None:
            line = f"\r{self.indent}{self.msg}... {self._result}"
        else:
            line = f"\r{self.indent}{self.msg}... {_WARN} failed"
        sys.stdout.write(line + " " * 40 + "\n")
        sys.stdout.flush()

    def _spin(self):
        frames = itertools.cycle(_SPINNER_FRAMES)
        while self._running:
            frame = next(frames)
            sys.stdout.write(f"\r{self.indent}{self.msg}... {frame} ")
            sys.stdout.flush()
            time.sleep(_FRAME_DELAY)


# ── Agent thinking indicator ────────────────────────────────────────────────

# Personality-appropriate "thinking" phrases. Add to or edit freely.
_AGENT_THINKING = {
    'sam':     "sam is finding the right agent",
    'norm':    "norm is thinking it through",
    'coach':   "coach is organizing the plan",
    'carla':   "carla is sharpening the knife",
    'woody':   "woody is drafting thoughtfully",
    'cliff':   "cliff is digging in",
    'frasier': "frasier is mapping the approach",
    'rebecca': "rebecca is pulling the numbers",
    'lilith':  "lilith is diagnosing",
    'diane':   "diane is reading the tone",
}


class AgentThinking:
    """Shows an agent-personality spinner during an LLM API call.

    Call `.stop()` the moment the first streamed token arrives so the
    indicator clears before response text starts printing. If you forget,
    `__exit__` will clear it anyway when the block ends.

    Usage (streaming API):
        thinking = AgentThinking('carla')
        thinking.start()
        try:
            stream = client.messages.stream(...)
            for i, chunk in enumerate(stream):
                if i == 0:
                    thinking.stop()  # clear the spinner before any response text
                print(chunk, end='', flush=True)
        finally:
            thinking.stop()  # safe to call twice

    Usage (non-streaming):
        with AgentThinking('carla'):
            response = client.messages.create(...)
        print(response)
    """

    def __init__(self, agent_slug):
        slug = (agent_slug or "norm").lower()
        self.msg = _AGENT_THINKING.get(slug, f"{slug} is thinking")
        self._running = False
        self._thread = None
        self._stopped = False

    def start(self):
        if self._running:
            return
        self._running = True
        self._stopped = False
        self._thread = threading.Thread(target=self._spin, daemon=True)
        self._thread.start()

    def stop(self):
        """Clear the spinner immediately. Safe to call multiple times."""
        if self._stopped:
            return
        self._stopped = True
        self._running = False
        if self._thread:
            self._thread.join(timeout=0.5)
        # Clear the whole line so response text starts clean
        sys.stdout.write("\r" + " " * 80 + "\r")
        sys.stdout.flush()

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.stop()

    def _spin(self):
        frames = itertools.cycle(_SPINNER_FRAMES)
        while self._running:
            frame = next(frames)
            sys.stdout.write(f"\r  {self.msg} {frame} ")
            sys.stdout.flush()
            time.sleep(_FRAME_DELAY)


# ── Simple status line (no animation, for very fast operations) ─────────────

def status(msg, result=_CHECK, indent=2):
    """Print an immediately-completed status line. For operations too fast to spin.

    Usage:
        status("Loaded 10 agents")
        status("Loaded 32 skills", f"v{VERSION}")
    """
    pad = " " * indent
    print(f"{pad}{msg}... {result}")
