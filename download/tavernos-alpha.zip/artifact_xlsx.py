"""
tavernos/artifact_xlsx.py — branded Excel workbook generator.

Shipped as part of Phase 2 (artifact generation) on top of the Phase 1 MCP
bootstrap. Sibling to `mcp_client.py` — follows the same "domain module next to
norm.py" pattern so norm.py stays readable.

Architecture notes
------------------
Agent handoff is via a first-party tool call (`generate_xlsx_report`) registered
into norm.py's existing generalized tool-use loop. Rebecca doesn't emit a text
marker — she calls the tool with a JSON spec, the tool runs, writes the file,
and returns the saved path. This closes the fabrication gap flagged in the
handoff doc (open strategic decision #7) — a tool_result is authoritative; a
text marker is not.

The existing `DELIVERABLE_SAVED` marker pattern in norm.py is `.md`-only
(forces the extension, writes the response text as the file). This module
produces an analog deliverable-dict with the same shape so the CLI banner
in call_execute_streaming renders identically for text and binary deliverables.

Builder scope
-------------
Phase 2 ships one template: `monthly_business_review` — the workflow featured
in the customer one-pager. Revenue/costs monthly tables with variance-vs-plan,
3-month trend, KPI strip on a Summary sheet. Additional templates (forecast,
cohort analysis, P&L) plug in by adding a function to BUILDERS.

Brand tokens mirror the strategy-doc stack: teal #009688, navy #0F2236,
Arial body, Consolas mono, US Letter page.

Formula trust
-------------
Per the Phase 2 design decision: formulas pass through openpyxl literally and
Excel evaluates on open. The builder emits standard-math formulas itself
(totals, variance columns); the spec carries only KPI formulas where the
agent's judgment matters. Three cheap syntactic guards catch the dumb cases
(missing '=', cross-sheet references to unknown sheets, row refs beyond the
written range). Semantic correctness is Phase 3's problem.
"""

from __future__ import annotations

import json
import re
import traceback
from datetime import datetime
from pathlib import Path
from typing import Any

# ═══════════════════════════════════════════════════════════════════════════════
#  OPENPYXL IMPORT — hard dependency for this module. If the operator's install
#  is missing it (shouldn't happen under the packaged install but can under
#  direct-script-mode), callers get a clean ImportError they can catch.
# ═══════════════════════════════════════════════════════════════════════════════

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.workbook.defined_name import DefinedName
from openpyxl.worksheet.worksheet import Worksheet


# ═══════════════════════════════════════════════════════════════════════════════
#  BRAND TOKENS — shared across all xlsx deliverables. Mirrors the teal/navy
#  strategy-doc palette. Consolidated here so one edit re-brands every workbook.
# ═══════════════════════════════════════════════════════════════════════════════

TEAL = "FF009688"     # accent — header fills, totals row, borders
NAVY = "FF0F2236"     # primary — title bar, nav elements
WHITE = "FFFFFFFF"
INK = "FF0F2236"       # body text color (same as navy — feels cohesive)
SUBTLE = "FFE8EEF1"    # zebra-strip / subtle section fill
AMBER = "FFD97706"     # negative-variance callout
GREEN = "FF059669"     # positive-variance callout

FONT_BODY = "Arial"
FONT_MONO = "Consolas"

# Number formats. Keep these conservative — Excel's default locale handling
# will adapt currency symbol and separators for the operator's region.
FMT_CURRENCY = '"$"#,##0;[Red]-"$"#,##0'
FMT_CURRENCY_CENTS = '"$"#,##0.00;[Red]-"$"#,##0.00'
FMT_PERCENT = '0.0%;[Red]-0.0%'
FMT_INTEGER = '#,##0;[Red]-#,##0'
FMT_DECIMAL = '#,##0.00;[Red]-#,##0.00'

_FORMAT_ALIASES = {
    "currency":        FMT_CURRENCY,
    "currency_cents":  FMT_CURRENCY_CENTS,
    "percent":         FMT_PERCENT,
    "integer":         FMT_INTEGER,
    "decimal":         FMT_DECIMAL,
    "text":            "@",
}


def _resolve_number_format(fmt: str | None) -> str | None:
    """Accept either a friendly alias ('currency') or a raw Excel format
    string ('"$"#,##0.00'). Returns None when fmt is None (leave cell default).
    """
    if fmt is None:
        return None
    return _FORMAT_ALIASES.get(fmt, fmt)


# ═══════════════════════════════════════════════════════════════════════════════
#  STYLE HELPERS — keep cell-styling verbose-but-readable. openpyxl requires
#  fresh style objects per cell (they're effectively value-types); these helpers
#  factor out the repetition.
# ═══════════════════════════════════════════════════════════════════════════════

def _side(color: str = TEAL, style: str = "thin") -> Side:
    return Side(style=style, color=color)

# Explicit empty side for Border construction. Excel 2013+ expects all five
# border child elements (left/right/top/bottom/diagonal) to be present in the
# XML even when unstyled — otherwise it triggers the "we found a problem with
# some content" repair dialog. openpyxl by default omits unset sides, so every
# Border() construction in this module passes Side() for unused edges.
def _empty_side() -> Side:
    return Side()

def _border_all(color: str = TEAL, style: str = "thin") -> Border:
    s = _side(color, style)
    return Border(left=s, right=s, top=s, bottom=s, diagonal=_empty_side())

def _border_bottom(color: str = TEAL, style: str = "medium") -> Border:
    return Border(
        left=_empty_side(), right=_empty_side(), top=_empty_side(),
        bottom=_side(color, style), diagonal=_empty_side(),
    )

def _font(size: int = 10, bold: bool = False, color: str = INK,
          name: str = FONT_BODY) -> Font:
    return Font(name=name, size=size, bold=bold, color=color)

def _fill(color: str) -> PatternFill:
    return PatternFill(start_color=color, end_color=color, fill_type="solid")

def _center() -> Alignment:
    return Alignment(horizontal="center", vertical="center", wrap_text=True)

def _left() -> Alignment:
    return Alignment(horizontal="left", vertical="center", wrap_text=True)

def _right() -> Alignment:
    return Alignment(horizontal="right", vertical="center")


# ═══════════════════════════════════════════════════════════════════════════════
#  SPEC VALIDATION — fail loudly and early on bad specs. The agent sees the
#  error in the tool_result and can self-correct on the next turn.
# ═══════════════════════════════════════════════════════════════════════════════

class XlsxSpecError(ValueError):
    """Raised when a spec fails validation. Message is surfaced to the agent
    verbatim via tool_result, so keep messages actionable and specific."""


_FILENAME_SAFE = re.compile(r"[^A-Za-z0-9._-]")

def _sanitize_filename(name: str) -> str:
    """Strip path separators and exotic chars; ensure .xlsx extension.
    Rejects empties and anything with `..` components."""
    if not name or not isinstance(name, str):
        raise XlsxSpecError("filename must be a non-empty string")
    name = name.strip()
    if ".." in name or "/" in name or "\\" in name:
        raise XlsxSpecError("filename must not contain path separators or '..'")
    # Drop extension if present, re-append .xlsx — avoids double-ext
    if name.lower().endswith(".xlsx"):
        name = name[:-5]
    name = _FILENAME_SAFE.sub("-", name).strip("-")
    if not name:
        raise XlsxSpecError("filename reduces to empty after sanitization")
    return name + ".xlsx"


def _validate_spec(spec: Any) -> None:
    """Structural check. Raises XlsxSpecError on the first problem."""
    if not isinstance(spec, dict):
        raise XlsxSpecError("spec must be a JSON object")
    if spec.get("artifact") != "xlsx":
        raise XlsxSpecError("spec.artifact must equal 'xlsx'")
    template = spec.get("template")
    if template not in BUILDERS:
        valid = ", ".join(sorted(BUILDERS.keys()))
        raise XlsxSpecError(
            f"spec.template must be one of: {valid}. Got: {template!r}"
        )
    if not spec.get("filename"):
        raise XlsxSpecError("spec.filename is required")


# ═══════════════════════════════════════════════════════════════════════════════
#  FORMULA GUARDS — three cheap syntactic checks, per the Phase 2 design note.
#  These don't evaluate formulas; they catch shapes the agent got confused on.
#
#    G1. Starts with '=' (silent-string-as-value bug)
#    G2. Cross-sheet references name a sheet the workbook defines
#    G3. Row refs are within the written row range of the referenced sheet
#
#  Violations are returned as warnings, not raised. Phase 3 evaluation will do
#  the real work; these guards are a trip-wire for the obvious cases.
# ═══════════════════════════════════════════════════════════════════════════════

_CELL_REF_RE = re.compile(r"(?:([A-Za-z_][\w\s]*?)!)?\$?([A-Za-z]+)\$?(\d+)")

# Matches strings that look like Excel formulas written WITHOUT a leading '='.
# Two signatures: a spreadsheet function call at the start (SUM(...), IFERROR(...))
# or a bare range reference (A1:B5, Sheet!A1:B5). Either is almost certainly an
# agent mistake — openpyxl will store these as text cells and Excel will
# display the literal string rather than evaluating anything.
_FORMULA_SMELL_RE = re.compile(
    r"^\s*[A-Z][A-Z0-9_]+\(|(?:\b[A-Z]+\d+:[A-Z]+\d+\b)"
)

def _looks_like_unequals_formula(s: str) -> bool:
    """True if a string looks like a formula but doesn't start with '='.
    Used to catch the 'agent forgot the equals sign' failure mode."""
    if s.startswith("="):
        return False
    return bool(_FORMULA_SMELL_RE.search(s))

def _check_formula(formula: str, sheet_extents: dict[str, int]) -> list[str]:
    """Return a list of warning strings. Empty list == OK."""
    warnings: list[str] = []
    if not formula.startswith("="):
        warnings.append(
            f"formula does not start with '=' and will be written as a "
            f"string value: {formula!r}"
        )
        return warnings  # further guards don't apply to non-formulas
    # Walk every A1-style reference inside the formula body.
    body = formula[1:]
    for m in _CELL_REF_RE.finditer(body):
        sheet, col, row = m.group(1), m.group(2), int(m.group(3))
        if sheet:
            # openpyxl quotes sheets with spaces as 'Sheet Name'!; strip quotes
            sheet_clean = sheet.strip().strip("'")
            if sheet_clean not in sheet_extents:
                warnings.append(
                    f"formula references sheet {sheet_clean!r} which is not "
                    f"defined in this workbook (formula: {formula!r})"
                )
                continue
            max_row = sheet_extents[sheet_clean]
        else:
            max_row = max(sheet_extents.values()) if sheet_extents else 0
        if row > max_row + 5:  # small slack for SUM-through-blank idioms
            warnings.append(
                f"formula references row {row} but the target sheet has only "
                f"{max_row} rows written (formula: {formula!r})"
            )
    return warnings


# ═══════════════════════════════════════════════════════════════════════════════
#  LOW-LEVEL WRITERS — kept small and stateless so the template builders below
#  stay declarative.
# ═══════════════════════════════════════════════════════════════════════════════

def _write_title_bar(ws: Worksheet, row: int, title: str, subtitle: str,
                     cols: int) -> int:
    """Navy title band across `cols` columns. Returns next free row."""
    ws.cell(row=row, column=1, value=title).font = _font(
        size=16, bold=True, color=WHITE
    )
    ws.cell(row=row, column=1).fill = _fill(NAVY)
    ws.cell(row=row, column=1).alignment = _left()
    ws.row_dimensions[row].height = 28
    for c in range(2, cols + 1):
        ws.cell(row=row, column=c).fill = _fill(NAVY)
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=cols)

    if subtitle:
        ws.cell(row=row + 1, column=1, value=subtitle).font = _font(
            size=10, color=WHITE
        )
        ws.cell(row=row + 1, column=1).fill = _fill(NAVY)
        ws.cell(row=row + 1, column=1).alignment = _left()
        ws.row_dimensions[row + 1].height = 18
        for c in range(2, cols + 1):
            ws.cell(row=row + 1, column=c).fill = _fill(NAVY)
        ws.merge_cells(
            start_row=row + 1, start_column=1, end_row=row + 1, end_column=cols
        )
        return row + 2
    return row + 1


def _write_header_row(ws: Worksheet, row: int, headers: list[str]) -> None:
    """Teal-fill header with white bold Arial. One row of cells."""
    for i, h in enumerate(headers, start=1):
        c = ws.cell(row=row, column=i, value=h)
        c.font = _font(size=10, bold=True, color=WHITE)
        c.fill = _fill(TEAL)
        c.alignment = _center()
        c.border = _border_all()
    ws.row_dimensions[row].height = 22


def _write_data_row(ws: Worksheet, row: int, values: list[Any],
                    formats: list[str | None], zebra: bool = False) -> None:
    """Write one data row with per-column number formats. Strings starting
    with '=' are treated as formulas (openpyxl handles the distinction on
    value set). Zebra stripes the row in subtle gray when `zebra` is True."""
    for i, (val, fmt) in enumerate(zip(values, formats), start=1):
        c = ws.cell(row=row, column=i, value=val)
        c.font = _font(size=10)
        resolved = _resolve_number_format(fmt)
        if resolved:
            c.number_format = resolved
        c.alignment = _right() if i > 1 else _left()
        c.border = _border_all(color="FFDDE3E7", style="thin")
        if zebra:
            c.fill = _fill(SUBTLE)


def _write_totals_row(ws: Worksheet, row: int, values: list[Any],
                      formats: list[str | None]) -> None:
    """Bold row with a thick teal top border — the totals band."""
    for i, (val, fmt) in enumerate(zip(values, formats), start=1):
        c = ws.cell(row=row, column=i, value=val)
        c.font = _font(size=10, bold=True, color=NAVY)
        resolved = _resolve_number_format(fmt)
        if resolved:
            c.number_format = resolved
        c.alignment = _right() if i > 1 else _left()
        c.border = Border(
            top=_side(TEAL, "medium"),
            bottom=_side(TEAL, "thin"),
            left=_side("FFDDE3E7", "thin"),
            right=_side("FFDDE3E7", "thin"),
            diagonal=_empty_side(),
        )
    ws.row_dimensions[row].height = 22


def _autosize(ws: Worksheet, widths: list[int]) -> None:
    """Set explicit column widths. openpyxl's auto_dimension is flaky with
    mixed-content columns, so we pin values and own the look."""
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w


def _setup_page(ws: Worksheet, title: str) -> None:
    """US Letter, fit-to-width, branded header/footer."""
    ws.page_setup.paperSize = ws.PAPERSIZE_LETTER
    ws.page_setup.orientation = ws.ORIENTATION_PORTRAIT
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_margins.left = 0.5
    ws.page_margins.right = 0.5
    ws.page_margins.top = 0.6
    ws.page_margins.bottom = 0.6
    ws.oddHeader.left.text = title
    ws.oddHeader.left.font = f"{FONT_BODY},Bold"
    ws.oddHeader.left.color = NAVY.replace("FF", "", 1)
    ws.oddFooter.center.text = "Page &P of &N | TavernOS"
    ws.oddFooter.center.size = 9


# ═══════════════════════════════════════════════════════════════════════════════
#  MONTHLY BUSINESS REVIEW — the flagship Phase 2 template.
#
#  Sheets:
#    1. Summary  — title bar, KPI strip, variance callout table
#    2. Revenue  — monthly rows with variance-vs-plan (builder emits variance
#                  and % formulas; spec provides actual + plan values)
#    3. Costs    — same shape as Revenue, split into COGS + OpEx columns
#    4. Trend    — 3-month running view with computed gross margin
#
#  The spec carries values (and optionally KPI formulas); the builder owns
#  all standard-math formulas. This split keeps the agent focused on story
#  and lets the builder guarantee formula consistency.
# ═══════════════════════════════════════════════════════════════════════════════

def _build_monthly_business_review(spec: dict) -> tuple[Workbook, dict[str, int]]:
    """Construct the MBR workbook. Returns (Workbook, sheet_extents) where
    sheet_extents maps sheet_name -> max row written, for formula guards."""
    meta = spec.get("meta") or {}
    client_name = meta.get("client_name", "Client")
    period = meta.get("period", datetime.now().strftime("%B %Y"))
    prepared_by = meta.get("prepared_by", "Rebecca / TavernOS")

    title = f"{client_name} — Monthly Business Review"
    subtitle = f"Period: {period}  ·  Prepared by: {prepared_by}"

    wb = Workbook()
    # The default "Sheet" gets repurposed as Summary.
    summary = wb.active
    summary.title = "Summary"
    revenue = wb.create_sheet("Revenue")
    costs = wb.create_sheet("Costs")
    trend = wb.create_sheet("Trend")

    sheet_extents: dict[str, int] = {}

    # ── Revenue sheet ──────────────────────────────────────────────────────
    rev_rows = (spec.get("revenue") or {}).get("rows") or []
    _setup_page(revenue, f"{client_name} — Revenue")
    row = _write_title_bar(revenue, 1, f"Revenue — {period}", subtitle, cols=5)
    header_row = row
    _write_header_row(
        revenue, header_row,
        ["Month", "Actual", "Plan", "Variance", "Variance %"],
    )
    data_start = header_row + 1
    rev_data_start = data_start  # saved for cross-sheet refs in the Trend section
    for i, r in enumerate(rev_rows):
        ws_row = data_start + i
        actual_ref = f"B{ws_row}"
        plan_ref = f"C{ws_row}"
        _write_data_row(
            revenue, ws_row,
            [
                r.get("month", ""),
                float(r.get("actual", 0) or 0),
                float(r.get("plan", 0) or 0),
                f"={actual_ref}-{plan_ref}",
                f"=IFERROR(({actual_ref}-{plan_ref})/{plan_ref},0)",
            ],
            [None, "currency", "currency", "currency", "percent"],
            zebra=(i % 2 == 1),
        )
    totals_row = data_start + len(rev_rows)
    if rev_rows:
        _write_totals_row(
            revenue, totals_row,
            [
                "Total",
                f"=SUM(B{data_start}:B{totals_row - 1})",
                f"=SUM(C{data_start}:C{totals_row - 1})",
                f"=SUM(D{data_start}:D{totals_row - 1})",
                f"=IFERROR(SUM(D{data_start}:D{totals_row - 1})/"
                f"SUM(C{data_start}:C{totals_row - 1}),0)",
            ],
            [None, "currency", "currency", "currency", "percent"],
        )
    _autosize(revenue, [18, 16, 16, 16, 14])
    sheet_extents["Revenue"] = totals_row if rev_rows else header_row

    # ── Costs sheet ────────────────────────────────────────────────────────
    cost_rows = (spec.get("costs") or {}).get("rows") or []
    _setup_page(costs, f"{client_name} — Costs")
    row = _write_title_bar(costs, 1, f"Costs — {period}", subtitle, cols=8)
    header_row = row
    _write_header_row(
        costs, header_row,
        ["Month", "COGS", "OpEx", "Total", "Plan COGS", "Plan OpEx", "Plan Total", "Variance"],
    )
    data_start = header_row + 1
    cost_data_start = data_start
    cost_month_to_row: dict[str, int] = {}  # month label -> Costs sheet row
    for i, r in enumerate(cost_rows):
        ws_row = data_start + i
        cost_month_to_row[r.get("month", "")] = ws_row
        cogs_ref = f"B{ws_row}"
        opex_ref = f"C{ws_row}"
        total_ref = f"D{ws_row}"
        plan_cogs_ref = f"E{ws_row}"
        plan_opex_ref = f"F{ws_row}"
        plan_total_ref = f"G{ws_row}"
        _write_data_row(
            costs, ws_row,
            [
                r.get("month", ""),
                float(r.get("cogs", 0) or 0),
                float(r.get("opex", 0) or 0),
                f"={cogs_ref}+{opex_ref}",
                float(r.get("plan_cogs", 0) or 0),
                float(r.get("plan_opex", 0) or 0),
                f"={plan_cogs_ref}+{plan_opex_ref}",
                f"={total_ref}-{plan_total_ref}",
            ],
            [None, "currency", "currency", "currency",
             "currency", "currency", "currency", "currency"],
            zebra=(i % 2 == 1),
        )
    totals_row = data_start + len(cost_rows)
    if cost_rows:
        _write_totals_row(
            costs, totals_row,
            [
                "Total",
                f"=SUM(B{data_start}:B{totals_row - 1})",
                f"=SUM(C{data_start}:C{totals_row - 1})",
                f"=SUM(D{data_start}:D{totals_row - 1})",
                f"=SUM(E{data_start}:E{totals_row - 1})",
                f"=SUM(F{data_start}:F{totals_row - 1})",
                f"=SUM(G{data_start}:G{totals_row - 1})",
                f"=SUM(H{data_start}:H{totals_row - 1})",
            ],
            [None] + ["currency"] * 7,
        )
    _autosize(costs, [18, 14, 14, 14, 14, 14, 14, 14])
    sheet_extents["Costs"] = totals_row if cost_rows else header_row

    # ── Named ranges — self-documenting cross-sheet references ─────────────
    # Replaces magic cell addresses like Costs!B7 with names like COGS_Total.
    # Benefits:
    #   - Formulas read as business logic: =Revenue_Actual_Total-COGS_Total
    #   - The evaluator (and a human reader) sees intent, not coordinates
    #   - Resilient to row shifts: if someone adds a month and the totals row
    #     moves, the named range definition is the single place to update.
    # Excel named ranges need absolute refs ($B$7), not relative (B7).
    rev_totals_row_local = totals_row if rev_rows else 0  # filled below
    # Recompute rev_totals_row from the Revenue section's extent — we lost
    # the local variable when the Costs section reassigned `totals_row`.
    rev_totals_row_local = sheet_extents.get("Revenue", 0) if rev_rows else 0
    cost_totals_row_local = sheet_extents.get("Costs", 0) if cost_rows else 0

    def _add_named_range(name: str, sheet: str, cell: str) -> None:
        """Register a workbook-level named range pointing at a single cell."""
        defn = DefinedName(name=name, attr_text=f"'{sheet}'!${cell[0]}${cell[1:]}")
        wb.defined_names[name] = defn

    if rev_totals_row_local:
        _add_named_range("Revenue_Actual_Total",   "Revenue", f"B{rev_totals_row_local}")
        _add_named_range("Revenue_Plan_Total",     "Revenue", f"C{rev_totals_row_local}")
        _add_named_range("Revenue_Variance_Total", "Revenue", f"D{rev_totals_row_local}")
    if cost_totals_row_local:
        _add_named_range("COGS_Total",             "Costs",   f"B{cost_totals_row_local}")
        _add_named_range("OpEx_Total",             "Costs",   f"C{cost_totals_row_local}")
        _add_named_range("Costs_Actual_Total",     "Costs",   f"D{cost_totals_row_local}")
        _add_named_range("Costs_Plan_Total",       "Costs",   f"G{cost_totals_row_local}")
        _add_named_range("Costs_Variance_Total",   "Costs",   f"H{cost_totals_row_local}")

    # ── Trend sheet — 3-month running view with MoM delta + gross margin ───
    # Previously this sheet wrote the revenue and COGS values as literals
    # copied from the spec, which meant editing the Revenue or Costs sheet
    # in Excel wouldn't flow through to Trend. Now every Trend data cell is
    # a cross-sheet formula (=Revenue!B4, =Costs!B4, etc), so the Trend
    # sheet stays consistent if the source sheets are edited.
    # The 'Rev MoM Delta' column (between Revenue and COGS) shows
    # month-over-month revenue change — addresses the period_comparability
    # rubric dimension by making direction visible, not just state.
    _setup_page(trend, f"{client_name} — Trend")
    row = _write_title_bar(trend, 1, f"3-Month Trend — {period}",
                           subtitle, cols=6)
    header_row = row
    _write_header_row(
        trend, header_row,
        ["Month", "Revenue", "Rev MoM Delta %", "COGS",
         "Gross Margin $", "Gross Margin %"],
    )
    data_start = header_row + 1
    trend_written = 0
    for i, r in enumerate(rev_rows):
        month = r.get("month", "")
        ws_row = data_start + i
        rev_sheet_row = rev_data_start + i
        cogs_sheet_row = cost_month_to_row.get(month)
        rev_ref = f"Revenue!B{rev_sheet_row}"
        # MoM delta: first row has no prior month, so leave blank.
        # Subsequent rows compute (current - prior) / prior using the
        # Trend sheet's own B column as the prior-month reference.
        if i == 0:
            mom_delta = ""
            mom_fmt = None
        else:
            prior_row = ws_row - 1
            mom_delta = f"=IFERROR((B{ws_row}-B{prior_row})/B{prior_row},0)"
            mom_fmt = "percent"
        if cogs_sheet_row is not None:
            cogs_ref = f"Costs!B{cogs_sheet_row}"
            _write_data_row(
                trend, ws_row,
                [
                    month,
                    f"={rev_ref}",
                    mom_delta,
                    f"={cogs_ref}",
                    f"={rev_ref}-{cogs_ref}",
                    f"=IFERROR(({rev_ref}-{cogs_ref})/{rev_ref},0)",
                ],
                [None, "currency", mom_fmt, "currency", "currency", "percent"],
                zebra=(i % 2 == 1),
            )
        else:
            # No matching cost row for this month — leave COGS & margin blank
            # rather than fabricate a value. This matches the intent of the
            # pre-existing comment ("leave the slot blank rather than
            # fabricate") which the prior code didn't actually honor.
            _write_data_row(
                trend, ws_row,
                [
                    month,
                    f"={rev_ref}",
                    mom_delta,
                    "",
                    "",
                    "",
                ],
                [None, "currency", mom_fmt, None, None, None],
                zebra=(i % 2 == 1),
            )
        trend_written += 1
    _autosize(trend, [18, 16, 18, 16, 18, 16])
    sheet_extents["Trend"] = data_start + trend_written - 1 if trend_written else header_row

    # ── Summary sheet — title bar, KPI strip, variance callouts ───────────
    _setup_page(summary, f"{client_name} — Summary")
    row = _write_title_bar(summary, 1, title, subtitle, cols=4)

    # KPI strip. Two paths:
    #   (a) Spec provides kpis[] — use them, but warn if an entry that names
    #       a derivable metric (revenue, margin, variance, etc.) uses a
    #       literal value instead of a formula. The static-value KPI was the
    #       failure mode observed in early Rebecca runs — she'd compute the
    #       margin in her head and write 60.9 as a number, which Excel
    #       formats as 6090% under percent format.
    #   (b) Spec omits kpis (or passes empty) — builder fills 4 standard
    #       formula-bearing KPIs derived from the data already on disk.
    #       This makes the failure mode impossible by default.
    rev_totals_row = sheet_extents.get("Revenue", 0)
    cost_totals_row = sheet_extents.get("Costs", 0)
    last_rev_data_row = rev_totals_row - 1 if rev_totals_row > 3 else 0
    last_cost_data_row = cost_totals_row - 1 if cost_totals_row > 3 else 0

    kpis = spec.get("kpis") or []
    if not kpis and rev_rows:
        # Default KPI strip — formula-bearing, derived from the actual data
        # rows the builder just wrote. All four cells are live formulas, so
        # editing the underlying numbers updates the strip automatically.
        kpis = [
            {
                "label":   "Latest Month Revenue",
                "formula": f"=Revenue!B{rev_totals_row - 1}" if last_rev_data_row else None,
                "format":  "currency",
            },
            {
                "label":   "Revenue Variance vs Plan (Total)",
                "formula": "=Revenue_Variance_Total" if rev_totals_row else None,
                "format":  "currency",
            },
            {
                # Label explicit about the basis so a reader doesn't have to
                # chase Costs!B7 to confirm it's COGS, not total costs. The
                # formula now uses named ranges so intent is self-documented.
                "label":   "Gross Margin % (Rev − COGS)",
                "formula": (
                    "=IFERROR((Revenue_Actual_Total-COGS_Total)"
                    "/Revenue_Actual_Total,0)"
                ) if (rev_totals_row and cost_totals_row) else None,
                "format":  "percent",
            },
            {
                "label":   "OpEx (Total)",
                "formula": "=OpEx_Total" if cost_totals_row else None,
                "format":  "currency",
            },
        ]
        # Drop any KPI whose formula we couldn't build (missing source data)
        kpis = [k for k in kpis if k.get("formula")]

    # Warn if agent-provided KPIs use literal values for metrics that look
    # like they should be formula-derived. The warning lands in the spec's
    # _warnings sidecar and gets surfaced to the agent via tool_result.
    _kpi_warnings = []
    _DERIVABLE_HINTS = (
        "revenue", "margin", "variance", "ytd", "qtd", "mtd", "cogs", "opex",
        "profit", "ebitda", "growth", "actual",
    )
    for kpi in kpis:
        label = (kpi.get("label") or "").lower()
        has_formula = kpi.get("formula") is not None
        has_value = kpi.get("value") is not None
        if has_value and not has_formula and any(h in label for h in _DERIVABLE_HINTS):
            _kpi_warnings.append(
                f"KPI {kpi.get('label')!r} uses a static value ({kpi.get('value')!r}) "
                "but the label suggests it should be a formula. Consider passing "
                "'formula' instead so the workbook recalculates when the source "
                "data changes (e.g. 'formula': '=Revenue!D7')."
            )
    # Stash warnings on the workbook for build_from_spec's guard sweep to find
    if _kpi_warnings:
        wb._tavernos_extra_warnings = _kpi_warnings

    kpi_label_row = row + 1
    kpi_value_row = row + 2

    # Background band across the KPI strip
    for c in range(1, 5):
        for rr in (kpi_label_row, kpi_value_row):
            summary.cell(row=rr, column=c).fill = _fill(SUBTLE)
    summary.row_dimensions[kpi_label_row].height = 18
    summary.row_dimensions[kpi_value_row].height = 28

    for i, kpi in enumerate(kpis[:4]):
        col = i + 1
        # Label
        lab = summary.cell(
            row=kpi_label_row, column=col, value=kpi.get("label", ""),
        )
        lab.font = _font(size=9, bold=True, color=NAVY)
        lab.alignment = _center()
        # Value or formula
        val = kpi.get("formula") if kpi.get("formula") is not None else kpi.get("value")
        v = summary.cell(row=kpi_value_row, column=col, value=val)
        v.font = _font(size=16, bold=True, color=TEAL,
                       name=FONT_MONO if kpi.get("mono") else FONT_BODY)
        resolved = _resolve_number_format(kpi.get("format"))
        if resolved:
            v.number_format = resolved
        v.alignment = _center()
        v.border = _border_bottom(TEAL, "thin")

    # Variance callout table (pulled from the Revenue totals row).
    callout_start = kpi_value_row + 2
    _write_header_row(
        summary, callout_start,
        ["Metric", "Actual", "Plan", "Variance"],
    )
    if rev_rows and rev_totals_row:
        _write_data_row(
            summary, callout_start + 1,
            [
                "Revenue",
                "=Revenue_Actual_Total",
                "=Revenue_Plan_Total",
                "=Revenue_Variance_Total",
            ],
            [None, "currency", "currency", "currency"],
        )
    if cost_rows and cost_totals_row:
        _write_data_row(
            summary, callout_start + 2,
            [
                "Total Costs",
                "=Costs_Actual_Total",
                "=Costs_Plan_Total",
                "=Costs_Variance_Total",
            ],
            [None, "currency", "currency", "currency"],
        )

    # ── Variance Commentary — operator-provided 'so what' narrative ─────────
    # An MBR without commentary is a report, not a review. The evaluator's
    # variance_commentary dimension specifically tests for this — materially-
    # missed-plan lines need a one-sentence driver + impact explanation from
    # the operator. Commentary is ALWAYS operator-provided verbatim; Rebecca
    # should never fabricate 'why' narratives (that's the OUTPUT_CONTRACT
    # grounding discipline — CLARIFY or BOUND, not invent).
    commentary_entries: list[dict] = list(spec.get("commentary") or [])

    # If operator didn't supply commentary, detect material variances from
    # the data we already have. Threshold: |actual - plan| / plan >= 5%.
    # For each material variance without matching commentary, append a [TBD]
    # stub so the BOUND-path deliverable still renders a Commentary section.
    material_variances: list[str] = []
    for r in rev_rows:
        plan = float(r.get("plan", 0) or 0)
        actual = float(r.get("actual", 0) or 0)
        if plan and abs(actual - plan) / plan >= 0.05:
            direction = "missed" if actual < plan else "beat"
            material_variances.append(
                f"{r.get('month', '')} revenue {direction} plan by "
                f"${abs(actual - plan):,.0f}"
            )
    # Material costs variance — compare (cogs + opex) actual vs plan
    for r in cost_rows:
        plan = float(r.get("plan_cogs", 0) or 0) + float(r.get("plan_opex", 0) or 0)
        actual = float(r.get("cogs", 0) or 0) + float(r.get("opex", 0) or 0)
        if plan and abs(actual - plan) / plan >= 0.05:
            direction = "over" if actual > plan else "under"
            material_variances.append(
                f"{r.get('month', '')} total costs ran {direction} plan by "
                f"${abs(actual - plan):,.0f}"
            )

    commentary_start = callout_start + 4
    if commentary_entries or material_variances:
        # Section header
        hdr = summary.cell(row=commentary_start, column=1, value="Variance Commentary")
        hdr.font = _font(size=13, bold=True, color=NAVY)
        summary.merge_cells(
            start_row=commentary_start, start_column=1,
            end_row=commentary_start, end_column=4,
        )
        summary.row_dimensions[commentary_start].height = 22
        row_cursor = commentary_start + 1

        if commentary_entries:
            # Render operator-supplied commentary verbatim
            for entry in commentary_entries:
                topic = str(entry.get("topic") or entry.get("month") or "Note")
                text = str(entry.get("text") or "").strip()
                if not text:
                    text = f"[TBD — commentary on {topic}]"
                topic_cell = summary.cell(row=row_cursor, column=1, value=topic)
                topic_cell.font = _font(size=11, bold=True, color=INK)
                summary.merge_cells(
                    start_row=row_cursor, start_column=1,
                    end_row=row_cursor, end_column=4,
                )
                row_cursor += 1
                text_cell = summary.cell(row=row_cursor, column=1, value=text)
                text_cell.font = _font(size=10, color=INK)
                text_cell.alignment = Alignment(
                    wrap_text=True, vertical="top", horizontal="left"
                )
                summary.merge_cells(
                    start_row=row_cursor, start_column=1,
                    end_row=row_cursor, end_column=4,
                )
                summary.row_dimensions[row_cursor].height = 36
                row_cursor += 1
        else:
            # BOUND path: no commentary supplied, but material variances exist.
            # Render [TBD] stubs so the section isn't empty and the operator
            # sees exactly what's waiting on their input.
            for mv in material_variances:
                tbd_cell = summary.cell(
                    row=row_cursor, column=1,
                    value=f"[TBD — {mv}. Commentary needed.]"
                )
                tbd_cell.font = _font(size=10, italic=True, color=GREY)
                summary.merge_cells(
                    start_row=row_cursor, start_column=1,
                    end_row=row_cursor, end_column=4,
                )
                row_cursor += 1

        sheet_extents["Summary"] = row_cursor - 1
    else:
        sheet_extents["Summary"] = callout_start + 3

    _autosize(summary, [22, 20, 20, 20])

    return wb, sheet_extents


# ═══════════════════════════════════════════════════════════════════════════════
#  BUILDER REGISTRY — one-line add to extend the spec vocabulary.
# ═══════════════════════════════════════════════════════════════════════════════

BUILDERS: dict[str, Any] = {
    "monthly_business_review": _build_monthly_business_review,
}


# ═══════════════════════════════════════════════════════════════════════════════
#  PATH RESOLUTION — sandboxed. Accepts an optional client_slug and a resolver
#  callable injected by norm.py (so this module doesn't need to import norm's
#  client-path helpers — avoids an import cycle when norm.py is split further).
# ═══════════════════════════════════════════════════════════════════════════════

# Injected by norm.py at import time via set_path_resolver().
_PATH_RESOLVER = None

def set_path_resolver(resolver) -> None:
    """norm.py calls this once at import, passing a callable
        (slug_or_None) -> Path of <active_client>/deliverables/
    so this module can write files into the correct workspace without taking
    a hard import dependency on norm.py's path helpers."""
    global _PATH_RESOLVER
    _PATH_RESOLVER = resolver


def _resolve_output_path(client_slug: str | None, category: str,
                         filename: str) -> Path:
    """Return the sandboxed absolute path for the xlsx. Raises XlsxSpecError
    on invalid category (matches norm.py's DELIVERABLE_DIRS) or sandbox escape.
    """
    if category not in {"reports", "audits", "blueprints", "content"}:
        raise XlsxSpecError(
            f"invalid category {category!r}; must be one of "
            f"reports, audits, blueprints, content"
        )
    safe_name = _sanitize_filename(filename)
    if _PATH_RESOLVER is None:
        # Fallback for direct-script-mode tests: use ~/.tavernos/clients/<slug>/
        base = (
            Path.home() / ".tavernos" / "clients"
            / (client_slug or "_self") / "deliverables"
        )
    else:
        base = _PATH_RESOLVER(client_slug)
    base = base.resolve()
    final = (base / category / safe_name).resolve()
    try:
        final.relative_to(base)
    except ValueError:
        raise XlsxSpecError("path escaped client sandbox")
    return final


# ═══════════════════════════════════════════════════════════════════════════════
#  MAIN ENTRY — build_from_spec. Called by the tool dispatcher in norm.py.
# ═══════════════════════════════════════════════════════════════════════════════

def build_from_spec(spec: dict, client_slug: str | None = None) -> dict:
    """Validate spec, run the matching builder, apply formula guards, write
    the workbook + a sibling .spec.json for auditability, return a
    deliverable-shaped dict matching the existing norm.py contract.

    Returns:
        {
          "ok":       True,
          "filename": "example-mbr-2026-04.xlsx",
          "path":     "clients/example/deliverables/reports/...",
          "abs_path": "/home/dan/.tavernos/clients/.../reports/...",
          "category": "reports",
          "template": "monthly_business_review",
          "bytes":    43210,
          "warnings": [...],          # formula-guard warnings, may be []
        }

    On validation failure, raises XlsxSpecError. Callers (the tool dispatcher)
    should catch and return the message as a tool_result error to the agent.
    """
    _validate_spec(spec)
    template = spec["template"]
    builder = BUILDERS[template]
    category = spec.get("category", "reports")

    wb, sheet_extents = builder(spec)

    # Formula guards — walk every cell, check strings that are formulas OR
    # look like formulas missing the leading '='. The latter catches the
    # dumb-but-common "agent forgot the = sign" failure that silently
    # writes the string as a text cell.
    warnings: list[str] = []
    # Pick up any builder-stashed warnings (e.g. KPI value-vs-formula nudges
    # that the builder collected while writing the Summary sheet)
    extra = getattr(wb, "_tavernos_extra_warnings", None)
    if extra:
        warnings.extend(extra)
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for cell in row:
                v = cell.value
                if not isinstance(v, str):
                    continue
                if v.startswith("="):
                    warnings.extend(_check_formula(v, sheet_extents))
                elif _looks_like_unequals_formula(v):
                    warnings.append(
                        f"cell {cell.coordinate} on sheet {ws.title!r} contains "
                        f"{v!r} which looks like a formula but does not start "
                        f"with '=' — it will render as literal text in Excel"
                    )

    final_path = _resolve_output_path(client_slug, category, spec["filename"])
    final_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(str(final_path))

    # Sidecar spec for Phase 3 evaluation and regeneration workflows.
    spec_copy = dict(spec)
    spec_copy["_generated_at"] = datetime.now().isoformat(timespec="seconds")
    spec_copy["_warnings"] = warnings
    spec_path = final_path.with_suffix(".spec.json")
    spec_path.write_text(
        json.dumps(spec_copy, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    user_dir = Path.home() / ".tavernos"
    try:
        rel = final_path.relative_to(user_dir).as_posix()
    except ValueError:
        rel = final_path.as_posix()

    return {
        "ok":       True,
        "filename": final_path.name,
        "path":     rel,
        "abs_path": str(final_path),
        "category": final_path.parent.name,
        "template": template,
        "bytes":    final_path.stat().st_size,
        "warnings": warnings,
    }


# ═══════════════════════════════════════════════════════════════════════════════
#  PRE-FLIGHT — Phase 3 addition. Public hook returning a list of mechanical
#  issues the evaluator pipeline can surface BEFORE the rubric LLM call.
#  Complements the formula guards (which run inside build_from_spec and are
#  exposed via result["warnings"]). Pre-flight adds structural checks that
#  don't require a built workbook — so it can run fast, before generation,
#  or on a saved result. Returns [] if everything looks mechanically sound.
# ═══════════════════════════════════════════════════════════════════════════════

def preflight(spec: dict, result: dict | None = None) -> list[str]:
    """Mechanical sanity checks. Returns a list of human-readable issue
    strings. Empty list = all clear. NEVER raises — the evaluator pipeline
    must survive malformed inputs.

    `result` is the dict returned by build_from_spec; if supplied, formula-
    guard warnings are pulled from result["warnings"]. If not supplied, only
    spec-level checks run (useful for pre-generation validation).

    Checks performed:
      P1. Spec has a template key matching a known builder
      P2. MBR has either revenue.rows or costs.rows (empty-on-both is a signal)
      P3. Filename looks reasonable after sanitization
      P4. Formula-guard warnings from the build (if result provided)
      P5. File size sanity — a workbook under 5KB is almost certainly empty
    """
    issues = []
    try:
        if not isinstance(spec, dict):
            issues.append("preflight: spec is not a dict")
            return issues
        template = spec.get("template")
        if template not in BUILDERS:
            issues.append(f"preflight P1: unknown template {template!r}")
        # Template-specific structural checks
        if template == "monthly_business_review":
            rev = (spec.get("revenue") or {}).get("rows") or []
            costs = (spec.get("costs") or {}).get("rows") or []
            if not rev and not costs:
                issues.append("preflight P2: MBR has no revenue or cost rows — "
                              "deliverable will be a KPI-only skeleton")
            # P6 — commentary gap check. MBRs with material variances but no
            # commentary will score ~1 on variance_commentary. Surface this
            # to Rebecca so she knows to elicit it from the operator, and to
            # the operator so they see what's missing before shipping.
            commentary = spec.get("commentary") or []
            material_variances = []
            for r in rev:
                plan = float(r.get("plan", 0) or 0)
                actual = float(r.get("actual", 0) or 0)
                if plan and abs(actual - plan) / plan >= 0.05:
                    material_variances.append(f"{r.get('month','?')} revenue")
            for r in costs:
                plan = float(r.get("plan_cogs", 0) or 0) + float(r.get("plan_opex", 0) or 0)
                actual = float(r.get("cogs", 0) or 0) + float(r.get("opex", 0) or 0)
                if plan and abs(actual - plan) / plan >= 0.05:
                    material_variances.append(f"{r.get('month','?')} costs")
            if material_variances and not commentary:
                issues.append(
                    f"preflight P6: {len(material_variances)} material "
                    f"variance(s) with no commentary ({', '.join(material_variances[:3])}"
                    f"{'...' if len(material_variances) > 3 else ''}). "
                    "MBR will render [TBD] placeholders. Ask the operator "
                    "for one sentence per variance — driver + impact."
                )
        # P4 — carry through formula guards
        if result is not None:
            for w in result.get("warnings", []) or []:
                issues.append(f"preflight P4 (formula guard): {w}")
            # P5 — size sanity
            if result.get("bytes", 0) < 5000:
                issues.append(f"preflight P5: workbook is only "
                              f"{result.get('bytes', 0)} bytes — likely empty")
    except Exception as e:
        issues.append(f"preflight crashed: {type(e).__name__}: {e}")
    return issues


# ═══════════════════════════════════════════════════════════════════════════════
#  TOOL REGISTRATION — exposed to norm.py's first-party tool registry.
# ═══════════════════════════════════════════════════════════════════════════════

TOOL_NAME = "generate_xlsx_report"
ALLOWED_AGENTS = {"rebecca"}  # Woody has his own docx tool in artifact_docx

TOOL_SCHEMA = {
    "name": TOOL_NAME,
    "description": (
        "Generate a branded Excel workbook (.xlsx) and save it into the "
        "active client's deliverables folder. Use this tool whenever the "
        "user asks for a spreadsheet deliverable, monthly business review, "
        "KPI report, variance analysis, or any .xlsx artifact. The tool "
        "writes a real file to disk and returns the saved path — do NOT "
        "describe spreadsheet contents in chat as a substitute for calling "
        "this tool."
    ),
    "input_schema": {
        "type": "object",
        "required": ["artifact", "template", "filename"],
        "properties": {
            "artifact": {
                "type": "string",
                "const": "xlsx",
                "description": "Must be the literal string 'xlsx'.",
            },
            "template": {
                "type": "string",
                "enum": list(BUILDERS.keys()),
                "description": (
                    "Workbook template. Currently only "
                    "'monthly_business_review' is supported."
                ),
            },
            "filename": {
                "type": "string",
                "description": (
                    "Kebab-case filename without extension, e.g. "
                    "'example-mbr-2026-04'. The tool adds '.xlsx'."
                ),
            },
            "category": {
                "type": "string",
                "enum": ["reports", "audits", "blueprints", "content"],
                "default": "reports",
            },
            "meta": {
                "type": "object",
                "properties": {
                    "client_name":  {"type": "string"},
                    "period":       {"type": "string"},
                    "prepared_by":  {"type": "string"},
                },
            },
            "revenue": {
                "type": "object",
                "properties": {
                    "rows": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "required": ["month", "actual", "plan"],
                            "properties": {
                                "month":  {"type": "string"},
                                "actual": {"type": "number"},
                                "plan":   {"type": "number"},
                            },
                        },
                    },
                },
            },
            "costs": {
                "type": "object",
                "properties": {
                    "rows": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "required": [
                                "month", "cogs", "opex",
                                "plan_cogs", "plan_opex",
                            ],
                            "properties": {
                                "month":     {"type": "string"},
                                "cogs":      {"type": "number"},
                                "opex":      {"type": "number"},
                                "plan_cogs": {"type": "number"},
                                "plan_opex": {"type": "number"},
                            },
                        },
                    },
                },
            },
            "kpis": {
                "type": "array",
                "maxItems": 4,
                "items": {
                    "type": "object",
                    "required": ["label"],
                    "properties": {
                        "label":   {"type": "string"},
                        "value":   {"type": ["number", "string", "null"]},
                        "formula": {"type": ["string", "null"]},
                        "format":  {"type": "string"},
                        "mono":    {"type": "boolean"},
                    },
                },
            },
        },
    },
}


def get_tool_registration() -> dict:
    """Return the dict norm.py registers into its first-party tool registry."""
    return {
        "name":           TOOL_NAME,
        "schema":         TOOL_SCHEMA,
        "allowed_agents": ALLOWED_AGENTS,
        "handler":        _tool_handler,
    }


def _tool_handler(tool_args: dict, agent_name: str,
                  client_slug: str | None) -> str:
    """Tool dispatcher. Returns a plain-text tool_result payload that goes
    back to the agent. Success: human-readable confirmation including the
    saved path + any warnings. Failure: the error message."""
    try:
        result = build_from_spec(tool_args, client_slug=client_slug)
    except XlsxSpecError as e:
        return f"Spec error: {e}"
    except Exception as e:
        return (
            "Unexpected error while generating workbook: "
            f"{type(e).__name__}: {e}\n"
            + traceback.format_exc(limit=3)
        )

    lines = [
        # Sentinel line — norm.py's dispatcher parses this for the post-stream
        # "✓ Deliverable saved" banner, then strips it before the rest of the
        # text is returned to the agent as tool_result content.
        # Format: __TAVERNOS_DELIVERABLE__\t<filename>\t<path>\t<bytes>
        f"__TAVERNOS_DELIVERABLE__\t{result['filename']}\t{result['path']}"
        f"\t{result['bytes']}",
        "Workbook saved.",
        f"Filename: {result['filename']}",
        f"Path:     {result['path']}",
        f"Template: {result['template']}",
        f"Size:     {result['bytes']} bytes",
    ]
    if result["warnings"]:
        lines.append("")
        lines.append("Formula guard warnings (Phase 3 will evaluate):")
        for w in result["warnings"][:8]:
            lines.append(f"  - {w}")
        if len(result["warnings"]) > 8:
            lines.append(
                f"  - ... and {len(result['warnings']) - 8} more"
            )
    return "\n".join(lines)