#!/bin/bash
# install-autostart-mac.sh
# Registers TavernOS web UI (norm --web) to auto-start at login and
# auto-restart on crash. Uses launchd (macOS native).
#
# Run from Terminal:
#   chmod +x install-autostart-mac.sh
#   ./install-autostart-mac.sh

set -e

LABEL="ai.tavernos.web"
PLIST_DIR="$HOME/Library/LaunchAgents"
PLIST_PATH="$PLIST_DIR/$LABEL.plist"
LOG_DIR="$HOME/.tavernos"

echo ""
echo "  TavernOS — Installing autostart for web UI"
echo "  ──────────────────────────────────────────"
echo ""

# ── Locate the 'norm' command ──────────────────────────────────────────────
NORM_PATH="$(command -v norm || true)"
if [ -z "$NORM_PATH" ]; then
    echo "  ✗ 'norm' command not found on PATH."
    echo "    Install TavernOS first: pip install tavernos"
    echo ""
    exit 1
fi
echo "  Found norm at:  $NORM_PATH"

# ── Ensure log dir exists ──────────────────────────────────────────────────
mkdir -p "$LOG_DIR"
mkdir -p "$PLIST_DIR"

# ── If already installed, unload first so we can replace cleanly ───────────
if [ -f "$PLIST_PATH" ]; then
    echo "  Replacing existing autostart agent..."
    launchctl unload "$PLIST_PATH" 2>/dev/null || true
fi

# ── Write the plist ────────────────────────────────────────────────────────
# KeepAlive=true — launchd restarts the process if it exits for any reason.
# That covers Part C from the plan (crash recovery) without needing any
# supervisor logic inside norm.py.
cat > "$PLIST_PATH" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>${LABEL}</string>

    <key>ProgramArguments</key>
    <array>
        <string>${NORM_PATH}</string>
        <string>--web</string>
    </array>

    <key>RunAtLoad</key>
    <true/>

    <key>KeepAlive</key>
    <true/>

    <key>ThrottleInterval</key>
    <integer>10</integer>

    <key>StandardOutPath</key>
    <string>${LOG_DIR}/web.log</string>

    <key>StandardErrorPath</key>
    <string>${LOG_DIR}/web.err.log</string>

    <key>EnvironmentVariables</key>
    <dict>
        <key>PATH</key>
        <string>/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin</string>
    </dict>
</dict>
</plist>
EOF

launchctl load "$PLIST_PATH"

echo ""
echo "  ✓ TavernOS web UI will auto-start at login."
echo "  ✓ launchd will restart it if it crashes (throttled to 1 restart per 10s)."
echo ""
echo "  Logs:"
echo "    stdout  →  $LOG_DIR/web.log"
echo "    stderr  →  $LOG_DIR/web.err.log"
echo ""
echo "  Web UI should already be starting — check with:"
echo "    norm --web-status"
echo ""
echo "  To remove autostart later:"
echo "    ./uninstall-autostart-mac.sh"
echo ""
