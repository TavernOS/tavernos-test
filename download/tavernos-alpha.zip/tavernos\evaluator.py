"""
tavernos/evaluator.py — Phase 3 evaluation layer.

Implements the rubric-driven scoring system specified in Doc 2 (Deliverable
Evaluation Rubrics, April 2026). Every deliverable produced by Woody,
Rebecca, Lilith, Coach, or Cliff passes through this module after save,
scored by a dedicated `eval` agent, logged to the perf database, and
regenerated if it falls below threshold.

Architecture
------------
Two-layer design:

  Layer 1 — Pre-flight (mechanical, in-module, no LLM)
    Each artifact module exposes preflight(spec, result) -> list[str] that
    returns dumb-failure warnings catchable without a second LLM call:
    missing sections, formula syntax errors, empty deliverables. The
    existing xlsx formula guards graduated to this pattern.

  Layer 2 — Evaluator agent (this module)
    A second LLM pass using the rubric for the deliverable's type. Scores
    every dimension, writes a structured critique, logs to
    skill_performance.db's deliverable_scores table, triggers regeneration
    when below threshold.

Design choices codified here
----------------------------
  - Evaluator model tier matches the generator's tier (per operator decision
    Apr 22, 2026). Opus generator → Opus evaluator; Haiku → Haiku. Falls
    back to Sonnet if tier can't be resolved.
  - Max 2 regeneration attempts. After that, deliverable surfaces with a
    warning banner showing failing dimensions (per operator decision).
  - Operator always overrides. The rubric doc's "scores are signals, not
    verdicts" framing is enforced by NEVER blocking deliverable access —
    the banner warns, it doesn't gate.
  - Calibration storage ships, but the manual-rating flow is deferred to a
    follow-up session. The table exists so first-50-per-type data can be
    captured once the UI lands.

Evaluator agent identity
------------------------
The 11th agent, named `eval`. NOT Cheers-themed because it's unlisted and
customer-invisible — it's a silent back-office role. Not in the router.
Not accessible via `/eval <agent>`. Surfaces only via `/scores
--deliverables` and the warning banner when regen fails.

Rubric source
-------------
All seven rubrics below are verbatim-equivalent to Doc 2 v1 (April 2026).
If Doc 2 updates, this module updates. Rubric weights, thresholds, and
dimension anchors are the contract with the operator.
"""

from __future__ import annotations

import json
import re
import sqlite3
import statistics
import threading
import traceback
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Optional


# ═══════════════════════════════════════════════════════════════════════════════
#  RUBRICS — Doc 2 codified. Each is a RubricSpec with:
#    - name:            human-readable, appears in UI
#    - deliverable_type: slug used for routing + DB keys
#    - agent_owner:     which agent typically produces this deliverable
#    - dimensions:      list of (name, weight, description, anchor_5, anchor_3, anchor_1)
#    - threshold_avg:   weighted avg floor (e.g. 4.0)
#    - threshold_hard:  {dim_name: floor} for dimensions with extra-strict thresholds
#    - regen_triggers:  {dim_name: prompt_add} — what to inject on regeneration
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class Dimension:
    name: str
    weight: float
    description: str
    anchor_5: str
    anchor_3: str
    anchor_1: str


@dataclass
class RubricSpec:
    name: str
    deliverable_type: str
    agent_owner: str
    dimensions: list[Dimension]
    threshold_avg: float
    threshold_hard: dict[str, float] = field(default_factory=dict)
    regen_triggers: dict[str, str] = field(default_factory=dict)

    def weighted_avg(self, scores: dict[str, float]) -> float:
        """Compute weighted average from a {dim_name: score} dict. Missing
        dimensions are skipped (don't zero out) and weights are renormalized
        over present dimensions — so a partial eval doesn't inflate failures."""
        total_w = 0.0
        total = 0.0
        for dim in self.dimensions:
            if dim.name in scores:
                total += scores[dim.name] * dim.weight
                total_w += dim.weight
        return (total / total_w) if total_w > 0 else 0.0

    def passes_threshold(self, scores: dict[str, float]) -> tuple[bool, list[str]]:
        """Return (pass_bool, list_of_failing_dims). A deliverable passes iff
        the weighted avg meets threshold_avg AND every dimension in
        threshold_hard meets its floor."""
        failing = []
        if self.weighted_avg(scores) < self.threshold_avg:
            failing.append(f"weighted_avg<{self.threshold_avg}")
        for dim_name, floor in self.threshold_hard.items():
            if scores.get(dim_name, 0) < floor:
                failing.append(f"{dim_name}<{floor}")
        return (len(failing) == 0, failing)

    def regeneration_prompt(self, scores: dict[str, float],
                            critiques: dict[str, str]) -> str:
        """Assemble a regeneration prompt from the triggers for failing
        dimensions. If no triggers match (unlikely), returns a generic
        "below threshold on <dims>" instruction."""
        parts = []
        for dim in self.dimensions:
            score = scores.get(dim.name, 5.0)
            # Triggers fire when a dimension's hard floor is missed OR when
            # the dim has a regen trigger and scored below 3.0 (per Doc 2
            # pattern — "below 3.0 → regenerate with X" for most dims).
            hard_floor = self.threshold_hard.get(dim.name)
            trigger = self.regen_triggers.get(dim.name)
            if trigger and (
                (hard_floor is not None and score < hard_floor)
                or (hard_floor is None and score < 3.0)
            ):
                critique = critiques.get(dim.name, "").strip()
                if critique:
                    parts.append(f"- {dim.name} scored {score:.1f}. "
                                 f"Critique: {critique} {trigger}")
                else:
                    parts.append(f"- {dim.name} scored {score:.1f}. {trigger}")
        if not parts:
            dims_low = [d for d in scores if scores[d] < 3.0]
            parts.append(f"- Overall below threshold. Weak dimensions: "
                         f"{', '.join(dims_low)}. Tighten specificity and grounding.")
        return (
            "REGENERATION — your previous draft scored below threshold. "
            "Regenerate the deliverable addressing these specific feedback "
            "points:\n" + "\n".join(parts)
        )


# ─── Rubric 1: Client Proposal (Woody) ──────────────────────────────────────
RUBRIC_CLIENT_PROPOSAL = RubricSpec(
    name="Client Proposal",
    deliverable_type="client_proposal",
    agent_owner="woody",
    threshold_avg=4.0,
    threshold_hard={},  # "no single dim below 3.0" is enforced inline below
    dimensions=[
        Dimension("specificity", 0.25,
            "Quotes the prospect back to themselves — named people, specific "
            "numbers, specific tools, specific pain points from the discovery call.",
            "Multiple named specifics from discovery (people, numbers, tools, phrases)",
            "General industry context, little client-specific grounding",
            "Obviously generic, no evidence of discovery call"),
        Dimension("problem_framing", 0.20,
            "Frames the problem from the prospect's POV, not the consultant's "
            "service menu. The prospect thinks 'yes, that's exactly what I said.'",
            "Uses prospect's own framing and evidence, feels like their voice",
            "Correctly identified but framed from the consultant's angle",
            "Problem framing is wrong or missing"),
        Dimension("scope_clarity", 0.20,
            "Every deliverable concretely named. Prospect can point at an "
            "artifact after each phase ships. Non-goals explicit.",
            "Every deliverable verifiable; non-goals section present",
            "Deliverables listed but a few vague ('strategic analysis')",
            "Scope is hand-waved"),
        Dimension("pricing_transparency", 0.15,
            "Prices stated. Payment terms stated. What's included vs not "
            "unambiguous. No 'contact us for pricing'.",
            "Clear prices with options, payment terms, inclusions/exclusions",
            "Single price, unclear terms",
            "No price or misleading pricing"),
        Dimension("call_to_action", 0.10,
            "One action the prospect can say yes to. Not 'let's schedule another "
            "call' — 'reply with Option 2 and we'll send the SOW by Friday.'",
            "Single, concrete, one-click action with clear path forward",
            "Options listed but no recommendation",
            "No call to action"),
        Dimension("voice_and_tone", 0.10,
            "Reads like the consultant wrote it. No 'leverage', 'cutting-edge', "
            "'in today's rapidly evolving landscape'. Uses operator voice profile.",
            "Matches operator voice, zero generic language",
            "Professional but anonymous",
            "Obviously AI-written"),
    ],
    regen_triggers={
        "specificity":       "Regenerate with discovery notes re-emphasized — "
                             "pull named people, specific numbers, tools, and "
                             "exact prospect phrases into the opening paragraph.",
        "problem_framing":   "Regenerate with the prospect's own quotes injected "
                             "verbatim in the problem-framing section.",
        "scope_clarity":     "Regenerate with the explicit constraint: each "
                             "deliverable must be a named artifact, not a "
                             "service category. Add a non-goals section.",
        "voice_and_tone":    "Regenerate with the voice profile re-injected; "
                             "ban 'leverage', 'cutting-edge', 'synergy', "
                             "'in today's rapidly evolving landscape'.",
        "pricing_transparency": "Regenerate with specific prices, payment terms, "
                             "and inclusion/exclusion list. No 'contact us'.",
        "call_to_action":    "Regenerate with a single concrete next action the "
                             "prospect can reply yes to.",
    },
)


# ─── Rubric 2: Operational Audit (Lilith) ───────────────────────────────────
RUBRIC_OPERATIONAL_AUDIT = RubricSpec(
    name="Operational Audit",
    deliverable_type="operational_audit",
    agent_owner="lilith",
    threshold_avg=4.0,
    threshold_hard={"evidence_density": 3.5},
    dimensions=[
        Dimension("evidence_density", 0.30,
            "Every finding grounded in a specific observation from ingested "
            "materials. No claims without citations.",
            "Every finding cites specific source; 8+ distinct sources referenced",
            "Findings are real but citation is sparse",
            "Findings feel like generic diagnosis with client name attached"),
        Dimension("prioritization_quality", 0.20,
            "Findings ranked by impact × effort, not alphabetically or by when "
            "they appeared in notes.",
            "Clear prioritization framework, top 3 defensibly the biggest issues",
            "Priorities listed but rationale weak",
            "No prioritization or wrong prioritization"),
        Dimension("roi_math_transparency", 0.20,
            "Hours-saved and dollar-savings estimates with the math shown. A CFO "
            "can recompute and find no errors.",
            "All numbers shown with computation, assumptions named",
            "Numbers stated, math opaque",
            "'Significant savings expected' hand-waving"),
        Dimension("actionability", 0.15,
            "Every finding paired with a concrete recommendation. Client can "
            "start implementing Monday.",
            "Every finding has a specific, sized, owner-assignable recommendation",
            "Recommendations exist but lack specificity",
            "Findings without recommendations"),
        Dimension("exec_summary", 0.10,
            "Page one readable in three minutes, conveys the three most "
            "important things.",
            "Executive summary exists, dense, names top findings with numbers",
            "Summary exists but buries the lede",
            "No executive summary"),
        Dimension("honesty_about_uncertainty", 0.05,
            "Where evidence is thin or conclusions tentative, document says so.",
            "Uncertainty called out explicitly in 2+ places",
            "Overclaiming in one or two spots",
            "Everything stated as known fact"),
    ],
    regen_triggers={
        "evidence_density":      "Regenerate with explicit instruction: cite the "
                                 "specific source file per finding.",
        "roi_math_transparency": "Regenerate with 'show your math for every "
                                 "number' in system prompt.",
        "actionability":         "Regenerate with requirement that every finding "
                                 "end with a named next step.",
        "prioritization_quality":"Regenerate with explicit impact × effort "
                                 "ranking applied to every finding.",
        "exec_summary":          "Regenerate with a dense executive summary on "
                                 "page 1 naming the top 3 findings with numbers.",
    },
)


# ─── Rubric 3: PRD / Product Spec (Coach) ───────────────────────────────────
RUBRIC_PRD = RubricSpec(
    name="PRD / Product Spec",
    deliverable_type="prd",
    agent_owner="coach",
    threshold_avg=4.0,
    threshold_hard={"scope_clarity": 4.0},
    dimensions=[
        Dimension("problem_framing", 0.20,
            "Problem grounded in specific evidence (user quotes, ticket patterns, "
            "churn signals). Not a solution looking for a problem.",
            "Problem grounded in multiple specific evidence points, measurable",
            "Problem stated but evidence thin",
            "No real problem named"),
        Dimension("scope_clarity", 0.25,
            "Goals named and ranked. Non-goals explicit. Open questions "
            "separated into blocking vs non-blocking.",
            "Goals ranked, non-goals explicit, open questions triaged",
            "Goals present, non-goals missing or thin",
            "Scope is ambiguous"),
        Dimension("user_stories_quality", 0.15,
            "Stories from user perspective, specific context, testable.",
            "Stories name specific user archetypes, include context and measurable outcomes",
            "Stories formatted correctly but generic",
            "No user stories, or requirements dressed as stories"),
        Dimension("functional_requirements", 0.15,
            "Numbered, testable, grouped by area. Each answers 'is this done?' "
            "unambiguously.",
            "Testable requirements, grouped logically, no ambiguity",
            "Requirements specified but not always verifiable",
            "Hand-waved requirements"),
        Dimension("success_metrics", 0.15,
            "Three metrics max. Each has a target and measurement source. "
            "Primary / secondary / leading separated.",
            "Three metrics, targets, sources, clean primary/secondary/leading",
            "Metrics listed but unmeasurable",
            "No metrics"),
        Dimension("rollout_phases", 0.10,
            "Phases have durations, audiences, criteria to advance.",
            "Clear phases, durations, gate criteria",
            "Phases listed without advancement gates",
            "No phasing"),
    ],
    regen_triggers={
        "scope_clarity":     "Regenerate with 'non-goals must be explicit' instruction.",
        "user_stories_quality": "Regenerate with template enforcement: 'As <specific "
                             "archetype>, in <context>, I need <measurable outcome>.'",
        "success_metrics":   "Regenerate with requirement for measurement source per metric.",
        "problem_framing":   "Regenerate with user quotes or ticket patterns pulled in as evidence.",
        "functional_requirements": "Regenerate with numbered, testable requirements grouped by area.",
        "rollout_phases":    "Regenerate with explicit gate criteria per phase.",
    },
)


# ─── Rubric 4: Slide Deck (Rebecca) ─────────────────────────────────────────
RUBRIC_SLIDE_DECK = RubricSpec(
    name="Slide Deck",
    deliverable_type="executive_review_deck",  # matches artifact_pptx template key
    agent_owner="rebecca",
    threshold_avg=4.0,
    threshold_hard={"narrative_arc": 3.5},
    dimensions=[
        Dimension("narrative_arc", 0.25,
            "Beginning, middle, end tells a coherent story. A reader flipping "
            "through without the operator still gets the argument.",
            "Clear story: context → insight → recommendation → path forward",
            "Slides are logical but disconnected",
            "No discernible narrative"),
        Dimension("content_density", 0.15,
            "One main point per slide. Headline states the point; content supports.",
            "One point per slide, headlines are assertions not labels",
            "Some slides are overloaded",
            "Wall-of-text slides"),
        Dimension("opening_closing", 0.15,
            "First slide sets stakes. Last slide names next action. No agenda-as-slide-2.",
            "Opening earns attention, closing names one action",
            "Functional opening and closing",
            "Agenda slide up front, no clear close"),
        Dimension("data_viz_choices", 0.15,
            "Chart type matches the data. Bars for comparisons, lines for trends, "
            "stacks for parts-of-whole. Pies only for 2–3 categories.",
            "Chart types match data structure, annotations call out insights",
            "Charts work but aren't optimal",
            "Pie charts with 8 slices, or charts that obscure the point"),
        Dimension("visual_balance", 0.15,
            "Text, whitespace, visuals balanced. No slide is a text dump.",
            "Every slide uses layout intentionally",
            "Balance is functional but uninspired",
            "Layout appears accidental"),
        Dimension("speaker_notes", 0.15,
            "Notes anticipate what the operator would say live. Not just slide "
            "bullets restated.",
            "Notes complement slides, anticipate questions",
            "Notes restate the slide",
            "No notes"),
    ],
    regen_triggers={
        "narrative_arc":   "Regenerate with explicit story structure: context → "
                           "insight → recommendation → path forward. Each slide "
                           "must advance the argument.",
        "content_density": "Regenerate with constraint: one point per slide, the "
                           "headline IS the point (assertion, not label).",
        "speaker_notes":   "Regenerate with speaker notes required on every "
                           "content slide — 2–3 sentences anticipating the live talk.",
        "data_viz_choices": "Regenerate with chart-type review per slide (bars for "
                            "compare, lines for trend, no pies over 3 slices).",
        "opening_closing": "Regenerate with opening slide that earns attention "
                           "(stakes / hook) and closing slide naming one action.",
    },
)


# ─── Rubric 5: Financial Model / Spreadsheet (Rebecca) ──────────────────────
RUBRIC_FINANCIAL_MODEL = RubricSpec(
    name="Monthly Business Review",
    deliverable_type="monthly_business_review",  # matches artifact_xlsx template key
    agent_owner="rebecca",
    threshold_avg=4.0,
    threshold_hard={"formula_correctness": 5.0},  # zero tolerance — Doc 2 explicit
    dimensions=[
        Dimension("formula_correctness", 0.25,
            "Do formulas COMPUTE CORRECTLY? This dimension is strictly about "
            "computational correctness, NOT clarity. Clarity of labels, use of "
            "named ranges, and self-documentation belong to structural_clarity. "
            "ZERO TOLERANCE: anything below 5 triggers regeneration regardless "
            "of other scores — because a wrong formula in a financial "
            "deliverable is a worst-case outcome.",
            "Every formula computes what its label says. No circular refs. No "
            "hard-coded values where formulas belong. Division has IFERROR "
            "wrappers. Score 5 when formulas are verifiably correct, even if "
            "labels or references could be clearer.",
            "Some formulas wrong or missing. A label-clarity issue alone is "
            "NOT grounds for a 3 here — score that down in structural_clarity.",
            "Formulas broken, circular, or absent."),
        Dimension("structural_clarity", 0.25,
            "Is the workbook self-documenting? Inputs distinguishable from "
            "calculated cells. Sheet names and labels make the reader's job "
            "easy. Formulas use named ranges or clear references so intent "
            "is readable without chasing coordinates. This is where label "
            "clarity and self-documentation are scored.",
            "Sheet names clear, named ranges used for cross-sheet refs, "
            "labels explicit about basis (e.g. 'Gross Margin % (Rev - COGS)' "
            "not just 'Gross Margin %'), reader finds any number in <15s",
            "Structure workable but mixed; a reader has to trace some "
            "references to understand intent",
            "Unreadable structure, cryptic labels, no self-documentation"),
        Dimension("variance_commentary", 0.20,
            "Explains WHY numbers differ from plan, not just that they do. "
            "Materially-missing-plan lines have commentary. This is what turns "
            "a report into a review — the 'so what' behind the variance.",
            "Every material variance has commentary naming the driver and impact",
            "Variance numbers present but sparse explanation",
            "Variance values shown with no commentary at all"),
        Dimension("period_comparability", 0.10,
            "Trends visible across months. MoM (or QoQ) deltas present, not just "
            "month-in-isolation snapshots. Reader can see direction, not just state.",
            "Trend sheet with explicit MoM Delta columns; period-over-period visible",
            "Trend exists but deltas not computed or not obvious",
            "No trend view — each month in isolation"),
        Dimension("output_summary", 0.10,
            "Summary view shows the 3–5 numbers a decision-maker cares about.",
            "Clean summary tab with key metrics and live updates",
            "Summary exists but buried",
            "Bottom line unclear"),
        Dimension("formatting_polish", 0.10,
            "Consistent number formatting (currency, percent, thousands separators). "
            "Borders and shading guide the eye.",
            "Consistent formatting, intentional use as signal",
            "Inconsistent but readable",
            "No formatting"),
    ],
    regen_triggers={
        "formula_correctness":    "CRITICAL regeneration — audit every formula "
                                  "for COMPUTATIONAL correctness only. Fix "
                                  "broken refs, replace hard-coded values with "
                                  "references, eliminate circular references. "
                                  "Label clarity issues go to structural_clarity.",
        "structural_clarity":     "Regenerate with named ranges for cross-sheet "
                                  "totals, explicit labels that state the basis "
                                  "of each metric, and clear input-vs-calculated "
                                  "separation.",
        "variance_commentary":    "Regenerate with commentary on every material "
                                  "plan variance — named driver, named impact, "
                                  "one sentence each.",
        "period_comparability":   "Regenerate with an explicit MoM (or QoQ) "
                                  "delta column and a trend view so direction is "
                                  "visible, not just per-month values.",
        "output_summary":         "Regenerate with a Summary sheet showing the "
                                  "3–5 key outputs live.",
    },
)


# ─── Rubric 6: Meeting Summary (Coach) ──────────────────────────────────────
RUBRIC_MEETING_SUMMARY = RubricSpec(
    name="Meeting Summary",
    deliverable_type="meeting_summary",
    agent_owner="coach",
    threshold_avg=4.0,
    threshold_hard={"action_item_clarity": 4.0},
    dimensions=[
        Dimension("decisions_extracted", 0.25,
            "Distinguishes decisions from discussion topics. If no decisions were "
            "made, says so plainly.",
            "Decisions clearly separated from topics; each includes rationale",
            "Decisions mixed with topics",
            "No distinction between decision and discussion"),
        Dimension("action_item_clarity", 0.25,
            "Every action names a specific task, owner, and date (or 'TBD' flagged).",
            "Every action specific, owned, dated",
            "Actions listed but ownership or deadlines missing",
            "No action items, or items without owners"),
        Dimension("open_questions", 0.15,
            "Unresolved questions captured with the person responsible.",
            "Open questions listed with owner and deadline",
            "Questions captured but un-owned",
            "No open-questions section"),
        Dimension("scannability", 0.15,
            "Reader can skim headings and find any section in <5s.",
            "Clear headings, dense bullets, no wall-of-text",
            "Functional structure",
            "Wall of text"),
        Dimension("fidelity_to_source", 0.10,
            "Nothing invented. When inferred rather than stated, marked.",
            "High fidelity, inferences flagged",
            "Some interpretation blurs facts",
            "Hallucinates decisions or actions"),
        Dimension("next_meeting_setup", 0.10,
            "Names the next meeting (or its absence) and what must happen before it.",
            "Next steps and prep required are explicit",
            "Implicit",
            "Missing"),
    ],
    regen_triggers={
        "action_item_clarity": "Regenerate with owner + date required on every action item.",
        "fidelity_to_source":  "Regenerate with explicit instruction: do not infer, "
                               "mark uncertainty. Quote source material verbatim where possible.",
        "decisions_extracted": "Regenerate with a dedicated Decisions section that "
                               "separates what was decided from what was discussed.",
        "open_questions":      "Regenerate with open questions in a named section, "
                               "each with owner and deadline.",
    },
)


# ─── Rubric 7: Research Report (Cliff) ──────────────────────────────────────
RUBRIC_RESEARCH_REPORT = RubricSpec(
    name="Research Report",
    deliverable_type="research_report",
    agent_owner="cliff",
    threshold_avg=4.0,
    threshold_hard={"source_quality": 4.0},
    dimensions=[
        Dimension("source_quality", 0.25,
            "Sources credible, current, directly relevant. Primary preferred "
            "over aggregators. Dates and authors present.",
            "Primary sources, recent, all attributed",
            "Mixed quality, citations complete",
            "Weak or missing sources"),
        Dimension("synthesis_quality", 0.25,
            "Makes sense of sources in combination. Conflicts noted.",
            "Coherent synthesis, conflicts named and resolved",
            "Serial summaries with limited synthesis",
            "No synthesis"),
        Dimension("answer_to_question", 0.20,
            "Answers the specific question asked. If unanswerable, says so.",
            "Directly answers the question, acknowledges limits",
            "Answers a related question",
            "Doesn't answer the question"),
        Dimension("key_points_extraction", 0.15,
            "Leads with a findings summary: 3–5 numbered takeaways.",
            "Clean numbered findings summary up top",
            "Implicit findings",
            "No clear findings"),
        Dimension("uncertainty_acknowledgment", 0.10,
            "Where data is thin or sources disagree, says so. Confidence signaled.",
            "Uncertainty explicit, confidence levels stated",
            "Some overclaiming",
            "All findings stated as certain"),
        Dimension("formatting_for_reuse", 0.05,
            "Structured so operator can pull sections for reuse.",
            "Reusable by section, well-structured",
            "Usable with editing",
            "Unstructured"),
    ],
    regen_triggers={
        "source_quality":          "Regenerate with explicit primary-source "
                                   "preference. Cite publication dates and authors.",
        "synthesis_quality":       "Regenerate with 'synthesize, don't summarize' "
                                   "instruction — find the story across sources.",
        "answer_to_question":      "Regenerate with the original question restated "
                                   "in the prompt; answer that specific question.",
        "key_points_extraction":   "Regenerate with a numbered findings summary at "
                                   "the top — 3–5 takeaways that stand alone.",
    },
)


# All rubrics, keyed by deliverable_type for fast lookup from the dispatcher
RUBRICS: dict[str, RubricSpec] = {
    r.deliverable_type: r for r in [
        RUBRIC_CLIENT_PROPOSAL,
        RUBRIC_OPERATIONAL_AUDIT,
        RUBRIC_PRD,
        RUBRIC_SLIDE_DECK,
        RUBRIC_FINANCIAL_MODEL,
        RUBRIC_MEETING_SUMMARY,
        RUBRIC_RESEARCH_REPORT,
    ]
}


# ═══════════════════════════════════════════════════════════════════════════════
#  EVALUATOR PROMPT — built dynamically from a rubric. Returns strict JSON per
#  Doc 2's evaluator-prompt template. The dedicated `eval` agent always uses
#  this system prompt; it's customer-invisible and never appears in the router.
# ═══════════════════════════════════════════════════════════════════════════════

def build_evaluator_prompt(rubric: RubricSpec) -> str:
    """Compose the full evaluator system prompt for a given rubric. The prompt
    includes every dimension with its full anchor set, threshold info, and
    the strict output schema. Total length is ~2–4KB per rubric — well under
    any model's system-prompt budget."""
    lines = [
        f"You are the TavernOS evaluator for '{rubric.name}' deliverables.",
        "",
        "Your ONLY job is to score the attached output against the rubric below. "
        "You are not a writer, not a coach, not an editor. Return ONLY valid JSON "
        "matching the schema at the end of this prompt. No preamble, no "
        "explanation outside the JSON.",
        "",
        f"Threshold for auto-accept: weighted average ≥ {rubric.threshold_avg:.1f}",
    ]
    if rubric.threshold_hard:
        for dim_name, floor in rubric.threshold_hard.items():
            lines.append(f"  AND {dim_name} ≥ {floor:.1f} (hard floor)")
    lines += ["", "RUBRIC DIMENSIONS:", ""]
    for dim in rubric.dimensions:
        lines += [
            f"### {dim.name} ({int(dim.weight * 100)}% weight)",
            f"{dim.description}",
            "",
            "Scoring anchors (1–5, you may use .5 increments):",
            f"  5 = {dim.anchor_5}",
            f"  3 = {dim.anchor_3}",
            f"  1 = {dim.anchor_1}",
            "",
        ]
    lines += [
        "OUTPUT SCHEMA — return exactly this JSON shape:",
        "{",
        '  "scores": {',
    ]
    for dim in rubric.dimensions:
        lines.append(f'    "{dim.name}": <float 1.0-5.0>,')
    # trim the trailing comma on the last one for pedantic JSON
    if lines[-1].endswith(","):
        lines[-1] = lines[-1][:-1]
    lines += [
        "  },",
        '  "critiques": {',
    ]
    for dim in rubric.dimensions:
        lines.append(f'    "{dim.name}": "<two-sentence critique explaining the score>",')
    if lines[-1].endswith(","):
        lines[-1] = lines[-1][:-1]
    lines += [
        "  },",
        '  "pass_threshold": <true/false>,',
        '  "overall_critique": "<one-sentence overall assessment>"',
        "}",
        "",
        "Score honestly. A 5 is rare — reserve it for deliverables that meet the "
        "anchor_5 description in spirit and letter. A 3 is 'adequate, would send "
        "but could be tighter.' Below 3 means the deliverable needs rework.",
    ]
    return "\n".join(lines)


# ═══════════════════════════════════════════════════════════════════════════════
#  DB SCHEMA — extends skill_performance.db with deliverable-level scoring +
#  calibration tables. Migration is additive; existing rows + tables untouched.
# ═══════════════════════════════════════════════════════════════════════════════

def eval_db_init(perf_db_path: Path, global_db_path: Path) -> None:
    """Add evaluator tables to both per-client and global perf DBs. Idempotent —
    safe to call on an already-migrated DB. Mirrors perf_db_init's structure so
    the /scores command can uniformly query both skill + deliverable tables."""
    perf_db_path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(perf_db_path)
    con.execute("""CREATE TABLE IF NOT EXISTS deliverable_scores (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT NOT NULL,
        agent TEXT, deliverable_type TEXT,
        filename TEXT, filepath TEXT,
        scores_json TEXT,            -- {dim_name: float}
        critiques_json TEXT,         -- {dim_name: str}
        weighted_avg REAL,
        pass_threshold INTEGER,      -- 0/1 bool
        failing_dims TEXT,           -- comma-separated
        regen_attempts INTEGER DEFAULT 0,
        evaluator_model TEXT,
        overall_critique TEXT
    )""")
    con.execute("""CREATE TABLE IF NOT EXISTS deliverable_calibration (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        deliverable_score_id INTEGER,
        ts TEXT NOT NULL,
        operator_scores_json TEXT,   -- {dim_name: float}
        operator_notes TEXT,
        evaluator_scores_json TEXT,  -- copied from deliverable_scores at rating time
        FOREIGN KEY (deliverable_score_id) REFERENCES deliverable_scores(id)
    )""")
    con.commit(); con.close()

    global_db_path.parent.mkdir(parents=True, exist_ok=True)
    gcon = sqlite3.connect(global_db_path)
    gcon.execute("""CREATE TABLE IF NOT EXISTS deliverable_scores (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT NOT NULL, client_slug TEXT,
        agent TEXT, deliverable_type TEXT,
        filename TEXT, filepath TEXT,
        scores_json TEXT, critiques_json TEXT,
        weighted_avg REAL,
        pass_threshold INTEGER,
        failing_dims TEXT,
        regen_attempts INTEGER DEFAULT 0,
        evaluator_model TEXT,
        overall_critique TEXT
    )""")
    gcon.commit(); gcon.close()


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def save_eval_result(perf_db_path: Path, global_db_path: Path,
                     client_slug: str, agent: str, deliverable_type: str,
                     filename: str, filepath: str, scores: dict[str, float],
                     critiques: dict[str, str], weighted_avg: float,
                     pass_threshold: bool, failing_dims: list[str],
                     regen_attempts: int, evaluator_model: str,
                     overall_critique: str) -> int:
    """Persist a scoring result. Returns the per-client deliverable_scores.id
    so calibration rows can link back."""
    con = sqlite3.connect(perf_db_path)
    cur = con.execute(
        """INSERT INTO deliverable_scores
           (ts, agent, deliverable_type, filename, filepath, scores_json,
            critiques_json, weighted_avg, pass_threshold, failing_dims,
            regen_attempts, evaluator_model, overall_critique)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (_now_iso(), agent, deliverable_type, filename, filepath,
         json.dumps(scores), json.dumps(critiques),
         weighted_avg, 1 if pass_threshold else 0,
         ",".join(failing_dims), regen_attempts,
         evaluator_model, overall_critique)
    )
    row_id = cur.lastrowid
    # Retention cap — keep last 2000 deliverable scores per client
    con.execute("DELETE FROM deliverable_scores WHERE id NOT IN "
                "(SELECT id FROM deliverable_scores ORDER BY id DESC LIMIT 2000)")
    con.commit(); con.close()

    gcon = sqlite3.connect(global_db_path)
    gcon.execute(
        """INSERT INTO deliverable_scores
           (ts, client_slug, agent, deliverable_type, filename, filepath,
            scores_json, critiques_json, weighted_avg, pass_threshold,
            failing_dims, regen_attempts, evaluator_model, overall_critique)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (_now_iso(), client_slug, agent, deliverable_type, filename, filepath,
         json.dumps(scores), json.dumps(critiques),
         weighted_avg, 1 if pass_threshold else 0,
         ",".join(failing_dims), regen_attempts,
         evaluator_model, overall_critique)
    )
    gcon.execute("DELETE FROM deliverable_scores WHERE id NOT IN "
                 "(SELECT id FROM deliverable_scores ORDER BY id DESC LIMIT 10000)")
    gcon.commit(); gcon.close()
    return row_id


# ═══════════════════════════════════════════════════════════════════════════════
#  MODEL TIER MATCHING — picks an evaluator model whose tier matches the
#  generator model's tier (per operator decision Apr 22, 2026).
# ═══════════════════════════════════════════════════════════════════════════════

def pick_evaluator_model(generator_model_id: str, provider: str,
                         available_models: list[dict]) -> str:
    """Return a model_id for the evaluator. Strategy:

    1. Look up generator_model_id's tier in available_models.
    2. Pick the first same-tier, same-provider model that isn't the generator itself.
       (Allows same model if it's the only one in its tier — that's fine.)
    3. Fall back to a same-tier match even if it equals the generator.
    4. Final fallback: first anthropic model with tier 2 (Sonnet-equivalent).

    Handles the realistic cases:
      - Generator is Opus → evaluator is Opus (or whatever's tier 1)
      - Generator is Haiku → evaluator is Haiku
      - Unknown model → Sonnet-class fallback"""
    gen_tier = None
    for m in available_models:
        if m.get("id") == generator_model_id and m.get("provider") == provider:
            gen_tier = m.get("tier")
            break

    if gen_tier is None:
        # Unknown generator — try Sonnet-class fallback for the provider
        tier2 = [m for m in available_models
                 if m.get("provider") == provider and m.get("tier") == 2]
        if tier2:
            return tier2[0]["id"]
        # Last resort: return the generator itself, let the caller handle it
        return generator_model_id

    # Prefer a different model at the same tier (rare — usually only one per tier)
    same_tier = [m for m in available_models
                 if m.get("provider") == provider and m.get("tier") == gen_tier]
    for m in same_tier:
        if m["id"] != generator_model_id:
            return m["id"]
    # Only one model in the tier — use the generator itself
    if same_tier:
        return same_tier[0]["id"]
    # Nothing in the provider's tier — same fallback as unknown
    return generator_model_id


# ═══════════════════════════════════════════════════════════════════════════════
#  EVALUATION CORE — score_deliverable is the main entry point. Callers
#  pass the deliverable content (text), the rubric, a built Anthropic/OpenAI
#  client, the model id to use, and optionally context (sidecar spec).
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class EvalResult:
    scores: dict[str, float]
    critiques: dict[str, str]
    weighted_avg: float
    pass_threshold: bool
    failing_dims: list[str]
    overall_critique: str
    evaluator_model: str
    error: Optional[str] = None  # set if the LLM call or JSON parse failed


def _clamp_score(v: Any) -> float:
    """Normalize whatever came back from the model into a [1.0, 5.0] float.
    LLMs sometimes return ints, sometimes strings, sometimes out-of-range."""
    try:
        f = float(v)
    except (TypeError, ValueError):
        return 3.0  # conservative default for malformed scores
    return max(1.0, min(5.0, f))


def score_deliverable(client, provider: str, evaluator_model_id: str,
                      rubric: RubricSpec, deliverable_text: str,
                      spec_context: dict | None = None,
                      max_chars: int = 40000) -> EvalResult:
    """Run one evaluator LLM call and return a parsed result. Exceptions in
    the LLM call or JSON parsing are captured in EvalResult.error rather
    than raised — callers should check .error and handle gracefully.

    `deliverable_text`: the extracted text of the deliverable (from a .docx,
        .xlsx, .pptx text-extractor; or the raw text for a markdown deliverable).
        Truncated to max_chars to keep context bounded.
    `spec_context`: optional — the sidecar .spec.json content, useful for
        structural claims (e.g. 'the spec claimed 3 phases but only 2 rendered')."""
    if not deliverable_text.strip():
        return EvalResult(
            scores={}, critiques={}, weighted_avg=0.0, pass_threshold=False,
            failing_dims=["empty_deliverable"], overall_critique="Empty deliverable",
            evaluator_model=evaluator_model_id, error="empty_deliverable_text",
        )

    system = build_evaluator_prompt(rubric)
    user_parts = []
    if spec_context:
        user_parts += [
            "SPEC (what the agent intended to produce):",
            "```json",
            json.dumps(spec_context, indent=2)[:4000],
            "```",
            "",
        ]
    user_parts += [
        "DELIVERABLE TEXT:",
        "```",
        deliverable_text[:max_chars],
        "```",
        "",
        "Score this deliverable against the rubric. Return JSON only.",
    ]
    user_msg = "\n".join(user_parts)

    try:
        if provider == "anthropic":
            r = client.messages.create(
                model=evaluator_model_id, max_tokens=2000,
                system=system, messages=[{"role": "user", "content": user_msg}]
            )
            raw = r.content[0].text
        else:
            r = client.chat.completions.create(
                model=evaluator_model_id, max_tokens=2000,
                messages=[{"role": "system", "content": system},
                          {"role": "user",   "content": user_msg}]
            )
            raw = r.choices[0].message.content
    except Exception as e:
        return EvalResult(
            scores={}, critiques={}, weighted_avg=0.0, pass_threshold=False,
            failing_dims=["evaluator_api_error"],
            overall_critique=f"Evaluator API call failed: {type(e).__name__}",
            evaluator_model=evaluator_model_id, error=str(e),
        )

    parsed = _try_extract_eval_json(raw)
    if not parsed:
        return EvalResult(
            scores={}, critiques={}, weighted_avg=0.0, pass_threshold=False,
            failing_dims=["evaluator_parse_error"],
            overall_critique="Evaluator returned unparseable output",
            evaluator_model=evaluator_model_id, error=f"parse_failed: {raw[:200]}",
        )

    raw_scores = parsed.get("scores", {})
    critiques = parsed.get("critiques", {})
    # Clamp every dimension; missing dims default to 3.0 (adequate) so a
    # partial-output evaluator call doesn't nuke the overall score.
    scores = {dim.name: _clamp_score(raw_scores.get(dim.name, 3.0))
              for dim in rubric.dimensions}
    weighted_avg = rubric.weighted_avg(scores)
    passed, failing = rubric.passes_threshold(scores)
    overall = parsed.get("overall_critique", "") or ""

    return EvalResult(
        scores=scores, critiques=critiques, weighted_avg=weighted_avg,
        pass_threshold=passed, failing_dims=failing,
        overall_critique=overall, evaluator_model=evaluator_model_id, error=None,
    )


def _try_extract_eval_json(raw: str) -> dict | None:
    """Parse the evaluator's JSON output, tolerant of code fences and preamble.
    Returns dict on success, None on failure."""
    if not raw:
        return None
    raw = raw.strip()
    # Strip markdown fences if present
    if raw.startswith("```"):
        lines = raw.split("\n")
        # drop first line (``` or ```json) and last line if it's ```
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        raw = "\n".join(lines)
    # Try direct parse
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        pass
    # Find the first balanced {...}
    depth = 0
    start = -1
    for i, ch in enumerate(raw):
        if ch == "{":
            if start < 0:
                start = i
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0 and start >= 0:
                try:
                    return json.loads(raw[start:i+1])
                except json.JSONDecodeError:
                    start = -1
                    continue
    return None


# ═══════════════════════════════════════════════════════════════════════════════
#  TEXT EXTRACTION — lightweight readers for the three artifact formats. Each
#  returns plain text suitable for the evaluator's context window. We don't
#  need perfect fidelity; we need enough for the rubric dimensions to be
#  scorable (presence of sections, prose content, table contents, etc.).
# ═══════════════════════════════════════════════════════════════════════════════

def extract_text_from_deliverable(filepath: Path) -> str:
    """Dispatch by extension. Returns empty string if the file can't be read
    (and logs via error_logger if supplied). Never raises — the evaluator
    pipeline must survive malformed deliverables."""
    suffix = filepath.suffix.lower()
    try:
        if suffix == ".docx":
            return _extract_docx(filepath)
        if suffix == ".xlsx":
            return _extract_xlsx(filepath)
        if suffix == ".pptx":
            return _extract_pptx(filepath)
        if suffix in (".md", ".txt"):
            return filepath.read_text(encoding="utf-8", errors="replace")
    except Exception:
        # Intentionally silent — the eval result will carry the empty-text
        # failure marker via score_deliverable's empty check.
        return ""
    return ""


def _extract_docx(path: Path) -> str:
    """Extract paragraphs + table cells from a .docx as plain text.

    Walks the document body in original order so tables surface adjacent
    to the prose they belong to. The prior implementation iterated
    doc.paragraphs first then doc.tables, which dumped every table after
    all prose — breaking the evaluator's ability to associate e.g. a
    per-priority ROI math table with the priority that owns it. Same
    class of silent-quality-drift bug as the xlsx formatting-blindness
    surfaced in Phase 4A.
    """
    from docx import Document
    from docx.table import Table
    from docx.text.paragraph import Paragraph

    doc = Document(str(path))
    lines = []
    for child in doc.element.body.iterchildren():
        tag = child.tag.rsplit("}", 1)[-1]
        if tag == "p":
            para = Paragraph(child, doc)
            if para.text.strip():
                lines.append(para.text)
        elif tag == "tbl":
            tbl = Table(child, doc)
            for row in tbl.rows:
                cells = [c.text.strip() for c in row.cells]
                if any(cells):
                    lines.append(" | ".join(cells))
    return "\n".join(lines)


def _extract_xlsx(path: Path) -> str:
    """Extract cell values per sheet. Includes formulas as the literal string
    (so 'formula correctness' dim can score them). Skips cells that are None.

    Also surfaces presentation metadata the evaluator would otherwise miss:
      - per-cell number_format (currency/percent/etc) when non-default
      - per-sheet summary: counts of bold cells, filled cells, bordered cells
      - workbook-level defined names (named ranges) — without these the
        evaluator sees `=Revenue_Actual_Total` as an unresolved identifier
        and can't confirm it's correctly defined.
    Without this the formatting_polish dimension is blind (extractor sees only
    values) and scores a file like 2.5 even when the actual xlsx is styled.
    """
    from openpyxl import load_workbook
    wb = load_workbook(str(path), data_only=False)
    lines = []

    # Workbook-level defined names first — the evaluator needs to know these
    # exist before it encounters =Revenue_Actual_Total in a Summary formula.
    try:
        names = []
        for n in wb.defined_names:
            try:
                target = wb.defined_names[n].attr_text
            except Exception:
                target = "?"
            names.append(f"  {n} -> {target}")
        if names:
            lines.append("=== DEFINED NAMES ===")
            lines.extend(names)
    except Exception:
        pass  # Best-effort; never fail extraction over name enumeration

    for ws_name in wb.sheetnames:
        ws = wb[ws_name]
        lines.append(f"=== SHEET: {ws_name} ===")

        # Per-sheet style counters — computed during the cell walk below
        n_bold = n_filled = n_bordered = 0
        fmt_counts: dict[str, int] = {}

        for row in ws.iter_rows():
            row_bits = []
            for cell in row:
                v = cell.value
                if v is None:
                    continue
                # Tally style presence. openpyxl returns default objects
                # (not None) for unstyled cells, so we test the meaningful fields.
                try:
                    if cell.font and cell.font.bold:
                        n_bold += 1
                    if cell.fill and cell.fill.fgColor and cell.fill.patternType:
                        n_filled += 1
                    if cell.border and any(
                        side.style for side in (
                            cell.border.left, cell.border.right,
                            cell.border.top, cell.border.bottom,
                        )
                    ):
                        n_bordered += 1
                    nf = cell.number_format
                    if nf and nf != "General":
                        fmt_counts[nf] = fmt_counts.get(nf, 0) + 1
                except Exception:
                    pass  # Style introspection is best-effort; never fail extraction

                # Inline format hint when non-default, so the evaluator can
                # see that a number is currency-formatted vs. bare.
                nf = cell.number_format if cell.number_format else ""
                if nf and nf != "General":
                    row_bits.append(f"{cell.coordinate}={v} [fmt={nf}]")
                else:
                    row_bits.append(f"{cell.coordinate}={v}")
            if row_bits:
                lines.append(" | ".join(row_bits))

        # One-line style summary per sheet. Keeps the evaluator grounded on
        # how much intentional formatting is present without dumping every
        # style object.
        fmt_summary = ", ".join(
            f"{n}x '{fmt}'" for fmt, n in sorted(
                fmt_counts.items(), key=lambda kv: -kv[1]
            )[:4]
        ) or "none"
        lines.append(
            f"[STYLE: {n_bold} bold, {n_filled} filled, "
            f"{n_bordered} bordered, number_formats: {fmt_summary}]"
        )
    return "\n".join(lines)


def _extract_pptx(path: Path) -> str:
    """Extract text and speaker notes per slide."""
    from pptx import Presentation
    prs = Presentation(str(path))
    lines = []
    for i, slide in enumerate(prs.slides, 1):
        lines.append(f"=== SLIDE {i} ===")
        for shape in slide.shapes:
            if shape.has_text_frame:
                for para in shape.text_frame.paragraphs:
                    t = para.text.strip()
                    if t:
                        lines.append(t)
            # Tables need separate handling
            if shape.has_table:
                for row in shape.table.rows:
                    cells = [c.text.strip() for c in row.cells]
                    if any(cells):
                        lines.append(" | ".join(cells))
        if slide.has_notes_slide:
            notes = slide.notes_slide.notes_text_frame.text.strip()
            if notes:
                lines.append(f"[NOTES] {notes}")
    return "\n".join(lines)


# ═══════════════════════════════════════════════════════════════════════════════
#  ORCHESTRATION — evaluate_and_persist is the single entry point callers
#  use. Non-blocking variant (run_on_background_thread) for the CLI path
#  so the operator sees the deliverable banner immediately.
# ═══════════════════════════════════════════════════════════════════════════════

def evaluate_and_persist(client, provider: str, generator_model_id: str,
                         agent: str, deliverable_type: str,
                         filename: str, filepath: Path,
                         spec_context: dict | None,
                         client_slug: str,
                         perf_db_path: Path, global_db_path: Path,
                         available_models: list[dict],
                         max_regen_attempts: int = 2,
                         error_logger: Callable | None = None) -> EvalResult | None:
    """One-shot evaluation (no regeneration — callers handle that). Extracts
    text, picks the evaluator model, scores, persists to DB. Returns the
    EvalResult so the caller can decide whether to regen.

    This is the SINGLE-PASS version. Regeneration is the caller's job because
    it requires re-invoking the generator, which is CLI-specific plumbing.
    See `should_regenerate` and `build_regeneration_prompt` below."""
    rubric = RUBRICS.get(deliverable_type)
    if rubric is None:
        # No rubric for this deliverable type — log and skip. Not an error;
        # Phase 3 covers 7 types, more will be added incrementally.
        if error_logger:
            error_logger("eval_no_rubric", deliverable_type=deliverable_type,
                         filename=filename)
        return None

    text = extract_text_from_deliverable(filepath)
    if not text:
        if error_logger:
            error_logger("eval_text_extraction_failed",
                         filepath=str(filepath), deliverable_type=deliverable_type)
        # We still persist a zero-score row so the operator sees the failure
        # in /scores output rather than a silent gap.

    evaluator_model = pick_evaluator_model(generator_model_id, provider, available_models)

    result = score_deliverable(
        client, provider, evaluator_model, rubric, text, spec_context,
    )

    # Persist regardless of success — a failed eval is diagnostic data too
    try:
        save_eval_result(
            perf_db_path, global_db_path, client_slug, agent, deliverable_type,
            filename, str(filepath), result.scores, result.critiques,
            result.weighted_avg, result.pass_threshold, result.failing_dims,
            0, evaluator_model, result.overall_critique,
        )
    except Exception as e:
        if error_logger:
            error_logger("eval_persist_failed", error=str(e), filename=filename)

    return result


def evaluate_in_background(executor_fn: Callable, *args, **kwargs) -> threading.Thread:
    """Run evaluate_and_persist on a daemon thread. Returns the thread so the
    caller can optionally join() it (e.g. before process exit). Normal usage
    is fire-and-forget — the CLI banner fires immediately, eval logs later."""
    t = threading.Thread(
        target=lambda: executor_fn(*args, **kwargs),
        daemon=True,
    )
    t.start()
    return t


def should_regenerate(result: EvalResult, attempts_so_far: int,
                      max_attempts: int = 2) -> bool:
    """Decide whether to trigger regeneration. True iff the result has
    failing dimensions AND we haven't exhausted our attempt budget."""
    if result.error is not None:
        # Evaluator failed — don't regen on that (it's not the generator's
        # fault). Operator sees a warning; deliverable ships.
        return False
    if result.pass_threshold:
        return False
    return attempts_so_far < max_attempts


def build_regeneration_prompt(result: EvalResult,
                              deliverable_type: str) -> str:
    """Build the text to prepend to the generator's next prompt. Thin wrapper
    around RubricSpec.regeneration_prompt for the common case."""
    rubric = RUBRICS.get(deliverable_type)
    if rubric is None:
        return ""
    return rubric.regeneration_prompt(result.scores, result.critiques)


# ═══════════════════════════════════════════════════════════════════════════════
#  DISPLAY — format_score_banner returns the text the CLI / web UI shows after
#  a deliverable saves. When a deliverable surfaces with failing dims after
#  max regens, this is the "big warning banner" the operator decided on.
# ═══════════════════════════════════════════════════════════════════════════════

def format_score_banner(result: EvalResult, rubric: RubricSpec,
                        attempts: int) -> list[str]:
    """Return a list of display lines (no color codes — caller applies).
    First line is always the compact one-liner (`Proposal · Woody · 4.2/5`).
    Subsequent lines only appear when the deliverable is below threshold."""
    lines = []
    score_str = f"{result.weighted_avg:.1f}/5"
    lines.append(f"{rubric.name} · {rubric.agent_owner.title()} · {score_str}")
    if result.error:
        lines.append(f"⚠ Evaluator error: {result.error[:120]}")
        lines.append("  (deliverable surfaced as-is — manual review recommended)")
        return lines
    if result.pass_threshold:
        return lines
    # Below threshold — show failing dims + critique
    lines.append(f"⚠ Below threshold after {attempts} regeneration attempt(s).")
    for dim_name in result.failing_dims:
        # Strip the comparator suffix from "dim_name<3.0"
        display = dim_name.split("<")[0]
        if display == "weighted_avg":
            continue  # already shown in the score string
        dim_score = result.scores.get(display)
        if dim_score is None:
            continue
        critique = result.critiques.get(display, "")
        lines.append(f"  {display}: {dim_score:.1f}")
        if critique:
            lines.append(f"    {critique[:200]}")
    if result.overall_critique:
        lines.append(f"  Overall: {result.overall_critique[:200]}")
    return lines


# ═══════════════════════════════════════════════════════════════════════════════
#  OPERATOR-FACING QUERIES — used by /scores --deliverables and future UI
# ═══════════════════════════════════════════════════════════════════════════════

def list_recent_scores(perf_db_path: Path, limit: int = 20) -> list[dict]:
    """Return the N most recent deliverable scores for the active client."""
    if not perf_db_path.exists():
        return []
    con = sqlite3.connect(perf_db_path)
    try:
        rows = con.execute(
            """SELECT ts, agent, deliverable_type, filename,
                      weighted_avg, pass_threshold, failing_dims,
                      regen_attempts, evaluator_model
               FROM deliverable_scores
               ORDER BY id DESC LIMIT ?""", (limit,)
        ).fetchall()
    finally:
        con.close()
    return [
        {
            "ts": r[0], "agent": r[1], "deliverable_type": r[2],
            "filename": r[3], "weighted_avg": r[4],
            "pass_threshold": bool(r[5]),
            "failing_dims": r[6], "regen_attempts": r[7],
            "evaluator_model": r[8],
        }
        for r in rows
    ]


def get_score_by_filename(perf_db_path: Path, filename: str) -> dict | None:
    """Fetch the most recent score record for a specific filename. Used by
    `/eval <filename>` to show the full critique set."""
    if not perf_db_path.exists():
        return None
    con = sqlite3.connect(perf_db_path)
    try:
        row = con.execute(
            """SELECT id, ts, agent, deliverable_type, filename, filepath,
                      scores_json, critiques_json, weighted_avg,
                      pass_threshold, failing_dims, regen_attempts,
                      evaluator_model, overall_critique
               FROM deliverable_scores WHERE filename=?
               ORDER BY id DESC LIMIT 1""", (filename,)
        ).fetchone()
    finally:
        con.close()
    if not row:
        return None
    return {
        "id": row[0], "ts": row[1], "agent": row[2],
        "deliverable_type": row[3], "filename": row[4], "filepath": row[5],
        "scores": json.loads(row[6] or "{}"),
        "critiques": json.loads(row[7] or "{}"),
        "weighted_avg": row[8], "pass_threshold": bool(row[9]),
        "failing_dims": row[10], "regen_attempts": row[11],
        "evaluator_model": row[12], "overall_critique": row[13],
    }


# ═══════════════════════════════════════════════════════════════════════════════
#  CALIBRATION STORAGE — operator manual-rating flow persistence + drift
#  analysis. Added Phase 5 (April 2026). The `deliverable_calibration` table
#  itself ships in eval_db_init above; these helpers power the /eval calibrate
#  and /eval calibration slash commands in norm.py.
#
#  Design notes
#  ------------
#  - Calibration rows are per-client only (no global mirror). Cross-client
#    aggregates are out of scope for v1 — the drift report runs over the
#    active client's DB. Most operator ratings will be against _self
#    fixtures + a handful of real engagements.
#  - No UNIQUE constraint on deliverable_score_id. Re-rating is first-class.
#    The latest rating wins for drift-report purposes, but the full history
#    is preserved for operator self-consistency analysis.
#  - evaluator_scores_json is denormalized at rating time (copied from the
#    parent deliverable_scores row) so drift analysis survives the 2000-row
#    retention cap on deliverable_scores.
# ═══════════════════════════════════════════════════════════════════════════════

def list_unrated_deliverables(perf_db_path: Path, limit: int = 10) -> list[dict]:
    """Return the N most recent deliverable_scores rows that have NO
    corresponding calibration row. Used by /eval calibrate (no-arg) to pick
    the next deliverable to rate. Ordered by recency (most recent first)."""
    if not perf_db_path.exists():
        return []
    con = sqlite3.connect(perf_db_path)
    try:
        rows = con.execute(
            """SELECT ds.id, ds.ts, ds.agent, ds.deliverable_type,
                      ds.filename, ds.filepath, ds.weighted_avg,
                      ds.pass_threshold
               FROM deliverable_scores ds
               LEFT JOIN deliverable_calibration dc
                 ON dc.deliverable_score_id = ds.id
               WHERE dc.id IS NULL
               ORDER BY ds.id DESC LIMIT ?""", (limit,)
        ).fetchall()
    finally:
        con.close()
    return [
        {"id": r[0], "ts": r[1], "agent": r[2], "deliverable_type": r[3],
         "filename": r[4], "filepath": r[5], "weighted_avg": r[6],
         "pass_threshold": bool(r[7])}
        for r in rows
    ]


def get_deliverable_score_by_id(perf_db_path: Path, score_id: int) -> dict | None:
    """Fetch a deliverable_scores row by primary key. Companion to
    get_score_by_filename for the calibration flow, which routes by id once
    a filename lookup or picker has resolved to a specific row."""
    if not perf_db_path.exists():
        return None
    con = sqlite3.connect(perf_db_path)
    try:
        row = con.execute(
            """SELECT id, ts, agent, deliverable_type, filename, filepath,
                      scores_json, critiques_json, weighted_avg,
                      pass_threshold, failing_dims, regen_attempts,
                      evaluator_model, overall_critique
               FROM deliverable_scores WHERE id=?""", (score_id,)
        ).fetchone()
    finally:
        con.close()
    if not row:
        return None
    return {
        "id": row[0], "ts": row[1], "agent": row[2],
        "deliverable_type": row[3], "filename": row[4], "filepath": row[5],
        "scores": json.loads(row[6] or "{}"),
        "critiques": json.loads(row[7] or "{}"),
        "weighted_avg": row[8], "pass_threshold": bool(row[9]),
        "failing_dims": row[10], "regen_attempts": row[11],
        "evaluator_model": row[12], "overall_critique": row[13],
    }


def save_calibration(perf_db_path: Path, deliverable_score_id: int,
                     operator_scores: dict[str, float],
                     operator_notes: str,
                     evaluator_scores: dict[str, float]) -> int:
    """Persist an operator rating for a previously-scored deliverable.
    Returns the new deliverable_calibration.id. No UNIQUE constraint on
    deliverable_score_id — repeated calibrations of the same deliverable
    append new rows, preserving operator-self-consistency history."""
    con = sqlite3.connect(perf_db_path)
    try:
        cur = con.execute(
            """INSERT INTO deliverable_calibration
               (deliverable_score_id, ts, operator_scores_json,
                operator_notes, evaluator_scores_json)
               VALUES (?,?,?,?,?)""",
            (deliverable_score_id, _now_iso(),
             json.dumps(operator_scores), operator_notes or "",
             json.dumps(evaluator_scores))
        )
        row_id = cur.lastrowid
        con.commit()
    finally:
        con.close()
    return row_id


def list_calibrations(perf_db_path: Path,
                      deliverable_score_id: int | None = None,
                      limit: int = 500) -> list[dict]:
    """Return calibration rows. If deliverable_score_id is given, returns
    only that deliverable's rating history (newest first). Otherwise
    returns the N most recent calibrations across all deliverables."""
    if not perf_db_path.exists():
        return []
    con = sqlite3.connect(perf_db_path)
    try:
        if deliverable_score_id is not None:
            rows = con.execute(
                """SELECT id, deliverable_score_id, ts, operator_scores_json,
                          operator_notes, evaluator_scores_json
                   FROM deliverable_calibration
                   WHERE deliverable_score_id=?
                   ORDER BY id DESC LIMIT ?""",
                (deliverable_score_id, limit)
            ).fetchall()
        else:
            rows = con.execute(
                """SELECT id, deliverable_score_id, ts, operator_scores_json,
                          operator_notes, evaluator_scores_json
                   FROM deliverable_calibration
                   ORDER BY id DESC LIMIT ?""", (limit,)
            ).fetchall()
    finally:
        con.close()
    out = []
    for r in rows:
        out.append({
            "id": r[0], "deliverable_score_id": r[1], "ts": r[2],
            "operator_scores": json.loads(r[3] or "{}"),
            "operator_notes": r[4] or "",
            "evaluator_scores": json.loads(r[5] or "{}"),
        })
    return out


def compute_calibration_drift(perf_db_path: Path,
                              min_n_per_type: int = 5) -> dict:
    """Analyze operator-vs-evaluator drift. Returns a dict shaped for the
    /eval calibration report:

        {
          "total_ratings": int,
          "by_type": {
            "<deliverable_type>": {
              "n": int,
              "below_floor": bool,             # true if n < min_n_per_type
              "per_dim": {
                "<dim_name>": {
                  "mean_op": float, "mean_mbr": float,
                  "mean_delta": float, "stdev_delta": float,
                  "op_range": float, "mbr_range": float,
                  "compression_ratio": float,  # op_range / mbr_range
                },
                ...
              },
              "weighted_mean_delta": float,    # mean of (op_wavg - mbr_wavg)
              "biggest_drift_dim": (str, float) | None,
              "scale_compression_flag": bool,  # true if ratio < 0.6 across dims
            },
            ...
          }
        }

    For each deliverable, the LATEST calibration row per deliverable_score_id
    is used — re-ratings supersede earlier ones for drift purposes. History
    is still available via list_calibrations(deliverable_score_id=...)."""
    if not perf_db_path.exists():
        return {"total_ratings": 0, "by_type": {}}
    con = sqlite3.connect(perf_db_path)
    try:
        # Latest calibration per deliverable_score_id, joined to get type
        rows = con.execute(
            """SELECT dc.id, dc.deliverable_score_id, dc.ts,
                      dc.operator_scores_json, dc.evaluator_scores_json,
                      ds.deliverable_type
               FROM deliverable_calibration dc
               JOIN deliverable_scores ds
                 ON ds.id = dc.deliverable_score_id
               ORDER BY dc.deliverable_score_id, dc.id DESC"""
        ).fetchall()
    finally:
        con.close()

    # Keep only the latest calibration row per deliverable_score_id
    seen_scores: set[int] = set()
    latest = []
    for r in rows:
        score_id = r[1]
        if score_id in seen_scores:
            continue
        seen_scores.add(score_id)
        latest.append({
            "operator_scores":  json.loads(r[3] or "{}"),
            "evaluator_scores": json.loads(r[4] or "{}"),
            "deliverable_type": r[5] or "?",
        })

    # Group by deliverable_type
    by_type: dict[str, list] = {}
    for row in latest:
        by_type.setdefault(row["deliverable_type"], []).append(row)

    out: dict = {"total_ratings": len(latest), "by_type": {}}
    for dtype, rows in by_type.items():
        n = len(rows)
        type_entry: dict = {
            "n": n,
            "below_floor": n < min_n_per_type,
            "per_dim": {},
            "weighted_mean_delta": 0.0,
            "biggest_drift_dim": None,
            "scale_compression_flag": False,
        }
        if n < min_n_per_type:
            out["by_type"][dtype] = type_entry
            continue

        # Collect per-dim paired scores across the rows that rated that dim
        dim_names: set[str] = set()
        for r in rows:
            dim_names.update(r["operator_scores"].keys())
            dim_names.update(r["evaluator_scores"].keys())

        biggest = None
        compression_ratios = []
        rubric = RUBRICS.get(dtype)
        weight_lookup = ({d.name: d.weight for d in rubric.dimensions}
                         if rubric else {})
        wavg_deltas = []

        for dim in dim_names:
            op_vals, mbr_vals, deltas = [], [], []
            for r in rows:
                op = r["operator_scores"].get(dim)
                mbr = r["evaluator_scores"].get(dim)
                if op is None or mbr is None:
                    continue
                op_vals.append(float(op))
                mbr_vals.append(float(mbr))
                deltas.append(float(op) - float(mbr))
            if not deltas:
                continue
            mean_op = sum(op_vals) / len(op_vals)
            mean_mbr = sum(mbr_vals) / len(mbr_vals)
            mean_delta = sum(deltas) / len(deltas)
            if len(deltas) >= 2:
                stdev_delta = statistics.stdev(deltas)
            else:
                stdev_delta = 0.0
            op_range = (max(op_vals) - min(op_vals)) if op_vals else 0.0
            mbr_range = (max(mbr_vals) - min(mbr_vals)) if mbr_vals else 0.0
            if mbr_range > 0:
                comp_ratio = op_range / mbr_range
                compression_ratios.append(comp_ratio)
            else:
                comp_ratio = 1.0  # MBR gave identical scores → no compression signal
            type_entry["per_dim"][dim] = {
                "mean_op": mean_op, "mean_mbr": mean_mbr,
                "mean_delta": mean_delta, "stdev_delta": stdev_delta,
                "op_range": op_range, "mbr_range": mbr_range,
                "compression_ratio": comp_ratio,
                "n_pairs": len(deltas),
            }
            if biggest is None or abs(mean_delta) > abs(biggest[1]):
                biggest = (dim, mean_delta)

        type_entry["biggest_drift_dim"] = biggest

        # Scale-compression flag: true if MEAN compression ratio across dims
        # with meaningful MBR range (>0.5) is below 0.6
        meaningful = [c for c, d in zip(compression_ratios, type_entry["per_dim"].values())
                      if d["mbr_range"] > 0.5]
        if meaningful:
            mean_comp = sum(meaningful) / len(meaningful)
            type_entry["scale_compression_flag"] = mean_comp < 0.6
            type_entry["mean_compression_ratio"] = mean_comp
        else:
            type_entry["mean_compression_ratio"] = None

        # Weighted-avg delta per deliverable, averaged over the type
        for r in rows:
            op_wavg, mbr_wavg, tw = 0.0, 0.0, 0.0
            for dim, w in weight_lookup.items():
                op = r["operator_scores"].get(dim)
                mbr = r["evaluator_scores"].get(dim)
                if op is None or mbr is None:
                    continue
                op_wavg += float(op) * w
                mbr_wavg += float(mbr) * w
                tw += w
            if tw > 0:
                wavg_deltas.append((op_wavg / tw) - (mbr_wavg / tw))
        if wavg_deltas:
            type_entry["weighted_mean_delta"] = sum(wavg_deltas) / len(wavg_deltas)
            if len(wavg_deltas) >= 2:
                type_entry["weighted_stdev_delta"] = statistics.stdev(wavg_deltas)
            else:
                type_entry["weighted_stdev_delta"] = 0.0

        out["by_type"][dtype] = type_entry

    return out


# ═══════════════════════════════════════════════════════════════════════════════
#  SELF-TEST HOOK — callable as `python -m tavernos.evaluator` for sanity
#  checks without a real LLM.
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print(f"Rubrics registered: {len(RUBRICS)}")
    for key, r in RUBRICS.items():
        n_dims = len(r.dimensions)
        total_w = sum(d.weight for d in r.dimensions)
        print(f"  {key:30s} {r.name:25s} ({r.agent_owner:10s}) "
              f"{n_dims} dims, weights sum={total_w:.2f}, "
              f"threshold avg≥{r.threshold_avg}")
        assert abs(total_w - 1.0) < 0.01, \
            f"Rubric {key} weights don't sum to 1.0: {total_w}"
    print("Weight sums OK for all rubrics.")