@echo off
REM goal-a-session-14-measure.bat
REM
REM Double-click wrapper for goal-a-session-14-measure.ps1.
REM Uses -ExecutionPolicy Bypass to sidestep policy issues, then
REM pauses at the end so the window stays open regardless of how
REM the .ps1 exits.
REM
REM Drop this .bat in the same folder as the .ps1 and double-click.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0goal-a-session-14-measure.ps1"

echo.
echo ========================================
echo Outer wrapper finished. Press any key to close.
echo ========================================
pause >nul
