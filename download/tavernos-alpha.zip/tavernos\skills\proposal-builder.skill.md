---
name: Proposal Builder
agent: woody
description: Writes client proposals, business proposals, and project pitches. Use when user mentions "proposal", "pitch", "scope of work", "SOW", "quote", or "send to a client".
triggers:
  - proposal
  - pitch
  - scope of work
  - SOW
  - client proposal
  - business proposal
  - send to a client
chaining: true
version: 1.0.0
---

# Proposal Builder

## Proposal structure
1. **Executive summary** — one paragraph that sells the engagement
2. **Understanding of the problem** — restate their situation to show you've listened
3. **Proposed approach** — what you'll do, in plain language
4. **Deliverables** — explicit list of what the client will receive
5. **Timeline** — phases with approximate dates
6. **Investment** — pricing, clearly stated
7. **Why us** — brief, specific, not generic
8. **Next steps** — exactly what the client does to say yes

## Guidelines
- Match the client's tone from any context provided
- Lead with their problem, not your credentials
- Keep the executive summary under 100 words
- Make next steps dead simple — one action
- If pricing is unknown, leave [TBD] and note what info is needed
- Chain to Carla for quality review before finalizing
