"""
test_cliff_research_report.py — Pipeline regression test for Cliff's research_report.

Thin wrapper over test_harness.py. Edit this file to change Cliff's test
scenarios; the harness handles all the plumbing.

Run:
  python test_cliff_research_report.py                    # tier 1 only, n=1
  python test_cliff_research_report.py --tier 1 --n 3     # tier 1, 3 iterations
  python test_cliff_research_report.py --tier 2 --n 3     # tiers 2a + 2b
  python test_cliff_research_report.py --tier all --n 3   # all implemented tiers
  python test_cliff_research_report.py --verbose          # dump plans + tool captures
  python test_cliff_research_report.py --tier 2 --n 3 --force-2b  # session-7 forcing arm

Baseline expectations (carried from session 1 pattern; specific Cliff
numbers not measured until session 9 priority 3):
  Tier 1:  should track Lilith's 100% — router rule for cliff
           (research/market/data/web-search) is well-established.
  Tier 2a: should track Lilith's ~100% CLARIFY — same grounding
           discipline.
  Tier 2b: session-1 Problem 1 applies to Cliff too; expect 0-25%
           invocation on rich prompts in baseline arm. Forced arm
           (--force-2b) should lift to ≥83% per the session-7 result
           for Lilith — priority 3 of session 9 validates this
           generalization.

Cliff-specific note: Cliff has access to real-time web_search. The R4
'source_quality' dim has the only 4.0 hard floor in any rubric — every
supporting_evidence item needs source + publisher + date. Rich prompts
should frame questions where Cliff can plausibly produce cited research
(either from web search or from the richness of the prompt itself).
"""

from test_harness import AgentTestConfig, run_tests


# ═══════════════════════════════════════════════════════════════════════════════
#  TEST SCENARIOS — cliff + research_report
#
#  SHORT prompts (Mode 3 / CLARIFY target): vague research requests with no
#  specific research question, no domain scoping, no cohort or time
#  window. Expected: no tool invocation, substantive prose asking what
#  specifically to research.
#
#  RICH prompts (Mode 2 / BOUND target): 4-6 sentences naming a specific
#  research question, domain, cohort or time window, and why the
#  research is needed (decision context). Expected: generate_docx_report
#  call with template=research_report, and a file saved to disk.
#
#  NEGATIVE prompts: must NOT route to Cliff. Proposal requests route to
#  Woody; operational audits route to Lilith; spreadsheet work routes
#  to Rebecca.
# ═══════════════════════════════════════════════════════════════════════════════

SHORT_PROMPTS = [
    "do some market research",
    "I need a research report",
    "look into the fintech market for me",
    "research the competitive landscape",
    "put together a research summary on AI tools",
]

RICH_PROMPTS = [
    # SaaS benchmarks — specific cohort, specific metric, decision context
    ("I'm prepping for a board meeting next week at our Series A SaaS "
     "company (B2B dev tools, $12M ARR, 68 headcount). The board wants "
     "to know how our ops-to-engineering headcount ratio compares to "
     "the cohort — we're 1:3, they've flagged that as possibly "
     "over-weighted on ops. Pull a research report comparing our ratio "
     "against Series A B2B SaaS cohort benchmarks from the last 18 "
     "months. Cite sources with publication dates. We use KeyBanc and "
     "OpenView surveys internally but I want you to pull from at "
     "least 3 sources total."),

    # Competitive landscape — specific companies, specific decision
    ("We're evaluating three AI coding assistants for a 180-engineer "
     "org: Cursor, Windsurf, and GitHub Copilot Enterprise. Decision "
     "drivers in priority order: code-review workflow integration, "
     "enterprise SSO/audit compliance, total cost of ownership at 180 "
     "seats, and vendor stability (funding runway, recent leadership "
     "changes). Pull a research report on the current state of these "
     "three as of this quarter, with cited sources on pricing, "
     "funding, and any enterprise deployment case studies. We're "
     "deciding in six weeks."),

    # Regulatory/policy research — time-sensitive, named jurisdiction
    ("Client is a mid-size fintech (Series B, payments infrastructure, "
     "$30M ARR). They're expanding into EU and need a research report "
     "on PSD3 and the Payment Services Regulation (PSR) — current "
     "status of the proposed regulations, expected timeline to "
     "finalization, and what specifically changes for non-bank "
     "payment institutions compared to PSD2. Focus on the "
     "strong-customer-authentication and open-banking API provisions. "
     "They need this for their Q2 board presentation so cite sources "
     "published in the last 6 months where possible."),

    # Market-sizing research — specific segment, decision context
    ("We're considering launching a vertical ERP product for "
     "independent veterinary practices in North America. Need a "
     "research report on the market: total number of independent "
     "(non-chain) veterinary practices in the US and Canada, "
     "average practice revenue, current software spend per practice, "
     "and who the incumbent vendors are (IDEXX Cornerstone, eVetPractice, "
     "Covetrus Pulse are the ones we know about — confirm and extend). "
     "This goes into a go/no-go investment memo in three weeks. Cite "
     "sources including publication dates."),
]

NEGATIVE_PROMPTS = [
    ("write me a client proposal for Meridian Labs",              "woody"),
    ("audit operations at a 22-person accounting firm",           "lilith"),
    ("build me a KPI dashboard spreadsheet with charts",          "rebecca"),
]


CONFIG = AgentTestConfig(
    agent_name="cliff",
    tool_name="generate_docx_report",
    template_key="research_report",
    short_prompts=SHORT_PROMPTS,
    rich_prompts=RICH_PROMPTS,
    negative_prompts=NEGATIVE_PROMPTS,
)


if __name__ == "__main__":
    run_tests(CONFIG)
