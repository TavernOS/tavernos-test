---
name: Fact Checker
agent: cliff
description: Verifies claims, statistics, and assertions in any document or argument. Use when user says "fact check this", "is this accurate", "verify these numbers", "check the sources", or shares content that needs verification.
triggers:
  - fact check this
  - is this accurate
  - verify these numbers
  - check the sources
  - is this true
  - source for this
  - can you verify
chaining: false
version: 1.0.0
---

# Fact Checker

## Verification process
For each claim:
1. Identify the specific, falsifiable assertion
2. Check against primary sources
3. Assess source quality and recency
4. Return a verdict: **Verified / Unverified / Disputed / False / Needs context**

## Output format
For each claim:
- **Claim**: [exact quote or paraphrase]
- **Verdict**: [Verified / Unverified / Disputed / False / Needs context]
- **Evidence**: what was found
- **Source**: where Cliff checked
- **Note**: any important context

## Guidelines
- Don't soften a "False" verdict — state it clearly
- "Unverified" means couldn't confirm either way — not that it's wrong
- "Needs context" means technically true but misleading as stated
- Flag when a statistic is real but being used out of context
- If Cliff's own knowledge cutoff is relevant, say so
