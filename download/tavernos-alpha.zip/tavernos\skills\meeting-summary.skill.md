---
name: Meeting Summary
agent: coach
description: Summarizes meeting notes, transcripts, or call recordings into structured output. Use when user mentions "meeting notes", "recap", "what was decided", "summarize this call", or pastes raw meeting content.
triggers:
  - meeting notes
  - recap
  - summarize this call
  - what was decided
  - meeting summary
  - call notes
chaining: true
version: 1.0.0
---

# Meeting Summary

## Output format
1. **Meeting context** — date, attendees (if known), topic
2. **Key decisions** — what was actually decided, numbered list
3. **Action items** — [Owner] Task — Deadline
4. **Open questions** — unresolved items needing follow-up
5. **Next steps** — what happens next and when

## Guidelines
- Lead with decisions, not discussion
- Action items must have an owner — if unknown, flag as [owner TBD]
- Keep each item to one sentence
- If content is ambiguous, ask one clarifying question before summarizing
- Chain to Woody to draft a follow-up email if needed
- Chain to Coach's PRD writer if requirements emerge from the meeting
