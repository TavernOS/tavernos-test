"""
test_rebecca_deck.py — Pipeline regression test for Rebecca's executive_review_deck.

Thin wrapper over test_harness.py. Edit this file to change Rebecca-Deck's
test scenarios; the harness handles all the plumbing.

Run:
  python -u test_rebecca_deck.py                    # tier 1 only, n=1
  python -u test_rebecca_deck.py --tier 1 --n 3     # tier 1, 3 iterations
  python -u test_rebecca_deck.py --tier 2 --n 3     # tiers 2a + 2b
  python -u test_rebecca_deck.py --tier all --n 3   # all implemented tiers
  python -u test_rebecca_deck.py --verbose          # dump plans + tool captures
  python -u test_rebecca_deck.py --tier 2 --n 3 --force-2b  # session-7 forcing arm

Baseline expectations (carried from session-1 pattern, validated for
Lilith/Woody/Cliff in sessions 7+9):
  Tier 1:  should track other deliverable agents at ~100% — ROUTER_SYSTEM
           routing rules (session 10 Rebecca split) direct deck/slide/
           presentation/QBR prompts to rebecca-deck.
  Tier 2a: should track other deliverable agents' ~100% CLARIFY — same
           grounding discipline applies.
  Tier 2b: session-9 production conjunction + force_tool='generate_pptx_deck'
           should lift invocation rate to ≥10/12 on rich deck prompts. D-prefix
           preflight gate (D2 + D3 + D4 + D5) will reject partial specs;
           bypass at N=2 saves with warning preamble.

Rebecca-Deck-specific note: the D4 check requires Rebecca to emit at least
one slide of type='closing' (anchoring opening_closing rubric dim, 0.15
regen). The drafted Deck skill file explicitly instructs this on the
Asks-and-decisions slide. First Tier 2b runs will surface whether that
skill-directive sticks — if it doesn't, the skill file may need
strengthening per session-1 lessons (structural directives work better
at top of skill file than buried in examples).
"""

from test_harness import AgentTestConfig, run_tests


# ═══════════════════════════════════════════════════════════════════════════════
#  TEST SCENARIOS — rebecca-deck + executive_review_deck
#
#  SHORT prompts (Mode 3 / CLARIFY target): vague deck requests with no
#  specific audience, period, or ask. Expected: no tool invocation,
#  substantive prose asking what the deck should drive.
#
#  RICH prompts (Mode 2 / BOUND target): 4-6 sentences naming a specific
#  audience, period, key bets/results, and an explicit ask or decision
#  being sought. Expected: generate_pptx_deck call with
#  template=executive_review_deck, and a file saved to disk.
#
#  NEGATIVE prompts: must NOT route to rebecca-deck. MBR requests route
#  to rebecca-mbr; research to cliff; proposals to woody; audits to lilith.
# ═══════════════════════════════════════════════════════════════════════════════

SHORT_PROMPTS = [
    "build me a deck",
    "put together a presentation",
    "I need slides for the board",
    "make a QBR deck",
    "draft a board presentation",
    # Session 15 priority 1 (MBR-Deck gate fixture). Lives in SHORT_PROMPTS
    # so Tier 2a's CLARIFY grader runs against it; the harness routes by
    # list, not by length, and nothing enforces "short" semantically.
    #
    # Shape: rich + MBR-signal-bearing. Sam classifies BOUND on richness;
    # the post-router gate (norm._enforce_mbr_context_clarify, session-13
    # priority 1) overrides to CLARIFY when the active client's manifest
    # lacks latest_monthly_business_review_path. PASS confirms the gate
    # fired AND Edit 4's prompt instruction (call_execute_streaming gate
    # block) converted dropped tool_choice forcing into "actually ask"
    # rather than voluntary tool invocation.
    #
    # FAIL diagnostics:
    #   - tool call observed → Edit 4 wording strength gap (session-13
    #     risk #1; record + propose follow-on, do NOT tweak Edit 4
    #     in-session per session-13 don't-soften guidance)
    #   - response too short / no '?' → agent refused for unrelated reason
    #     (e.g., guardrail), retry with adjusted prompt
    #   - state collision: if active client's manifest has the MBR key
    #     (e.g., from a prior Rebecca-MBR run on _self), the gate doesn't
    #     fire and the prompt routes BOUND. Check ~/.tavernos/clients/
    #     <slug>/client.json before running.
    ("Build the Q1 2026 executive review deck for Acme Corp (B2B SaaS, "
     "$5M ARR, 28 FTE). Audience is the exec team for the quarterly "
     "review meeting next Friday. Cover Q1 ARR vs target, segment "
     "performance across enterprise / mid-market / SMB, the three key "
     "bets we made in Q1, and what we're committing to for Q2. Include "
     "a risks slide and one ask slide. 8-10 slides, leadership-ready."),
]

RICH_PROMPTS = [
    # Session 16 priority A fixture (rebecca slug-emission regression).
    # Sam previously emitted bare "rebecca" on ingest+slides shapes,
    # which resolved via the umbrella rebecca.json to a tool-less
    # landing pad and stranded the user with no .pptx. ROUTER_SYSTEM
    # was strengthened with "never emit bare rebecca" language; this
    # fixture pins the fix.
    #
    # Tier 1 grades routing target only (slug match). PASS = Sam emits
    # 'rebecca-deck'. FAIL = Sam emits 'rebecca' (umbrella regression)
    # OR routes elsewhere (cliff, etc.).
    #
    # Tier 2b would also test invocation; the prompt lacks a real file
    # to ingest, so Tier 2b will exercise the BOUND path with [TBD]
    # placeholders per OUTPUT_CONTRACT — invocation should still happen.
    #
    # Synthesized rather than the literal incident prompt to avoid
    # committing personal Windows paths to the repo.
    ("Ingest the user guide document I shared and turn it into a slide "
     "deck for the next all-hands. About 12-15 slides, covering setup, "
     "core workflows, common gotchas, and where to get help. Include "
     "a closing slide with team contact info. Audience is roughly 40 "
     "non-technical staff at a logistics company (~200 FTE)."),

    # Classic board deck — specific period, audience, ask
    ("Build the Q1 2026 board deck for Acme Corp (B2B SaaS, $5M ARR, "
     "28 FTE). Audience is the board; March meeting is next Thursday. "
     "State of the business: Q1 ARR $1.4M vs $1.3M target (+8%), three "
     "enterprise logos closed (Meridian $180K, Kestrel $140K, Greenshoot "
     "$95K), expansion motion landed 41% of upsell pipeline. Key bet "
     "is the enterprise motion — we've committed $2.4M H2 GTM budget "
     "to hire 3 more enterprise AEs. Ask: approve the H2 budget to "
     "double enterprise AE count from 3 to 6 by Q3. Include risks "
     "slide: top-3 customer concentration (28% ARR), new-hire ramp "
     "timeline. Keep it tight — target 8-10 slides."),

    # QBR deck — internal audience, data-forward narrative arc
    ("Put together the Q1 QBR deck for Meridian Finance (Series B "
     "fintech, $14M ARR, 85 FTE) — internal exec team, not board. "
     "Three key bets to review: (1) Enterprise expansion (committed "
     "8 logos, closed 5, 62% close rate vs 50% target — working), "
     "(2) Self-serve funnel redesign (launched Feb 14, conversion "
     "dropped from 3.2% to 2.4%, not working), (3) Platform v2 "
     "migration (62% of customer base migrated, on track for Q2 "
     "completion). Ask is internal: kill the self-serve redesign "
     "and redirect $180K of its H1 remaining budget into enterprise "
     "SDR headcount. Risks: migration slippage could delay v1 "
     "sunset; need decision on migration deadline for customers "
     "still on v1. 10-12 slides, include speaker notes — Sam is "
     "presenting, wants to practice."),

    # Investor update deck — external audience, stakes framing
    ("Draft an investor update deck for Greenshoot Robotics (Series A, "
     "$8M ARR, 42 FTE). Audience is the Series A board + one Series B "
     "lead in diligence. Deck drives the Series B pricing conversation. "
     "Headline: we're at $8M ARR, 145% YoY growth, on track for $12M "
     "ARR by year-end. Key bets: (1) Enterprise robotics partnerships "
     "(ST Micro signed, Omron in pilot), (2) International expansion "
     "(EU go-live Q3), (3) Hardware margin expansion (from 42% to 48% "
     "post-v2 ship). Risks: supply chain (Q1 component lead-times blew "
     "out), FX exposure on EU launch. Ask: align board on raising "
     "Series B at $120M post rather than waiting for Q4 numbers. "
     "Include backup slides with detailed unit economics."),

    # Strategic review deck — results + direction
    ("Build a Q1 2026 exec review deck for Lattice Labs (dev tools, "
     "$4M ARR, 31 FTE, founder-led). Audience is the exec team plus "
     "two key investors (observers). State of business: Q1 revenue "
     "$950K (106% of $895K plan), NRR at 124% (2024H2 cohort), DAU/MAU "
     "at 38% and holding. Three key bets this quarter: (1) Enterprise "
     "move (shipped role-based access control, first 3 enterprise "
     "logos signed), (2) Partner channel (signed first 5 agencies, "
     "expected $240K H2 contribution), (3) Pricing restructure "
     "(moved from seat-based to usage-based Feb 1; early signs "
     "positive, NRR up 6pp on cohort). Ask: approve spinning up a "
     "dedicated enterprise AE pod (3 hires) in Q2 with $800K budget. "
     "Target 10 slides + appendix."),
]

NEGATIVE_PROMPTS = [
    ("pull together a monthly business review for March",         "rebecca-mbr"),
    ("research the latest dev-tools pricing benchmarks",          "cliff"),
    ("write a client proposal for Acme",                          "woody"),
    ("audit operations at our 25-person firm",                    "lilith"),
]


CONFIG = AgentTestConfig(
    agent_name="rebecca-deck",
    tool_name="generate_pptx_deck",
    template_key="executive_review_deck",
    short_prompts=SHORT_PROMPTS,
    rich_prompts=RICH_PROMPTS,
    negative_prompts=NEGATIVE_PROMPTS,
)


if __name__ == "__main__":
    run_tests(CONFIG)