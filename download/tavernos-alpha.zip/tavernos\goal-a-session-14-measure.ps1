# goal-a-session-14-measure.ps1  (revision r5)
#
# docx bypass multi-save measurement -- session 14 priority 4
#
# Revision notes (r5 vs r4):
#   - Set PYTHONIOENCODING=cp1252:replace early. r4 exposed that
#     norm.py's _splash() print at line 5056 crashes with
#     UnicodeEncodeError when stdout is piped (Python falls back to
#     cp1252 on Windows with no TTY, and cp1252 can't encode the
#     box-drawing chars in the splash). Setting cp1252:replace makes
#     Python substitute '?' for unencodable chars instead of
#     crashing. Banner string "Deliverable saved" is pure ASCII so
#     unaffected. r0 tried PYTHONIOENCODING=utf-8 and produced
#     mojibake because PS decoded cp1252 while Python emitted UTF-8;
#     cp1252:replace keeps both ends on Windows native encoding.
#   - Refactored Find-Python to return a hashtable. Arrays from
#     functions in PowerShell are a recurring footgun (single-element
#     unwrap, comma-operator over-wrap). Hashtables don't enumerate,
#     so no surprises. Cleans up the cosmetic "System.Object[]" diag
#     line from r4.
#
# Revision notes (r4 vs r3):
#   - Fixed array-unwrap bug in Find-Python. PowerShell collapses
#     single-element arrays returned from functions to scalars. r3
#     returned @("python") which became the scalar "python" at the
#     receive site. Then $Python + @(...) string-concatenated instead
#     of array-extending, and $exe = $pyArgs[0] indexed the first
#     character of the resulting string -- causing PowerShell to try
#     to invoke the command 'p'. Fix attempt: comma operator on
#     return. (Worked for invocation but over-wrapped for display.)
#
# Revision notes (r3 vs r2):
#   - Fixed Python detection rejecting good Pythons.
#     With $ErrorActionPreference = "Stop", PowerShell treats native
#     commands writing to stderr as terminating errors. Python and
#     py.exe both write --version output to stderr on some Windows
#     configurations. r2's Find-Python's catch block fired on the
#     stderr text and rejected valid Pythons. r3 wraps the --version
#     call in a local EAP=Continue so stderr is captured cleanly and
#     only exit code + output are used to judge.
#   - Fixed run invocation killing the pipeline on first stderr byte.
#     Same Stop-preference bug, same fix: local EAP=Continue around
#     the actual CLI invocation. Now whatever norm.py prints
#     (stdout, stderr, traceback) flows through Tee-Object into the
#     transcript instead of crashing the pipeline.
#
# Recommended invocation: double-click goal-a-session-14-measure.bat.
# The .bat uses -ExecutionPolicy Bypass and pauses at the end. If
# you'd rather run this .ps1 directly: right-click -> Run with
# PowerShell. Either way the window stays open until you press Enter.
#
# Rule 1: full prebuilt file, no edits required.
# Rule 2: ASCII-only.
# Rule 3: self-locating, self-unblocking, double-click runnable.

$ErrorActionPreference = "Stop"

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

$script:DiagLog = $null

function Log {
    param([string]$msg)
    $stamp = Get-Date -Format "HH:mm:ss"
    $line = "[$stamp] $msg"
    Write-Host $line
    if ($script:DiagLog) {
        try {
            Add-Content -Path $script:DiagLog -Value $line -Encoding ASCII -ErrorAction SilentlyContinue
        } catch { }
    }
}

function PauseAndExit {
    param([int]$code = 0)
    Write-Host ""
    Write-Host "----------------------------------------"
    [void](Read-Host "Press Enter to close this window")
    exit $code
}

# Run a native command with EAP suspended so stderr does not kill the
# pipeline. Returns a hashtable with Output, Exit, and Threw keys.
function Invoke-Native {
    param(
        [string]$Exe,
        [string[]]$NativeArgs,
        [string]$RunFile = $null
    )
    $oldEAP = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    $threw = $null
    $output = ""
    $exitCode = $null
    try {
        if ($RunFile) {
            # Tee mode: stream to file and console, return nothing meaningful
            & $Exe @NativeArgs *>&1 | Tee-Object -FilePath $RunFile | Out-Host
            $exitCode = $LASTEXITCODE
        } else {
            # Capture mode: collect output for inspection
            $output = (& $Exe @NativeArgs 2>&1 | Out-String).Trim()
            $exitCode = $LASTEXITCODE
        }
    } catch {
        $threw = $_
    } finally {
        $ErrorActionPreference = $oldEAP
    }
    return @{
        Output = $output
        Exit   = $exitCode
        Threw  = $threw
    }
}

function Find-Python {
    Log "Phase 2: detecting Python interpreter"
    foreach ($candidate in @("python", "python3", "py")) {
        $cmd = Get-Command $candidate -ErrorAction SilentlyContinue
        if (-not $cmd) {
            Log "  Candidate '$candidate': not found on PATH"
            continue
        }
        $cmdPath = $cmd.Source
        Log "  Candidate '$candidate': found at $cmdPath"

        # Reject Microsoft Store stub
        if ($cmdPath -and ($cmdPath -like "*WindowsApps*")) {
            Log "  -> REJECTED (Microsoft Store stub; not a real Python)"
            continue
        }

        # Verify by running --version (with EAP suspended)
        $verArgs = if ($candidate -eq "py") { @("-3", "--version") } else { @("--version") }
        $result = Invoke-Native -Exe $candidate -NativeArgs $verArgs

        if ($result.Threw) {
            Log "  --version unexpected throw: $($result.Threw)"
            Log "  -> REJECTED"
            continue
        }
        Log "  --version exit=$($result.Exit) output='$($result.Output)'"
        if ($result.Exit -ne 0) {
            Log "  -> REJECTED (--version exit code $($result.Exit))"
            continue
        }
        if ($result.Output -notmatch "Python 3") {
            Log "  -> REJECTED (--version did not report Python 3)"
            continue
        }
        Log "  -> ACCEPTED"
        # Hashtable return avoids PowerShell's array-unwrap-on-return
        # footgun. Arrays inside hashtables are not enumerated by the
        # output stream, so they survive function boundaries intact.
        if ($candidate -eq "py") {
            return @{ Found = $true; ExeArgs = @("py", "-3") }
        } else {
            return @{ Found = $true; ExeArgs = @($candidate) }
        }
    }
    return @{ Found = $false; ExeArgs = $null }
}

function Count-Banners {
    param([string]$RunFile)
    if (-not (Test-Path $RunFile)) { return 0 }
    $bannerMatches = Select-String -Path $RunFile -Pattern "Deliverable saved" -SimpleMatch -ErrorAction SilentlyContinue
    if ($bannerMatches) {
        return @($bannerMatches).Count
    } else {
        return 0
    }
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

try {

    # Phase 0: self-locate and self-unblock
    $ScriptDir = $PSScriptRoot
    if (-not $ScriptDir) {
        $ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
    }
    Set-Location $ScriptDir

    Write-Host ""
    Write-Host "=== docx bypass multi-save measurement (r5) ==="
    Write-Host "Script dir: $ScriptDir"
    Write-Host ""

    try {
        Get-ChildItem -Path $ScriptDir -Recurse -ErrorAction SilentlyContinue |
            Unblock-File -ErrorAction SilentlyContinue
    } catch { }

    # Phase 1: locate norm.py
    $NormPy = "C:\TavernOS\tavernos\norm.py"
    Write-Host "Phase 1: checking for norm.py at $NormPy"
    if (-not (Test-Path $NormPy)) {
        Write-Host "ERROR: norm.py not found at $NormPy" -ForegroundColor Red
        PauseAndExit -code 1
    }
    Write-Host "  Found."
    Write-Host ""

    # Phase 3 (early -- need DiagLog for later phases)
    $Timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
    $OutDir = Join-Path $ScriptDir "runs-$Timestamp"
    New-Item -ItemType Directory -Path $OutDir -Force | Out-Null
    $script:DiagLog = Join-Path $OutDir "diag.log"
    Set-Content -Path $script:DiagLog -Value "diag.log for run $Timestamp (r5)" -Encoding ASCII

    Log "Output dir: $OutDir"
    Log "norm.py: $NormPy"

    # Phase 2: detect Python (hardened)
    # Find-Python returns a hashtable to avoid array-unwrap surprises.
    $pyResult = Find-Python
    if (-not $pyResult.Found) {
        Write-Host ""
        Write-Host "ERROR: no usable Python 3 interpreter found on PATH." -ForegroundColor Red
        Write-Host "diag.log location: $script:DiagLog"
        PauseAndExit -code 1
    }
    $Python = $pyResult.ExeArgs
    Log "Python: $($Python -join ' ')"

    # Set Python's stdout/stderr encoding to cp1252 with replacement so
    # un-encodable Unicode chars (like the box-drawing chars in norm.py's
    # splash) become '?' instead of crashing with UnicodeEncodeError when
    # Python's stdout is piped instead of attached to a TTY. Banner
    # string "Deliverable saved" is pure ASCII so unaffected.
    $env:PYTHONIOENCODING = "cp1252:replace"
    Log "PYTHONIOENCODING=cp1252:replace (prevents splash-print crash on piped stdout)"

    # Phase 4: write the synthesized bypass prompt
    #
    # Carried unchanged from r1/r2. Fallback options A/B/C in the r2
    # comment block remain authorized; if smoke test fails, pick one
    # and request a revised script.
    Log "Phase 4: writing prompt file"
    $PromptFile = Join-Path $OutDir "prompt.txt"
    $PromptText = "Lilith, my mornings have been dragging lately -- I wake up around 7, futz around for a while, then start work feeling like I've already lost an hour. Quick ops audit, save as docx."
    Set-Content -Path $PromptFile -Value $PromptText -Encoding ASCII
    Log "Prompt file: $PromptFile"
    Log "Prompt text: $PromptText"

    # Phase 5: run loop with smoke-test gate
    $N = 5
    $RunFiles = @()

    function Invoke-OneRun {
        param(
            [int]$RunNum,
            [string]$RunFile
        )
        Log ("--- Run {0} of {1} ---" -f $RunNum, $N)
        Log "  Output: $RunFile"

        $pyArgs = $Python + @($NormPy, "--batch", $PromptFile)
        $exe = $pyArgs[0]
        $rest = $pyArgs[1..($pyArgs.Length - 1)]

        Log "  Command: $exe $($rest -join ' ')"

        $result = Invoke-Native -Exe $exe -NativeArgs $rest -RunFile $RunFile

        if ($result.Threw) {
            Log "  Run threw unexpectedly: $($result.Threw)"
        }
        if ($result.Exit -ne $null) {
            Log "  Exit code: $($result.Exit)"
        }
        if (Test-Path $RunFile) {
            $size = (Get-Item $RunFile).Length
            Log "  Transcript size: $size bytes"
        } else {
            Log "  Transcript file was NOT created (no output captured)"
        }
    }

    Log "Phase 5: run loop (N=$N)"

    # Run 1 (smoke test)
    $Run1File = Join-Path $OutDir "run_01.txt"
    Invoke-OneRun -RunNum 1 -RunFile $Run1File
    $RunFiles += $Run1File

    $Run1Banners = Count-Banners -RunFile $Run1File
    Log "Run 1 banner count: $Run1Banners"

    if ($Run1Banners -eq 0) {
        Write-Host ""
        Write-Host "=== SMOKE TEST FAILED ===" -ForegroundColor Yellow
        Write-Host "Run 1 produced zero 'Deliverable saved' banners."
        Write-Host ""
        Write-Host "Halting before runs 2-5 per proposal smoke-test clause."
        Write-Host ""
        Write-Host "Next steps:"
        Write-Host "  1. Inspect: $Run1File"
        Write-Host "  2. Inspect: $script:DiagLog"
        Write-Host "  3. Report what the transcript shows. r3 captures stderr"
        Write-Host "     so any Python traceback will be in run_01.txt."
        PauseAndExit -code 0
    }

    # Runs 2 through N
    for ($i = 2; $i -le $N; $i++) {
        $RunFile = Join-Path $OutDir ("run_{0:D2}.txt" -f $i)
        Invoke-OneRun -RunNum $i -RunFile $RunFile
        $RunFiles += $RunFile
    }

    # Phase 6: parse all runs and write summary
    Log "Phase 6: parsing transcripts and writing summary"

    $SummaryFile = Join-Path $OutDir "summary.txt"
    $SummaryLines = @()
    $SummaryLines += "docx bypass multi-save measurement -- summary (r5)"
    $SummaryLines += "Run timestamp: $Timestamp"
    $SummaryLines += "Prompt: $PromptText"
    $SummaryLines += "N runs: $N"
    $SummaryLines += "Output dir: $OutDir"
    $SummaryLines += ""
    $SummaryLines += "--- Per-run banner counts ---"

    $BannerCounts = @()

    for ($i = 1; $i -le $N; $i++) {
        $RunFile = Join-Path $OutDir ("run_{0:D2}.txt" -f $i)
        if (-not (Test-Path $RunFile)) {
            $SummaryLines += ("Run {0}: (file missing)" -f $i)
            continue
        }
        $count = Count-Banners -RunFile $RunFile
        $BannerCounts += $count
        $SummaryLines += ("Run {0}: {1} banner(s)" -f $i, $count)
    }

    $SummaryLines += ""
    $SummaryLines += "--- Aggregate ---"
    if ($BannerCounts.Count -gt 0) {
        $sorted = $BannerCounts | Sort-Object
        $median = $sorted[[int]([math]::Floor($sorted.Count / 2))]
        $sum = ($BannerCounts | Measure-Object -Sum).Sum
        $mean = [math]::Round($sum / $BannerCounts.Count, 2)
        $SummaryLines += ("Distribution: {0}" -f ($BannerCounts -join ", "))
        $SummaryLines += ("Median: {0}" -f $median)
        $SummaryLines += ("Mean:   {0}" -f $mean)
        $SummaryLines += ("Total banners across all runs: {0}" -f $sum)
    } else {
        $SummaryLines += "No banner counts collected."
    }

    $SummaryLines += ""
    $SummaryLines += "--- Per-banner context (banner line + 4 following lines) ---"

    for ($i = 1; $i -le $N; $i++) {
        $RunFile = Join-Path $OutDir ("run_{0:D2}.txt" -f $i)
        if (-not (Test-Path $RunFile)) { continue }

        $bannerMatches = Select-String -Path $RunFile -Pattern "Deliverable saved" -SimpleMatch -ErrorAction SilentlyContinue
        if (-not $bannerMatches) {
            $SummaryLines += ("Run {0}: no banners" -f $i)
            continue
        }

        $allLines = Get-Content -Path $RunFile -ErrorAction SilentlyContinue
        $bannerNum = 0
        foreach ($m in @($bannerMatches)) {
            $bannerNum++
            $lineIdx = $m.LineNumber - 1
            $SummaryLines += ""
            $SummaryLines += ("Run {0}, banner {1} (line {2}):" -f $i, $bannerNum, $m.LineNumber)
            $endIdx = [math]::Min($lineIdx + 4, $allLines.Count - 1)
            for ($j = $lineIdx; $j -le $endIdx; $j++) {
                $SummaryLines += ("  | " + $allLines[$j])
            }
        }
    }

    $SummaryLines += ""
    $SummaryLines += "--- Decision hint (per proposal) ---"
    if ($BannerCounts.Count -gt 0) {
        $median = ($BannerCounts | Sort-Object)[[int]([math]::Floor($BannerCounts.Count / 2))]
        $allOnes = ($BannerCounts | Where-Object { $_ -ne 1 }).Count -eq 0
        $allTwoPlus = ($BannerCounts | Where-Object { $_ -lt 2 }).Count -eq 0
        $mixed = (-not $allOnes) -and (-not $allTwoPlus) -and ($median -eq 1)

        if ($allOnes) {
            $SummaryLines += "Branch: median 1, all-1s -> Hypothesis 3 (wording held; close item)"
        } elseif ($allTwoPlus) {
            $SummaryLines += "Branch: median 2+, mostly-2s -> Hypothesis 1 (wording-only fix; session 15 structural fix)"
        } elseif ($mixed) {
            $SummaryLines += "Branch: median 1, mixed -> Hypothesis 2 (agent-side non-determinism; session 15 Option B cap 5->4)"
        } else {
            $SummaryLines += "Branch: review distribution manually -- does not match a clean tree branch"
        }
    } else {
        $SummaryLines += "Branch: no data"
    }

    Set-Content -Path $SummaryFile -Value $SummaryLines -Encoding ASCII

    Write-Host ""
    Write-Host "=== Summary ==="
    Write-Host ""
    $SummaryLines | ForEach-Object { Write-Host $_ }
    Write-Host ""
    Write-Host "Summary written to: $SummaryFile"
    Write-Host "diag.log:           $script:DiagLog"

    PauseAndExit -code 0

}
catch {
    Write-Host ""
    Write-Host "=== FATAL ERROR ===" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host ""
    Write-Host "Stack trace:" -ForegroundColor DarkGray
    Write-Host $_.ScriptStackTrace -ForegroundColor DarkGray
    Write-Host ""
    if ($script:DiagLog) {
        Add-Content -Path $script:DiagLog -Value "FATAL ERROR: $($_.Exception.Message)" -Encoding ASCII -ErrorAction SilentlyContinue
        Add-Content -Path $script:DiagLog -Value $_.ScriptStackTrace -Encoding ASCII -ErrorAction SilentlyContinue
        Write-Host "diag.log saved at: $script:DiagLog"
    }
    PauseAndExit -code 1
}
