#!/bin/sh
# TavernOS pre-push Tier 0 check - Goal A session 7 priority 3
# Runs test_layer1_mechanism.py and blocks the push on non-zero exit.

repo_root="$(git rev-parse --show-toplevel 2>/dev/null)"
if [ -z "$repo_root" ]; then
    echo "pre-push: ERROR - not inside a git repo" >&2
    exit 1
fi

pkg_dir="$repo_root/tavernos"
if [ ! -f "$pkg_dir/test_layer1_mechanism.py" ]; then
    echo "pre-push: ERROR - test_layer1_mechanism.py not found at $pkg_dir" >&2
    exit 1
fi

cd "$pkg_dir" || exit 1

echo "pre-push: running Tier 0 (test_layer1_mechanism.py)..."
python test_layer1_mechanism.py
code=$?

if [ $code -ne 0 ]; then
    echo ""
    echo "pre-push: Tier 0 FAILED (exit $code). Push blocked."
    echo "  Fix the failing test(s) or bypass with 'git push --no-verify'."
    exit $code
fi

echo "pre-push: Tier 0 passed. Push allowed."
exit 0
