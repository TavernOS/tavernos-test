# refresh-friend-zip.ps1
# Sanitizes Dan-specific content from shipped files and builds a clean friend ZIP.
#
# Uses .NET String.Replace() (literal substring, not regex) for bulletproof replacement.
# Replacements stored as ordered array of From/To objects so case-sensitive pairs
# (Hypothetica vs hypothetica) don't collide as hashtable keys would.
#
# Safe to re-run - idempotent on already-sanitized files.
# ASCII-only, PowerShell 5 compatible, writes UTF-8 without BOM.

$ErrorActionPreference = "Stop"
$repo = "C:\TavernOS\tavernos"
Set-Location $repo

# ----------------------------------------------------------------------------
# Replacement list - ORDERED, longest patterns first.
# Stored as array (not hashtable) so 'Hypothetica' and 'hypothetica' can both
# appear as case-sensitive entries. .Replace() is itself case-sensitive.
# ----------------------------------------------------------------------------
$replacements = @(
    [PSCustomObject]@{ From = 'Meridian Ventures';          To = 'Example Ventures' }
    [PSCustomObject]@{ From = 'Hypothetica Co.';            To = 'Example Co.' }
    [PSCustomObject]@{ From = 'Jamie Patel';                To = 'Jordan Lee' }
    [PSCustomObject]@{ From = 'Maya Rodriguez';             To = 'Alex Rivera' }
    [PSCustomObject]@{ From = 'Maya Chen';                  To = 'Alex Rivera' }
    [PSCustomObject]@{ From = 'Dan Cooper';                 To = '[Your Name]' }
    [PSCustomObject]@{ From = 'Dan Cobb';                   To = '[Your Name]' }
    [PSCustomObject]@{ From = 'dan@tavernos.ai';            To = 'you@tavernos.ai' }
    [PSCustomObject]@{ From = 'dan@tavernos';               To = 'you@tavernos' }
    [PSCustomObject]@{ From = 'hypothetica-mbr-2026-04';    To = 'example-mbr-2026-04' }
    [PSCustomObject]@{ From = 'proposal-hypothetica-q2.md'; To = 'proposal-northstar-q2.md' }
    [PSCustomObject]@{ From = 'Hypothetica';                To = 'Example Client' }
    [PSCustomObject]@{ From = 'hypothetica';                To = 'example' }
    [PSCustomObject]@{ From = 'Brightwave';                 To = 'Example Co.' }
    [PSCustomObject]@{ From = 'Zephyr';                     To = 'Example Co.' }
    [PSCustomObject]@{ From = 'Foldco';                     To = 'FormerCo' }
    [PSCustomObject]@{ From = '@maya';                      To = '@alex' }
)

# ----------------------------------------------------------------------------
# False positives to exclude from the rescan.
# Lines containing these tokens are INTENTIONAL references (audit check logic)
# and are not leaks. Any line matching any of these strings is skipped.
# ----------------------------------------------------------------------------
$rescanSuppressions = @(
    'FORBIDDEN_STRINGS_IN_HTML'    # tavernos_audit.py check constant
)

# ----------------------------------------------------------------------------
# Files/folders to clean. Only files that actually ship to friends.
# ----------------------------------------------------------------------------
$targetFiles = @(
    'norm.py','evaluator.py','artifact_docx.py','artifact_pptx.py','artifact_xlsx.py',
    'server.py','tavernos_audit.py','tavernos_ux.py','mcp_client.py','requirements.txt'
)
$targetFolders = @('agents','skills')

# Collect candidate files
$files = New-Object System.Collections.ArrayList
foreach ($t in $targetFiles) {
    if (Test-Path $t) { [void]$files.Add((Get-Item $t).FullName) }
}
foreach ($f in $targetFolders) {
    if (Test-Path $f) {
        Get-ChildItem -Path $f -Recurse -File -Include *.md,*.json,*.txt,*.py -ErrorAction SilentlyContinue |
            ForEach-Object { [void]$files.Add($_.FullName) }
    }
}

Write-Host ("=== STEP 1: Scan and sanitize " + $files.Count + " files ===") -ForegroundColor Cyan

$utf8NoBom = New-Object System.Text.UTF8Encoding $false
$totalReplacements = 0
$filesChanged = 0

foreach ($file in $files) {
    $content = [System.IO.File]::ReadAllText($file)
    $original = $content
    $fileChanges = New-Object System.Collections.ArrayList

    foreach ($r in $replacements) {
        if ($content.Contains($r.From)) {
            # Count matches before replacing
            $count = 0
            $idx = 0
            while (($idx = $content.IndexOf($r.From, $idx)) -ge 0) {
                $count++
                $idx += $r.From.Length
            }
            $content = $content.Replace($r.From, $r.To)
            [void]$fileChanges.Add([PSCustomObject]@{ From = $r.From; To = $r.To; Count = $count })
            $totalReplacements += $count
        }
    }

    if ($content -ne $original) {
        [System.IO.File]::WriteAllText($file, $content, $utf8NoBom)
        $filesChanged++
        $rel = $file.Replace($repo + '\', '')
        Write-Host ("  + " + $rel) -ForegroundColor Green
        foreach ($c in $fileChanges) {
            Write-Host ("      '" + $c.From + "' -> '" + $c.To + "'  x" + $c.Count)
        }
    }
}

Write-Host ""
Write-Host ("  Summary: " + $filesChanged + " file(s) changed, " + $totalReplacements + " total replacement(s)") -ForegroundColor Cyan

# ----------------------------------------------------------------------------
# Rescan: case-insensitive Select-String against a wide pattern list,
# confirms nothing slipped through. False positives are filtered below.
# ----------------------------------------------------------------------------
Write-Host ""
Write-Host "=== STEP 2: Rescan for any remaining leaks ===" -ForegroundColor Cyan

$scanPatterns = 'hypothetica','maya chen','maya rodriguez','jamie patel','meridian ventures','foldco','dan cobb','dan cooper','dan@tavernos','brightwave','zephyr','@maya'
$hits = Get-ChildItem -Path $targetFolders -Recurse -File -Include *.md,*.json,*.txt,*.py -ErrorAction SilentlyContinue |
    Select-String -Pattern $scanPatterns
foreach ($t in $targetFiles) {
    if (Test-Path $t) {
        $h = Select-String -Path $t -Pattern $scanPatterns
        if ($h) { $hits = @($hits) + @($h) }
    }
}

# Filter out known false positives (audit check logic that legitimately
# contains these strings in order to detect them in site HTML).
$suppressedCount = 0
if ($hits) {
    $filtered = New-Object System.Collections.ArrayList
    foreach ($hit in $hits) {
        $isSuppressed = $false
        foreach ($s in $rescanSuppressions) {
            if ($hit.Line.Contains($s)) { $isSuppressed = $true; break }
        }
        if ($isSuppressed) { $suppressedCount++ }
        else { [void]$filtered.Add($hit) }
    }
    $hits = $filtered.ToArray()
}

if ($suppressedCount -gt 0) {
    Write-Host ("  (suppressed " + $suppressedCount + " known false positive(s) - audit check logic)") -ForegroundColor DarkGray
}

if ($hits -and $hits.Count -gt 0) {
    Write-Host "  ! LEAKS REMAIN - do not ship:" -ForegroundColor Red
    $hits | ForEach-Object {
        $rel = $_.Path.Replace($repo + '\', '')
        Write-Host ("    " + $rel + ":" + $_.LineNumber + "  " + $_.Line.Trim())
    }
    Write-Host ""
    Write-Host "  Stopping. Paste these lines back and we will extend the replacement table." -ForegroundColor Red
    exit 1
}
Write-Host "  + clean" -ForegroundColor Green

# ----------------------------------------------------------------------------
# Build staging folder and ZIP.
# ----------------------------------------------------------------------------
Write-Host ""
Write-Host "=== STEP 3: Build staging folder ===" -ForegroundColor Cyan

$staging = Join-Path $env:TEMP "tavernos-alpha-staging"
if (Test-Path $staging) { Remove-Item -Recurse -Force $staging }
New-Item -ItemType Directory -Path $staging | Out-Null

$keep = @(
    'artifact_docx.py','artifact_pptx.py','artifact_xlsx.py',
    'evaluator.py','mcp_client.py','norm.py','server.py',
    'tavernos_audit.py','tavernos_ux.py','requirements.txt',
    'audit_config.json.example'
)
foreach ($f in $keep) {
    if (Test-Path $f) { Copy-Item $f $staging\ }
}
Copy-Item -Recurse agents $staging\
Copy-Item -Recurse skills $staging\

New-Item -ItemType Directory -Path "$staging\web" | Out-Null
if (Test-Path "web\__init__.py") { Copy-Item "web\__init__.py" "$staging\web\" }
if (Test-Path "web\static")      { Copy-Item -Recurse "web\static" "$staging\web\" }

$stagedCount = (Get-ChildItem $staging -Recurse -File).Count
Write-Host ("  + staging assembled at " + $staging + " (" + $stagedCount + " files)") -ForegroundColor Green

Write-Host ""
Write-Host "=== STEP 4: Build ZIP ===" -ForegroundColor Cyan

$zipOut = Join-Path $HOME "Downloads\tavernos-alpha.zip"
if (Test-Path $zipOut) { Remove-Item $zipOut }
Compress-Archive -Path "$staging\*" -DestinationPath $zipOut
$sizeKB = [math]::Round((Get-Item $zipOut).Length / 1KB, 1)
Write-Host ("  + " + $zipOut + "  (" + $sizeKB + " KB)") -ForegroundColor Green

Remove-Item -Recurse -Force $staging

Write-Host ""
Write-Host "DONE." -ForegroundColor Cyan
Write-Host ("  ZIP:  " + $zipOut) -ForegroundColor Cyan
Write-Host "  Next: .\verify-friend-zip.ps1" -ForegroundColor Cyan
