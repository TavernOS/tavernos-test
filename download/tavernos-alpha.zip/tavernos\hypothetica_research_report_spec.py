"""tavernos/tests/hypothetica_research_report_spec.py — Phase 4C test fixture.

Parallels hypothetica_audit_spec.py from 4B. The deliverable is Cliff's
research-memo answering a question Maya Chen actually has: where does her
company sit operationally vs its Series A SaaS cohort? The audit (Lilith)
says "here's what's wrong internally"; the research (Cliff) says "here's
what 'normal' looks like so you can calibrate."

Design choices baked into this fixture
--------------------------------------
- Real benchmark publishers only. KeyBanc, OpenView, ChartMogul, Gainsight,
  SaaS Capital, Bessemer — each is a genuine primary-data shop that runs
  its own cohort surveys. Every citation has publisher + approximate date
  (required by preflight R4 — source_quality has the only 4.0 hard floor
  in any rubric).
- Two structured points_of_tension — the synthesis_quality anchor-5 slot
  ("conflicts named and resolved"). Cohort-definition tension (KeyBanc vs
  OpenView on ARR range) and methodology tension (Gainsight vs Gorgias on
  what counts as CS-backlog). Both have "our_read" reconciliations.
- Numbers are benchmark-plausible, not benchmark-exact. A real research
  memo hedges — "roughly median", "bottom quartile", "above peer median of
  5-7%" — rather than pretending to point-estimate precision that annual
  surveys don't support. This feeds uncertainty_acknowledgment AND source
  honesty; the methodology note explicitly calls out the imprecision.
- Hypothetica's profile drives the findings: $4.2M ARR / 42 FTE = $100K
  ARR/FTE (median-ish for Series A SaaS). 8-day CS backlog is unambiguously
  bottom quartile. ~10% planning variance is directly from the audit — a
  hook that lets Cliff's memo compose with Lilith's diagnosis.

Operator identity: Dan Cobb, TavernOS — not Dan Cooper, not Zephyr.
"""

from hypothetica import HYPOTHETICA

# ═══════════════════════════════════════════════════════════════════════════════
#  THE SPEC — passed directly to artifact_docx.build_from_spec.
# ═══════════════════════════════════════════════════════════════════════════════

RESEARCH_REPORT_SPEC = {
    "artifact":  "docx",
    "template":  "research_report",
    "filename":  "hypothetica-saas-ops-benchmarks",
    "category":  "reports",
    "meta": {
        "title":       "Series A SaaS Operational-Leverage Benchmarks",
        "client_name": HYPOTHETICA["company"],
        "prepared_by": f"{HYPOTHETICA['operator']['name']}, {HYPOTHETICA['operator']['org']}",
        "date":        "April 28, 2026",
    },

    # ── Research question — the hook the report delivers against ──────────
    "research_question": (
        "Where does Hypothetica Co. sit against its Series A B2B SaaS cohort "
        "on operational-leverage metrics — and which of the three pain points "
        "Maya Chen surfaced (dashboard reconciliation, planning variance, CS "
        "backlog) is most out-of-line with peers?"
    ),

    # ── Executive summary — direct answer + confidence + framing ──────────
    "executive_summary": {
        "headline": (
            "Hypothetica is roughly median on ARR-per-FTE and headcount mix, "
            "but bottom-quartile on CS-ticket backlog and above peer median "
            "on monthly planning variance — the CS backlog is the most "
            "out-of-line metric and the highest-leverage place to start."
        ),
        "confidence": (
            "moderate — cohort definitions vary across sources by up to "
            "25% in ARR range, and the B2B-agency-SaaS sub-cohort is "
            "small in every benchmark set we consulted. Direction of the "
            "findings is robust; exact percentile placement is not."
        ),
        "context": (
            "Maya asked for three things on the Apr 16 call: a number to "
            "open monthly ops reviews with, a single dashboard, and a "
            "handle on the CS backlog. This memo tells her whether her "
            "pain is normal or acute — the answer shapes where the "
            "operational-audit priority stack spends its first $3K."
        ),
    },

    # ── Key findings — numbered, stand-alone, each with confidence + implication ──
    # Preflight R2 requires 3-5. Five here to give the scorer both the
    # headline metrics and the pattern-match finding that ties them together.
    "key_findings": [
        {
            "finding": (
                "ARR-per-FTE of ~$100K places Hypothetica at roughly the "
                "45th-55th percentile of Series A B2B SaaS — median, not "
                "the leverage bottleneck"
            ),
            "confidence": "high",
            "so_what": (
                "Don't restructure hiring; the gross-output-per-person "
                "number is normal. The leverage problem is elsewhere."
            ),
        },
        {
            "finding": (
                "An 8-day CS-ticket backlog is bottom-quartile vs peer "
                "cohort (top quartile resolves in under 48 hours; peer "
                "median is ~3 days)"
            ),
            "confidence": "high",
            "so_what": (
                "This is the out-of-line metric. Correlates in two "
                "source datasets with elevated 12-month gross-dollar "
                "churn — direct threat to Hypothetica's expansion motion."
            ),
        },
        {
            "finding": (
                "Hypothetica's ~10% monthly revenue-vs-plan variance "
                "exceeds peer median of 5-7% (OpenView Q4 2025 FP&A "
                "benchmark; n~140)"
            ),
            "confidence": "moderate",
            "so_what": (
                "Variance itself is survivable at Series A scale; the "
                "tell is that Maya can't tell you whether variance is "
                "getting better or worse. Reporting infra, not demand "
                "volatility, is the root cause."
            ),
        },
        {
            "finding": (
                "Headcount mix (approximately 60/40 engineering to "
                "non-engineering at 42 FTE) matches the Series A "
                "structural median — not a hiring-mix problem"
            ),
            "confidence": "moderate",
            "so_what": (
                "Validates the audit's implicit assumption that the "
                "fixes are tooling + cadence, not org-design."
            ),
        },
        {
            "finding": (
                "The pattern (median ARR/FTE + bottom-quartile CS + "
                "elevated planning variance) is a documented 'post-A "
                "ops-debt' profile — revenue maturity outrunning "
                "operational maturity, typical 6-12 months before a "
                "Series B raise"
            ),
            "confidence": "high",
            "so_what": (
                "This is a stage-appropriate problem, not a broken "
                "company. The fixes are well-trodden: reporting "
                "reconciliation first, CS cadence second, planning "
                "discipline third. Priority order matches the audit."
            ),
        },
    ],

    # ── Synthesis — cross-source narrative + agreement + tension ──────────
    # This is the synthesis_quality anchor-5 block. Two documented tensions
    # with explicit "our read" reconciliations — mechanically visible to the
    # evaluator's text extraction.
    "synthesis": {
        "narrative": (
            "The benchmark literature converges on one frame for Series A "
            "B2B SaaS: the transition from founder-led selling to "
            "repeatable revenue operations produces a predictable "
            "operational-debt profile. KeyBanc's 2025 survey, OpenView's "
            "Q4 SaaS benchmarks, and SaaS Capital's 2025 index all show "
            "the same median ARR-per-FTE band ($95K-$110K) for companies "
            "in Hypothetica's stage and size. On that axis, Hypothetica "
            "is unremarkable.\n\n"
            "Where the sources diverge, and where Hypothetica's specific "
            "profile stands out, is in customer operations. The CS "
            "benchmark literature (Gainsight, Gorgias, Zendesk) uses "
            "different backlog definitions and different cohort mixes, "
            "but every one of them places an 8-day resolution backlog "
            "in their bottom quartile. This is the 'real' signal in the "
            "Hypothetica data — the ARR-per-FTE number is noise, the "
            "CS-backlog number is the pattern.\n\n"
            "OpenView's 2025 work on 'post-A ops debt' gives us the "
            "framing that ties the three pain points together. Their "
            "cohort analysis shows that reporting-variance above 8%, "
            "CS-backlog above 5 days, and difficulty answering 'are we "
            "on plan' in real time all co-occur in the 12-month window "
            "before a Series B raise. Hypothetica hits all three markers. "
            "That's not a crisis signal — it's a stage signal."
        ),
        "points_of_agreement": [
            (
                "KeyBanc, OpenView, and SaaS Capital all place the Series "
                "A B2B SaaS ARR-per-FTE median in the $95K-$110K band, "
                "despite different cohort cut-offs"
            ),
            (
                "Every consulted CS benchmark (Gainsight 2025, Gorgias "
                "2026, Zendesk State of CX 2025) places multi-day "
                "resolution backlogs in the bottom quartile, regardless "
                "of vertical"
            ),
            (
                "Post-A 'ops-debt' is a named pattern in both the "
                "OpenView and Bessemer literature — revenue maturity "
                "outrunning operational maturity is the default state, "
                "not the exception"
            ),
        ],
        "points_of_tension": [
            {
                "topic": (
                    "What ARR range counts as 'Series A B2B SaaS' for "
                    "benchmarking — different cohort definitions produce "
                    "different percentile placements"
                ),
                "source_a_says": (
                    "KeyBanc's 2025 Private SaaS Survey uses $1M-$100M "
                    "ARR as the 'growth stage' band (n=364), which means "
                    "a $4.2M-ARR company sits near the bottom of a wide "
                    "cohort"
                ),
                "source_b_says": (
                    "OpenView's SaaS Benchmarks 2025 splits 'Seed/Pre-A' "
                    "($1M-$3M), 'Series A' ($3M-$10M), and 'Series B' "
                    "($10M-$30M) into discrete cohorts, which puts "
                    "Hypothetica solidly inside a tighter Series A peer "
                    "set (n~140)"
                ),
                "our_read": (
                    "Use OpenView for percentile placement (tighter, "
                    "stage-specific) and KeyBanc for scale-invariant "
                    "metrics like ARR-per-FTE (wider n, more stable). "
                    "Mixing them produces the 45th-55th percentile ARR/FTE "
                    "read we report in Finding 1."
                ),
            },
            {
                "topic": (
                    "What counts as a CS-backlog benchmark — support-"
                    "ticket shops (Gorgias, Zendesk) and CS-ops shops "
                    "(Gainsight) measure different things"
                ),
                "source_a_says": (
                    "Gorgias's 2026 CX benchmarks focus on first-"
                    "response and resolution times for transactional "
                    "support tickets, with a heavy DTC-ecommerce skew "
                    "that may not apply to B2B-agency software"
                ),
                "source_b_says": (
                    "Gainsight's 2025 State of Customer Success looks "
                    "at post-sale account-health workflows, not ticket "
                    "queues — its 'backlog' metric is more about QBR "
                    "cadence than response time"
                ),
                "our_read": (
                    "Hypothetica's 8-day backlog is ticket-queue "
                    "backlog (Gorgias-style). Use the Gorgias benchmark "
                    "for percentile placement; use Gainsight for the "
                    "implication ('bottom-quartile ticket ops correlate "
                    "with CS-motion breakdown, which correlates with "
                    "expansion-ARR underperformance')."
                ),
            },
        ],
    },

    # ── Findings in detail — per-finding analysis + structured citations ──
    # Preflight R3 requires >=2 citations per entry; R4 requires
    # source+publisher+date populated on each. This is where source_quality
    # gets scored — the hard-floor dimension.
    "findings_detail": [
        {
            "finding_ref": 1,
            "analysis": (
                "Hypothetica's $4.2M ARR and 42 FTE headcount produce an "
                "ARR-per-FTE of approximately $100K. Three benchmark "
                "sources place the Series A B2B SaaS median in the "
                "$95K-$110K band, meaning Hypothetica sits at roughly "
                "the 45th-55th percentile on this axis.\n\n"
                "This is the cleanest 'you are normal' finding in the "
                "report. Gross output per person is not where Hypothetica "
                "is leaking leverage. Any diagnosis that points at "
                "headcount or hiring mix as a primary lever should be "
                "deprioritized relative to operational fixes."
            ),
            "supporting_evidence": [
                {
                    "source":    "2025 Private SaaS Company Survey",
                    "publisher": "KeyBanc Capital Markets",
                    "date":      "October 2025",
                    "detail": (
                        "Median ARR-per-FTE for 'growth-stage' SaaS "
                        "(defined as $1M-$100M ARR, n=364) reported "
                        "at approximately $108K"
                    ),
                    "url": "https://www.key.com/businesses-institutions/industry-expertise/saas-survey.jsp",
                },
                {
                    "source":    "SaaS Benchmarks 2025",
                    "publisher": "OpenView Partners",
                    "date":      "Q4 2025",
                    "detail": (
                        "Series A cohort ($3M-$10M ARR, n~140) "
                        "ARR-per-FTE median around $98K; 40th-60th "
                        "percentile band approximately $85K-$115K"
                    ),
                    "url": "https://openviewpartners.com/saas-benchmarks",
                },
                {
                    "source":    "SaaS Capital Index 2025",
                    "publisher": "SaaS Capital",
                    "date":      "August 2025",
                    "detail": (
                        "Sub-$10M ARR private SaaS cohort ARR-per-FTE "
                        "median reported in the $95K-$105K band; no "
                        "meaningful variance by vertical at this size"
                    ),
                    "url": "https://www.saas-capital.com/research",
                },
            ],
        },
        {
            "finding_ref": 2,
            "analysis": (
                "An 8-day ticket-resolution backlog is bottom-quartile "
                "across every consulted benchmark that reports ticket-"
                "queue metrics. Gorgias's 2026 CX Benchmarks place the "
                "median resolution time at approximately 2.5 days and "
                "the top-quartile threshold at under 48 hours. Zendesk's "
                "2025 State of CX report uses slightly different cohort "
                "definitions but shows the same shape: 5+ day backlogs "
                "sit in the bottom 20-25%.\n\n"
                "The implication is not just 'slow support.' Gainsight's "
                "2025 State of CS work documents that ticket-queue "
                "backlogs above 5 days correlate with a breakdown in "
                "post-sale motion more broadly — CS reps caught up in "
                "reactive firefighting don't run the expansion playbook, "
                "which compounds the revenue impact the audit already "
                "flagged (Priority #2's $9K March expansion-ARR miss)."
            ),
            "supporting_evidence": [
                {
                    "source":    "CX Benchmarks Report 2026",
                    "publisher": "Gorgias",
                    "date":      "January 2026",
                    "detail": (
                        "Median resolution time 2.5 days across n=2,400 "
                        "B2B+DTC merchants; top-quartile threshold 48 "
                        "hours; bottom-quartile begins at approximately "
                        "5 days"
                    ),
                    "url": "https://www.gorgias.com/benchmarks",
                },
                {
                    "source":    "State of CX 2025",
                    "publisher": "Zendesk",
                    "date":      "September 2025",
                    "detail": (
                        "B2B SaaS segment (n not disclosed) resolution-"
                        "time median 3.2 days; 5+ day backlogs placed "
                        "in bottom quartile"
                    ),
                    "url": "https://www.zendesk.com/state-of-cx",
                },
                {
                    "source":    "State of Customer Success 2025",
                    "publisher": "Gainsight",
                    "date":      "November 2025",
                    "detail": (
                        "Post-sale motion breakdown correlates with "
                        "ticket backlog >5 days; affected cohort shows "
                        "~1.5x gross-dollar churn vs top quartile"
                    ),
                    "url": "https://www.gainsight.com/state-of-cs",
                },
            ],
        },
        {
            "finding_ref": 3,
            "analysis": (
                "Hypothetica's Q1 2026 shows monthly revenue-vs-plan "
                "variance of approximately 10% (March: $305K actual vs "
                "$340K plan = -10.3%). OpenView's Q4 2025 FP&A benchmark "
                "places the Series A peer median in the 5-7% band.\n\n"
                "Variance at this magnitude is not itself alarming at "
                "$4.2M ARR — small absolute base, normal deal-timing "
                "noise. The diagnostic signal is the one Maya herself "
                "volunteered on the April 16 call: she can't tell "
                "whether variance is getting better or worse. That's a "
                "reporting-infrastructure problem, not a demand "
                "problem. Bessemer's State of the Cloud 2025 notes the "
                "same pattern: companies with reporting reconciliation "
                "issues show higher forecast variance not because their "
                "business is more volatile but because their measurement "
                "is noisier."
            ),
            "supporting_evidence": [
                {
                    "source":    "SaaS Benchmarks 2025, FP&A Section",
                    "publisher": "OpenView Partners",
                    "date":      "Q4 2025",
                    "detail": (
                        "Series A cohort monthly revenue-vs-plan "
                        "variance median 6%, top-quartile threshold "
                        "below 3%; 10%+ variance places respondent in "
                        "roughly the 25th percentile"
                    ),
                    "url": "https://openviewpartners.com/saas-benchmarks",
                },
                {
                    "source":    "State of the Cloud 2025",
                    "publisher": "Bessemer Venture Partners",
                    "date":      "February 2025",
                    "detail": (
                        "Qualitative finding: reporting-reconciliation "
                        "friction at Series A correlates with higher "
                        "forecast variance independent of underlying "
                        "business volatility"
                    ),
                    "url": "https://www.bvp.com/atlas/state-of-the-cloud-2025",
                },
            ],
        },
        {
            "finding_ref": 4,
            "analysis": (
                "Hypothetica's 42-FTE headcount splits roughly 60/40 "
                "between engineering (including product and design) and "
                "non-engineering (GTM, CS, ops, G&A). Both primary "
                "sources we consulted place the Series A B2B SaaS "
                "median in the 55-65% engineering band, with a "
                "reasonably narrow distribution at this size.\n\n"
                "The finding is a deliberate negative result — we "
                "looked at hiring mix because it is a common Series A "
                "leverage lever, and found no signal. This matters "
                "because it closes off a branch of diagnosis: Maya's "
                "ops problems are not downstream of an unbalanced team. "
                "The fixes live in tooling, cadence, and measurement — "
                "not in org design or hiring plan."
            ),
            "supporting_evidence": [
                {
                    "source":    "2025 Private SaaS Company Survey, Org Section",
                    "publisher": "KeyBanc Capital Markets",
                    "date":      "October 2025",
                    "detail": (
                        "Growth-stage SaaS median engineering share of "
                        "headcount reported at 58%, with interquartile "
                        "range 52-64%"
                    ),
                    "url": "https://www.key.com/businesses-institutions/industry-expertise/saas-survey.jsp",
                },
                {
                    "source":    "SaaS Benchmarks 2025, Team Composition",
                    "publisher": "OpenView Partners",
                    "date":      "Q4 2025",
                    "detail": (
                        "Series A cohort engineering/product share "
                        "median 61%; range 50-70% encompasses the "
                        "middle two quartiles"
                    ),
                    "url": "https://openviewpartners.com/saas-benchmarks",
                },
            ],
        },
        {
            "finding_ref": 5,
            "analysis": (
                "OpenView's 2025 benchmark work names and describes a "
                "recurring pattern in their Series A cohort: 'post-A "
                "operational debt,' where revenue processes mature "
                "faster than measurement, CS, and planning "
                "infrastructure. Companies in this pattern show three "
                "co-occurring markers: (a) monthly planning variance "
                "above 8%, (b) multi-day CS-backlog, and (c) difficulty "
                "answering 'are we on plan' in real time. Hypothetica "
                "hits all three.\n\n"
                "The pattern is described as common in the 12-month "
                "window before a Series B raise. It is not a crisis "
                "signal; it is a stage signal. The implication for "
                "Hypothetica's audit priority order is that the fixes "
                "are well-trodden — reporting reconciliation first, CS "
                "cadence second, planning discipline third — and the "
                "audit's proposed sequence matches the literature's "
                "prescription."
            ),
            "supporting_evidence": [
                {
                    "source":    "SaaS Benchmarks 2025, Ops Section",
                    "publisher": "OpenView Partners",
                    "date":      "Q4 2025",
                    "detail": (
                        "'Post-A ops debt' pattern described with the "
                        "three co-occurring markers; characterized as "
                        "typical 6-12 months pre-Series-B"
                    ),
                    "url": "https://openviewpartners.com/saas-benchmarks",
                },
                {
                    "source":    "Scaling to $100M ARR (research note)",
                    "publisher": "Bessemer Venture Partners",
                    "date":      "October 2025",
                    "detail": (
                        "Independent characterization of the same "
                        "pattern under different naming; prescriptive "
                        "sequence: measurement infra, CS cadence, "
                        "planning discipline"
                    ),
                    "url": "https://www.bvp.com/atlas",
                },
            ],
        },
    ],

    # ── Limitations — where this research could not determine ─────────────
    # uncertainty_acknowledgment anchor-5: "uncertainty explicit"
    "limitations": [
        (
            "Cohort definitions for 'Series A B2B SaaS' vary by up to "
            "25% in ARR range across the consulted benchmark sources. "
            "Hypothetica's $4.2M ARR places it near the low end of "
            "KeyBanc's cohort and solidly inside OpenView's cohort — "
            "percentile placements within ±10 percentile points should "
            "be treated as directional, not precise."
        ),
        (
            "The B2B-agency-SaaS vertical sub-cohort is small (n<50) in "
            "every benchmark we consulted. Vertical-specific benchmarks "
            "are not robust; cross-vertical Series A benchmarks are the "
            "right reference class for this analysis."
        ),
        (
            "CS-backlog benchmarks skew toward DTC-adjacent SaaS "
            "(Gorgias, Zendesk data). B2B-agency-software-specific "
            "benchmarks don't exist at publishable scale; we relied on "
            "cross-vertical data and the qualitative Gainsight read to "
            "triangulate."
        ),
        (
            "Hypothetica's 10% planning variance is a one-quarter "
            "snapshot (Jan-Mar 2026). Directional claims would benefit "
            "from trailing 4 quarters; variance readings on <$5M ARR "
            "bases are inherently noisy."
        ),
        (
            "We did not find public benchmark data for the specific "
            "'six dashboards, no single source of truth' symptom Maya "
            "described. The audit's diagnosis of that pain is grounded "
            "in internal evidence; this memo does not externally "
            "corroborate or challenge it."
        ),
    ],

    # ── Recommendations — optional, deliberately short ────────────────────
    # Cliff's persona is research, not prescription. Three bulleted
    # decision-support items, not directives.
    "recommendations": [
        (
            "Open the next monthly ops review with the CS-backlog "
            "metric (days-to-resolution), not the revenue variance "
            "number. It's the out-of-line metric; the revenue number "
            "is within stage-normal range."
        ),
        (
            "Frame the audit's priority stack to Maya using the 'post-A "
            "ops-debt' pattern — this is stage-appropriate, not "
            "broken — to de-risk the conversation about paying for "
            "operational fixes before Series B."
        ),
        (
            "Re-benchmark against the same sources at end of Q3 2026. "
            "A 6-month delta on CS-backlog is the single cleanest "
            "external signal that the audit's Priority #2 is working."
        ),
    ],

    # ── Sources consulted — full reference list ────────────────────────────
    # source_quality + formatting_for_reuse. Six sources, all real
    # benchmark-publishing shops, with publisher + date + cohort notes.
    "sources_consulted": [
        {
            "title":     "2025 Private SaaS Company Survey",
            "author":    "KeyBanc Capital Markets",
            "publisher": "KeyBanc Capital Markets",
            "date":      "October 2025",
            "url":       "https://www.key.com/businesses-institutions/industry-expertise/saas-survey.jsp",
            "notes":     "n=364; 'growth-stage' cohort $1M-$100M ARR; annual survey, widely cited as primary benchmark source",
        },
        {
            "title":     "SaaS Benchmarks 2025",
            "author":    "OpenView Partners",
            "publisher": "OpenView Partners",
            "date":      "Q4 2025",
            "url":       "https://openviewpartners.com/saas-benchmarks",
            "notes":     "Stage-specific cohorts; Series A n~140; strongest source for percentile placement at Hypothetica's scale",
        },
        {
            "title":     "SaaS Capital Index — Q3 2025 Report",
            "author":    "SaaS Capital",
            "publisher": "SaaS Capital",
            "date":      "August 2025",
            "url":       "https://www.saas-capital.com/research",
            "notes":     "Private-market SaaS index; useful for ARR-growth benchmarks, less useful for operational metrics",
        },
        {
            "title":     "State of Customer Success 2025",
            "author":    "Gainsight",
            "publisher": "Gainsight",
            "date":      "November 2025",
            "url":       "https://www.gainsight.com/state-of-cs",
            "notes":     "Post-sale motion focus; strongest source for the churn-backlog correlation read",
        },
        {
            "title":     "CX Benchmarks Report 2026",
            "author":    "Gorgias",
            "publisher": "Gorgias",
            "date":      "January 2026",
            "url":       "https://www.gorgias.com/benchmarks",
            "notes":     "n=2,400 merchants; DTC skew but methodology is clean; used for ticket-queue resolution-time placement",
        },
        {
            "title":     "State of the Cloud 2025",
            "author":    "Bessemer Venture Partners",
            "publisher": "Bessemer Venture Partners",
            "date":      "February 2025",
            "url":       "https://www.bvp.com/atlas/state-of-the-cloud-2025",
            "notes":     "Public-market focused; qualitative framing on Series-A-to-B ops-debt pattern",
        },
    ],

    # ── Methodology note — search strategy + inclusion criteria ────────────
    "methodology_note": (
        "Consulted six published benchmark sources dated within the last "
        "18 months (Feb 2025 - Jan 2026), prioritizing reports that (a) "
        "run their own primary data collection rather than aggregating "
        "secondary sources, (b) report cohort size (n) and ARR-range "
        "definitions, and (c) separate Series A peers from earlier/later "
        "stages where possible. Where sources disagree on cohort "
        "definitions (see Synthesis), we used OpenView for percentile "
        "placement and KeyBanc for scale-invariant metrics. Point "
        "estimates for Hypothetica's percentile placement are "
        "intentionally expressed as ranges (e.g. '45th-55th') because "
        "annual survey methodology does not support tighter precision."
    ),
}
