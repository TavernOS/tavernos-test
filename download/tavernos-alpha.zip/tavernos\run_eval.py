"""Run the TavernOS evaluator against the three Hypothetica deliverables.

Prereqs:
  - Three files present in _self deliverables (or pointed at via --dir)
  - ANTHROPIC_API_KEY set in the environment (or OPENAI_API_KEY with --provider openai)
  - `anthropic` or `openai` Python package installed
  - Run from the tavernos package dir so `evaluator` imports cleanly,
    or set PYTHONPATH

Usage:
  # Default -- looks for files in the built output dir
  python run_eval.py --dir "C:\\TavernOS\\dogfood\\outputs"

  # Override model (e.g., to match async-mode default)
  python run_eval.py --dir ... --model claude-opus-4-5

  # Use OpenAI instead
  python run_eval.py --dir ... --provider openai --model gpt-4o

Output: prints score table to stdout, writes eval-results.json next to the files.
"""

import argparse
import json
import os
import sys
from pathlib import Path

# This script is written to live next to evaluator.py. If you drop it in
# tavernos/tavernos/ (same dir as evaluator.py), the import just works.
# If not, uncomment and point at your actual path:
# sys.path.insert(0, r"C:\TavernOS\tavernos")

from evaluator import (
    RUBRICS,
    score_deliverable,
    extract_text_from_deliverable,
)

# Files-to-rubric mapping. These template keys match the RUBRICS registry
# AND the artifact_*.py BUILDERS keys -- that symmetry is intentional.
DELIVERABLES = [
    ("monthly_business_review", "hypothetica-mbr-q1-2026.xlsx"),
    ("client_proposal",         "hypothetica-ops-audit-proposal.docx"),
    ("executive_review_deck",   "hypothetica-q1-review.pptx"),
]


def _validate_key(key: str, provider: str) -> None:
    """Sanity-check an API key before we waste three API calls failing on it.
    Catches the most common paste failures: placeholder-as-literal, whitespace,
    accidental quote chars, and truncated copies."""
    expected_prefix = "sk-ant-" if provider == "anthropic" else "sk-"
    min_length = 50
    if not key:
        sys.exit(f"error: {provider.upper()}_API_KEY is empty")
    if len(key) < min_length:
        sys.exit(
            f"error: API key looks too short (length {len(key)}, expected "
            f">= {min_length}). This usually means a placeholder like "
            f"'{expected_prefix}...' was set as the literal value instead "
            "of a real key. Grab a fresh key from the provider's console."
        )
    if not key.startswith(expected_prefix):
        sys.exit(
            f"error: {provider.upper()}_API_KEY doesn't start with "
            f"'{expected_prefix}'. Got: {key[:15]!r}"
        )
    if key != key.strip():
        sys.exit("error: API key has leading/trailing whitespace")
    if any(c in key for c in '"\''):
        sys.exit(
            "error: API key contains quote characters. The value was "
            "probably pasted with surrounding quotes — strip them."
        )


def make_client(provider: str):
    if provider == "anthropic":
        from anthropic import Anthropic
        _validate_key(os.environ.get("ANTHROPIC_API_KEY", ""), "anthropic")
        return Anthropic()
    elif provider == "openai":
        from openai import OpenAI
        _validate_key(os.environ.get("OPENAI_API_KEY", ""), "openai")
        return OpenAI()
    else:
        sys.exit(f"error: unknown provider {provider!r}")


def load_spec_sidecar(deliverable_path: Path) -> dict | None:
    """If a sidecar .spec.json exists next to the deliverable, load and return
    it. Gives the evaluator extra context about what the agent intended."""
    sidecar = deliverable_path.with_suffix(deliverable_path.suffix + ".spec.json")
    if sidecar.exists():
        try:
            return json.loads(sidecar.read_text(encoding="utf-8"))
        except Exception as e:
            print(f"  (sidecar load failed: {e})")
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", required=True, help="directory containing the 3 deliverables")
    ap.add_argument("--provider", default="anthropic", choices=["anthropic", "openai"])
    ap.add_argument("--model", default="claude-opus-4-5",
                    help="evaluator model id (default: claude-opus-4-5)")
    args = ap.parse_args()

    base = Path(args.dir).expanduser().resolve()
    if not base.is_dir():
        sys.exit(f"error: {base} is not a directory")

    client = make_client(args.provider)
    results_json = []

    print(f"Evaluator run -- provider={args.provider} model={args.model}")
    print(f"Deliverable dir: {base}")
    print("=" * 78)

    for rubric_key, filename in DELIVERABLES:
        # Walk the tree under --dir. Deliverables live in category subdirs
        # (reports/, content/, audits/, blueprints/) per the TavernOS layout,
        # not at the deliverables root. rglob finds them wherever they landed.
        matches = sorted(base.rglob(filename))
        if not matches:
            print(f"\n[SKIP] {filename} -- not found anywhere under {base}")
            continue
        if len(matches) > 1:
            print(f"\n[WARN] {filename} found in multiple locations:")
            for m in matches:
                print(f"         {m}")
            print(f"       using the first match.")
        path = matches[0]
        if not path.exists():
            print(f"\n[SKIP] {filename} -- not found at {path}")
            continue
        rubric = RUBRICS[rubric_key]
        print(f"\n---- {filename} -- rubric: {rubric.name} ----")

        text = extract_text_from_deliverable(path)
        spec_ctx = load_spec_sidecar(path)
        if not text.strip():
            print("  ERROR: extractor returned empty text")
            continue

        print(f"  Extracted {len(text)} chars of text"
              f"{' + sidecar spec' if spec_ctx else ' (no sidecar)'}")
        print(f"  Calling evaluator...")

        result = score_deliverable(
            client, args.provider, args.model,
            rubric, text, spec_context=spec_ctx,
        )

        if result.error:
            print(f"  EVAL ERROR: {result.error}")
            if result.overall_critique:
                print(f"    {result.overall_critique}")
            continue

        pass_fail = "PASS" if result.pass_threshold else "FAIL"
        print(f"  weighted_avg = {result.weighted_avg:.2f} / 5.00   [{pass_fail}]")
        if result.failing_dims:
            print(f"  failing: {', '.join(result.failing_dims)}")
        print(f"  dimension scores:")
        for dim in rubric.dimensions:
            s = result.scores.get(dim.name, "?")
            crit = result.critiques.get(dim.name, "")
            # First sentence of the critique, to keep output readable
            first_sent = crit.split(". ")[0][:80] if crit else ""
            score_str = f"{s:.1f}" if isinstance(s, (int, float)) else str(s)
            print(f"    {dim.name:<26} {score_str}  {first_sent}")
        if result.overall_critique:
            print(f"  overall: {result.overall_critique[:200]}")

        results_json.append({
            "filename":      filename,
            "rubric":        rubric.name,
            "weighted_avg":  result.weighted_avg,
            "pass":          result.pass_threshold,
            "failing_dims":  result.failing_dims,
            "scores":        result.scores,
            "critiques":     result.critiques,
            "overall":       result.overall_critique,
            "evaluator_model": result.evaluator_model,
        })

    out_file = base / "eval-results.json"
    out_file.write_text(json.dumps(results_json, indent=2), encoding="utf-8")
    print(f"\nResults written to {out_file}")


if __name__ == "__main__":
    main()
