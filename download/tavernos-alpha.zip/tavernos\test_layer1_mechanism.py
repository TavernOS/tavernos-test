"""
test_layer1_mechanism.py — Direct mechanism test for Goal A Layer 1.

Runs against the local code path only — no Anthropic API, no Lilith, no
test_harness. Imports artifact_docx + norm directly and exercises the gate
and dispatcher contracts against constructed specs.

Written session 2 (Apr 23 2026) after test_lilith_ops_audit.py confirmed
Tier 2a stable but produced only 1 Tier 2b invocation across 12 runs,
leaving gate behavior mostly unverified at the agent-invocation layer.
This script verifies gate behavior at the dispatch layer instead, which
is where the gate lives and therefore where it can be measured without
API variance.

Run:
    python test_layer1_mechanism.py
    python test_layer1_mechanism.py --verbose   # prints each contract

Exits 0 on all pass, 1 on any fail.
"""

from __future__ import annotations

import argparse
import copy
import json
import shutil
import sys
import tempfile
from pathlib import Path

import artifact_docx
import artifact_gate
import artifact_pptx
import artifact_xlsx
import norm


# ─── Test fixtures ────────────────────────────────────────────────────────────

STUB_SPEC = {
    # Mimics the session-1 saved file: has meta + diagnosis + uncertainty,
    # missing everything rubric-critical.
    "artifact": "docx",
    "template": "operational_audit",
    "filename": "test_stub_audit",
    "category": "audits",
    "meta": {"title": "Operational Audit — Test Stub",
             "subtitle": "Prepared for [Client] · by Lilith"},
    "diagnosis": "The client operates with three separate SaaS "
                 "systems acting as islands. "
                 "Mindbody functions as the source of truth for bookings "
                 "but Stripe sees only payment metadata.",
    "uncertainty_notes": ["Integration method unconfirmed.",
                          "Direction of mismatches unconfirmed."],
    # missing: executive_summary, priority_stack
}

COMPLETE_SPEC = {
    "artifact": "docx",
    "template": "operational_audit",
    "filename": "test_complete_audit",
    "category": "audits",
    "meta": {"title": "Operational Audit — Test Complete",
             "subtitle": "Prepared for Acme Corp · by Lilith"},
    "executive_summary": {
        "prose": "Acme Corp recovers an estimated $120K/year of operational "
                 "drag by addressing three workflow gaps. The audit identifies "
                 "scheduling-to-billing reconciliation as the top priority, "
                 "followed by onboarding automation and inventory sync. "
                 "Each recommendation includes sized ROI math.",
        "headline_number": "$120K/year recoverable operational drag",
        "top_findings": ["Scheduling reconciliation drift",
                         "Onboarding manual drag",
                         "Inventory sync failures"],
    },
    "priority_stack": [
        {"workflow": "Scheduling-to-billing reconciliation",
         "evidence": ["Finance lead interview (2026-04-20)",
                      "Stripe vs. Mindbody variance report Q1"],
         "recommendation": "Build reconciliation dashboard in Airtable + "
                           "webhook listener for variance alerts.",
         "roi_math": {"hours_saved_week": 8, "hours_saved_year": 416,
                      "blended_rate_usd": 75, "annual_value_usd": 31200,
                      "build_cost_usd": 15000, "payback_months": 6}},
        {"workflow": "Client onboarding",
         "evidence": ["Ops manager workflow sample",
                      "Onboarding checklist audit"],
         "recommendation": "Automate kickoff document generation via template."},
        {"workflow": "Inventory sync",
         "evidence": ["Shopify vs. QB variance log",
                      "Phantom-batch incident report"],
         "recommendation": "Nightly reconciliation job with exception queue."},
    ],
    "uncertainty_notes": ["Mindbody integration method not fully observed."],
    "assumptions": ["Blended rate $75/hr reflects loaded mid-tier staff."],
}


# ─── Session 3 fixtures: malformed-subfield specs for builder robustness ──────
#
# Each fixture is built by deep-copying COMPLETE_SPEC and corrupting one
# specific subfield, so the "what's different from valid" is localized and
# obvious on inspection. The session-2 live bug was exactly this shape:
# Lilith's attempt-3 spec had priority_stack entries that were strings
# instead of dicts. These fixtures pin that bug and its siblings.

def _corrupt(base: dict, path: str, value) -> dict:
    """Deep-copy `base` and set the value at `path` (dotted with numeric
    indices for lists). Keeps fixtures compact."""
    out = copy.deepcopy(base)
    cur = out
    parts = path.split(".")
    for key in parts[:-1]:
        if key.isdigit():
            cur = cur[int(key)]
        else:
            cur = cur[key]
    last = parts[-1]
    if last.isdigit():
        cur[int(last)] = value
    else:
        cur[last] = value
    return out


# Session-2 bug reproduction: entries 2 and 3 are bare strings. Entry 1
# stays as a dict so the complete-spec path is still exercised before
# the malformed entries hit the renderer.
MALFORMED_PRIORITY_STRING_SPEC = copy.deepcopy(COMPLETE_SPEC)
MALFORMED_PRIORITY_STRING_SPEC["filename"] = "test_malformed_priority_string"
MALFORMED_PRIORITY_STRING_SPEC["priority_stack"][1] = \
    "Client onboarding: automate via template"
MALFORMED_PRIORITY_STRING_SPEC["priority_stack"][2] = \
    "Inventory sync: nightly reconciliation job"

# roi_math field is a string instead of a dict — second crash shape from
# session-2 live run and listed in session 3 success criteria.
MALFORMED_ROI_STRING_SPEC = _corrupt(
    COMPLETE_SPEC, "priority_stack.0.roi_math",
    "$33k/year, 6-month payback"
)
MALFORMED_ROI_STRING_SPEC["filename"] = "test_malformed_roi_string"

# executive_summary as a string instead of a dict — a plausible agent
# shortcut where the model flattened a nested schema.
MALFORMED_EXEC_SUMMARY_STRING = _corrupt(
    COMPLETE_SPEC, "executive_summary",
    "Acme Corp recovers $120K/year of drag by fixing three workflow gaps."
)
MALFORMED_EXEC_SUMMARY_STRING["filename"] = "test_malformed_exec_summary"

# meta as a list instead of a dict — would crash meta.get() immediately
# under the old code. Guards should reduce to empty meta + warning.
MALFORMED_META_LIST_SPEC = _corrupt(
    COMPLETE_SPEC, "meta",
    ["Operational Audit — Test", "Prepared for Acme Corp"]
)
MALFORMED_META_LIST_SPEC["filename"] = "test_malformed_meta_list"

# diagnosis as a list instead of a string — .strip() on a list crashes.
MALFORMED_DIAGNOSIS_LIST_SPEC = _corrupt(
    COMPLETE_SPEC, "diagnosis",
    ["Point one about the operational character.",
     "Point two about the operational character."]
)
MALFORMED_DIAGNOSIS_LIST_SPEC["filename"] = "test_malformed_diagnosis_list"

# Structurally valid but semantically empty: priority entry that IS a dict
# but has no fields. Policy (per session 3 proposal): render heading only,
# no builder-warning — this is the sparse-by-design case, not a malformation.
EMPTY_PRIORITY_DICT_SPEC = copy.deepcopy(COMPLETE_SPEC)
EMPTY_PRIORITY_DICT_SPEC["filename"] = "test_empty_priority_dict"
EMPTY_PRIORITY_DICT_SPEC["priority_stack"][1] = {}


# ─── Session 4 fixtures: client_proposal Layer 1 rollout ─────────────────────
#
# Parallel to the audit's STUB_SPEC / COMPLETE_SPEC pair, for the session-4
# per-template gate rollout. CP_STUB is shaped to trip P3 (pricing present but
# empty) + P5 (thin: only 2 of 7 sections populated) without tripping P2
# (which only fires on the catastrophic no-title + no-sections case). CP
# malformed variants mirror the audit's Contract 6 shapes with one flip —
# executive_summary is a string in client_proposal (so a dict-shaped value
# is the malformation, inverse of the audit).

CLIENT_PROPOSAL_STUB_SPEC = {
    "artifact": "docx",
    "template": "client_proposal",
    "filename": "test_stub_proposal",
    "category": "content",
    "meta": {"title": "Proposal for Acme Corp — Ops Audit"},
    "situation": "Acme is scaling revenue 30% YoY with flat headcount. "
                 "The ops team is burning out on manual reconciliation "
                 "between Stripe and Mindbody.",
    # pricing present but empty → P3 fires
    "pricing": {"rows": [], "total": ""},
    # Only 2 of 7 sections populated (situation + pricing-as-present) → P5 fires.
    # Missing: executive_summary, approach, scope, timeline, next_steps.
}

CLIENT_PROPOSAL_COMPLETE_SPEC = {
    "artifact": "docx",
    "template": "client_proposal",
    "filename": "test_complete_proposal",
    "category": "content",
    "meta": {
        "title": "Proposal for Acme Corp — Operations Audit",
        "client_name": "Acme Corp",
        "prepared_by": "Dan, TavernOS",
        "date": "April 23, 2026",
    },
    "executive_summary": "Acme is losing ~15 hours/week of senior time to "
                         "manual reconciliation work. A six-week operations "
                         "audit will surface the top three workflows and "
                         "deliver a prioritized build plan.",
    "situation": "Revenue is up 30% YoY; ops headcount is flat. Maya "
                 "mentioned on the discovery call that she spends most "
                 "Mondays reconciling Stripe charges against Mindbody "
                 "bookings by hand.",
    "approach": [
        {"phase": "Discover", "detail": "Interview ops leads, inventory tools"},
        {"phase": "Diagnose", "detail": "Workflow inventory + friction register"},
        {"phase": "Deliver",  "detail": "Audit doc + prioritized build plan"},
    ],
    "scope": {
        "in_scope":     ["Workflow inventory", "Priority stack with ROI math",
                         "30-60-90 build plan"],
        "out_of_scope": ["Tool procurement", "Change management facilitation"],
    },
    "timeline": [
        {"phase": "Discover", "duration": "2 weeks",
         "deliverables": "Workflow inventory + friction register"},
        {"phase": "Deliver",  "duration": "2 weeks",
         "deliverables": "Operations audit document"},
    ],
    "pricing": {
        "rows": [
            {"item": "Operations audit (6 weeks)",
             "amount": "$8,000", "notes": "fixed fee, milestone-based"},
        ],
        "total": "$8,000",
    },
    "next_steps": ["Reply with 'Option A' and we'll send the SOW by Friday."],
}


# Session-2-shape bug analog for client_proposal: approach[1] and approach[2]
# are bare strings instead of {"phase":..., "detail":...} dicts. Entry 0
# stays as a dict so the complete-spec path is exercised before the
# malformed entries hit the renderer — same test shape as the audit's
# MALFORMED_PRIORITY_STRING_SPEC.
CP_MALFORMED_APPROACH_STRING_SPEC = copy.deepcopy(CLIENT_PROPOSAL_COMPLETE_SPEC)
CP_MALFORMED_APPROACH_STRING_SPEC["filename"] = "test_cp_malformed_approach_string"
CP_MALFORMED_APPROACH_STRING_SPEC["approach"][1] = \
    "Diagnose: workflow inventory and friction register"
CP_MALFORMED_APPROACH_STRING_SPEC["approach"][2] = \
    "Deliver: audit doc and prioritized build plan"

# pricing as a string instead of a dict — a plausible agent shortcut where
# "pricing": "$8,000 fixed fee" is flattened.
CP_MALFORMED_PRICING_STRING_SPEC = _corrupt(
    CLIENT_PROPOSAL_COMPLETE_SPEC, "pricing",
    "$8,000 fixed fee, milestone-based"
)
CP_MALFORMED_PRICING_STRING_SPEC["filename"] = "test_cp_malformed_pricing_string"

# scope as a list instead of a dict — the agent might think of scope as a
# flat bullet list rather than an in/out structure.
CP_MALFORMED_SCOPE_LIST_SPEC = _corrupt(
    CLIENT_PROPOSAL_COMPLETE_SPEC, "scope",
    ["Workflow inventory", "Priority stack", "Build plan"]
)
CP_MALFORMED_SCOPE_LIST_SPEC["filename"] = "test_cp_malformed_scope_list"

# meta as a list — shares guard path with the audit's MALFORMED_META_LIST_SPEC.
# Covering it here confirms the shared path holds when called from the CP
# builder, not just the audit builder.
CP_MALFORMED_META_LIST_SPEC = _corrupt(
    CLIENT_PROPOSAL_COMPLETE_SPEC, "meta",
    ["Proposal for Acme Corp", "Prepared by Dan, TavernOS"]
)
CP_MALFORMED_META_LIST_SPEC["filename"] = "test_cp_malformed_meta_list"

# executive_summary as a dict instead of a string — the INVERSE of the
# audit's MALFORMED_EXEC_SUMMARY_STRING. In the audit, exec_summary is a
# dict and a string is malformed. In client_proposal, exec_summary is a
# string and a dict is malformed. Catches the agent mistake of carrying
# audit-shaped exec_summary into a proposal call.
CP_MALFORMED_EXEC_SUMMARY_DICT_SPEC = _corrupt(
    CLIENT_PROPOSAL_COMPLETE_SPEC, "executive_summary",
    {"prose": "Acme is losing ~15 hours/week to reconciliation.",
     "headline_number": "$120K/year recoverable"}
)
CP_MALFORMED_EXEC_SUMMARY_DICT_SPEC["filename"] = \
    "test_cp_malformed_exec_summary_dict"

# Structurally valid but semantically empty: approach entry that IS a dict
# but has no fields. Policy call (mirrors the audit's empty-priority-dict):
# render nothing for the entry, no builder-warning — this is sparse-by-design,
# not a malformation.
CP_EMPTY_APPROACH_DICT_SPEC = copy.deepcopy(CLIENT_PROPOSAL_COMPLETE_SPEC)
CP_EMPTY_APPROACH_DICT_SPEC["filename"] = "test_cp_empty_approach_dict"
CP_EMPTY_APPROACH_DICT_SPEC["approach"][1] = {}


# ─── Contract 8 fixtures — research_report (session 5) ────────────────────────
#
# Cliff's template. Nesting is deeper than either of the previous two:
# findings_detail[i].supporting_evidence[j].{source, publisher, date} is the
# three-level path the warning regex will need to parse at max depth. Nested
# malformed variants (#9, #10) exercise that depth — there's no CP analog.

RESEARCH_REPORT_STUB_SPEC = {
    "artifact": "docx",
    "template": "research_report",
    "filename": "test_stub_research_report",
    "category": "reports",
    "meta": {"title": "Series A SaaS Ops Benchmarks — Example Co."},
    # Only 1 key_finding → R2 fires (count outside 3-5)
    "key_findings": [
        {"finding": "A single finding with no supporting structure.",
         "confidence": "low", "so_what": "insufficient to act on"},
    ],
    # findings_detail present but empty → R3 fires
    "findings_detail": [],
    # exec_summary present but missing headline + confidence → R5 fires twice
    "executive_summary": {"context": "why this matters one-liner"},
    # No limitations, no synthesis.points_of_tension → R6 fires
    # (R4 can't fire because there are no supporting_evidence items to check)
}

RESEARCH_REPORT_COMPLETE_SPEC = {
    "artifact": "docx",
    "template": "research_report",
    "filename": "test_complete_research_report",
    "category": "reports",
    "meta": {
        "title": "Series A SaaS Operational-Leverage Benchmarks",
        "client_name": "Example Co.",
        "prepared_by": "Cliff, TavernOS",
        "date": "April 23, 2026",
    },
    "research_question": "Where does Example Co. sit vs. its Series A SaaS "
                        "cohort on operational-leverage ratios?",
    "executive_summary": {
        "headline": "Example Co. is in the 75th percentile on revenue-per-FTE "
                    "but bottom-quartile on ops-per-eng-ratio.",
        "confidence": "moderate — cohort size varies by metric (n=164 to n=364); "
                      "see limitations",
        "context": "The Series A board is evaluating ops-hiring velocity "
                   "against the cohort for the next raise.",
    },
    "key_findings": [
        {"finding": "Revenue-per-FTE at Example Co. is $312K vs. cohort "
                    "median $198K (KeyBanc 2025).",
         "confidence": "high",
         "so_what": "Strong topline productivity; defensible at the board."},
        {"finding": "Ops-to-eng ratio is 1:2.1 vs. cohort median 1:4.3 — "
                    "roughly 2× over-weighted on ops headcount.",
         "confidence": "high",
         "so_what": "Surfaces as a question mark in dilution modeling."},
        {"finding": "Gross margin at 78% is in-line with the 75-82% cohort "
                    "band for the ARR stage.",
         "confidence": "moderate",
         "so_what": "No story to tell here; move on."},
    ],
    "synthesis": {
        "narrative": "Two sources agree on the direction of the revenue "
                     "productivity finding but differ on the cohort "
                     "definition. KeyBanc's cohort is ARR-banded; "
                     "OpenView's is headcount-banded. We use KeyBanc for "
                     "the headline metric because Example Co. is at the "
                     "upper edge of OpenView's headcount band, which "
                     "biases comparisons downward.\n\nThe ops-ratio "
                     "finding is consistent across both sources once the "
                     "ARR band is held fixed.",
        "points_of_agreement": [
            "Series A SaaS margins cluster in the high-70s band",
            "Revenue-per-FTE is the cleanest productivity benchmark at this stage",
        ],
        "points_of_tension": [
            {"topic": "Which cohort definition — ARR-banded or headcount-banded?",
             "source_a_says": "KeyBanc: ARR-banded cohorts are the defensible "
                              "benchmark unit at Series A.",
             "source_b_says": "OpenView: headcount-banded cohorts normalize "
                              "for scale-of-team effects better.",
             "our_read": "Use KeyBanc's ARR-banded cohort for the headline; "
                         "OpenView biases against growth-stage companies."},
        ],
    },
    "findings_detail": [
        {"finding_ref": 1,
         "analysis": "Revenue-per-FTE at Example Co. traces to the 2024 "
                     "hiring freeze paired with the Q3 ARR expansion. The "
                     "metric stabilizes at $312K over the last four "
                     "quarters, which puts Example Co. in the 75th "
                     "percentile of the KeyBanc ARR-banded cohort.",
         "supporting_evidence": [
             {"source": "2025 Private SaaS Company Survey",
              "publisher": "KeyBanc Capital Markets",
              "date": "October 2025",
              "detail": "Cohort median revenue-per-FTE at Series A: $198K "
                        "(n=364, $1M-$100M ARR).",
              "url": "https://keybanc.example/private-saas-2025"},
             {"source": "Example Co. Q4 board deck",
              "publisher": "Example Co. (internal)",
              "date": "January 2026",
              "detail": "ARR $28.3M / FTE count 91 = $312K "
                        "revenue-per-FTE, confirmed by CFO sign-off."},
         ]},
        {"finding_ref": 2,
         "analysis": "The ops-to-eng ratio of 1:2.1 is meaningfully outside "
                     "the cohort band (1:4.3 median). This is structural: "
                     "ops-heavy teams at this ARR stage typically "
                     "signal a services-bias revenue model, which Example "
                     "Co. is not.",
         "supporting_evidence": [
             {"source": "2025 SaaS Benchmarks Report",
              "publisher": "OpenView Partners",
              "date": "September 2025",
              "detail": "Cohort median ops-to-eng ratio at Series A: 1:4.3 "
                        "(n=164, 20-100 FTE).",
              "url": "https://openview.example/saas-benchmarks-2025"},
             {"source": "2025 Private SaaS Company Survey",
              "publisher": "KeyBanc Capital Markets",
              "date": "October 2025",
              "detail": "Confirms 1:4-to-1:5 as the modal range at this "
                        "ARR band; outliers trend services-heavy."},
         ]},
        {"finding_ref": 3,
         "analysis": "Gross margin at 78% is well-within the 75-82% cohort "
                     "band. No story of interest — included for "
                     "completeness since the board will ask.",
         "supporting_evidence": [
             {"source": "2025 Private SaaS Company Survey",
              "publisher": "KeyBanc Capital Markets",
              "date": "October 2025",
              "detail": "Cohort gross margin interquartile range: 75-82%."},
             {"source": "Example Co. 2025 audited financials",
              "publisher": "Example Co. (audited)",
              "date": "March 2026",
              "detail": "Gross margin 78.2% on $28.3M ARR."},
         ]},
    ],
    "limitations": [
        "Cohort definitions are not uniform across sources; KeyBanc and "
        "OpenView use different band boundaries.",
        "Ops-role definitions vary — one source's 'ops' includes CS, another "
        "treats CS separately. Ratio findings sensitive to this.",
    ],
    "recommendations": [
        "Lead with revenue-per-FTE in the next board deck; it's the "
        "cleanest positive story.",
        "Prepare a one-page answer on the ops-ratio question before the "
        "next board meeting.",
    ],
    "sources_consulted": [
        {"title": "2025 Private SaaS Company Survey",
         "author": "KeyBanc Capital Markets",
         "publisher": "KeyBanc",
         "date": "October 2025",
         "url": "https://keybanc.example/private-saas-2025",
         "notes": "cohort: $1M-$100M ARR, n=364"},
        {"title": "2025 SaaS Benchmarks Report",
         "author": "OpenView Partners",
         "publisher": "OpenView",
         "date": "September 2025",
         "url": "https://openview.example/saas-benchmarks-2025",
         "notes": "cohort: 20-100 FTE, n=164"},
    ],
    "methodology_note": "Sources limited to public and purchased private-SaaS "
                        "surveys published since January 2025. Cohort "
                        "filters: Series A, $5M-$50M ARR, B2B SaaS only.",
}


# Session-2-shape bug analog for research_report: findings_detail[1] and [2]
# are bare strings. Entry 0 stays a dict so the happy path runs first. Mirrors
# MALFORMED_PRIORITY_STRING_SPEC and CP_MALFORMED_APPROACH_STRING_SPEC.
RR_MALFORMED_FINDINGS_DETAIL_STRING_SPEC = copy.deepcopy(
    RESEARCH_REPORT_COMPLETE_SPEC)
RR_MALFORMED_FINDINGS_DETAIL_STRING_SPEC["filename"] = \
    "test_rr_malformed_findings_detail_string"
RR_MALFORMED_FINDINGS_DETAIL_STRING_SPEC["findings_detail"][1] = \
    "Finding 2: ops-to-eng ratio is 1:2.1 vs cohort 1:4.3"
RR_MALFORMED_FINDINGS_DETAIL_STRING_SPEC["findings_detail"][2] = \
    "Finding 3: gross margin in-line with cohort"

# Plausible agent shortcut: flattening a finding into a single string.
RR_MALFORMED_KEY_FINDINGS_STRING_SPEC = copy.deepcopy(
    RESEARCH_REPORT_COMPLETE_SPEC)
RR_MALFORMED_KEY_FINDINGS_STRING_SPEC["filename"] = \
    "test_rr_malformed_key_findings_string"
RR_MALFORMED_KEY_FINDINGS_STRING_SPEC["key_findings"][1] = \
    "Ops-to-eng ratio 1:2.1 vs 1:4.3 cohort — confidence high"

# synthesis as a string instead of a dict — the plausible agent shortcut of
# flattening the whole synthesis block into a single narrative paragraph.
RR_MALFORMED_SYNTHESIS_STRING_SPEC = _corrupt(
    RESEARCH_REPORT_COMPLETE_SPEC, "synthesis",
    "Two sources agree on the direction but differ on cohort definition. "
    "We use KeyBanc as the headline and OpenView for cross-reference."
)
RR_MALFORMED_SYNTHESIS_STRING_SPEC["filename"] = \
    "test_rr_malformed_synthesis_string"

# meta as a list — shared guard path across all three templates. Exercises
# the _as_dict helper from the RR call site.
RR_MALFORMED_META_LIST_SPEC = _corrupt(
    RESEARCH_REPORT_COMPLETE_SPEC, "meta",
    ["Series A SaaS Ops Benchmarks", "Prepared by Cliff, TavernOS"]
)
RR_MALFORMED_META_LIST_SPEC["filename"] = "test_rr_malformed_meta_list"

# executive_summary as a STRING instead of a dict — this is the INVERSE of
# CP_MALFORMED_EXEC_SUMMARY_DICT_SPEC. In CP, exec_summary is a string and
# a dict is the malformation. In RR, exec_summary is a dict and a string is
# the malformation. Catches the agent mistake of carrying CP-shaped
# exec_summary into an RR call. Note: this case ALSO fires preflight R5
# (builder-channel + preflight-channel both signal; see session 5 proposal §5).
RR_MALFORMED_EXEC_SUMMARY_STRING_SPEC = _corrupt(
    RESEARCH_REPORT_COMPLETE_SPEC, "executive_summary",
    "Example Co. is in the 75th percentile on revenue-per-FTE with "
    "moderate confidence — cohort sizes vary across sources."
)
RR_MALFORMED_EXEC_SUMMARY_STRING_SPEC["filename"] = \
    "test_rr_malformed_exec_summary_string"

# Structurally valid but semantically empty: findings_detail entry that IS
# a dict but has no fields. Policy pin (§3 proposal): bare heading renders,
# no TBDs for missing keys, no builder-warning. This diverges slightly from
# CP's empty-approach-dict (which renders nothing) because _render_finding_detail
# always renders a heading (finding_ref defaults to index+1). The bare
# heading acts as a structural slot marker; R3 preflight catches the quality
# complaint at gate time.
RR_EMPTY_FINDINGS_DICT_SPEC = copy.deepcopy(RESEARCH_REPORT_COMPLETE_SPEC)
RR_EMPTY_FINDINGS_DICT_SPEC["filename"] = "test_rr_empty_findings_dict"
RR_EMPTY_FINDINGS_DICT_SPEC["findings_detail"][1] = {}

# Nested malformation — no CP parallel. A valid findings_detail[0] entry
# containing a malformed supporting_evidence item. Exercises the
# two-level nested warning path.
RR_MALFORMED_NESTED_EVIDENCE_SPEC = copy.deepcopy(RESEARCH_REPORT_COMPLETE_SPEC)
RR_MALFORMED_NESTED_EVIDENCE_SPEC["filename"] = \
    "test_rr_malformed_nested_evidence"
RR_MALFORMED_NESTED_EVIDENCE_SPEC["findings_detail"][0][
    "supporting_evidence"][1] = \
    "Example Co. Q4 board deck — $312K revenue-per-FTE"

# Three-level nested malformation — the deepest warning path in the module.
# A valid finding + valid evidence item, but the `source` subfield is a list.
# Pins the regex `builder: \S+ is \w+, expected \w+` at maximum depth.
RR_MALFORMED_NESTED_SOURCE_STRING_SPEC = copy.deepcopy(
    RESEARCH_REPORT_COMPLETE_SPEC)
RR_MALFORMED_NESTED_SOURCE_STRING_SPEC["filename"] = \
    "test_rr_malformed_nested_source_field"
RR_MALFORMED_NESTED_SOURCE_STRING_SPEC["findings_detail"][0][
    "supporting_evidence"][0]["source"] = \
    ["KeyBanc Capital Markets", "2025 Private SaaS Company Survey"]

# Co-existence carrier for the session-3 backlog item: stub spec (R-issues
# at preflight) + malformed meta (builder-warning). Bypass-save must emit
# BOTH warning blocks, in order (bypass first, builder-warning second).
RR_STUB_WITH_MALFORMED_META_SPEC = copy.deepcopy(RESEARCH_REPORT_STUB_SPEC)
RR_STUB_WITH_MALFORMED_META_SPEC["filename"] = \
    "test_rr_stub_with_malformed_meta"
RR_STUB_WITH_MALFORMED_META_SPEC["meta"] = \
    ["Series A SaaS Ops Benchmarks", "Prepared by Cliff"]


# ─── Session 7 fixtures: preflight absence-check + dead-spot coverage ─────────
#
# Five fixtures covering the session-3/4/5/6 carry-forward pile that
# session 7 priority 2 closes:
#   AUDIT_NO_ROI_MATH_SPEC      — A4b (no priority has roi_math at all)
#   CP_NO_PRICING_SPEC          — P4b (pricing section entirely absent)
#   RR_NO_FINDINGS_DETAIL_SPEC  — R3b (findings_detail entirely absent)
#   CP_TITLE_ONLY_SPEC          — P5 dead-spot (title + zero sections)
#   (A3/A4 isinstance skip reuses MALFORMED_PRIORITY_STRING_SPEC)
#   (R3/R4 isinstance skip reuses RR_MALFORMED_FINDINGS_DETAIL_STRING_SPEC)

# AUDIT_NO_ROI_MATH_SPEC: deep-copy COMPLETE_SPEC and strip roi_math from
# priority[0]. A4b is a COLLECTIVE check — fires only when NO priority has
# roi_math. COMPLETE_SPEC ships with roi_math on priority[0] only; removing
# it means zero priorities have roi_math, so A4b fires. Confirms the
# session-7 design choice (collective, not per-entry) doesn't over-reject
# realistic audits where some priorities are qualitative.
AUDIT_NO_ROI_MATH_SPEC = copy.deepcopy(COMPLETE_SPEC)
AUDIT_NO_ROI_MATH_SPEC["filename"] = "test_audit_no_roi_math"
del AUDIT_NO_ROI_MATH_SPEC["priority_stack"][0]["roi_math"]

# CP_NO_PRICING_SPEC: deep-copy CP complete, delete pricing key. P4b must
# fire (absent pricing); P3 must NOT fire (P3 is present-but-empty, absence
# is P4b's lane). Distinguishing these two checks matters because they map
# to the same rubric dim via different regen triggers.
CP_NO_PRICING_SPEC = copy.deepcopy(CLIENT_PROPOSAL_COMPLETE_SPEC)
CP_NO_PRICING_SPEC["filename"] = "test_cp_no_pricing"
del CP_NO_PRICING_SPEC["pricing"]

# RR_NO_FINDINGS_DETAIL_SPEC: deep-copy RR complete, delete findings_detail
# key. R3b must fire (absent); R3 must NOT fire (R3 is present-but-empty).
# Highest-consequence absence check in the preflight — synthesis_quality
# (0.25) AND source_quality (0.25, 4.0 hard floor) both depend on the key.
RR_NO_FINDINGS_DETAIL_SPEC = copy.deepcopy(RESEARCH_REPORT_COMPLETE_SPEC)
RR_NO_FINDINGS_DETAIL_SPEC["filename"] = "test_rr_no_findings_detail"
del RR_NO_FINDINGS_DETAIL_SPEC["findings_detail"]

# CP_TITLE_ONLY_SPEC: minimum-viable CP exercise of the P5 dead-spot. Title
# present, ALL 7 content sections absent. Before session 7: P2 passes (title
# saves), P5 passes silently (the `and non_empty` short-circuit dead-spotted
# on empty non_empty list). After: P5 fires. Also triggers P4b (no pricing),
# which is expected and correct — a title-only CP is the catastrophic stub
# state across the board. P2 still does NOT fire (title is present).
CP_TITLE_ONLY_SPEC = {
    "artifact": "docx",
    "template": "client_proposal",
    "filename": "test_cp_title_only",
    "category": "content",
    "meta": {"title": "Proposal for Acme Corp"},
    # deliberately zero content sections
}


# ─── Test infrastructure ──────────────────────────────────────────────────────

class TestRunner:
    """Minimal test runner — no pytest dep. Tracks pass/fail, supports verbose."""

    def __init__(self, verbose: bool = False):
        self.verbose = verbose
        self.passed = 0
        self.failed = 0
        self.failures: list[tuple[str, str]] = []

    def run(self, name: str, func):
        try:
            func()
        except AssertionError as e:
            self.failed += 1
            self.failures.append((name, str(e)))
            print(f"  ✗ {name}")
            print(f"      {e}")
        except Exception as e:
            self.failed += 1
            self.failures.append((name, f"{type(e).__name__}: {e}"))
            print(f"  ✗ {name}  (raised)")
            print(f"      {type(e).__name__}: {e}")
        else:
            self.passed += 1
            if self.verbose:
                print(f"  ✓ {name}")

    def summary(self) -> int:
        total = self.passed + self.failed
        print()
        print(f"  {self.passed}/{total} passed")
        if self.failures:
            print(f"  {self.failed} failures:")
            for name, msg in self.failures:
                print(f"    - {name}: {msg}")
            return 1
        return 0


def setup_temp_workspace() -> Path:
    """Create a temp dir, patch norm.py's workspace constants, scaffold the
    _self client, wire all three artifact-module path resolvers, and
    register all three first-party tool handlers. Returns tmp root for
    caller's shutil.rmtree teardown.

    Session 12 priority 1 sub-item 1 rewrite: pre-session-12 this only
    wired docx's resolver; pptx + xlsx resolvers were present in the
    module code (session 10) but the test harness never invoked them,
    so every Tier 0 run leaked real files into
    ~/.tavernos/clients/_self/deliverables/. Rule 6 documented this as
    accepted residue. Session-12 rewrite closes the gap — all three
    resolvers point at the temp deliverables dir, and norm's
    USER_DIR / CLIENTS_DIR / ACTIVE_CLIENT_FILE module constants are
    patched onto tmp so the Contract 19 auto-link tests (which load and
    write client.json) operate entirely inside the temp workspace.

    No teardown of the module-constant patches: the process exits after
    main()'s shutil.rmtree(tmp). If a future change runs Tier 0 as part
    of a longer-lived process, the patches would need restoration — flag
    this if that day comes."""
    tmp = Path(tempfile.mkdtemp(prefix="layer1_test_"))

    # Patch norm's workspace roots. Must land BEFORE any helper that
    # reads these (client_workspace_path, client_load_manifest, etc.)
    # is called by the test body.
    norm.USER_DIR = tmp
    norm.CLIENTS_DIR = tmp / "clients"
    norm.ACTIVE_CLIENT_FILE = norm.CLIENTS_DIR / "_active"

    # Scaffold the _self client: empty client.json + all four deliverable
    # subfolders. Tests that save via _tool_handler land files in
    # <tmp>/clients/_self/deliverables/<category>/; tests that read
    # client.json (Contract 19) see an empty-but-present manifest.
    self_dir = norm.CLIENTS_DIR / "_self"
    deliverables = self_dir / "deliverables"
    for sub in ("reports", "audits", "blueprints", "content"):
        (deliverables / sub).mkdir(parents=True, exist_ok=True)
    (self_dir / "client.json").write_text("{}", encoding="utf-8")
    norm.ACTIVE_CLIENT_FILE.write_text("_self", encoding="utf-8")

    # Wire artifact-module path resolvers. All three modules carry the
    # set_path_resolver hook (docx: reference; pptx + xlsx: ported
    # session-10). Single lambda handles all three because the per-slug
    # resolution is uniform in the test workspace (every save goes to
    # the _self deliverables dir regardless of which slug the handler
    # was invoked with).
    def _resolver(_slug):
        return deliverables

    artifact_docx.set_path_resolver(_resolver)
    artifact_pptx.set_path_resolver(_resolver)
    artifact_xlsx.set_path_resolver(_resolver)

    # Re-register all three handlers into norm's tool registry. The
    # modules auto-register at import time, but we re-register after
    # resolver wiring so the dispatcher sees handlers whose
    # build_from_spec() path will actually route through tmp.
    for mod in (artifact_docx, artifact_pptx, artifact_xlsx):
        reg = mod.get_tool_registration()
        norm.FIRST_PARTY_TOOLS[reg["name"]] = reg

    return tmp


# ─── CONTRACT 1: handler gate mechanics ───────────────────────────────────────

def test_handler_rejects_stub_spec():
    """Stub spec should return REJECTED_SENTINEL as first line, not save anything."""
    result = artifact_docx._tool_handler(STUB_SPEC, "lilith", None)
    first_line = result.split("\n", 1)[0]
    assert first_line == artifact_docx.REJECTED_SENTINEL, \
        f"expected REJECTED_SENTINEL first line, got: {first_line!r}"
    # Rejection text should mention the template
    assert "operational_audit" in result, "rejection text missing template name"


def test_handler_saves_complete_spec():
    """Complete spec should return DELIVERABLE_SENTINEL and create a file."""
    result = artifact_docx._tool_handler(COMPLETE_SPEC, "lilith", None)
    first_line = result.split("\n", 1)[0]
    assert first_line.startswith("__TAVERNOS_DELIVERABLE__\t"), \
        f"expected DELIVERABLE_SENTINEL first line, got: {first_line!r}"
    # Parse the sentinel header for the path
    parts = first_line.split("\t")
    assert len(parts) >= 4, f"sentinel header malformed: {parts}"
    path = Path(parts[2])
    assert path.exists(), f"handler reported save but file missing: {path}"
    assert path.stat().st_size > 5000, \
        f"saved file suspiciously small: {path.stat().st_size} bytes"


def test_handler_bypass_saves_stub_with_warnings():
    """skip_preflight_gate=True should save even with critical issues, plus warnings."""
    # Use a stub with enough structural completeness that build_from_spec
    # doesn't crash — the session-3 builder-robustness bug is that build
    # crashes on malformed subfields, not on missing sections.
    bypass_stub = dict(STUB_SPEC)
    bypass_stub["filename"] = "test_bypass_save"
    result = artifact_docx._tool_handler(bypass_stub, "lilith", None,
                                         skip_preflight_gate=True)
    first_line = result.split("\n", 1)[0]
    assert first_line.startswith("__TAVERNOS_DELIVERABLE__\t"), \
        f"bypass should save; got: {first_line!r}"
    # Bypass warning preamble must be present before the "Document saved." line
    assert "Preflight gate bypassed" in result, \
        "bypass save missing warning preamble"
    assert "preflight A" in result, \
        "bypass warning should list the critical issues that were bypassed"


def test_handler_accepts_complete_spec_with_bypass_flag():
    """skip_preflight_gate=True on a complete spec should save without warnings."""
    clean_spec = dict(COMPLETE_SPEC)
    clean_spec["filename"] = "test_complete_with_bypass"
    result = artifact_docx._tool_handler(clean_spec, "lilith", None,
                                         skip_preflight_gate=True)
    first_line = result.split("\n", 1)[0]
    assert first_line.startswith("__TAVERNOS_DELIVERABLE__\t")
    assert "Preflight gate bypassed" not in result, \
        "warning preamble should not appear when no critical issues"


# ─── CONTRACT 2: _rubric_critical_issues filtering ────────────────────────────

def test_filter_operational_audit_stub_returns_A_issues():
    issues = artifact_docx._rubric_critical_issues(STUB_SPEC)
    assert issues, "stub spec should produce critical issues"
    # Stub has no priority_stack → A2 fires
    assert any(i.startswith("preflight A2") for i in issues), \
        f"expected A2 in issues, got: {issues}"
    # Stub has no executive_summary → A5 fires
    assert any(i.startswith("preflight A5") for i in issues), \
        f"expected A5 in issues, got: {issues}"
    # Stub has uncertainty_notes → A6 should NOT fire
    assert not any(i.startswith("preflight A6") for i in issues), \
        f"A6 fired but stub has uncertainty_notes: {issues}"


def test_filter_complete_spec_returns_empty():
    issues = artifact_docx._rubric_critical_issues(COMPLETE_SPEC)
    assert issues == [], f"complete spec produced issues: {issues}"


def test_filter_handles_degenerate_inputs():
    """None, non-dict, and unknown-template specs must return [] without raising."""
    assert artifact_docx._rubric_critical_issues(None) == []
    assert artifact_docx._rubric_critical_issues("not a dict") == []
    assert artifact_docx._rubric_critical_issues({}) == []
    assert artifact_docx._rubric_critical_issues(
        {"template": "nonexistent"}) == []


# ─── CONTRACT 3: rejection message content ────────────────────────────────────

def test_rejection_message_contains_sentinel_first():
    msg = artifact_docx._format_rejection_message(
        "operational_audit",
        ["preflight A2: priority_stack has 0 entries; ..."])
    assert msg.split("\n", 1)[0] == "__TAVERNOS_REJECTED__", \
        "rejection message must start with REJECTED_SENTINEL"


def test_rejection_message_has_actionable_structure():
    issues = artifact_docx._rubric_critical_issues(STUB_SPEC)
    msg = artifact_docx._format_rejection_message("operational_audit", issues)
    # Each failing issue must appear verbatim (not paraphrased)
    for issue in issues:
        assert issue in msg, f"issue not present verbatim: {issue}"
    # Required sections must be named
    assert "executive_summary" in msg
    assert "priority_stack" in msg
    # Retry nudge must be there
    assert "extend" in msg.lower(), "retry nudge missing"
    assert artifact_docx.TOOL_NAME in msg, \
        f"tool name {artifact_docx.TOOL_NAME!r} missing from retry guidance"


def test_bypass_warning_lines_include_issues():
    lines = artifact_docx._format_bypass_warning_lines(
        ["preflight A3: priority 'X' has 0 evidence items; ..."])
    text = "\n".join(lines)
    assert "bypassed" in text.lower()
    assert "preflight A3" in text, "bypass warning missing the issue list"


# ─── CONTRACT 4: dispatcher 3-tuple ───────────────────────────────────────────

def test_dispatch_success_returns_clean_text_and_banner():
    spec = dict(COMPLETE_SPEC)
    spec["filename"] = "test_dispatch_success"
    text, banner, is_err = norm._dispatch_first_party_tool(
        "generate_docx_report", spec, "lilith")
    assert is_err is False, f"expected is_error=False on success, got {is_err}"
    assert banner is not None, "expected banner dict on success"
    assert set(banner.keys()) >= {"filename", "path", "bytes"}
    assert "__TAVERNOS_DELIVERABLE__" not in text, \
        "dispatcher must strip success sentinel before returning text"
    assert text.startswith("Document saved."), \
        f"unexpected text shape after sentinel strip: {text[:100]!r}"


def test_dispatch_rejection_returns_is_error_and_strips_sentinel():
    spec = dict(STUB_SPEC)
    spec["filename"] = "test_dispatch_reject"
    text, banner, is_err = norm._dispatch_first_party_tool(
        "generate_docx_report", spec, "lilith")
    assert is_err is True, f"expected is_error=True on rejection, got {is_err}"
    assert banner is None, "expected no banner on rejection"
    assert "__TAVERNOS_REJECTED__" not in text, \
        "dispatcher must strip rejection sentinel before returning text"
    assert text.startswith("Spec rejected"), \
        f"rejection text lost its preamble: {text[:100]!r}"


def test_dispatch_unknown_tool_returns_is_error():
    text, banner, is_err = norm._dispatch_first_party_tool(
        "nonexistent_tool", {}, "lilith")
    assert is_err is True, "unknown tool should produce is_error=True"
    assert banner is None
    assert "Unknown" in text


# ─── CONTRACT 5: bypass-kwarg routing ─────────────────────────────────────────

def test_dispatch_bypass_flag_reaches_docx_handler():
    """With bypass_gates=True on generate_docx_report, the handler must receive
    skip_preflight_gate=True — verified by the stub spec saving instead of
    being rejected."""
    spec = dict(STUB_SPEC)
    spec["filename"] = "test_bypass_routing"
    text, banner, is_err = norm._dispatch_first_party_tool(
        "generate_docx_report", spec, "lilith", bypass_gates=True)
    # If bypass reached the handler, the stub saved with warnings (is_err=False)
    assert is_err is False, \
        f"bypass_gates=True should reach handler and save; got is_err={is_err}"
    assert banner is not None, "bypass save must emit a banner"
    assert "bypassed" in text.lower(), "bypass save must include warning text"


def test_dispatch_bypass_flag_reaches_pptx_handler():
    """Session 10: pptx handler now accepts skip_preflight_gate kwarg
    (gate machinery ported). Dispatcher should pass it through when
    name=='generate_pptx_deck' and bypass_gates=True. Verified by capturing
    kwargs on a fake pptx handler registered under the real tool name."""
    received = {}
    def fake_pptx_handler(args, agent, slug, **kwargs):
        received["kwargs"] = kwargs
        # Legacy 4-field sentinel (no trailing \t<template>). Session 12
        # priority 1 sub-item 2 extended the sentinel to 5 fields with
        # template as the auto-link key; this test stays on the 4-field
        # format so it (a) doesn't touch client.json via auto-link and
        # (b) exercises the dispatcher's back-compat branch that skips
        # auto-link when len(parts) < 4. Contract 20's
        # test_dispatcher_skips_autolink_on_four_field_sentinel pins
        # this back-compat behavior explicitly.
        return "__TAVERNOS_DELIVERABLE__\tfake.pptx\t/tmp/fake.pptx\t20000\nok"

    saved = dict(norm.FIRST_PARTY_TOOLS)
    try:
        norm.FIRST_PARTY_TOOLS["generate_pptx_deck"] = {
            "name": "generate_pptx_deck",
            "schema": {}, "allowed_agents": {"rebecca-deck"},
            "handler": fake_pptx_handler,
        }
        text, banner, is_err = norm._dispatch_first_party_tool(
            "generate_pptx_deck", {}, "rebecca-deck", bypass_gates=True)
        assert is_err is False
        assert received["kwargs"] == {"skip_preflight_gate": True}, \
            f"pptx handler expected skip_preflight_gate=True kwarg; got: {received['kwargs']}"
    finally:
        norm.FIRST_PARTY_TOOLS.clear()
        norm.FIRST_PARTY_TOOLS.update(saved)


def test_dispatch_bypass_flag_reaches_xlsx_handler():
    """Session 10: xlsx handler now accepts skip_preflight_gate kwarg
    (gate machinery ported). Dispatcher should pass it through when
    name=='generate_xlsx_report' and bypass_gates=True."""
    received = {}
    def fake_xlsx_handler(args, agent, slug, **kwargs):
        received["kwargs"] = kwargs
        # Legacy 4-field sentinel — same rationale as the pptx fake above.
        return "__TAVERNOS_DELIVERABLE__\tfake.xlsx\t/tmp/fake.xlsx\t12345\nok"

    saved = dict(norm.FIRST_PARTY_TOOLS)
    try:
        norm.FIRST_PARTY_TOOLS["generate_xlsx_report"] = {
            "name": "generate_xlsx_report",
            "schema": {}, "allowed_agents": {"rebecca-mbr"},
            "handler": fake_xlsx_handler,
        }
        text, banner, is_err = norm._dispatch_first_party_tool(
            "generate_xlsx_report", {}, "rebecca-mbr", bypass_gates=True)
        assert is_err is False
        assert received["kwargs"] == {"skip_preflight_gate": True}, \
            f"xlsx handler expected skip_preflight_gate=True kwarg; got: {received['kwargs']}"
    finally:
        norm.FIRST_PARTY_TOOLS.clear()
        norm.FIRST_PARTY_TOOLS.update(saved)


def test_dispatch_bypass_flag_NOT_passed_to_non_allowlisted_tools():
    """The dispatcher gates the bypass kwarg to the _BYPASS_CAPABLE_TOOLS
    allow-list (session 10: docx + pptx + xlsx). Any new first-party tool
    registered outside the allow-list must NOT receive the kwarg, so its
    handler signature is free to omit skip_preflight_gate without crashing
    on an unexpected keyword argument."""
    received = {}
    def fake_new_handler(args, agent, slug, **kwargs):
        received["kwargs"] = kwargs
        return "ok no sentinel"

    saved = dict(norm.FIRST_PARTY_TOOLS)
    try:
        # Hypothetical new tool that isn't in _BYPASS_CAPABLE_TOOLS.
        norm.FIRST_PARTY_TOOLS["generate_future_tool"] = {
            "name": "generate_future_tool",
            "schema": {}, "allowed_agents": {"somebody"},
            "handler": fake_new_handler,
        }
        text, banner, is_err = norm._dispatch_first_party_tool(
            "generate_future_tool", {}, "somebody", bypass_gates=True)
        assert received["kwargs"] == {}, \
            f"non-allowlisted handler got unexpected kwargs: {received['kwargs']}"
    finally:
        norm.FIRST_PARTY_TOOLS.clear()
        norm.FIRST_PARTY_TOOLS.update(saved)


def test_bypass_capable_tools_allowlist_sanity():
    """Pin the session-10 allow-list content so a future refactor can't
    silently drop a tool. If a new template ships with gate machinery, add
    its tool name to both _BYPASS_CAPABLE_TOOLS and this assertion."""
    assert hasattr(norm, "_BYPASS_CAPABLE_TOOLS")
    expected = {"generate_docx_report", "generate_pptx_deck", "generate_xlsx_report"}
    assert set(norm._BYPASS_CAPABLE_TOOLS) == expected, \
        f"allow-list drift: expected {expected}, got {set(norm._BYPASS_CAPABLE_TOOLS)}"


def test_gate_rejection_threshold_constant():
    """N=2 is the tunable. Confirm it's exposed and sensible."""
    assert hasattr(norm, "_PREFLIGHT_GATE_MAX_REJECTIONS")
    assert norm._PREFLIGHT_GATE_MAX_REJECTIONS >= 1
    assert norm._PREFLIGHT_GATE_MAX_REJECTIONS <= 5, \
        "N too high — loop could burn a lot of tokens"


# ─── CONTRACT 6: builder robustness (session 3) ───────────────────────────────
#
# Pins the "malformed subfields render as TBD + side-channel warning, don't
# crash" contract shipped in session 3 per goal-a-session-2-handoff's
# build_from_spec bug. All tests bypass the preflight gate so the builder is
# actually reached — without skip_preflight_gate=True, a COMPLETE_SPEC-derived
# malformed fixture would still pass preflight (since preflight mostly checks
# shape-at-the-top-level) and hit the builder anyway, but using the bypass
# path makes the test intent unambiguous: we're testing that the BUILDER is
# the one handling the malformation.

def _save_and_split(spec):
    """Handler-run helper. Returns (full_text, first_line) and asserts save."""
    text = artifact_docx._tool_handler(spec, "lilith", None,
                                       skip_preflight_gate=True)
    first_line = text.split("\n", 1)[0]
    assert first_line.startswith("__TAVERNOS_DELIVERABLE__\t"), \
        f"builder crashed or rejected; handler said: {text[:200]!r}"
    return text, first_line


def test_builder_survives_string_priority_entries():
    """Session-2 bug repro: priority_stack has bare strings. Must save a
    real file (>5KB) rather than returning the 'Unexpected error...' from
    _tool_handler's generic exception handler."""
    text, first_line = _save_and_split(MALFORMED_PRIORITY_STRING_SPEC)
    parts = first_line.split("\t")
    path = Path(parts[2])
    assert path.exists(), f"reported save but file missing: {path}"
    assert path.stat().st_size > 5000, \
        f"saved file suspiciously small: {path.stat().st_size} bytes"


def test_builder_emits_warning_for_string_priority_entries():
    """Malformed priority entries must surface in the builder-warning block
    with the exact path syntax a grep-based CI rule can parse."""
    text, _ = _save_and_split(MALFORMED_PRIORITY_STRING_SPEC)
    assert "malformed and rendered as" in text.lower(), \
        "builder-warning block missing from tool_result"
    assert "priority_stack[1]" in text, \
        f"entry-1 path not named in warnings:\n{text}"
    assert "priority_stack[2]" in text, \
        f"entry-2 path not named in warnings:\n{text}"
    # "builder: " prefix pinned so the evaluator / CI can distinguish
    # builder-channel signal from preflight-channel signal.
    assert "builder:" in text, \
        "builder-warning prefix missing — cannot distinguish from preflight"


def test_builder_survives_string_roi_math():
    """roi_math as a string instead of a dict must save (not crash inside
    _roi_math_table's roi.get) and emit the exact field-path in warnings."""
    text, first_line = _save_and_split(MALFORMED_ROI_STRING_SPEC)
    parts = first_line.split("\t")
    path = Path(parts[2])
    assert path.exists() and path.stat().st_size > 5000
    assert "priority_stack[0].roi_math" in text, \
        f"roi_math field-path missing from warnings:\n{text}"


def test_builder_survives_string_executive_summary():
    """executive_summary as a string instead of a dict must save + warn."""
    text, first_line = _save_and_split(MALFORMED_EXEC_SUMMARY_STRING)
    parts = first_line.split("\t")
    path = Path(parts[2])
    assert path.exists() and path.stat().st_size > 5000
    assert "executive_summary" in text and "expected dict" in text


def test_builder_survives_list_meta():
    """meta as a list instead of a dict must save + warn + fall through to
    the default title 'Operational Audit' rather than crashing."""
    text, first_line = _save_and_split(MALFORMED_META_LIST_SPEC)
    parts = first_line.split("\t")
    path = Path(parts[2])
    assert path.exists() and path.stat().st_size > 5000
    assert "builder: meta is list" in text, \
        f"meta-list warning shape missing:\n{text}"


def test_builder_survives_list_diagnosis():
    """diagnosis as a list instead of a str must save + warn."""
    text, first_line = _save_and_split(MALFORMED_DIAGNOSIS_LIST_SPEC)
    parts = first_line.split("\t")
    path = Path(parts[2])
    assert path.exists() and path.stat().st_size > 5000
    assert "builder: diagnosis is list" in text


def test_builder_empty_priority_dict_no_warnings():
    """Policy pin: a dict-but-empty priority entry is a sparse-by-design
    case, not a malformation. Must save with NO builder-warning block.
    If this fails, we're either warning on valid input (false positive)
    or silently papering over real malformations (false negative). Either
    way the signal is wrong."""
    text, first_line = _save_and_split(EMPTY_PRIORITY_DICT_SPEC)
    parts = first_line.split("\t")
    path = Path(parts[2])
    assert path.exists() and path.stat().st_size > 5000
    assert "malformed and rendered as" not in text.lower(), \
        f"empty-dict case wrongly fired builder-warning:\n{text}"
    # Spot-check the rendered doc has the (unnamed workflow) heading for the
    # empty entry — proves the entry rendered rather than being skipped.
    import zipfile
    with zipfile.ZipFile(path) as z:
        body = z.read("word/document.xml").decode("utf-8", errors="replace")
    assert "unnamed workflow" in body, \
        "empty priority dict should render '(unnamed workflow)' heading"


def test_builder_complete_spec_produces_zero_warnings():
    """Regression guard against false-positive warnings on valid input.
    If a future edit tightens a type check in a way that rejects legitimate
    data (e.g., asserting int where spec allows ranges like '6-8'), this
    fails at Tier 0 before the bad code ships."""
    clean = copy.deepcopy(COMPLETE_SPEC)
    clean["filename"] = "test_complete_zero_warnings"
    text, _ = _save_and_split(clean)
    assert "malformed and rendered as" not in text.lower(), \
        f"complete spec produced builder-warnings:\n{text}"


def test_builder_warning_shape_is_parseable():
    """Pin the warning string shape so CI rules / evaluator hooks can parse
    it later. Shape: 'builder: <field-path> is <type>, expected <type> ...'.
    """
    text, _ = _save_and_split(MALFORMED_PRIORITY_STRING_SPEC)
    import re
    pattern = re.compile(
        r"builder: \S+ is \w+, expected \w+"
    )
    matches = pattern.findall(text)
    assert matches, \
        f"no warnings matched expected shape 'builder: <path> is " \
        f"<type>, expected <type>':\n{text}"


# ─── CONTRACT 7: client_proposal Layer 1 rollout (session 4) ──────────────────
#
# Mirrors Contract 1 (gate mechanics) + Contract 6 (builder robustness) but
# scoped to the client_proposal template. Following the per-template rollout
# workflow from the session 3 handoff: builder hardened first, then gate
# wired, then fixtures pin both at once. Step 2 of the workflow ("harden the
# builder before gating it") is what distinguishes session 4's rollout shape
# from session 2's original audit rollout.
#
# Woody is the agent owner for client_proposal per evaluator.py
# RUBRIC_CLIENT_PROPOSAL, but agent_name doesn't affect handler behavior —
# tests use "woody" for readability.


# ── Contract 7A: gate mechanics for client_proposal ─────────────────────────

def test_handler_rejects_client_proposal_stub_spec():
    """CP stub spec (2 sections, pricing present but empty) must be rejected
    with REJECTED_SENTINEL as first line. Parallel to
    test_handler_rejects_stub_spec for the audit."""
    result = artifact_docx._tool_handler(
        CLIENT_PROPOSAL_STUB_SPEC, "woody", None)
    first_line = result.split("\n", 1)[0]
    assert first_line == artifact_docx.REJECTED_SENTINEL, \
        f"expected REJECTED_SENTINEL first line, got: {first_line!r}"
    assert "client_proposal" in result, "rejection text missing template name"


def test_handler_saves_complete_client_proposal_spec():
    """Complete CP spec (all 7 sections populated) must save and return
    the DELIVERABLE_SENTINEL. Regression guard against the gate over-firing
    on well-formed input."""
    result = artifact_docx._tool_handler(
        CLIENT_PROPOSAL_COMPLETE_SPEC, "woody", None)
    first_line = result.split("\n", 1)[0]
    assert first_line.startswith("__TAVERNOS_DELIVERABLE__\t"), \
        f"expected DELIVERABLE_SENTINEL first line, got: {first_line!r}"
    parts = first_line.split("\t")
    assert len(parts) >= 4, f"sentinel header malformed: {parts}"
    path = Path(parts[2])
    assert path.exists(), f"handler reported save but file missing: {path}"
    assert path.stat().st_size > 5000, \
        f"saved file suspiciously small: {path.stat().st_size} bytes"


def test_handler_bypass_saves_client_proposal_stub_with_warnings():
    """skip_preflight_gate=True on CP stub must save + include P-prefix
    warnings in the bypass preamble. Parallel to the audit's
    test_handler_bypass_saves_stub_with_warnings."""
    bypass_stub = dict(CLIENT_PROPOSAL_STUB_SPEC)
    bypass_stub["filename"] = "test_cp_bypass_save"
    result = artifact_docx._tool_handler(bypass_stub, "woody", None,
                                         skip_preflight_gate=True)
    first_line = result.split("\n", 1)[0]
    assert first_line.startswith("__TAVERNOS_DELIVERABLE__\t"), \
        f"bypass should save; got: {first_line!r}"
    assert "Preflight gate bypassed" in result, \
        "bypass save missing warning preamble"
    # Check the P-prefix (not A-prefix) appears — this is what distinguishes
    # a correctly-routed CP rejection from the audit shape bleeding through.
    assert "preflight P" in result, \
        f"bypass warning should list P-prefix CP issues, got:\n{result}"


def test_filter_client_proposal_stub_returns_P_issues():
    """CP stub (pricing empty, 2 sections) must produce P3 + P5 issues.
    P2 must NOT fire (stub has meta.title). Parallels the audit's
    test_filter_operational_audit_stub_returns_A_issues."""
    issues = artifact_docx._rubric_critical_issues(CLIENT_PROPOSAL_STUB_SPEC)
    assert issues, "CP stub spec should produce critical issues"
    # Stub has empty pricing → P3 fires
    assert any(i.startswith("preflight P3") for i in issues), \
        f"expected P3 in issues, got: {issues}"
    # Stub has < 3 populated sections → P5 fires
    assert any(i.startswith("preflight P5") for i in issues), \
        f"expected P5 in issues, got: {issues}"
    # Stub has meta.title → P2 should NOT fire
    assert not any(i.startswith("preflight P2") for i in issues), \
        f"P2 fired but stub has meta.title: {issues}"


# ── Contract 7B: builder robustness for client_proposal ─────────────────────

def test_cp_builder_survives_string_approach_entries():
    """Session-2-bug analog for CP: approach[1] and approach[2] are bare
    strings. Must save a real file (not crash into _tool_handler's generic
    exception handler) and name the field paths in the warning block."""
    text, first_line = _save_and_split(CP_MALFORMED_APPROACH_STRING_SPEC)
    parts = first_line.split("\t")
    path = Path(parts[2])
    assert path.exists(), f"reported save but file missing: {path}"
    assert path.stat().st_size > 5000, \
        f"saved file suspiciously small: {path.stat().st_size} bytes"
    assert "malformed and rendered as" in text.lower(), \
        "builder-warning block missing from tool_result"
    assert "approach[1]" in text, \
        f"entry-1 path not named in warnings:\n{text}"
    assert "approach[2]" in text, \
        f"entry-2 path not named in warnings:\n{text}"
    assert "builder:" in text, \
        "builder-warning prefix missing — cannot distinguish from preflight"


def test_cp_builder_survives_string_pricing():
    """pricing as a string instead of a dict must save + warn, with the
    field path 'pricing' (not 'pricing.rows' or deeper) named since the
    guard fires at the container level before subfield access."""
    text, first_line = _save_and_split(CP_MALFORMED_PRICING_STRING_SPEC)
    parts = first_line.split("\t")
    path = Path(parts[2])
    assert path.exists() and path.stat().st_size > 5000
    assert "builder: pricing is str" in text, \
        f"pricing-as-string warning shape missing:\n{text}"


def test_cp_builder_survives_list_scope():
    """scope as a list instead of a dict must save + warn. Same shape as
    the audit's list-meta test — exercises the shared _as_dict guard path
    from a different caller."""
    text, first_line = _save_and_split(CP_MALFORMED_SCOPE_LIST_SPEC)
    parts = first_line.split("\t")
    path = Path(parts[2])
    assert path.exists() and path.stat().st_size > 5000
    assert "builder: scope is list" in text, \
        f"scope-as-list warning shape missing:\n{text}"


def test_cp_builder_survives_list_meta():
    """meta as a list — the guard path is shared with the audit's version
    of this test, but the CP builder is a different call site. Confirms
    the shared path holds across templates."""
    text, first_line = _save_and_split(CP_MALFORMED_META_LIST_SPEC)
    parts = first_line.split("\t")
    path = Path(parts[2])
    assert path.exists() and path.stat().st_size > 5000
    assert "builder: meta is list" in text, \
        f"meta-list warning shape missing:\n{text}"


def test_cp_builder_survives_dict_executive_summary():
    """executive_summary is a STRING in client_proposal (inverse of the
    audit, where it's a dict). A dict-shaped exec_summary is the
    malformation here — catches the agent mistake of carrying audit-shaped
    exec_summary into a proposal call."""
    text, first_line = _save_and_split(CP_MALFORMED_EXEC_SUMMARY_DICT_SPEC)
    parts = first_line.split("\t")
    path = Path(parts[2])
    assert path.exists() and path.stat().st_size > 5000
    assert "builder: executive_summary is dict" in text, \
        f"exec-summary-as-dict warning shape missing:\n{text}"


def test_cp_builder_empty_approach_dict_no_warnings():
    """Policy pin: an approach entry that IS a dict but has no fields is
    sparse-by-design, not a malformation. Must save with NO builder-warning
    block. Mirrors the audit's test_builder_empty_priority_dict_no_warnings.
    If this fails, we're either warning on valid input (false positive)
    or silently papering over real malformations (false negative)."""
    text, first_line = _save_and_split(CP_EMPTY_APPROACH_DICT_SPEC)
    parts = first_line.split("\t")
    path = Path(parts[2])
    assert path.exists() and path.stat().st_size > 5000
    assert "malformed and rendered as" not in text.lower(), \
        f"empty-dict case wrongly fired builder-warning:\n{text}"


def test_cp_builder_complete_spec_produces_zero_warnings():
    """Regression guard against false-positive warnings on valid CP input.
    Parallels the audit's test_builder_complete_spec_produces_zero_warnings.
    Catches the 'robustness tightened to the point of rejecting legitimate
    data' failure mode for CP — e.g., if someone later makes pricing.total
    stricter in a way that rejects '$8,000' string amounts."""
    clean = copy.deepcopy(CLIENT_PROPOSAL_COMPLETE_SPEC)
    clean["filename"] = "test_cp_complete_zero_warnings"
    text, _ = _save_and_split(clean)
    assert "malformed and rendered as" not in text.lower(), \
        f"CP complete spec produced builder-warnings:\n{text}"


# ═══════════════════════════════════════════════════════════════════════════════
#  CONTRACT 8 — research_report Layer 1 (session 5)
# ═══════════════════════════════════════════════════════════════════════════════
#
# Mirrors Contract 7's shape (CP is the closer template than the audit was).
# Per-template rollout workflow step 2 (session 3 addition): builder hardened
# BEFORE gate wired. For research_report this rule is load-bearing — the
# nested structure findings_detail[i].supporting_evidence[j].{source, ...}
# has three levels of .get() chains, any of which crashes on a non-dict.
#
# Cliff is the agent owner for research_report per evaluator.py
# RUBRIC_RESEARCH_REPORT, but agent_name doesn't affect handler behavior —
# tests use "cliff" for readability; existing _save_and_split uses "lilith"
# which is also fine because ALLOWED_AGENTS covers all three.


# ── Contract 8A: gate mechanics for research_report ─────────────────────────

def test_handler_rejects_research_report_stub_spec():
    """RR stub spec (1 key_finding, empty findings_detail, partial
    executive_summary, no limitations/tensions) must be rejected with
    REJECTED_SENTINEL as the first line. Parallel to
    test_handler_rejects_client_proposal_stub_spec."""
    result = artifact_docx._tool_handler(
        RESEARCH_REPORT_STUB_SPEC, "cliff", None)
    first_line = result.split("\n", 1)[0]
    assert first_line == artifact_docx.REJECTED_SENTINEL, \
        f"expected REJECTED_SENTINEL first line, got: {first_line!r}"
    assert "research_report" in result, "rejection text missing template name"


def test_handler_saves_complete_research_report_spec():
    """Complete RR spec (3 findings, 2+ citations each with source+publisher+date,
    full executive_summary, limitations populated) must save and return the
    DELIVERABLE_SENTINEL. Regression guard against the gate over-firing on
    well-formed input, especially R4 (4.0 hard floor) over-firing on legitimate
    citations."""
    result = artifact_docx._tool_handler(
        RESEARCH_REPORT_COMPLETE_SPEC, "cliff", None)
    first_line = result.split("\n", 1)[0]
    assert first_line.startswith("__TAVERNOS_DELIVERABLE__\t"), \
        f"expected DELIVERABLE_SENTINEL first line, got: {first_line!r}"
    parts = first_line.split("\t")
    assert len(parts) >= 4, f"sentinel header malformed: {parts}"
    path = Path(parts[2])
    assert path.exists(), f"handler reported save but file missing: {path}"
    assert path.stat().st_size > 5000, \
        f"saved file suspiciously small: {path.stat().st_size} bytes"


def test_handler_bypass_saves_research_report_stub_with_warnings():
    """skip_preflight_gate=True on RR stub must save + include R-prefix
    warnings in the bypass preamble. Parallel to the audit's and CP's
    bypass-save tests. Confirms the dispatcher's bypass path correctly
    routes R-prefix issues into the preamble (not A- or P-prefix)."""
    bypass_stub = dict(RESEARCH_REPORT_STUB_SPEC)
    bypass_stub["filename"] = "test_rr_bypass_save"
    result = artifact_docx._tool_handler(bypass_stub, "cliff", None,
                                         skip_preflight_gate=True)
    first_line = result.split("\n", 1)[0]
    assert first_line.startswith("__TAVERNOS_DELIVERABLE__\t"), \
        f"bypass should save; got: {first_line!r}"
    assert "Preflight gate bypassed" in result, \
        "bypass save missing warning preamble"
    # Check the R-prefix (not A- or P-prefix) appears — distinguishes a
    # correctly-routed RR rejection from the other templates' shapes
    # bleeding through.
    assert "preflight R" in result, \
        f"bypass warning should list R-prefix RR issues, got:\n{result}"


def test_filter_research_report_stub_returns_R_issues():
    """RR stub (1 finding, empty findings_detail, partial exec_summary,
    no limits/tensions) must produce R2 + R3 + R5 + R6 issues.
    R4 must NOT fire (no supporting_evidence items present to validate).
    R7 must NOT fire (preflight runs pre-build, no result passed).
    Parallels test_filter_client_proposal_stub_returns_P_issues but with
    more checks because RR has more gate-level anchors."""
    issues = artifact_docx._rubric_critical_issues(RESEARCH_REPORT_STUB_SPEC)
    assert issues, "RR stub spec should produce critical issues"
    assert any(i.startswith("preflight R2") for i in issues), \
        f"expected R2 (key_findings count) in issues, got: {issues}"
    assert any(i.startswith("preflight R3") for i in issues), \
        f"expected R3 (findings_detail empty) in issues, got: {issues}"
    assert any(i.startswith("preflight R5") for i in issues), \
        f"expected R5 (exec_summary subfields) in issues, got: {issues}"
    assert any(i.startswith("preflight R6") for i in issues), \
        f"expected R6 (no uncertainty channel) in issues, got: {issues}"
    # R4 can't fire without supporting_evidence items to validate.
    assert not any(i.startswith("preflight R4") for i in issues), \
        f"R4 fired but stub has no evidence items to validate: {issues}"
    # R7 is a post-build file-size check; should not fire at gate time.
    assert not any(i.startswith("preflight R7") for i in issues), \
        f"R7 fired at gate time (should be post-build only): {issues}"


# ── Contract 8B: builder robustness for research_report ─────────────────────

def test_rr_builder_survives_string_findings_detail_entries():
    """Session-2-bug analog for RR at the top-level entry depth:
    findings_detail[1] and [2] are bare strings. Must save a real file
    (not crash into _tool_handler's generic exception handler) and name
    the field paths in the warning block. Parallels the audit's
    MALFORMED_PRIORITY_STRING test."""
    text, first_line = _save_and_split(RR_MALFORMED_FINDINGS_DETAIL_STRING_SPEC)
    parts = first_line.split("\t")
    path = Path(parts[2])
    assert path.exists(), f"reported save but file missing: {path}"
    assert path.stat().st_size > 5000, \
        f"saved file suspiciously small: {path.stat().st_size} bytes"
    assert "malformed and rendered as" in text.lower(), \
        "builder-warning block missing from tool_result"
    assert "findings_detail[1]" in text, \
        f"entry-1 path not named in warnings:\n{text}"
    assert "findings_detail[2]" in text, \
        f"entry-2 path not named in warnings:\n{text}"
    assert "builder:" in text, \
        "builder-warning prefix missing — cannot distinguish from preflight"


def test_rr_builder_survives_string_key_findings_entry():
    """key_findings[1] as a bare string — plausible agent shortcut of
    flattening a finding into one line. Guard fires at the entry level
    from _render_key_finding's isinstance check."""
    text, first_line = _save_and_split(RR_MALFORMED_KEY_FINDINGS_STRING_SPEC)
    parts = first_line.split("\t")
    path = Path(parts[2])
    assert path.exists() and path.stat().st_size > 5000
    assert "builder: key_findings[1] is str" in text, \
        f"key_findings-entry-string warning shape missing:\n{text}"


def test_rr_builder_survives_string_synthesis():
    """synthesis as a string instead of a dict — container coerced.
    Same shape as CP's pricing-as-string test; exercises _as_dict guard
    at the top-level section."""
    text, first_line = _save_and_split(RR_MALFORMED_SYNTHESIS_STRING_SPEC)
    parts = first_line.split("\t")
    path = Path(parts[2])
    assert path.exists() and path.stat().st_size > 5000
    assert "builder: synthesis is str" in text, \
        f"synthesis-as-string warning shape missing:\n{text}"


def test_rr_builder_survives_list_meta():
    """meta as a list — shared guard path across audit / CP / RR builders.
    Confirms the shared _as_dict path holds when called from the RR
    builder, not just audit or CP."""
    text, first_line = _save_and_split(RR_MALFORMED_META_LIST_SPEC)
    parts = first_line.split("\t")
    path = Path(parts[2])
    assert path.exists() and path.stat().st_size > 5000
    assert "builder: meta is list" in text, \
        f"meta-list warning shape missing:\n{text}"


def test_rr_builder_survives_string_executive_summary():
    """executive_summary as a STRING — inverse of CP's dict-malformation.
    In RR, exec_summary is a dict. A string-shaped value is the malformation,
    typically from the agent carrying CP-shaped exec_summary into an RR call.

    Double-channel case (see proposal §5 risk 1): builder emits a warning
    AND preflight R5 fires with a template-specific semantic explanation.
    This test only asserts the builder-channel warning; the R5 preflight
    message is pinned by test_filter_research_report_stub_returns_R_issues
    when exec_summary is a string in other fixtures."""
    text, first_line = _save_and_split(RR_MALFORMED_EXEC_SUMMARY_STRING_SPEC)
    parts = first_line.split("\t")
    path = Path(parts[2])
    assert path.exists() and path.stat().st_size > 5000
    assert "builder: executive_summary is str" in text, \
        f"exec-summary-as-string warning shape missing:\n{text}"


def test_rr_builder_survives_malformed_nested_evidence():
    """A valid findings_detail[0] containing a malformed supporting_evidence
    item (string instead of dict). Two-level nested warning path — no CP
    parallel because CP doesn't nest this deep. Pins that the nested path
    renders with the full dotted context."""
    text, first_line = _save_and_split(RR_MALFORMED_NESTED_EVIDENCE_SPEC)
    parts = first_line.split("\t")
    path = Path(parts[2])
    assert path.exists() and path.stat().st_size > 5000
    # Warning must name the full two-level path, not just "supporting_evidence"
    assert "findings_detail[0].supporting_evidence[1]" in text, \
        f"nested path not named in warnings:\n{text}"
    assert "builder:" in text, "builder-warning prefix missing"


def test_rr_builder_survives_malformed_nested_source_field():
    """A valid finding + valid evidence item, but `source` is a list instead
    of a string. THREE-LEVEL nested path — the deepest warning path the
    module will produce. Pins the regex `builder: \\S+ is \\w+, expected \\w+`
    at maximum depth.

    This is the fixture that proves the Contract 6 warning-shape regex
    (pinned by test_builder_warning_shape_is_parseable) still parses at the
    depth research_report introduces."""
    text, first_line = _save_and_split(RR_MALFORMED_NESTED_SOURCE_STRING_SPEC)
    parts = first_line.split("\t")
    path = Path(parts[2])
    assert path.exists() and path.stat().st_size > 5000
    # Full three-level path must be in the warning text
    assert "findings_detail[0].supporting_evidence[0].source" in text, \
        f"three-level nested path not named in warnings:\n{text}"
    # Verify the shape matches the Contract 6 regex at this depth.
    import re
    # Regex from test_builder_warning_shape_is_parseable
    shape_re = re.compile(r"builder: \S+ is \w+, expected \w+")
    matches = shape_re.findall(text)
    assert any("findings_detail[0].supporting_evidence[0].source" in m
               for m in matches), \
        f"deep-nested warning shape does not match Contract 6 regex:\n{text}"


def test_rr_builder_empty_findings_dict_no_warnings():
    """Policy pin (§3 of session 5 proposal): a findings_detail entry that
    IS a dict but has no fields is sparse-by-design, not a malformation.
    Must save with NO builder-warning block. Mirrors the audit's and CP's
    empty-dict policy tests.

    Note: unlike CP's empty-approach-dict (which renders nothing),
    _render_finding_detail always renders a heading because finding_ref
    defaults to index+1. That bare heading is a structural slot marker
    and is fine — R3 preflight catches the quality complaint at gate time."""
    text, first_line = _save_and_split(RR_EMPTY_FINDINGS_DICT_SPEC)
    parts = first_line.split("\t")
    path = Path(parts[2])
    assert path.exists() and path.stat().st_size > 5000
    assert "malformed and rendered as" not in text.lower(), \
        f"empty-dict findings_detail case wrongly fired builder-warning:\n{text}"


def test_rr_builder_complete_spec_produces_zero_warnings():
    """Regression guard against false-positive warnings on valid RR input.
    Parallels the audit's and CP's equivalent tests. Catches the 'robustness
    tightened to the point of rejecting legitimate data' failure mode —
    e.g., if a future edit makes `source` stricter in a way that rejects
    legitimate publication titles, or if `date` is coerced to a type check
    that rejects legitimate range strings like 'Oct-Nov 2025'."""
    clean = copy.deepcopy(RESEARCH_REPORT_COMPLETE_SPEC)
    clean["filename"] = "test_rr_complete_zero_warnings"
    text, _ = _save_and_split(clean)
    assert "malformed and rendered as" not in text.lower(), \
        f"RR complete spec produced builder-warnings:\n{text}"


# ── Contract 8C: co-existence of both warning channels ──────────────────────

def test_handler_bypass_saves_malformed_spec_with_both_warning_blocks():
    """Session-3 carry-forward backlog item, finally pinned in session 5.

    Bypass-mode on a spec that has BOTH preflight-critical issues AND
    builder-caught malformations must emit BOTH warning blocks in the
    correct chronological order: preflight-channel (bypass preamble) first,
    builder-channel second. This pins the co-existence contract that
    sessions 3 and 4 tested each block independently but never in
    combination.

    Carrier fixture: RR stub (triggers R2/R3/R5/R6 at preflight) + meta
    replaced with a list (triggers builder-warning on `meta`). The RR
    fixture was chosen because it's the first template to have BOTH the
    guarded builder (session 5) AND a rich set of gate-level issues on
    its stub — but any of the three templates could have carried this."""
    spec = copy.deepcopy(RR_STUB_WITH_MALFORMED_META_SPEC)
    result = artifact_docx._tool_handler(spec, "cliff", None,
                                         skip_preflight_gate=True)
    first_line = result.split("\n", 1)[0]
    assert first_line.startswith("__TAVERNOS_DELIVERABLE__\t"), \
        f"bypass should save; got: {first_line!r}"

    # Both blocks must be present.
    assert "Preflight gate bypassed" in result, \
        "bypass preamble (preflight-channel) missing:\n" + result
    assert "malformed and rendered as" in result.lower(), \
        "builder-warning block (builder-channel) missing:\n" + result

    # Order: bypass preamble first, builder-warning second.
    bypass_idx = result.index("Preflight gate bypassed")
    builder_idx = result.lower().index("malformed and rendered as")
    assert bypass_idx < builder_idx, \
        (f"wrong order: bypass preamble at {bypass_idx}, "
         f"builder-warning at {builder_idx} — preflight-channel should "
         f"precede builder-channel per chronological order")

    # Sanity: the builder-warning must name the `meta` field.
    assert "builder: meta is list" in result, \
        "builder-warning does not name the malformed field:\n" + result


# ─── CONTRACT 9: tool_choice forcing (session 6) ──────────────────────────────
#
# Pins the tool_choice_override plumbing added to run_tool_use_loop to attack
# Problem 1 (invocation reliability) from the session-1 diagnosis. Mirrors
# Contract 5's kwarg-routing shape with one extra test for the interaction
# between forcing and the rubric-critical preflight gate — per the session-6
# kickoff, that interaction is the single most load-bearing design question
# this session, so it gets its own pin.
#
# What these tests cover:
#   (9.1) helper produces the Anthropic API-shape dict (no OpenAI drift)
#   (9.2) override reaches the FIRST messages.create AND is absent from the
#         in-loop create — this is the first-call-only policy, without
#         which the while-True loop would be uncapped under forcing
#   (9.3) override is NOT re-applied on a retry after the preflight gate
#         rejected the forced tool call — so the existing
#         _PREFLIGHT_GATE_MAX_REJECTIONS escape hatch still works
#   (9.4) backward-compat: default (no override) behaves identically to
#         the pre-session-6 code — no tool_choice kwarg on any create
#
# The tests use an in-process mock client that records messages.create
# kwargs; they do NOT hit the Anthropic API. This matches the Tier 0
# discipline (mechanism only; no agent variance). The mock exercises the
# real _dispatch_first_party_tool and real _tool_handler so the gate
# interaction in 9.3 is genuine.


class _FakeBlock:
    """Minimal stand-in for an Anthropic content block. Ducks both the
    text-block shape (.type="text", .text=...) and the tool_use shape
    (.type="tool_use", .name=..., .input=..., .id=...) on one class so a
    canned response can mix them."""
    def __init__(self, type=None, text=None, name=None, input=None, id=None):
        self.type = type
        self.text = text
        self.name = name
        self.input = input
        self.id = id


class _FakeResponse:
    """Minimal stand-in for an Anthropic messages.create response object."""
    def __init__(self, content):
        self.content = content


class _RecorderClient:
    """Mock Anthropic client. Records every messages.create kwargs dict and
    returns the next canned response from a queue. `client.messages.create`
    works because `self.messages = self` — the nested-attribute shape of
    the real SDK is collapsed onto one object for test simplicity."""
    def __init__(self, responses):
        self._responses = list(responses)
        self.calls = []
        self.messages = self

    def create(self, **kwargs):
        self.calls.append(dict(kwargs))
        if not self._responses:
            raise AssertionError(
                "_RecorderClient ran out of canned responses — test "
                "expected fewer turns than run_tool_use_loop took")
        return self._responses.pop(0)


def _tool_use_block(tool_name: str, tool_input: dict, block_id: str = "tu_01"):
    return _FakeBlock(type="tool_use", name=tool_name,
                      input=tool_input, id=block_id)


def _text_block(text: str):
    return _FakeBlock(type="text", text=text)


def test_tool_choice_force_tool_helper_shape():
    """Helper produces the Anthropic-shape tool_choice dict. Pinned so
    callers don't drift to OpenAI-shaped {"type":"function","function":{...}}
    variants. Module-level TOOL_CHOICE_* constants pinned alongside."""
    got = norm.tool_choice_force_tool("generate_docx_report")
    assert got == {"type": "tool", "name": "generate_docx_report"}, \
        f"helper shape wrong: {got!r}"
    # The non-parametric modes are exposed as module constants.
    assert norm.TOOL_CHOICE_AUTO == {"type": "auto"}
    assert norm.TOOL_CHOICE_ANY  == {"type": "any"}
    assert norm.TOOL_CHOICE_NONE == {"type": "none"}


def test_run_tool_use_loop_passes_override_to_first_create_only():
    """Primary kwarg-routing contract + first-call-only policy pin.

    Two-turn scenario: turn 1 emits a forced tool_use (complete spec, so
    dispatch succeeds), turn 2 emits only text so the loop terminates.
    Assert the override lands on create call #1 and is absent from call
    #2. The latter is load-bearing — without it, every subsequent turn
    would re-force tool_use and the loop would never reach a natural
    text-only termination."""
    complete = dict(COMPLETE_SPEC)
    complete["filename"] = "test_tool_choice_first_call_only"

    turn1 = _FakeResponse(content=[
        _tool_use_block("generate_docx_report", complete, block_id="tu_01"),
    ])
    turn2 = _FakeResponse(content=[_text_block("Audit saved. ")])
    client = _RecorderClient([turn1, turn2])

    override = norm.tool_choice_force_tool("generate_docx_report")
    messages = [{"role": "user", "content": "audit this business"}]
    norm.run_tool_use_loop(
        client, "model-id", "system", messages, [], 1000, "lilith",
        tool_choice_override=override)

    assert len(client.calls) == 2, \
        f"expected 2 messages.create calls, got {len(client.calls)}"
    assert client.calls[0].get("tool_choice") == override, \
        ("override missing from first create: "
         f"{client.calls[0].get('tool_choice')!r}")
    assert "tool_choice" not in client.calls[1], \
        ("override leaked into in-loop create — would create an "
         "infinite forced-tool_use loop with no text-only termination "
         f"path. Got: {client.calls[1].get('tool_choice')!r}")


def test_run_tool_use_loop_passes_any_mode_constant_to_first_create():
    """TOOL_CHOICE_ANY end-to-end through the loop. Pins that the module
    constant (not just tool-specific forcing via the helper) also routes
    through to messages.create correctly.

    Single-turn scenario — response is text-only so the loop exits after
    one create. First-call-only semantics are already pinned by test
    `override reaches first create only` above; this test only needs to
    confirm the constant itself lands as the tool_choice kwarg. Matters
    for Cliff's path: research_report + web_search, where `any` forces
    invocation without dictating which tool."""
    turn1 = _FakeResponse(content=[_text_block("I'll look into that.")])
    client = _RecorderClient([turn1])

    messages = [{"role": "user", "content": "find me sources"}]
    norm.run_tool_use_loop(
        client, "model-id", "system", messages, [], 1000, "cliff",
        tool_choice_override=norm.TOOL_CHOICE_ANY)

    assert len(client.calls) == 1
    assert client.calls[0].get("tool_choice") == {"type": "any"}, \
        ("TOOL_CHOICE_ANY constant did not reach messages.create: "
         f"{client.calls[0].get('tool_choice')!r}")


def test_tool_choice_override_absent_when_rejected_tool_retries():
    """Preflight-gate × tool_choice interaction pin — the load-bearing
    design question this session.

    Turn 1 is forced with a STUB spec; the handler rejects it
    (is_error=True, gate_rejection_counts bumps to 1). Turn 2 must NOT
    re-apply the override — if it did, a rejection would force another
    invocation and the agent couldn't escape to natural language. The
    existing _PREFLIGHT_GATE_MAX_REJECTIONS bypass is the correct retry
    mechanism; forcing must not interfere with it."""
    stub = dict(STUB_SPEC)
    stub["filename"] = "test_tool_choice_rejected_retry"

    turn1 = _FakeResponse(content=[
        _tool_use_block("generate_docx_report", stub, block_id="tu_03"),
    ])
    # Turn 2: agent emits natural-language response to the rejection.
    turn2 = _FakeResponse(content=[
        _text_block("I need more detail before I can produce the audit."),
    ])
    client = _RecorderClient([turn1, turn2])

    override = norm.tool_choice_force_tool("generate_docx_report")
    messages = [{"role": "user", "content": "audit something"}]
    norm.run_tool_use_loop(
        client, "model-id", "system", messages, [], 1000, "lilith",
        tool_choice_override=override)

    assert len(client.calls) == 2, \
        f"expected 2 create calls, got {len(client.calls)}"
    # Turn 1 had the override — forcing reached the API as intended.
    assert client.calls[0].get("tool_choice") == override
    # Turn 2 must NOT have it, even though turn 1's tool was rejected.
    # If the override re-applied here, a rejection would trigger another
    # forced invocation. The existing _PREFLIGHT_GATE_MAX_REJECTIONS
    # bypass caps total rejections at 2, but only works if the agent
    # has the option to emit text between rejections.
    assert "tool_choice" not in client.calls[1], \
        ("override re-applied on retry after rejection — would bypass "
         "the _PREFLIGHT_GATE_MAX_REJECTIONS natural-language escape "
         "hatch and risk a forced-retry loop")

    # Sanity check: the rejection actually happened. If the stub silently
    # passed the gate, the interaction pin above would be a false positive.
    user_messages = [m for m in messages if m.get("role") == "user"]
    assert len(user_messages) >= 2, \
        "loop did not append tool_results user-turn after dispatch"
    tool_results = [c for c in user_messages[-1].get("content", [])
                    if isinstance(c, dict) and c.get("type") == "tool_result"]
    assert tool_results, "test setup bug — no tool_result in last user turn"
    assert tool_results[0].get("is_error") is True, \
        ("stub spec should have triggered is_error=True tool_result; "
         f"got: {tool_results[0]}")


def test_run_tool_use_loop_default_omits_tool_choice():
    """Backward-compat pin. Without tool_choice_override, neither the
    first nor any subsequent create gets a tool_choice kwarg. Protects
    the session-1-through-5 behavior; any future default change must be
    deliberate and would fail this test first."""
    complete = dict(COMPLETE_SPEC)
    complete["filename"] = "test_tool_choice_default_omitted"

    turn1 = _FakeResponse(content=[
        _tool_use_block("generate_docx_report", complete, block_id="tu_02"),
    ])
    turn2 = _FakeResponse(content=[_text_block("Done. ")])
    client = _RecorderClient([turn1, turn2])

    messages = [{"role": "user", "content": "audit this business"}]
    # No tool_choice_override — pre-session-6 behavior.
    norm.run_tool_use_loop(
        client, "model-id", "system", messages, [], 1000, "lilith")

    assert len(client.calls) == 2
    for i, call in enumerate(client.calls):
        assert "tool_choice" not in call, \
            (f"tool_choice leaked into default-path create #{i+1}: "
             f"{call.get('tool_choice')!r}")


# ─── CONTRACT 11: forcing deployment conjunction (session 9) ──────────────────
#
# Pins the two-gate conjunction that gates production forcing:
#   (a) agent config declares `force_tool`, AND
#   (b) Sam classified the current task as `BOUND`
# Conjunction lives in norm._compute_force_tool_override — a pure helper
# so the conjunction can be tested directly without mocking
# call_execute_streaming + the full streaming pipeline.
#
# What these tests cover:
#   (11.1) truth table — all 4 rows of (force_tool x mode_hint)
#   (11.2) backward compat — missing mode field routes to no-force
#   (11.3) fail-safe — malformed mode value routes to no-force
#
# These are unit tests against the helper, no API calls, no mocks needed.


def test_force_conjunction_truth_table():
    """All 4 rows of the (force_tool, mode_hint) truth table. Only the
    (set, "BOUND") combination fires forcing; everything else is None."""
    # Row 1: no force_tool config, no mode hint → no force
    assert norm._compute_force_tool_override({}, None) is None
    assert norm._compute_force_tool_override({"name": "Norm"}, None) is None

    # Row 2: no force_tool config, BOUND mode → no force (agent not opted in)
    assert norm._compute_force_tool_override({}, "BOUND") is None
    assert norm._compute_force_tool_override({"name": "Norm"}, "BOUND") is None

    # Row 3: force_tool config, no/CLARIFY mode → no force (Sam said CLARIFY)
    lilith_like = {"name": "Lilith", "force_tool": "generate_docx_report"}
    assert norm._compute_force_tool_override(lilith_like, None) is None
    assert norm._compute_force_tool_override(lilith_like, "CLARIFY") is None

    # Row 4: force_tool config AND BOUND mode → FORCE
    result = norm._compute_force_tool_override(lilith_like, "BOUND")
    assert result == {"type": "tool", "name": "generate_docx_report"}, \
        f"expected forcing dict, got: {result}"


def test_force_conjunction_missing_mode_defaults_to_no_force():
    """Backward compat: routers that predate session-9's ROUTER_SYSTEM
    won't emit `mode`. call_router's post-processing defaults absent
    mode to None. The conjunction must not fire on None — otherwise
    pre-session-9 plans would activate forcing on every deliverable-
    agent call, regressing Tier 2a catastrophically."""
    lilith_like = {"name": "Lilith", "force_tool": "generate_docx_report"}
    # Three shapes of absence
    assert norm._compute_force_tool_override(lilith_like, None) is None
    # mode as empty string (shouldn't happen but fail-safe anyway)
    assert norm._compute_force_tool_override(lilith_like, "") is None


def test_force_conjunction_malformed_mode_defaults_to_no_force():
    """Fail-safe: if Sam emits something other than BOUND/CLARIFY/None
    in the mode field (e.g. 'bound' lowercase, 'Bound' mixed case,
    'true', a number, an object), the conjunction must treat it as
    'not BOUND' and not fire. call_router's validation also coerces
    malformed values to None, but defense-in-depth here catches any
    path where malformed values slip through."""
    lilith_like = {"name": "Lilith", "force_tool": "generate_docx_report"}
    # Case variants
    assert norm._compute_force_tool_override(lilith_like, "bound") is None
    assert norm._compute_force_tool_override(lilith_like, "Bound") is None
    assert norm._compute_force_tool_override(lilith_like, "BOUND ") is None  # trailing space
    # Non-string
    assert norm._compute_force_tool_override(lilith_like, True) is None
    assert norm._compute_force_tool_override(lilith_like, 1) is None
    assert norm._compute_force_tool_override(lilith_like, ["BOUND"]) is None
    assert norm._compute_force_tool_override(lilith_like, {"mode": "BOUND"}) is None


# ─── CONTRACT 10: preflight absence checks + dead-spot + isinstance skip ──────
#
# Session 7 priority 2. Closes the session-3/4/5/6 carry-forward pile in
# one pass. Six tests covering five preflight tightenings:
#
#   (10.1) A4b — audit with priorities but zero roi_math blocks rejected
#   (10.2) P4b — CP with pricing entirely absent rejected
#   (10.3) R3b — RR with findings_detail entirely absent rejected
#   (10.4) P5 dead-spot — CP with only meta.title now caught (previously
#          passed the gate silently because of the `and non_empty` short-
#          circuit in preflight())
#   (10.5) A3/A4 loop isinstance skip — malformed-priority stub does not
#          silence the preflight via outer try/except; later checks still
#          surface clean issues
#   (10.6) R3/R4 loop isinstance skip — malformed-findings stub same shape
#          as 10.5 for research_report
#
# Contract 10 is a single-theme cross-cutting block (like Contract 9) rather
# than spread across Contracts 2/6/7/8. Session-7 handoff design choice:
# absence checks share a mechanism story ("preflight catches what it used
# to miss") that's easier to read co-located.
#
# These are mechanism-only tests against the preflight layer — no API
# calls, no builder invocation, deterministic.


def test_audit_collective_absence_of_roi_math_fires_A4b():
    """Audit with 3 priorities but NO roi_math on any priority must produce
    A4b. Session-7 design: A4b uses collective semantics — fires only when
    no priority has roi_math, not per-entry. This matches COMPLETE_SPEC's
    realistic shape (roi_math on priority[0] only) and the rubric anchor
    ('show your math' = must be visible somewhere, not on every line)."""
    issues = artifact_docx._rubric_critical_issues(AUDIT_NO_ROI_MATH_SPEC)
    assert any(i.startswith("preflight A4b") for i in issues), \
        f"expected A4b in issues, got: {issues}"
    # Regression guard: A4 (partial) must NOT fire — fixture has no roi_math
    # blocks at all; partial-check has nothing to iterate. A4b is the only
    # roi-math-related issue expected.
    assert not any(i.startswith("preflight A4:") for i in issues), \
        f"A4 fired but fixture has no partial roi_math: {issues}"


def test_cp_absent_pricing_fires_P4b_not_P3():
    """CP with pricing key entirely removed must produce P4b (absence),
    NOT P3 (present-but-empty). The two checks map to the same rubric
    dim (pricing_transparency) via different regen triggers — distinguishing
    them lets the agent get a targeted retry message."""
    issues = artifact_docx._rubric_critical_issues(CP_NO_PRICING_SPEC)
    assert any(i.startswith("preflight P4b") for i in issues), \
        f"expected P4b in issues, got: {issues}"
    assert not any(i.startswith("preflight P3") for i in issues), \
        f"P3 fired but fixture has pricing ABSENT (not present-but-empty): {issues}"


def test_rr_absent_findings_detail_fires_R3b_not_R3():
    """RR with findings_detail key entirely removed must produce R3b
    (absence), NOT R3 (present-but-empty). Highest-consequence absence
    check in the preflight — synthesis_quality + source_quality both
    depend on the key. Before session 7, this case passed silently."""
    issues = artifact_docx._rubric_critical_issues(RR_NO_FINDINGS_DETAIL_SPEC)
    assert any(i.startswith("preflight R3b") for i in issues), \
        f"expected R3b in issues, got: {issues}"
    # R3's per-entry check must not fire — there are no entries to iterate.
    # R3's present-but-empty check must not fire either — fixture omits the
    # key entirely.
    assert not any(i == "preflight R3: findings_detail is empty — rubric "
                        "synthesis_quality and source_quality both need "
                        "per-finding evidence; need at least 3 detailed findings"
                   for i in issues), \
        f"R3 present-but-empty fired but fixture has findings_detail ABSENT: {issues}"


def test_cp_title_only_now_fires_P5_dead_spot_fix():
    """CP with only meta.title + zero content sections must now produce
    P5. Session-7 one-liner fix: `if len(non_empty) < 3:` (was
    `< 3 and non_empty`). The `and non_empty` short-circuit dead-spotted
    on empty non_empty list, so title-only specs passed P5 silently and
    built as styled title bars. P2 must still NOT fire (title is present)."""
    issues = artifact_docx._rubric_critical_issues(CP_TITLE_ONLY_SPEC)
    assert any(i.startswith("preflight P5") for i in issues), \
        f"expected P5 in issues (session-7 dead-spot fix), got: {issues}"
    # P2 must stay silent — title is present, so "no content + no title"
    # does not apply. P4b is allowed to fire (fixture also has no pricing);
    # that's expected, not a regression.
    assert not any(i.startswith("preflight P2") for i in issues), \
        f"P2 fired but fixture has meta.title: {issues}"


def test_preflight_audit_malformed_priorities_does_not_silence_later_checks():
    """Session-7 isinstance skip on the A3/A4 shared loop. Before the fix,
    non-dict priority entries crashed the .get() calls; the outer try/except
    silenced the crash and returned ONLY 'preflight crashed: ...' — every
    valid downstream check (A5, A6) lost. After the fix, the loop skips
    non-dict entries and later checks still surface clean issues.

    Reuses the Contract 6 malformed-priority fixture (entries 1 and 2 are
    bare strings, entry 0 is a complete dict). Preflight should return a
    clean list with no 'preflight crashed:' entries."""
    issues = artifact_docx.preflight(MALFORMED_PRIORITY_STRING_SPEC)
    # The isinstance skip must close the silent-failure loop — no crash.
    assert not any(i.startswith("preflight crashed:") for i in issues), \
        f"preflight crashed on malformed priorities: {issues}"
    # Positive check: entry 0 is a complete dict with 2 evidence items and
    # full roi_math, so no A3/A4 issue fires for it. Entries 1 and 2 are
    # skipped. A4b must NOT fire — entry 0 has roi_math. All downstream
    # checks (A5 exec_summary, A6 uncertainty) run because they're outside
    # the loop — the COMPLETE_SPEC-derived fixture has both present, so
    # neither fires either. Result: issues is [] (clean).
    assert issues == [], \
        f"malformed-priority-with-valid-[0] should produce clean preflight; got: {issues}"


def test_preflight_rr_malformed_findings_does_not_silence_later_checks():
    """Session-7 isinstance skip on R3 + R4 outer loops. Same shape as
    the audit counterpart — non-dict findings_detail entries previously
    crashed .get() and silenced the whole preflight via outer try/except.

    Reuses the Contract 8 malformed-findings fixture (entries 1 and 2 are
    bare strings, entry 0 is complete). Preflight should complete cleanly."""
    issues = artifact_docx.preflight(RR_MALFORMED_FINDINGS_DETAIL_STRING_SPEC)
    assert not any(i.startswith("preflight crashed:") for i in issues), \
        f"preflight crashed on malformed findings: {issues}"
    # Entry 0 is complete — 2 evidence items, all with source+publisher+date.
    # Entries 1 and 2 are skipped by the isinstance guards on BOTH the R3
    # loop and the R4 loop. R3b must NOT fire — findings_detail key is
    # present. R5 / R6 run outside the loop against COMPLETE_SPEC-derived
    # subfields, both populated → no fire. Result: issues is [] (clean).
    assert issues == [], \
        f"malformed-findings-with-valid-[0] should produce clean preflight; got: {issues}"


# ═══════════════════════════════════════════════════════════════════════════════
#  CONTRACT 12 — Deck (executive_review_deck) Layer 1 gate (session 10).
#  Mirrors Contracts 7 (client_proposal) and 8 (research_report): stub
#  rejected, complete spec saves, bypass saves stub with D-prefix warnings,
#  _rubric_critical_issues returns D-prefix subset.
# ═══════════════════════════════════════════════════════════════════════════════

DECK_STUB_SPEC = {
    "artifact": "pptx",
    "template": "executive_review_deck",
    "filename": "test_stub_deck",
    "category": "reports",
    "meta": {"title": "Q1 Review", "client_name": "Acme"},
    # 3 slides, no closing, middle content slide has empty bullets →
    # D2 fires (< 5 slides), D3 fires (thin content), D4 fires (no closing).
    # D5 does NOT fire — slide[1] is type=content (non-section, non-title).
    "slides": [
        {"type": "title", "title": "Q1 Review"},
        {"type": "content", "title": "Revenue update", "bullets": []},
        {"type": "section", "title": "Key Bets"},
    ],
}

DECK_COMPLETE_SPEC = {
    "artifact": "pptx",
    "template": "executive_review_deck",
    "filename": "test_complete_deck",
    "category": "reports",
    "meta": {"title": "Q1 Executive Review",
             "subtitle": "Acme Corp · April 2026",
             "prepared_by": "Rebecca / TavernOS",
             "client_name": "Acme Corp"},
    "slides": [
        {"type": "title",
         "title": "Q1 Executive Review",
         "subtitle": "Acme Corp · April 2026"},
        {"type": "content",
         "title": "Q1 revenue: $1.4M, 108% of target, expansion accelerating",
         "bullets": [
             "Q1 ARR closed at $1.4M, beating $1.3M target by 8.3%",
             "Three enterprise logos closed — $415K total new ARR",
             "Expansion motion landed 41% of upsell pipeline",
         ]},
        {"type": "content",
         "title": "Enterprise bet: 3 logos committed; on track for Q3 milestone",
         "bullets": [
             "Meridian Labs ($180K), Kestrel ($140K), Greenshoot ($95K) signed",
             "All 3 deploying in Q2; production traffic by end of quarter",
             "Pipeline carries 8 more enterprise ICPs; 4 in late-stage",
         ]},
        {"type": "content",
         "title": "Risks: churn concentration, new hire onboarding",
         "bullets": [
             "Top-3 accounts represent 28% of ARR — concentration risk",
             "New enterprise AEs ramping; full productivity not until Q3",
             "Mitigations in flight for both",
         ]},
        {"type": "closing",
         "title": "Ask: approve $2.4M H2 add to GTM budget",
         "bullets": [
             "Doubles enterprise AE count from 3 to 6 before Q3",
             "Funds $400K for enterprise demand-gen program",
             "Decision needed by end of April to hit Q3 ramp timeline",
         ]},
    ],
}


def test_handler_rejects_deck_stub_spec():
    """Deck stub (3 slides, no closing, empty content bullets) must be
    rejected with REJECTED_SENTINEL as the first line. Parallel to
    test_handler_rejects_research_report_stub_spec."""
    result = artifact_pptx._tool_handler(DECK_STUB_SPEC, "rebecca-deck", None)
    first_line = result.split("\n", 1)[0]
    assert first_line == artifact_pptx.REJECTED_SENTINEL, \
        f"expected REJECTED_SENTINEL first line, got: {first_line!r}"
    assert "executive_review_deck" in result, "rejection text missing template name"


def test_handler_saves_complete_deck_spec():
    """Complete Deck spec (5 slides including a closing slide, all content
    slides with bullets) must save. Regression guard against the D-prefix
    gate over-firing on well-formed input.

    Session 12 priority 1 sub-item 1: path resolution now routes through
    setup_temp_workspace's wiring for all three artifact modules, so the
    handler's returned path is absolute inside the temp workspace. Prior
    ~/.tavernos fallback removed — Rule 6 retired."""
    result = artifact_pptx._tool_handler(DECK_COMPLETE_SPEC, "rebecca-deck", None)
    first_line = result.split("\n", 1)[0]
    assert first_line.startswith("__TAVERNOS_DELIVERABLE__\t"), \
        f"expected DELIVERABLE_SENTINEL first line, got: {first_line!r}"
    parts = first_line.split("\t")
    assert len(parts) >= 4, f"sentinel header malformed: {parts}"
    path = Path(parts[2])
    assert path.is_absolute(), \
        f"expected absolute path from temp-workspace resolver, got: {path}"
    assert path.exists(), f"handler reported save but file missing: {path}"
    assert path.stat().st_size > 15000, \
        f"saved file suspiciously small: {path.stat().st_size} bytes"
    # TASK COMPLETE trailer must be present on success (session 9 2a + session 10 port).
    assert "TASK COMPLETE" in result, \
        "completion directive missing from success trailer"


def test_handler_bypass_saves_deck_stub_with_warnings():
    """skip_preflight_gate=True on Deck stub must save + include D-prefix
    warnings in the bypass preamble. Confirms the dispatcher's bypass path
    correctly routes D-prefix issues into the preamble."""
    bypass_stub = dict(DECK_STUB_SPEC)
    bypass_stub["filename"] = "test_deck_bypass_save"
    result = artifact_pptx._tool_handler(bypass_stub, "rebecca-deck", None,
                                         skip_preflight_gate=True)
    first_line = result.split("\n", 1)[0]
    assert first_line.startswith("__TAVERNOS_DELIVERABLE__\t"), \
        f"bypass should save; got: {first_line!r}"
    assert "Preflight gate bypassed" in result, \
        "bypass save missing warning preamble"
    assert "preflight D" in result, \
        f"bypass warning should list D-prefix Deck issues, got:\n{result}"


def test_filter_deck_stub_returns_D_issues():
    """Deck stub (3 slides, no closing, empty middle content bullets) must
    produce D2 + D3 + D4. D5 must NOT fire — there's one content slide
    which is non-section/non-title. Parallels
    test_filter_research_report_stub_returns_R_issues."""
    issues = artifact_pptx._rubric_critical_issues(DECK_STUB_SPEC)
    assert issues, "Deck stub spec should produce critical issues"
    assert any(i.startswith("preflight D2") for i in issues), \
        f"expected D2 (slide count < 5) in issues, got: {issues}"
    assert any(i.startswith("preflight D3") for i in issues), \
        f"expected D3 (thin content bullets) in issues, got: {issues}"
    assert any(i.startswith("preflight D4") for i in issues), \
        f"expected D4 (no closing slide) in issues, got: {issues}"
    # D5 must not fire — stub has a content slide.
    assert not any(i.startswith("preflight D5") for i in issues), \
        f"D5 fired but stub has a content slide: {issues}"


# ═══════════════════════════════════════════════════════════════════════════════
#  CONTRACT 13 — MBR (monthly_business_review) Layer 1 gate (session 10).
#  Same shape as Contract 12 but for xlsx + M-prefix.
# ═══════════════════════════════════════════════════════════════════════════════

MBR_STUB_SPEC = {
    "artifact": "xlsx",
    "template": "monthly_business_review",
    "filename": "test_stub_mbr",
    "category": "reports",
    "meta": {"client_name": "Acme Corp", "period": "March 2026",
             "prepared_by": "Rebecca / TavernOS"},
    # No revenue rows, no cost rows → M2 fires.
    "revenue": {"rows": []},
    "costs": {"rows": []},
}

MBR_MATERIAL_VARIANCE_NO_COMMENTARY_SPEC = {
    "artifact": "xlsx",
    "template": "monthly_business_review",
    "filename": "test_mbr_variance_no_commentary",
    "category": "reports",
    "meta": {"client_name": "Acme Corp", "period": "March 2026",
             "prepared_by": "Rebecca / TavernOS"},
    # Material variance (actual 412 vs plan 448 = 8% miss) with NO commentary → M3.
    "revenue": {"rows": [
        {"month": "Jan 2026", "actual": 380000, "plan": 400000},
        {"month": "Feb 2026", "actual": 395000, "plan": 420000},
        {"month": "Mar 2026", "actual": 412000, "plan": 448000},
    ]},
    "costs": {"rows": [
        {"month": "Jan 2026", "cogs": 80000, "opex": 220000,
         "plan_cogs": 85000, "plan_opex": 215000},
        {"month": "Feb 2026", "cogs": 82000, "opex": 230000,
         "plan_cogs": 85000, "plan_opex": 225000},
        {"month": "Mar 2026", "cogs": 88000, "opex": 245000,
         "plan_cogs": 85000, "plan_opex": 230000},
    ]},
    # commentary deliberately absent — M3 should fire.
}

MBR_COMPLETE_SPEC = {
    "artifact": "xlsx",
    "template": "monthly_business_review",
    "filename": "test_complete_mbr",
    "category": "reports",
    "meta": {"client_name": "Acme Corp", "period": "March 2026",
             "prepared_by": "Rebecca / TavernOS"},
    "revenue": {"rows": [
        {"month": "Jan 2026", "actual": 380000, "plan": 400000},
        {"month": "Feb 2026", "actual": 395000, "plan": 420000},
        {"month": "Mar 2026", "actual": 412000, "plan": 448000},
    ]},
    "costs": {"rows": [
        {"month": "Jan 2026", "cogs": 80000, "opex": 220000,
         "plan_cogs": 85000, "plan_opex": 215000},
        {"month": "Feb 2026", "cogs": 82000, "opex": 230000,
         "plan_cogs": 85000, "plan_opex": 225000},
        {"month": "Mar 2026", "cogs": 88000, "opex": 245000,
         "plan_cogs": 85000, "plan_opex": 230000},
    ]},
    "commentary": [
        {"topic": "March revenue miss",
         "note": "Meridian Labs churn ($14K MRR exit, March 18) plus Greenshoot "
                 "contract delay (shifted $22K into April). Absent both events, "
                 "period closed at 99.1% of target."},
        {"topic": "March opex overage",
         "note": "Engineering hiring pulled forward by 4 weeks to de-risk Q2 "
                 "product roadmap. One-time signing-bonus accrual in March."},
    ],
}


def test_handler_rejects_mbr_stub_spec():
    """MBR stub (empty revenue + costs rows) must be rejected with
    REJECTED_SENTINEL as the first line."""
    result = artifact_xlsx._tool_handler(MBR_STUB_SPEC, "rebecca-mbr", None)
    first_line = result.split("\n", 1)[0]
    assert first_line == artifact_xlsx.REJECTED_SENTINEL, \
        f"expected REJECTED_SENTINEL first line, got: {first_line!r}"
    assert "monthly_business_review" in result, "rejection text missing template name"


def test_handler_rejects_mbr_variance_no_commentary():
    """MBR with material variance but no commentary must fire M3."""
    result = artifact_xlsx._tool_handler(
        MBR_MATERIAL_VARIANCE_NO_COMMENTARY_SPEC, "rebecca-mbr", None)
    first_line = result.split("\n", 1)[0]
    assert first_line == artifact_xlsx.REJECTED_SENTINEL, \
        f"expected REJECTED_SENTINEL first line, got: {first_line!r}"
    assert "preflight M3" in result, \
        f"expected M3 commentary-gap in rejection, got:\n{result}"


def test_handler_saves_complete_mbr_spec():
    """Complete MBR (revenue + costs + commentary) must save with TASK
    COMPLETE trailer.

    Session 12 priority 1 sub-item 1: path resolution now routes through
    setup_temp_workspace's wiring for all three artifact modules, so the
    handler's returned path is absolute inside the temp workspace. Prior
    ~/.tavernos fallback removed — Rule 6 retired."""
    result = artifact_xlsx._tool_handler(MBR_COMPLETE_SPEC, "rebecca-mbr", None)
    first_line = result.split("\n", 1)[0]
    assert first_line.startswith("__TAVERNOS_DELIVERABLE__\t"), \
        f"expected DELIVERABLE_SENTINEL first line, got: {first_line!r}"
    parts = first_line.split("\t")
    assert len(parts) >= 4, f"sentinel header malformed: {parts}"
    path = Path(parts[2])
    assert path.is_absolute(), \
        f"expected absolute path from temp-workspace resolver, got: {path}"
    assert path.exists(), f"handler reported save but file missing: {path}"
    assert path.stat().st_size > 5000, \
        f"saved file suspiciously small: {path.stat().st_size} bytes"
    assert "TASK COMPLETE" in result, \
        "completion directive missing from success trailer"


def test_handler_bypass_saves_mbr_stub_with_warnings():
    """skip_preflight_gate=True on MBR stub must save + include M-prefix
    warnings in the bypass preamble."""
    bypass_stub = dict(MBR_STUB_SPEC)
    bypass_stub["filename"] = "test_mbr_bypass_save"
    result = artifact_xlsx._tool_handler(bypass_stub, "rebecca-mbr", None,
                                         skip_preflight_gate=True)
    first_line = result.split("\n", 1)[0]
    assert first_line.startswith("__TAVERNOS_DELIVERABLE__\t"), \
        f"bypass should save; got: {first_line!r}"
    assert "Preflight gate bypassed" in result, \
        "bypass save missing warning preamble"
    assert "preflight M" in result, \
        f"bypass warning should list M-prefix MBR issues, got:\n{result}"


def test_filter_mbr_stub_returns_M_issues():
    """MBR stub (empty revenue + costs) must produce M2. M3 must NOT fire —
    no rows means no material variances to check for commentary against."""
    issues = artifact_xlsx._rubric_critical_issues(MBR_STUB_SPEC)
    assert issues, "MBR stub spec should produce critical issues"
    assert any(i.startswith("preflight M2") for i in issues), \
        f"expected M2 (no revenue/cost rows) in issues, got: {issues}"
    assert not any(i.startswith("preflight M3") for i in issues), \
        f"M3 fired but stub has no rows to compute variances: {issues}"


def test_filter_mbr_variance_no_commentary_returns_M3():
    """MBR with material variance but no commentary must produce M3
    specifically (not M2 — rows are present)."""
    issues = artifact_xlsx._rubric_critical_issues(
        MBR_MATERIAL_VARIANCE_NO_COMMENTARY_SPEC)
    assert issues, "MBR with variance-no-commentary should produce critical issues"
    assert any(i.startswith("preflight M3") for i in issues), \
        f"expected M3 (variance commentary gap) in issues, got: {issues}"
    assert not any(i.startswith("preflight M2") for i in issues), \
        f"M2 fired but revenue rows are present: {issues}"


# ═══════════════════════════════════════════════════════════════════════════════
#  CONTRACT 14 — xlsx builder code-path coverage (session 11 priority 1).
#
#  Session 10 surfaced two latent xlsx builder bugs (GREY undefined, _font
#  italic kwarg missing) that lived in the TBD-placeholder branch at
#  artifact_xlsx.py line ~817-831. That branch is only reachable when
#  commentary is absent AND material variance is present AND preflight is
#  bypassed — a conjunction that no Contract 13 fixture exercises (MBR_STUB
#  has no rows → no variance; MBR_VARIANCE_NO_COMMENTARY gets rejected at
#  M3; MBR_COMPLETE supplies commentary, so the other branch fires).
#
#  Contract 14 closes the reachability gap for the TBD branch plus pins
#  the three formula-guard helpers (_looks_like_unequals_formula,
#  _check_formula G1/G2/G3) which had zero Tier 0 coverage, plus adds a
#  direct regression-pin on _font(italic=True) so a future refactor of
#  the styling helpers can't silently drop the kwarg again.
#
#  Coverage targets (session 11 audit):
#  - gap 1: _looks_like_unequals_formula           → regex positive/negative
#  - gap 2: _check_formula G1 (missing '=')        → warning list non-empty
#           _check_formula G2 (unknown sheet)      → warning mentions sheet
#           _check_formula G3 (out-of-range row)   → warning mentions row
#  - gap 3: _font(italic=True)                     → returns Font w/ italic
#  - gap 4: _build_monthly_business_review else    → bypass-save TBD path
# ═══════════════════════════════════════════════════════════════════════════════


def test_looks_like_unequals_formula_positive_and_negative():
    """Regex pins: SUM(...) as bare string trips, '=SUM(...)' does not,
    plain prose does not. Catches the 'agent forgot the equals sign'
    failure mode that _check_formula G1 also guards against."""
    # Positive — bare function call that looks like a formula
    assert artifact_xlsx._looks_like_unequals_formula("SUM(A1:A5)") is True, \
        "bare SUM(...) should trip the formula-smell regex"
    # Positive — bare range reference
    assert artifact_xlsx._looks_like_unequals_formula("Sheet1!A1:B5") is True, \
        "bare cross-sheet range should trip the formula-smell regex"
    # Negative — legitimate formula with leading '='
    assert artifact_xlsx._looks_like_unequals_formula("=SUM(A1:A5)") is False, \
        "leading '=' should short-circuit the regex"
    # Negative — plain prose
    assert artifact_xlsx._looks_like_unequals_formula("March revenue notes") is False, \
        "plain prose should not trip the regex"


def test_check_formula_flags_string_without_equals():
    """G1: formula string that doesn't start with '=' must produce a
    warning that will land in result['warnings'] for the evaluator to see."""
    warnings = artifact_xlsx._check_formula("SUM(A1:A10)", {"Sheet1": 10})
    assert warnings, "G1 should produce a warning for non-'=' formula"
    assert any("does not start with '='" in w for w in warnings), \
        f"G1 warning text should mention missing '=', got: {warnings}"


def test_check_formula_flags_unknown_sheet():
    """G2: cross-sheet reference to a sheet not in sheet_extents must
    produce a warning naming the unknown sheet."""
    warnings = artifact_xlsx._check_formula(
        "=OtherSheet!A1", {"Summary": 10, "Revenue": 5})
    assert warnings, "G2 should produce a warning for unknown sheet"
    assert any("OtherSheet" in w for w in warnings), \
        f"G2 warning should name the unknown sheet, got: {warnings}"


def test_check_formula_flags_out_of_range_row():
    """G3: cell reference beyond the written row extent must warn. Guard
    allows 5 rows of slack for SUM-through-blank idioms, so row 50 against
    extent 10 must trip (45 rows past extent, far outside slack)."""
    warnings = artifact_xlsx._check_formula("=A50", {"Summary": 10})
    assert warnings, "G3 should produce a warning for out-of-range row"
    assert any("row 50" in w or "50" in w for w in warnings), \
        f"G3 warning should cite the out-of-range row, got: {warnings}"


def test_check_formula_clean_formula_produces_no_warnings():
    """Negative control: a well-formed formula referencing a valid sheet
    at an in-range row must produce zero warnings. Pins that the guards
    don't over-fire on the happy path."""
    warnings = artifact_xlsx._check_formula("=SUM(Summary!A1:A5)", {"Summary": 10})
    assert warnings == [], \
        f"clean formula should produce zero warnings, got: {warnings}"


def test_font_accepts_italic_true_and_preserves_defaults():
    """Direct regression pin on the session-10 _font fix. The TBD-
    placeholder call at line ~826 does _font(size=10, italic=True,
    color=GREY); if a future refactor drops the italic kwarg, _font
    will crash with TypeError before the test even asserts — which
    is itself the regression signal we want."""
    # Primary assertion — italic kwarg accepted + propagated
    f = artifact_xlsx._font(size=10, italic=True, color=artifact_xlsx.GREY)
    assert f.italic is True, "italic=True should propagate to Font object"
    assert f.size == 10, "size kwarg should propagate"
    # Default kwarg preserved for non-italic callers
    f_default = artifact_xlsx._font(size=12)
    assert f_default.italic is False, \
        "default italic should remain False for existing callers"


# Fixture variant: complete revenue/cost data (identical to MBR_VARIANCE_NO_COMMENTARY)
# but routed through skip_preflight_gate=True so the builder actually
# renders. The M3 gate otherwise rejects before the builder runs.
MBR_VARIANCE_NO_COMMENTARY_BYPASS_SPEC = {
    "artifact": "xlsx",
    "template": "monthly_business_review",
    "filename": "test_mbr_tbd_commentary_stubs",
    "category": "reports",
    "meta": {"client_name": "Acme Corp", "period": "March 2026",
             "prepared_by": "Rebecca / TavernOS"},
    "revenue": {"rows": [
        {"month": "Jan 2026", "actual": 380000, "plan": 400000},
        {"month": "Feb 2026", "actual": 395000, "plan": 420000},
        {"month": "Mar 2026", "actual": 412000, "plan": 448000},
    ]},
    "costs": {"rows": [
        {"month": "Jan 2026", "cogs": 80000, "opex": 220000,
         "plan_cogs": 85000, "plan_opex": 215000},
        {"month": "Feb 2026", "cogs": 82000, "opex": 230000,
         "plan_cogs": 85000, "plan_opex": 225000},
        {"month": "Mar 2026", "cogs": 88000, "opex": 245000,
         "plan_cogs": 85000, "plan_opex": 230000},
    ]},
    # commentary deliberately absent — triggers the TBD-placeholder branch
    # inside the builder when preflight is bypassed.
}


def test_mbr_builder_renders_tbd_commentary_stubs_on_bypass():
    """Closes the exact coverage gap that let GREY + italic ship latent.

    The TBD-placeholder branch in _build_monthly_business_review fires
    only when commentary_entries is empty AND material_variances is
    non-empty. No session-10 fixture reaches this branch in a way that
    runs the builder — the M3 gate rejects first. This test routes
    around M3 with skip_preflight_gate=True, exercising the branch that
    referenced GREY (line 76) and called _font(italic=True) (line 826).

    If either fix regresses, this test either crashes with NameError
    (GREY undefined) or TypeError (italic kwarg), both of which surface
    as a test-runner 'raised' failure. That's the session-10 bug's
    original failure shape — exactly what we want to catch at Tier 0."""
    result = artifact_xlsx._tool_handler(
        MBR_VARIANCE_NO_COMMENTARY_BYPASS_SPEC, "rebecca-mbr", None,
        skip_preflight_gate=True)
    first_line = result.split("\n", 1)[0]
    assert first_line.startswith("__TAVERNOS_DELIVERABLE__\t"), \
        f"bypass save should produce DELIVERABLE_SENTINEL, got: {first_line!r}"
    parts = first_line.split("\t")
    assert len(parts) >= 4, f"sentinel header malformed: {parts}"
    path = Path(parts[2])
    assert path.is_absolute(), \
        f"expected absolute path from temp-workspace resolver, got: {path}"
    assert path.exists(), f"handler reported save but file missing: {path}"
    assert path.stat().st_size > 5000, \
        f"saved file suspiciously small: {path.stat().st_size} bytes"
    # Bypass preamble should be present since we bypassed the gate.
    assert "Preflight gate bypassed" in result, \
        "bypass save missing warning preamble"


# ═══════════════════════════════════════════════════════════════════════════════
#  CONTRACT 15 — pptx builder code-path coverage (session 11 priority 1).
#
#  Session 10 shipped Contract 12 with four tests that cover title/content/
#  closing (populated) + content (empty-bullet TBD) + section. Three slide
#  types remain completely dark to Tier 0:
#
#    _render_kpis      — entire function (populated + empty-TBD branches)
#    _render_table     — entire function (populated + empty-TBD branches)
#    _render_closing   — empty-bullet TBD branch (populated is covered by
#                        DECK_COMPLETE_SPEC's closing slide)
#    _set_notes        — with non-empty text (early-return is covered by
#                        most fixtures omitting 'notes')
#
#  These are the four renderers in _SLIDE_RENDERERS that a spec could use
#  without any existing Tier 0 fixture exercising them. Rebecca could
#  produce a deck with kpis or table slides today — both slide types are
#  in _VALID_SLIDE_TYPES — and the first exercise would be production.
#
#  Contract 15 closes these gaps with the same mechanism-level posture as
#  Contract 12: assert save succeeds + file has non-trivial size. Speaker
#  notes get a slightly deeper check (load back + verify notes text
#  landed on the right slide) because notes is a scored rubric dim and
#  readback is cheap.
# ═══════════════════════════════════════════════════════════════════════════════


def _pptx_deck_spec_with_slides(filename: str, extra_slides: list[dict]) -> dict:
    """Helper: build a minimum-valid deck spec (title + content + closing)
    with caller-supplied extra slides inserted before the closing slide.
    Keeps each Contract 15 test from duplicating the boilerplate meta +
    title + closing anchor. Not a production helper — only used by
    Contract 15 tests."""
    return {
        "artifact": "pptx",
        "template": "executive_review_deck",
        "filename": filename,
        "category": "reports",
        "meta": {"title": "Test Deck", "client_name": "Acme Corp",
                 "prepared_by": "Rebecca / TavernOS"},
        "slides": [
            {"type": "title", "title": "Test Deck", "subtitle": "Q1 2026"},
            {"type": "content", "title": "Context",
             "bullets": ["first point", "second point"]},
            *extra_slides,
            {"type": "closing", "title": "Asks",
             "bullets": ["ask one", "ask two"]},
        ],
    }


def _assert_pptx_saved(result: str, min_size: int = 15000) -> Path:
    """Helper: parse a tool_handler result, assert the file exists and has
    non-trivial size, return the Path. Mirrors the inline logic in
    Contract 12 so Contract 15 tests stay focused on what they're proving.

    Session 12 priority 1 sub-item 1: ~/.tavernos fallback removed. The
    setup_temp_workspace resolver routes all pptx saves to the temp
    deliverables dir; the handler's returned path is absolute."""
    first_line = result.split("\n", 1)[0]
    assert first_line.startswith("__TAVERNOS_DELIVERABLE__\t"), \
        f"expected DELIVERABLE_SENTINEL first line, got: {first_line!r}"
    parts = first_line.split("\t")
    assert len(parts) >= 4, f"sentinel header malformed: {parts}"
    path = Path(parts[2])
    assert path.is_absolute(), \
        f"expected absolute path from temp-workspace resolver, got: {path}"
    assert path.exists(), f"handler reported save but file missing: {path}"
    assert path.stat().st_size > min_size, \
        f"saved file suspiciously small: {path.stat().st_size} bytes"
    return path


def test_pptx_builder_renders_kpis_slide_populated():
    """Exercises _render_kpis populated branch — tile layout math, per-KPI
    value/label/delta rendering. If the tile-width arithmetic at line ~334
    silently returns a negative width, python-pptx raises during shape
    placement and the save crashes. skip_preflight_gate because a 4-slide
    deck trips D2 (<5 slides)."""
    spec = _pptx_deck_spec_with_slides(
        "test_pptx_kpis_populated",
        [{"type": "kpis", "title": "Q1 highlights", "kpis": [
            {"value": "$1.4M", "label": "Q1 ARR", "delta": "+8% vs plan"},
            {"value": "124%", "label": "NRR", "delta": "+6pp YoY"},
            {"value": "38%", "label": "DAU/MAU"},
        ]}])
    result = artifact_pptx._tool_handler(spec, "rebecca-deck", None,
                                         skip_preflight_gate=True)
    _assert_pptx_saved(result)


def test_pptx_builder_renders_kpis_slide_empty_tbd():
    """Exercises _render_kpis empty-TBD branch at line ~324. Empty kpis
    list means the for-loop is skipped and the TBD text box is the only
    content. bypass because a 4-slide deck trips D2."""
    spec = _pptx_deck_spec_with_slides(
        "test_pptx_kpis_empty_tbd",
        [{"type": "kpis", "title": "Metrics (pending)", "kpis": []}])
    result = artifact_pptx._tool_handler(spec, "rebecca-deck", None,
                                         skip_preflight_gate=True)
    _assert_pptx_saved(result)


def test_pptx_builder_renders_table_slide_populated():
    """Exercises _render_table populated branch — the most complex renderer
    in the module (native pptx table construction, header row styling,
    zebra striping, column derivation from first row's keys)."""
    spec = _pptx_deck_spec_with_slides(
        "test_pptx_table_populated",
        [{"type": "table", "title": "Segment breakdown", "rows": [
            {"segment": "Enterprise", "actual": "$3.2M", "plan": "$3.5M"},
            {"segment": "Mid-market", "actual": "$1.8M", "plan": "$1.6M"},
            {"segment": "SMB",        "actual": "$420K", "plan": "$480K"},
        ]}])
    result = artifact_pptx._tool_handler(spec, "rebecca-deck", None,
                                         skip_preflight_gate=True)
    _assert_pptx_saved(result)


def test_pptx_builder_renders_table_slide_empty_tbd():
    """Exercises _render_table empty-TBD branch at line ~386. Empty rows +
    no columns list means TBD text renders instead of the table."""
    spec = _pptx_deck_spec_with_slides(
        "test_pptx_table_empty_tbd",
        [{"type": "table", "title": "Segment breakdown (pending)", "rows": []}])
    result = artifact_pptx._tool_handler(spec, "rebecca-deck", None,
                                         skip_preflight_gate=True)
    _assert_pptx_saved(result)


def test_pptx_builder_renders_closing_tbd_when_bullets_empty():
    """Exercises _render_closing empty-bullet TBD branch at line ~454.
    DECK_COMPLETE_SPEC's closing slide has populated bullets, so this
    branch is dark without an explicit fixture. Replace the default
    closing with an empty-bullet one; 5-slide deck so D2 doesn't fire,
    but D4 closing-type check is satisfied."""
    spec = {
        "artifact": "pptx",
        "template": "executive_review_deck",
        "filename": "test_pptx_closing_empty_tbd",
        "category": "reports",
        "meta": {"title": "Test Deck", "client_name": "Acme Corp",
                 "prepared_by": "Rebecca / TavernOS"},
        "slides": [
            {"type": "title", "title": "Test Deck", "subtitle": "Q1 2026"},
            {"type": "content", "title": "One",
             "bullets": ["a", "b"]},
            {"type": "content", "title": "Two",
             "bullets": ["c", "d"]},
            {"type": "content", "title": "Three",
             "bullets": ["e", "f"]},
            {"type": "closing", "title": "Asks (to be filled)", "bullets": []},
        ],
    }
    # Empty-bullet closing would trip D3-like "thin content" posture, so
    # bypass the gate regardless — we're testing the renderer, not the gate.
    result = artifact_pptx._tool_handler(spec, "rebecca-deck", None,
                                         skip_preflight_gate=True)
    _assert_pptx_saved(result)


def test_pptx_builder_attaches_speaker_notes():
    """Speaker notes is a scored rubric dim (0.15 weight per evaluator
    RUBRIC_EXECUTIVE_REVIEW_DECK). _set_notes with non-empty text is not
    exercised by Contract 12 fixtures. Save, then load the file back with
    python-pptx and assert the notes text landed on the expected slide."""
    from pptx import Presentation  # lazy import — only needed in this test

    notes_text = "Open with the variance story; keep pricing discussion for Q3."
    spec = _pptx_deck_spec_with_slides(
        "test_pptx_speaker_notes",
        [{"type": "content", "title": "Narrative spine",
          "bullets": ["point one", "point two"],
          "notes": notes_text}])
    result = artifact_pptx._tool_handler(spec, "rebecca-deck", None,
                                         skip_preflight_gate=True)
    path = _assert_pptx_saved(result)

    # Load back + verify notes attached to the extra slide (index 2:
    # [title, content, extra-content-with-notes, closing])
    prs = Presentation(str(path))
    target_slide = prs.slides[2]
    assert target_slide.has_notes_slide, \
        "slide with notes in spec should have notes_slide attached after build"
    notes_content = target_slide.notes_slide.notes_text_frame.text
    assert notes_text in notes_content, \
        f"expected notes text in slide 2's notes_slide, got: {notes_content!r}"


# ═══════════════════════════════════════════════════════════════════════════════
#  CONTRACT 16 — bypass preamble wording pins (session 11 priority 2).
#
#  Session-10 Rebecca-Deck Meridian QBR Tier 2 runs produced 2-3 saves per
#  run because the previous bypass preamble framed the issue list as an
#  implied to-do and added only a soft "do not immediately retry" caveat.
#  Session 11 priority 2 rewrites the preamble to lead with the stop-
#  command ("TASK COMPLETE — do not invoke generate_<tool> again for this
#  task"), name the retry misconception explicitly ("a retry produces a
#  second file, not a revision"), and reframe the issue list as evaluator
#  context.
#
#  Contract 16 pins the new wording at Tier 0 so a future refactor can't
#  silently soften it back to the session-10 shape. Each test hits
#  _format_bypass_warning_lines directly with a synthetic critical_issues
#  list and asserts the three load-bearing tokens are present plus the
#  session-10 tokens that Contracts 12/13 already rely on remain present.
# ═══════════════════════════════════════════════════════════════════════════════


def test_pptx_bypass_preamble_contains_stop_command_tokens():
    """pptx bypass preamble must contain the three session-11 load-bearing
    tokens (stop-command, explicit tool-name reference, retry-misconception
    callout) AND the two session-10 tokens Contract 12 depends on
    (gate-bypassed signal, preflight-D prefix pass-through)."""
    issues = ["preflight D2 — deck has 3 slides; rubric expects 5+",
              "preflight D4 — no closing-type slide found"]
    preamble = "\n".join(artifact_pptx._format_bypass_warning_lines(issues))

    # Session 11 tokens — NEW, load-bearing for the multi-save fix.
    assert "TASK COMPLETE" in preamble, \
        "pptx bypass preamble must lead with TASK COMPLETE stop-signal"
    assert "do not invoke generate_pptx_deck again" in preamble, \
        "pptx bypass preamble must name the exact tool to stop invoking"
    assert "second file, not a revision" in preamble, \
        "pptx bypass preamble must name the retry-misconception directly"

    # Session 10 tokens — Contract 12 test_handler_bypass_saves_deck_stub_
    # with_warnings depends on both of these remaining present.
    assert "Preflight gate bypassed" in preamble, \
        "pptx bypass preamble must keep the session-10 gate-bypassed signal"
    assert "preflight D2" in preamble, \
        "critical_issues list must still be extended into the preamble body"


def test_xlsx_bypass_preamble_contains_stop_command_tokens():
    """xlsx bypass preamble must contain the three session-11 load-bearing
    tokens plus the two session-10 tokens Contract 13 depends on. Parallel
    to the pptx test — text shape must stay in sync across both modules
    even though MBR didn't show the session-10 multi-save pattern."""
    issues = ["preflight M2 — no revenue or cost rows",
              "preflight M3 — material variance without commentary"]
    preamble = "\n".join(artifact_xlsx._format_bypass_warning_lines(issues))

    # Session 11 tokens — NEW, parallel-text pin.
    assert "TASK COMPLETE" in preamble, \
        "xlsx bypass preamble must lead with TASK COMPLETE stop-signal"
    assert "do not invoke generate_xlsx_report again" in preamble, \
        "xlsx bypass preamble must name the exact tool to stop invoking"
    assert "second file, not a revision" in preamble, \
        "xlsx bypass preamble must name the retry-misconception directly"

    # Session 10 tokens — Contract 13 test_handler_bypass_saves_mbr_stub_
    # with_warnings depends on both of these remaining present.
    assert "Preflight gate bypassed" in preamble, \
        "xlsx bypass preamble must keep the session-10 gate-bypassed signal"
    assert "preflight M2" in preamble, \
        "critical_issues list must still be extended into the preamble body"


# ═══════════════════════════════════════════════════════════════════════════════
#  CONTRACT 17 — agent-dict slug keying + tool-gating slug derivation
#                (session 11 priority 3).
#
#  Session-10 Rebecca split ("rebecca" → rebecca-mbr + rebecca-deck) introduced
#  three production-CLI bugs that no measurement in session 10 or session 11
#  priority 1/2 surfaced:
#
#    Finding 1: agents dict keyed by a.get("name", f.stem).lower() collapsed
#               both Rebecca JSONs onto key "rebecca" — second-loaded file
#               silently overwrote the first.
#
#    Finding 2: execute_plan's agents.get(slug) for "rebecca-mbr"/"rebecca-deck"
#               missed (dict was name-keyed) and fell through to norm. Plan
#               banner said [REBECCA-DECK]; thinking indicator said "Norm is…";
#               response was narrative-only with no file save.
#
#    Finding 3: call_execute_streaming's agent_name derived from name.lower()
#               = "rebecca", which missed the slug-keyed
#               ALLOWED_AGENTS = {"rebecca-mbr"} / {"rebecca-deck"} sets in
#               artifact_{xlsx,pptx}.py. Rebecca got zero first-party tools
#               in production CLI even if finding 2 hadn't intercepted first.
#
#  Session 11 priority 3 fix:
#    - Load loop keys by slug (or f.stem fallback), not name.
#    - call_execute_streaming splits agent_display_name / agent_display_key /
#      agent_slug; tool-gating + skill-loading use slug, display maps use
#      display key.
#    - /rebecca CLI handler adds name-based fallback with merged-card render.
#
#  Contract 17 pins each of the three mechanism-level fixes at Tier 0. None
#  of these tests require real agent JSON files on disk — they exercise the
#  logic shapes directly. The manual CLI spot-check script (priority 3 close)
#  covers end-to-end production-CLI behavior which Tier 0 can't reach.
# ═══════════════════════════════════════════════════════════════════════════════


def test_agents_dict_keys_by_slug_not_name():
    """Finding 1 regression pin. Simulates the session-11 load-loop key
    derivation with two Rebecca-shaped JSONs sharing name='Rebecca' but
    distinct slugs. Pre-fix both collapsed to key 'rebecca'. Post-fix
    both get distinct keys and no collision occurs. Also pins non-Rebecca
    agents still key correctly (slug == f.stem == name.lower() for them)."""
    agents = {}
    # Rebecca split — same name, different slugs. This is the bug shape.
    rebecca_mbr = {"name": "Rebecca", "slug": "rebecca-mbr",
                   "skills": ["spreadsheet-analyst", "kpi-tracker"]}
    rebecca_deck = {"name": "Rebecca", "slug": "rebecca-deck",
                    "skills": ["deck-builder", "executive-review-deck"]}
    # Non-Rebecca — canonical case where name.lower() and slug match.
    woody = {"name": "Woody", "slug": "woody", "skills": ["proposal-writer"]}

    # Post-fix key derivation: slug wins, f.stem is the fallback.
    for a, stem in [(rebecca_mbr, "rebecca-mbr"),
                    (rebecca_deck, "rebecca-deck"),
                    (woody, "woody")]:
        agents[(a.get("slug") or stem).lower()] = a

    # Both Rebeccas present with their own keys
    assert "rebecca-mbr" in agents, \
        "slug-keyed dict must expose rebecca-mbr key (was collapsed to 'rebecca' pre-fix)"
    assert "rebecca-deck" in agents, \
        "slug-keyed dict must expose rebecca-deck key (was collapsed to 'rebecca' pre-fix)"
    # Neither Rebecca's data was lost to overwrite
    assert agents["rebecca-mbr"]["skills"] == ["spreadsheet-analyst", "kpi-tracker"]
    assert agents["rebecca-deck"]["skills"] == ["deck-builder", "executive-review-deck"]
    # The collapsed name-key must NOT exist — its presence would mean the
    # old logic snuck back in.
    assert "rebecca" not in agents, \
        "name-collapsed 'rebecca' key must NOT appear; dict must be slug-keyed"
    # Non-Rebecca agent keyed the same way it always was
    assert "woody" in agents
    assert agents["woody"]["name"] == "Woody"


def test_agent_slug_derivation_prefers_slug_over_name():
    """Finding 3 regression pin (part 1 — the derivation logic).
    call_execute_streaming derives agent_slug for tool/skill gating via
    `(agent.get('slug') or agent.get('name', 'norm')).lower()`. Rebecca
    agents have slug != name.lower(); non-Rebecca agents have matching
    values. Pin both shapes plus the slug-missing fallback."""
    # Rebecca case — slug != name.lower(). Slug must win.
    rebecca_mbr = {"name": "Rebecca", "slug": "rebecca-mbr"}
    slug_mbr = (rebecca_mbr.get("slug") or rebecca_mbr.get("name", "norm")).lower()
    assert slug_mbr == "rebecca-mbr", \
        "slug 'rebecca-mbr' must win over name 'Rebecca' for agent_slug"

    rebecca_deck = {"name": "Rebecca", "slug": "rebecca-deck"}
    slug_deck = (rebecca_deck.get("slug") or rebecca_deck.get("name", "norm")).lower()
    assert slug_deck == "rebecca-deck", \
        "slug 'rebecca-deck' must win over name 'Rebecca' for agent_slug"

    # Non-Rebecca case — slug == name.lower(). Either source yields same key.
    woody = {"name": "Woody", "slug": "woody"}
    slug_woody = (woody.get("slug") or woody.get("name", "norm")).lower()
    assert slug_woody == "woody", \
        "matching slug/name agents produce slug-lowercased key unchanged"

    # Slug-missing case — old-schema agent JSON with no slug field must
    # fall back to name.lower() without raising.
    no_slug = {"name": "Someone"}
    slug_fallback = (no_slug.get("slug") or no_slug.get("name", "norm")).lower()
    assert slug_fallback == "someone", \
        "missing slug must fall back to name.lower()"

    # Both missing — final fallback to "norm" (hardcoded default).
    empty = {}
    slug_default = (empty.get("slug") or empty.get("name", "norm")).lower()
    assert slug_default == "norm", "both missing must default to 'norm'"


def test_first_party_tools_resolve_for_rebecca_slugs():
    """Finding 3 regression pin (part 2 — the functional outcome).
    _first_party_tools_for_agent checks `agent_lower in entry['allowed_agents']`.
    ALLOWED_AGENTS in artifact_xlsx.py is {"rebecca-mbr"} and in
    artifact_pptx.py is {"rebecca-deck"} (session 10). Passing the slug
    must resolve to the tool schema; passing the name-collapsed "rebecca"
    must resolve to NOTHING — that's the bug shape the slug fix eliminates."""
    # The artifact modules auto-register their tools at import time. Verify
    # the tool registry contains both entries before asserting resolution.
    assert "generate_xlsx_report" in norm.FIRST_PARTY_TOOLS, \
        "artifact_xlsx should have auto-registered generate_xlsx_report in norm.FIRST_PARTY_TOOLS"
    assert "generate_pptx_deck" in norm.FIRST_PARTY_TOOLS, \
        "artifact_pptx should have auto-registered generate_pptx_deck in norm.FIRST_PARTY_TOOLS"

    # Positive: slug-keyed resolution returns the gated tool.
    xlsx_tools = norm._first_party_tools_for_agent("rebecca-mbr")
    assert any(t["name"] == "generate_xlsx_report" for t in xlsx_tools), \
        f"rebecca-mbr slug should resolve to generate_xlsx_report, got: {[t['name'] for t in xlsx_tools]}"

    pptx_tools = norm._first_party_tools_for_agent("rebecca-deck")
    assert any(t["name"] == "generate_pptx_deck" for t in pptx_tools), \
        f"rebecca-deck slug should resolve to generate_pptx_deck, got: {[t['name'] for t in pptx_tools]}"

    # Negative: the name-collapsed "rebecca" must NOT resolve to either
    # Rebecca tool. If it did, the name-based lookup would be working AND
    # the slug-based lookup would be working — double-binding would be a
    # hidden failure mode that could mask future mistakes.
    collapsed_tools = norm._first_party_tools_for_agent("rebecca")
    collapsed_names = {t["name"] for t in collapsed_tools}
    assert "generate_xlsx_report" not in collapsed_names, \
        "name-collapsed 'rebecca' must NOT resolve to generate_xlsx_report"
    assert "generate_pptx_deck" not in collapsed_names, \
        "name-collapsed 'rebecca' must NOT resolve to generate_pptx_deck"


# ═══════════════════════════════════════════════════════════════════════════════
#  CONTRACT 16 EXTENSION — docx bypass preamble wording pins (session 12).
#
#  Session 11 Contract 16 pinned the three load-bearing tokens on pptx + xlsx:
#    - "TASK COMPLETE"
#    - "do not invoke <tool_name> again"
#    - "second file, not a revision"
#
#  Session 12 priority 1 sub-item 3 harmonized docx to the same wording via
#  artifact_gate.format_bypass_warning_lines. Pre-session-12 docx carried
#  the session-5 "save succeeded with known gaps; do not immediately retry"
#  framing — the same framing that caused the Meridian QBR multi-save
#  regression on pptx before session-11 rewrote it. This extension pins
#  the Contract 16 token set on docx so any future silent softening of
#  the shared formatter in artifact_gate fails here first.
# ═══════════════════════════════════════════════════════════════════════════════


def test_docx_bypass_preamble_contains_stop_command_tokens():
    """docx bypass preamble — must carry the Contract 16 token set
    (session 11 pptx + xlsx pins, session 12 extension to docx).

    Load-bearing tokens:
      - "TASK COMPLETE" — mirrors the success-trailer's stop-command
      - "do not invoke generate_docx_report again" — exact tool name
      - "second file, not a revision" — names the retry misconception

    Plus the session-10 tokens Contracts 12/13 depend on:
      - "Preflight gate bypassed" — preamble marker
      - "preflight A" — issue-prefix surface for operational_audit

    If this test breaks, artifact_gate.format_bypass_warning_lines has
    drifted. Do not soften without extending this contract first."""
    lines = artifact_docx._format_bypass_warning_lines(["preflight A2"])
    text = "\n".join(lines)
    assert "TASK COMPLETE" in text, \
        f"missing TASK COMPLETE lead in docx bypass preamble:\n{text}"
    assert "do not invoke generate_docx_report again" in text, \
        f"missing exact stop-command for generate_docx_report:\n{text}"
    assert "second file, not a revision" in text, \
        f"missing second-file-not-revision token:\n{text}"
    assert "Preflight gate bypassed" in text, \
        f"missing session-10 preamble marker:\n{text}"
    assert "preflight A" in text, \
        f"missing preflight issue surface:\n{text}"


# ═══════════════════════════════════════════════════════════════════════════════
#  CONTRACT 19 — auto-link on tool-handler save (session 12 priority 1
#  sub-item 2). Successful first-party saves must stamp
#  client.json["latest_<template>_path"] with the saved file's path.
#
#  Coverage matrix:
#    - operational_audit  (docx, Lilith)
#    - client_proposal    (docx, Woody)
#    - research_report    (docx, Cliff)
#    - executive_review_deck  (pptx, Rebecca-Deck)
#    - monthly_business_review (xlsx, Rebecca-MBR)
#
#  Plus two behavior pins:
#    - bypass saves also auto-link (file is real, downstream chains need path)
#    - second save of same template overwrites the key (latest = latest)
#
#  The setup_temp_workspace rewrite (session 12 sub-item 1) patches
#  norm.CLIENTS_DIR onto tmp, so these tests read/write client.json
#  entirely inside the temp workspace with no ~/.tavernos leak.
# ═══════════════════════════════════════════════════════════════════════════════


def _read_client_manifest() -> dict:
    """Helper: read the _self client's manifest as a plain dict. Goes
    through norm.client_load_manifest so the test exercises the same
    path the production auto-link uses."""
    return norm.client_load_manifest() or {}


def _clear_autolink_keys() -> None:
    """Helper: strip all latest_*_path keys from _self's manifest so
    each Contract 19 test starts from a known state. Doesn't remove the
    manifest file (keeps client scaffold intact)."""
    manifest = _read_client_manifest()
    stripped = {k: v for k, v in manifest.items()
                if not k.startswith("latest_")}
    # Also strip last_active so the no-op-skip branch of
    # _auto_link_deliverable has a clean baseline.
    stripped.pop("last_active", None)
    norm.client_save_manifest(stripped)


def test_autolink_docx_client_proposal_writes_latest_path():
    """Complete client_proposal save → client.json has
    latest_client_proposal_path pointing at the saved file."""
    _clear_autolink_keys()
    # Go through the full dispatcher (not _tool_handler directly) so
    # the 5-field sentinel parse + auto-link wiring is exercised.
    text, banner, is_err = norm._dispatch_first_party_tool(
        "generate_docx_report", CLIENT_PROPOSAL_COMPLETE_SPEC, "woody",
        bypass_gates=False)
    assert is_err is False, f"expected successful save, got is_err=True:\n{text}"
    assert banner is not None, "dispatcher should emit banner on success"
    manifest = _read_client_manifest()
    assert "latest_client_proposal_path" in manifest, \
        f"auto-link did not stamp key; manifest keys: {list(manifest)}"
    stored = manifest["latest_client_proposal_path"]
    assert stored, "auto-link stamped empty value"
    # Stored path should either match the banner's path (if absolute
    # outside workspace) or resolve under the _self deliverables dir.
    assert (stored == banner["path"]
            or "deliverables" in stored), \
        f"stored path neither matches banner nor under deliverables: {stored}"


def test_autolink_docx_operational_audit_writes_latest_path():
    """Complete operational_audit save → latest_operational_audit_path."""
    _clear_autolink_keys()
    text, banner, is_err = norm._dispatch_first_party_tool(
        "generate_docx_report", COMPLETE_SPEC, "lilith", bypass_gates=False)
    assert is_err is False, f"expected successful save:\n{text}"
    manifest = _read_client_manifest()
    assert "latest_operational_audit_path" in manifest, \
        f"auto-link did not stamp key; manifest keys: {list(manifest)}"


def test_autolink_docx_research_report_writes_latest_path():
    """Complete research_report save → latest_research_report_path."""
    _clear_autolink_keys()
    text, banner, is_err = norm._dispatch_first_party_tool(
        "generate_docx_report", RESEARCH_REPORT_COMPLETE_SPEC, "cliff",
        bypass_gates=False)
    assert is_err is False, f"expected successful save:\n{text}"
    manifest = _read_client_manifest()
    assert "latest_research_report_path" in manifest, \
        f"auto-link did not stamp key; manifest keys: {list(manifest)}"


def test_autolink_pptx_executive_review_deck_writes_latest_path():
    """Complete executive_review_deck save →
    latest_executive_review_deck_path."""
    _clear_autolink_keys()
    text, banner, is_err = norm._dispatch_first_party_tool(
        "generate_pptx_deck", DECK_COMPLETE_SPEC, "rebecca-deck",
        bypass_gates=False)
    assert is_err is False, f"expected successful save:\n{text}"
    manifest = _read_client_manifest()
    assert "latest_executive_review_deck_path" in manifest, \
        f"auto-link did not stamp key; manifest keys: {list(manifest)}"


def test_autolink_xlsx_monthly_business_review_writes_latest_path():
    """Complete monthly_business_review save →
    latest_monthly_business_review_path."""
    _clear_autolink_keys()
    text, banner, is_err = norm._dispatch_first_party_tool(
        "generate_xlsx_report", MBR_COMPLETE_SPEC, "rebecca-mbr",
        bypass_gates=False)
    assert is_err is False, f"expected successful save:\n{text}"
    manifest = _read_client_manifest()
    assert "latest_monthly_business_review_path" in manifest, \
        f"auto-link did not stamp key; manifest keys: {list(manifest)}"


def test_autolink_bypass_save_still_writes_latest_path():
    """Bypass-path saves must auto-link too. The file is real and user-
    accessible; downstream chains need the path regardless of preflight
    outcome. The 'latest' convention means most recent save, not most
    recent quality save.

    Uses a pptx stub spec with bypass_gates=True — exercises the exact
    Meridian-shape path that session-11 priority 2 reshaped."""
    _clear_autolink_keys()
    bypass_spec = copy.deepcopy(DECK_STUB_SPEC)
    bypass_spec["filename"] = "test_autolink_bypass_deck"
    text, banner, is_err = norm._dispatch_first_party_tool(
        "generate_pptx_deck", bypass_spec, "rebecca-deck",
        bypass_gates=True)
    assert is_err is False, f"bypass save should succeed:\n{text}"
    assert "Preflight gate bypassed" in text, \
        "bypass preamble missing — wrong code path exercised"
    manifest = _read_client_manifest()
    assert "latest_executive_review_deck_path" in manifest, \
        f"bypass save did NOT auto-link; manifest keys: {list(manifest)}"


def test_autolink_second_save_overwrites_key():
    """Two successive saves of the same template → latest_<template>_path
    reflects the SECOND save's path, not the first."""
    _clear_autolink_keys()
    # First save.
    spec1 = copy.deepcopy(MBR_COMPLETE_SPEC)
    spec1["filename"] = "test_autolink_mbr_first"
    _t, _b, is_err = norm._dispatch_first_party_tool(
        "generate_xlsx_report", spec1, "rebecca-mbr", bypass_gates=False)
    assert is_err is False
    first_stored = _read_client_manifest().get(
        "latest_monthly_business_review_path")
    assert first_stored, "first save did not stamp key"
    # Second save with a distinct filename.
    spec2 = copy.deepcopy(MBR_COMPLETE_SPEC)
    spec2["filename"] = "test_autolink_mbr_second"
    _t, _b, is_err = norm._dispatch_first_party_tool(
        "generate_xlsx_report", spec2, "rebecca-mbr", bypass_gates=False)
    assert is_err is False
    second_stored = _read_client_manifest().get(
        "latest_monthly_business_review_path")
    assert second_stored, "second save did not stamp key"
    assert second_stored != first_stored, \
        (f"second save did not overwrite key — both show {second_stored!r}; "
         "expected latest = latest")
    assert "mbr_second" in second_stored, \
        f"second stored path should reference second filename: {second_stored}"


def test_autolink_normalizes_userdir_relative_path_to_workspace_relative():
    """Production builders emit USER_DIR-relative paths in the sentinel
    (e.g. 'clients/_self/deliverables/audits/foo.docx'), computed via
    final_path.relative_to(Path.home()/".tavernos") in
    artifact_docx.build_from_spec line ~2010-2014 (and the matching
    blocks in artifact_pptx / artifact_xlsx). _auto_link_deliverable
    must normalize these to workspace-relative before storing in
    client.json so the stored value matches write_deliverable's
    audit_path / voice_profile_path convention ('deliverables/audits/...').

    Session 12a bug fix: the session-12 implementation joined the
    input against `workspace` (not USER_DIR), doubling the <slug>
    segment. relative_to() then stripped one copy of the workspace
    prefix and stored the OTHER copy as the "relative" path — yielding
    'clients/_self/deliverables/...' instead of 'deliverables/...'.
    Downstream consumers doing `client_workspace_path() / stored`
    would have dereferenced to a non-existent doubled path.

    Why the existing seven Contract 19 tests missed this: in-test the
    builder's relative_to(Path.home()/".tavernos") ValueErrors (files
    live under tmp, not ~/.tavernos), so result["path"] is always
    absolute — the buggy non-absolute branch was never exercised.
    This test exercises it directly by calling _auto_link_deliverable
    with a synthesized USER_DIR-relative string matching what
    production actually emits."""
    _clear_autolink_keys()
    # Create a real file so .resolve() has something to anchor on,
    # defensive against a future refactor adding strict=True.
    # setup_temp_workspace already scaffolded the audits/ subdir.
    target = norm.CLIENTS_DIR / "_self" / "deliverables" / "audits" / "s12a_synthetic.docx"
    target.write_bytes(b"x")
    # Input shape matches what artifact_docx.build_from_spec returns
    # in production: USER_DIR-relative with forward slashes.
    userdir_rel = "clients/_self/deliverables/audits/s12a_synthetic.docx"
    norm._auto_link_deliverable("operational_audit", userdir_rel, slug="_self")
    stored = _read_client_manifest().get("latest_operational_audit_path")
    assert stored, "auto-link did not stamp the key"
    # Normalize separators for cross-platform comparison (Windows
    # relative_to returns a path with backslashes).
    normalized = stored.replace("\\", "/")
    # Must NOT start with "clients/" — that's either the raw USER_DIR-
    # relative shape (wrong; should be normalized) or the session-12
    # doubling-bug shape ('clients/_self/deliverables/...').
    assert not normalized.startswith("clients/"), (
        f"stored path is not workspace-relative: {stored!r} — "
        "reintroduces the session-12 doubling bug (see "
        "don't-reintroduce: 'Don't resolve sentinel paths against "
        "workspace instead of USER_DIR')"
    )
    # Must end with the workspace-relative path ending with the file.
    assert normalized.endswith("deliverables/audits/s12a_synthetic.docx"), (
        f"stored path doesn't look workspace-relative: {stored!r}"
    )


# ═══════════════════════════════════════════════════════════════════════════════
#  CONTRACT 20 — deliverable sentinel 5-field format (session 12 priority 1
#  sub-item 2). Extension to __TAVERNOS_DELIVERABLE__ carries template as
#  the 5th tab-delimited field; norm.py's dispatcher parses it defensively
#  and skips auto-link when only 4 fields are present (back-compat).
# ═══════════════════════════════════════════════════════════════════════════════


def test_deliverable_sentinel_has_five_tab_fields():
    """A successful docx save's first line must split into exactly 5
    fields on tab: sentinel-token, filename, path, bytes, template."""
    result = artifact_docx._tool_handler(COMPLETE_SPEC, "lilith", None)
    first_line = result.split("\n", 1)[0]
    parts = first_line.split("\t")
    # parts[0] is the sentinel token itself; fields follow.
    assert len(parts) == 5, \
        (f"expected 5 tab-delimited fields (sentinel + 4 values), "
         f"got {len(parts)}: {parts!r}")
    assert parts[0] == "__TAVERNOS_DELIVERABLE__", \
        f"first field should be sentinel token, got: {parts[0]!r}"


def test_deliverable_sentinel_template_field_matches_spec():
    """The 5th field (parts[4] after split) must equal the spec's
    `template` value verbatim — this is what drives the auto-link key."""
    result = artifact_pptx._tool_handler(DECK_COMPLETE_SPEC,
                                          "rebecca-deck", None)
    first_line = result.split("\n", 1)[0]
    parts = first_line.split("\t")
    assert len(parts) == 5, f"sentinel malformed: {parts}"
    template_field = parts[4]
    assert template_field == DECK_COMPLETE_SPEC["template"], \
        (f"template field should match spec; "
         f"got {template_field!r}, expected {DECK_COMPLETE_SPEC['template']!r}")


def test_dispatcher_skips_autolink_on_four_field_sentinel():
    """Back-compat guard: a handler that emits the legacy 4-field
    sentinel (no template) must NOT trigger auto-link. Protects any
    future first-party tool that hasn't been updated to the 5-field
    contract from silently corrupting client.json with empty-template
    keys."""
    _clear_autolink_keys()
    baseline = _read_client_manifest()
    baseline_keys = {k for k in baseline if k.startswith("latest_")}

    def legacy_handler(args, agent, slug, **kwargs):
        # Four fields: sentinel, filename, path, bytes. No template.
        return "__TAVERNOS_DELIVERABLE__\tlegacy.bin\t/tmp/legacy.bin\t999\nok"

    saved = dict(norm.FIRST_PARTY_TOOLS)
    try:
        norm.FIRST_PARTY_TOOLS["legacy_tool"] = {
            "name": "legacy_tool", "schema": {},
            "allowed_agents": {"norm"}, "handler": legacy_handler,
        }
        _text, _banner, is_err = norm._dispatch_first_party_tool(
            "legacy_tool", {}, "norm", bypass_gates=False)
        assert is_err is False, "legacy handler returned error"
        post = _read_client_manifest()
        post_keys = {k for k in post if k.startswith("latest_")}
        assert post_keys == baseline_keys, \
            (f"legacy 4-field handler triggered auto-link; added keys: "
             f"{post_keys - baseline_keys}")
    finally:
        norm.FIRST_PARTY_TOOLS.clear()
        norm.FIRST_PARTY_TOOLS.update(saved)


# ═══════════════════════════════════════════════════════════════════════════════
#  CONTRACT 21 — artifact_gate module surface (session 12 priority 1
#  sub-item 3). The extracted shared formatters must pin the session-11
#  Contract 16 token set in one place, handle the per-module flavoring
#  kwargs (tool_name, drafted_keeper_line, intro_lines) correctly, and
#  emit a well-formed 5-field deliverable sentinel.
# ═══════════════════════════════════════════════════════════════════════════════


def test_gate_rejection_message_has_sentinel_first_line():
    """format_rejection_message output's first line must be
    REJECTED_SENTINEL so norm.py's dispatcher can intercept + mark
    is_error=True. Template name appears in the body. Issues are
    reproduced verbatim."""
    msg = artifact_gate.format_rejection_message(
        template="operational_audit",
        critical_issues=["preflight A2", "preflight A3"],
        tool_name="generate_docx_report",
        required_sections=("diagnosis", "priorities"),
        drafted_keeper_line="keep your work; just extend it.",
    )
    first_line = msg.split("\n", 1)[0]
    assert first_line == artifact_gate.REJECTED_SENTINEL, \
        f"first line should be REJECTED_SENTINEL, got: {first_line!r}"
    assert "operational_audit" in msg, \
        "template name missing from rejection body"
    assert "preflight A2" in msg and "preflight A3" in msg, \
        "preflight issues not reproduced verbatim"


def test_gate_rejection_message_injects_tool_name():
    """The retry directive must name the tool the agent should call
    again — so the agent sees the exact string it emitted last turn.
    Interpolation is done by the shared formatter, not hard-coded."""
    msg = artifact_gate.format_rejection_message(
        template="monthly_business_review",
        critical_issues=["preflight M2"],
        tool_name="generate_xlsx_report",
        required_sections=(),
        drafted_keeper_line="(unused in this test)",
    )
    assert "generate_xlsx_report" in msg, \
        f"retry directive missing tool name:\n{msg}"
    # And the wrong tool name must NOT appear, so a future swap can't
    # silently break the interpolation.
    assert "generate_docx_report" not in msg, \
        "wrong tool name leaked into output"
    assert "generate_pptx_deck" not in msg, \
        "wrong tool name leaked into output"


def test_gate_rejection_message_injects_drafted_keeper_line():
    """The caller-supplied drafted_keeper_line must appear verbatim as
    the closing line. Session-12 design choice: callers supply the full
    sentence including grammar (docx: 'sections ... do not', pptx:
    'slides ... do not', xlsx: 'data ... does not') because noun-swap
    alone cannot carry the singular/plural verb shift."""
    sentinel_line = "THE SENTINEL LINE FOR THIS TEST — grep target."
    msg = artifact_gate.format_rejection_message(
        template="client_proposal",
        critical_issues=["preflight P2"],
        tool_name="generate_docx_report",
        required_sections=(),
        drafted_keeper_line=sentinel_line,
    )
    assert sentinel_line in msg, \
        f"drafted_keeper_line not injected verbatim:\n{msg}"


def test_gate_bypass_warning_lines_contain_session11_tokens():
    """The canonical Contract 16 tokens live in one place now —
    artifact_gate.format_bypass_warning_lines. This test pins them
    there so any future cleanup that drops a token fails at the source
    of truth, before the module wrappers propagate the drift."""
    lines = artifact_gate.format_bypass_warning_lines(
        critical_issues=["preflight X1"],
        tool_name="generate_whatever_report",
    )
    text = "\n".join(lines)
    assert "TASK COMPLETE" in text, \
        f"missing TASK COMPLETE lead:\n{text}"
    assert "do not invoke generate_whatever_report again" in text, \
        f"stop-command missing tool-name interpolation:\n{text}"
    assert "second file, not a revision" in text, \
        f"missing second-file-not-revision token:\n{text}"
    assert "Preflight gate bypassed" in text, \
        f"missing preamble marker (session-10 surface):\n{text}"
    assert "preflight X1" in text, \
        f"issue not reproduced verbatim:\n{text}"


def test_gate_builder_warning_lines_lists_all_warnings():
    """Builder warnings must appear bulleted in output. Both default
    intro (docx) and custom intro (xlsx formula-guard) paths must
    emit the full warning list."""
    # Default intro path.
    out_default = artifact_gate.format_builder_warning_lines(
        builder_warnings=["fieldA malformed", "fieldB malformed"],
    )
    default_text = "\n".join(out_default)
    assert "TBD placeholders" in default_text, \
        "default intro should reference TBD placeholders"
    assert "fieldA malformed" in default_text, "warning 1 missing"
    assert "fieldB malformed" in default_text, "warning 2 missing"

    # Custom intro path (xlsx-style).
    out_custom = artifact_gate.format_builder_warning_lines(
        builder_warnings=["formula G2: unknown sheet"],
        intro_lines=(
            "Custom intro line 1",
            "Custom intro line 2",
        ),
    )
    custom_text = "\n".join(out_custom)
    assert "Custom intro line 1" in custom_text, "custom intro dropped"
    assert "TBD placeholders" not in custom_text, \
        "default intro leaked when custom provided"
    assert "formula G2: unknown sheet" in custom_text, \
        "warning missing under custom intro path"


# ═══════════════════════════════════════════════════════════════════════════════
#  CONTRACT 22 — tmp-workspace path discipline (session 12 priority 1
#  sub-item 1). setup_temp_workspace now wires all three module path
#  resolvers; these tests pin that saves land under tmp, not under
#  Path.home() / '.tavernos'. Retires Rule 6.
# ═══════════════════════════════════════════════════════════════════════════════


def test_pptx_save_under_temp_workspace_not_home():
    """A pptx save in the test harness must land under the tmp workspace,
    not under ~/.tavernos. Pins against future regression where the
    resolver wiring is dropped or the test harness loses track of tmp."""
    result = artifact_pptx._tool_handler(DECK_COMPLETE_SPEC,
                                          "rebecca-deck", None)
    first_line = result.split("\n", 1)[0]
    parts = first_line.split("\t")
    assert len(parts) >= 4, f"sentinel malformed: {parts}"
    saved_path = Path(parts[2])
    assert saved_path.is_absolute(), \
        f"expected absolute path from resolver, got: {saved_path}"
    home_tavernos = (Path.home() / ".tavernos").resolve()
    try:
        saved_path.resolve().relative_to(home_tavernos)
    except ValueError:
        pass  # Good — path is outside ~/.tavernos
    else:
        raise AssertionError(
            f"pptx save landed under ~/.tavernos despite resolver wiring: "
            f"{saved_path}")


def test_xlsx_save_under_temp_workspace_not_home():
    """Same pin for xlsx. Paired with the pptx variant above — both must
    stay green for Rule 6 retirement to hold."""
    result = artifact_xlsx._tool_handler(MBR_COMPLETE_SPEC,
                                          "rebecca-mbr", None)
    first_line = result.split("\n", 1)[0]
    parts = first_line.split("\t")
    assert len(parts) >= 4, f"sentinel malformed: {parts}"
    saved_path = Path(parts[2])
    assert saved_path.is_absolute(), \
        f"expected absolute path from resolver, got: {saved_path}"
    home_tavernos = (Path.home() / ".tavernos").resolve()
    try:
        saved_path.resolve().relative_to(home_tavernos)
    except ValueError:
        pass  # Good — path is outside ~/.tavernos
    else:
        raise AssertionError(
            f"xlsx save landed under ~/.tavernos despite resolver wiring: "
            f"{saved_path}")


# ═══════════════════════════════════════════════════════════════════════════════
#  CONTRACT 23 — MBR→Deck chaining consumer-side gate (session 13 priority 1).
#
#  Consumer side of the MBR→Deck chain. Producer side landed session 12
#  (Contract 19 — Rebecca-MBR's save stamps latest_monthly_business_review_
#  path into client.json via _auto_link_deliverable). Session 12a closed
#  the path-format bug so stored values are workspace-relative.
#
#  Three surfaces, two unit-testable here:
#    - _client_context_block extension (norm.py line ~1424): surfaces MBR
#      path alongside voice_path / audit_path when present, silent when
#      absent. Tests 1-2.
#    - _enforce_mbr_context_clarify (pre-call_router): forces mode=CLARIFY
#      on rebecca-deck steps when prompt implies MBR context AND manifest
#      lacks the key. Tests 3-5.
#    - Rebecca-Deck prompt nudge in call_execute_streaming: load-bearing
#      because CLARIFY mode only drops tool_choice forcing; the agent can
#      still invoke its tool voluntarily. Not unit-testable here (agent-
#      side behavior); pinned via Tier 1/Tier 2.
# ═══════════════════════════════════════════════════════════════════════════════


def _setup_non_self_client(slug: str, manifest_extra: dict | None = None) -> None:
    """Scaffold a non-_self client (dir + client.json + active-client
    pointer) so _client_context_block doesn't short-circuit on the
    DEFAULT_CLIENT_SLUG guard at norm.py line ~1419. Tests that call
    _client_context_block MUST pair this with _reset_active_to_self in
    a finally block to avoid leaking a non-_self active-client pointer
    into subsequent tests."""
    ws = norm.CLIENTS_DIR / slug
    (ws / "deliverables").mkdir(parents=True, exist_ok=True)
    (ws / "client.json").write_text("{}", encoding="utf-8")
    base = {"slug": slug, "name": slug.title()}
    if manifest_extra:
        base.update(manifest_extra)
    norm.client_save_manifest(base, slug=slug)
    norm.set_active_client_slug(slug)


def _reset_active_to_self() -> None:
    """Restore _self as active client. Paired with _setup_non_self_client
    in test finally blocks."""
    norm.set_active_client_slug("_self")


_SYNTHETIC_MBR_TRIGGERS = [
    "qbr", "board deck", "board presentation", "board review",
    "exec review", "executive review", "executive review deck",
    "quarterly review", "quarterly business review",
    "quarterly board review",
]


def _patch_mbr_triggers_cache(triggers: list[str]) -> None:
    """Inject synthetic triggers into norm's module-level cache so the
    enforce pass exercises independent of rebecca-deck.json file state.
    AGENTS_DIR is not patched by setup_temp_workspace (production agents
    dir leaks in otherwise). Contract 23 leaves the cache set to the last
    test's value — safe because nothing runs after Contract 23 in the
    manifest order."""
    norm._MBR_CONTEXT_TRIGGERS_CACHE = [t.lower() for t in triggers]


def _clear_mbr_key_on_self() -> None:
    """Strip latest_monthly_business_review_path from _self's manifest."""
    manifest = norm.client_load_manifest() or {}
    manifest.pop("latest_monthly_business_review_path", None)
    norm.client_save_manifest(manifest)


def test_client_context_block_surfaces_mbr_path_when_present():
    """Session 13 priority 1 Edit 1: when the active client's manifest has
    latest_monthly_business_review_path, _client_context_block emits a
    'Latest MBR at: <path>' line parallel to voice_path / audit_path.
    Path is surfaced as stored (workspace-relative per Contract 19/s12a
    — this test also pins that workspace-relative is what the context
    block emits, closing the consumer-side integration gap)."""
    stored = "deliverables/reports/mbr-2026-04.xlsx"
    _setup_non_self_client("ctx-mbr-present", {
        "latest_monthly_business_review_path": stored,
    })
    try:
        block = norm._client_context_block()
    finally:
        _reset_active_to_self()
    assert "Latest MBR at:" in block, (
        f"context block missing 'Latest MBR at:' line. Full block:\n{block}"
    )
    assert stored in block, (
        f"stored path {stored!r} not surfaced in context block. "
        f"Full block:\n{block}"
    )
    # Pin workspace-relative shape — the emitted path must match stored
    # exactly, not an absolute rewrite or a slug-prefixed variant.
    mbr_lines = [line for line in block.splitlines()
                 if line.startswith("Latest MBR at:")]
    assert len(mbr_lines) == 1, (
        f"expected exactly one 'Latest MBR at:' line, got {mbr_lines}"
    )
    emitted = mbr_lines[0].split(":", 1)[1].strip()
    assert emitted == stored, (
        f"emitted path {emitted!r} != stored {stored!r} — "
        "consumer-side integration with Contract 19/s12a broken"
    )


def test_client_context_block_omits_mbr_line_when_absent():
    """Negative guard: manifest without the MBR key produces a context
    block with NO 'Latest MBR at:' line. Mirrors existing voice_path /
    audit_path omission behavior — consistent shape for all three
    manifest-surfaced paths."""
    _setup_non_self_client("ctx-mbr-absent")  # no MBR key
    try:
        block = norm._client_context_block()
    finally:
        _reset_active_to_self()
    assert "Latest MBR at:" not in block, (
        f"context block emitted 'Latest MBR at:' with no key present. "
        f"Full block:\n{block}"
    )


def test_mode_forced_clarify_on_mbr_signal_trigger_when_manifest_lacks_key():
    """Positive case — the whole point of the consumer-side gate.
    Parametrized across every MBR-signal trigger phrase: a rebecca-deck
    step with BOUND mode gets overridden to CLARIFY when the prompt
    contains that trigger and the manifest lacks the MBR key.

    Parametrizing over the full trigger list catches a trigger added to
    rebecca-deck.json's mbr_context_triggers but missed by a future
    substring-match refactor, or vice versa."""
    _clear_mbr_key_on_self()
    _patch_mbr_triggers_cache(_SYNTHETIC_MBR_TRIGGERS)
    for trigger in _SYNTHETIC_MBR_TRIGGERS:
        plan = {
            "steps": [{
                "agent": "rebecca-deck",
                "task": f"build me a {trigger} for Meridian Q4",
                "mode": "BOUND",
            }],
        }
        user_input = f"can you do a {trigger} for Meridian"
        norm._enforce_mbr_context_clarify(plan, user_input)
        assert plan["steps"][0]["mode"] == "CLARIFY", (
            f"trigger {trigger!r} with missing MBR did not force CLARIFY: "
            f"got mode={plan['steps'][0]['mode']!r}"
        )


def test_mode_unchanged_when_non_mbr_trigger():
    """Negative case #1: non-MBR-signal trigger leaves the mode alone.
    Pitch decks, demo-day slide decks, all-hands PowerPoints route to
    rebecca-deck via the main triggers list but are not MBR-dependent,
    so the manifest check + override must not fire. Regression guard
    against an over-broad substring match gating ALL rebecca-deck work
    on MBR presence."""
    _clear_mbr_key_on_self()
    _patch_mbr_triggers_cache(_SYNTHETIC_MBR_TRIGGERS)
    non_mbr_phrases = (
        "pitch deck",
        "slide deck for demo day",
        "pptx for the all-hands",
        "presentation on our roadmap",
    )
    for non_mbr_phrase in non_mbr_phrases:
        plan = {
            "steps": [{
                "agent": "rebecca-deck",
                "task": f"build a {non_mbr_phrase}",
                "mode": "BOUND",
            }],
        }
        user_input = f"make me a {non_mbr_phrase}"
        norm._enforce_mbr_context_clarify(plan, user_input)
        assert plan["steps"][0]["mode"] == "BOUND", (
            f"non-MBR phrase {non_mbr_phrase!r} should not have triggered "
            f"override; got mode={plan['steps'][0]['mode']!r}"
        )


def test_mode_unchanged_when_mbr_signal_and_manifest_has_key():
    """Negative case #2: MBR-signal trigger AND manifest has the key →
    no override. The happy path on the MBR-present branch. Critical
    because a false override here would break the success path — BOUND
    steps fire their tool, CLARIFY steps don't — so Rebecca-Deck would
    stop building decks even when the MBR data is available."""
    _patch_mbr_triggers_cache(_SYNTHETIC_MBR_TRIGGERS)
    # Stamp the MBR key as if Rebecca-MBR just ran and auto-linked.
    manifest = norm.client_load_manifest() or {}
    manifest["latest_monthly_business_review_path"] = (
        "deliverables/reports/mbr-2026-04.xlsx"
    )
    norm.client_save_manifest(manifest)
    try:
        plan = {
            "steps": [{
                "agent": "rebecca-deck",
                "task": "build me a board deck for Meridian Q4",
                "mode": "BOUND",
            }],
        }
        norm._enforce_mbr_context_clarify(plan, "board deck for Meridian")
        assert plan["steps"][0]["mode"] == "BOUND", (
            f"MBR-present should not trigger override; "
            f"got mode={plan['steps'][0]['mode']!r}"
        )
    finally:
        _clear_mbr_key_on_self()


def test_mbr_context_triggers_is_strict_subset_of_triggers():
    """Subset invariant for rebecca-deck.json: every entry in
    mbr_context_triggers must also appear in the agent's main triggers
    list. Session 13 don't-reintroduce, pinned at Tier 0 in session 15.

    The post-router gate (norm._enforce_mbr_context_clarify) only fires
    on rebecca-deck-routed steps. Routing is decided by ROUTER_SYSTEM
    (which matches against the full triggers list). If
    mbr_context_triggers contains an entry not in triggers, the prompt
    never routes to rebecca-deck when that entry is the only match —
    the entry is dead code. Worse, if a future refactor wires routing
    off the agent JSON's triggers field, a dead-code mbr_context_triggers
    entry silently starts routing prompts that weren't meant to.

    Reads the production rebecca-deck.json directly via AGENTS_DIR
    (intentionally NOT patched by setup_temp_workspace per the comment
    on _patch_mbr_triggers_cache). This pins the production file's
    invariant; edits to the file that break it fail Tier 0."""
    path = norm.AGENTS_DIR / "rebecca-deck.json"
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    triggers = {
        str(t).strip().lower()
        for t in (data.get("triggers") or [])
    }
    mbr_triggers = {
        str(t).strip().lower()
        for t in (data.get("mbr_context_triggers") or [])
    }
    assert mbr_triggers, (
        "mbr_context_triggers is empty in rebecca-deck.json — "
        "Session 13 priority 1 gate is dead code"
    )
    extra = mbr_triggers - triggers
    assert not extra, (
        f"mbr_context_triggers contains entries not in triggers: "
        f"{sorted(extra)}. Subset invariant required — "
        f"Session 13 don't-reintroduce."
    )


def test_rebecca_umbrella_does_not_exist():
    """Session 16 priority A: the rebecca.json umbrella file is a
    pre-session-10 artifact. Post-session-10, the persona split into
    rebecca-mbr.json and rebecca-deck.json with separate slugs and
    force_tool fields. The umbrella has no slug, no force_tool, and
    no triggers — it's a tool-less landing pad.

    The agents dict is slug-keyed (norm.py:5321 fallback to filename
    stem when slug is absent). rebecca.json's stem-derived key is
    'rebecca'. Sam's classifier occasionally drifts to emitting bare
    'rebecca' on ambiguous prompts (despite ROUTER_SYSTEM teaching
    the split). Without this file, 'rebecca' resolves via the
    agents.get fallback to norm — wrong agent, but at least norm
    doesn't promise to produce decks.

    With this file, Sam's bare 'rebecca' emission strands the user:
    rebecca-umbrella runs, can't invoke generate_pptx_deck (no
    force_tool), produces text-only response, the user gets nothing.

    This was the root cause of the session-16 Carla deflection
    incident (where the operator asked for slides via /ingest and
    got an outline + Python code instead of a .pptx).

    Operator renamed agents/rebecca.json → rebecca.json.bak in
    session 16. This test pins that rename out of existence —
    *.json glob in agent loader won't pick up .bak; this test
    guards against future re-introduction (e.g. someone undoing
    the rename, restoring the file from git history, or shipping
    a new umbrella for a different reason)."""
    path = norm.AGENTS_DIR / "rebecca.json"
    assert not path.exists(), (
        f"rebecca.json umbrella exists at {path}. This file is a "
        f"tool-less landing pad that catches Sam's bare 'rebecca' "
        f"emissions and prevents proper rebecca-deck/rebecca-mbr "
        f"routing. Rename to rebecca.json.bak or delete. See "
        f"session 16 handoff for full diagnosis."
    )


# ─── Contract 25 — file ingestion architecture (session 17) ──────────────────
#
# Session 16 reproduction surfaced the architectural gap behind the Carla
# deflection AND the proposal-pipeline issues: extract_file_paths' strict
# regex silently missed common file references (quoted bare names, directory
# paths, file-noun phrases), so Sam routed prompts as if Cliff could do
# filesystem ingestion he can't actually do. Session 17 ships Options A + B
# (pre-router permissive detector + interactive resolver + /ingest slash
# command). These tests pin the new detection contract and guard against
# the specific false positive killed during smoke testing
# (bare /ingest token misread as a Unix path).

def test_strict_extract_file_paths_still_catches_path_with_ext():
    """Session 17 regression guard: the new permissive layer is a
    superset of extract_file_paths via Pass 1 delegation, but the
    strict regex itself must keep working — it's still load-bearing
    for the orchestrator's path-shape detection. If this test fails,
    the orchestrator's Pass 1 will silently miss real paths."""
    refs = norm._detect_file_references('summarize /home/dan/Q1.pdf')
    paths = [r for r in refs if r["kind"] == "path"]
    assert len(paths) == 1, f"expected 1 path ref, got {refs}"
    assert paths[0]["value"] == "/home/dan/Q1.pdf"
    assert paths[0]["has_ext"] is True


def test_detector_catches_quoted_bare_name():
    """Pass 2: quoted bare names like "User_Guide" must be detected
    as kind='name'. This is the session-16 incident shape that
    silently no-op'd under extract_file_paths. Without this match,
    the resolver never gets a chance to ask the user for the folder."""
    refs = norm._detect_file_references('ingest "User_Guide" please')
    names = [r for r in refs if r["kind"] == "name" and r["value"] == "User_Guide"]
    assert len(names) == 1, f"expected User_Guide as name ref, got {refs}"
    assert names[0]["has_ext"] is False


def test_detector_catches_windows_directory_path():
    """Pass 3: Windows directory paths (no file extension) are
    caught as kind='directory'. The session-16 incident prompt
    contained C:\\Users\\danco\\Downloads — extract_file_paths missed
    this because no extension."""
    refs = norm._detect_file_references(
        'ingest "User_Guide" from C:\\Users\\danco\\Downloads'
    )
    dirs = [r for r in refs if r["kind"] == "directory"]
    assert any("Downloads" in r["value"] for r in dirs), (
        f"expected directory ref containing 'Downloads', got {refs}"
    )


def test_detector_catches_unix_directory_path():
    """Pass 3 (Unix branch): /home/dan/Downloads-style paths are
    caught. The branch requires ≥2 path segments to avoid matching
    bare slash-command tokens (see false-positive guard test below)."""
    refs = norm._detect_file_references('look in /home/dan/Downloads for it')
    dirs = [r for r in refs if r["kind"] == "directory"]
    assert any(r["value"] == "/home/dan/Downloads" for r in dirs), (
        f"expected /home/dan/Downloads as directory ref, got {refs}"
    )


def test_detector_rejects_bare_slash_command_token_as_path():
    """Pass 3 false-positive guard: the Unix-path branch must NOT
    match bare slash-command tokens like '/ingest' or '/files'.
    Found during session-17 smoke testing on the literal session-16
    incident prompt: the original regex /[^\\s,;\"'<>]+ matched
    '/ingest' as a Unix path, polluting the ref list with
    {kind:'directory', value:'/ingest'}.

    Fix was to require ≥2 segments (/seg1/seg2...). This test pins
    the fix. Don't relax the regex without preserving this guard."""
    # Bare /ingest in mid-prompt, no following path
    refs = norm._detect_file_references('try /ingest first then /files')
    bad = [r for r in refs if r["value"] in ("/ingest", "/files")]
    assert not bad, f"slash-command tokens leaked into refs: {refs}"


def test_detector_catches_explicit_file_noun_phrase():
    """Pass 4: 'the X document', 'my Y report' etc. catch X/Y as
    name refs when X/Y looks filename-shaped (per
    _looks_filename_shaped — has underscore, dash, digit, or initial
    capital). Required for the session-16 fixture prompt 'the User_Guide
    document' shape."""
    refs = norm._detect_file_references('summarize the User_Guide document')
    names = [r for r in refs if r["kind"] == "name" and r["value"] == "User_Guide"]
    assert len(names) == 1, f"expected User_Guide via file-noun phrase, got {refs}"


def test_detector_rejects_lowercase_descriptor_in_phrase():
    """Pass 4 filter: tokens that don't look filename-shaped (pure
    lowercase, no _, no -, no digit) are rejected. 'fix the latest
    report' must NOT detect 'latest' as a file name. Without this
    filter, almost every prompt with 'the X report' would generate
    a spurious follow-up question."""
    refs = norm._detect_file_references('fix the latest report')
    assert refs == [], f"expected no refs, got {refs}"


def test_detector_returns_empty_for_plain_prompt():
    """Sanity: plain prompts with no file-shaped content produce
    empty ref list. Without this, the natural-language path could
    erroneously gate behind a follow-up on every turn."""
    assert norm._detect_file_references("what time is it in Paris") == []
    assert norm._detect_file_references("write me a haiku about coffee") == []


def test_detector_dedupes_same_value():
    """De-dup: same path mentioned twice in a prompt yields one
    ref, not two. Avoids redundant resolver work + duplicate
    follow-up prompts."""
    refs = norm._detect_file_references(
        '/home/dan/x.pdf is broken; please fix /home/dan/x.pdf'
    )
    assert len(refs) == 1, f"expected 1 (de-duped), got {refs}"


def test_memory_has_name_handles_stem_and_full_filename():
    """_memory_has_name powers the 'skip resolver if already in
    memory' branch. Must match by both full filename ('User_Guide.pdf')
    and by stem ('User_Guide'). Wired to memory_list_files which
    reads the SQLite db; we redirect the db path to a tmp dir
    via save/restore (no pytest fixtures available — TestRunner
    calls test_fn with no args)."""
    tmp = Path(tempfile.mkdtemp(prefix="layer1_c25_"))
    orig_db_path = norm._memory_db_path
    orig_mem_dir = norm.client_memory_dir
    try:
        norm._memory_db_path = lambda: str(tmp / "test_memory.db")
        norm.client_memory_dir = lambda: tmp
        norm.memory_init()
        norm.memory_save_file({
            "path": str(tmp / "User_Guide.pdf"),
            "name": "User_Guide.pdf",
            "type": ".pdf",
            "word_count": 100,
            "page_count": 1,
            "content": "stub",
            "preview": "stub",
            "toc": [],
            "file_mtime": 0,
        })
        assert norm._memory_has_name("User_Guide") is True, "stem match failed"
        assert norm._memory_has_name("User_Guide.pdf") is True, "full-name match failed"
        assert norm._memory_has_name("user_guide") is True, "case-insensitive failed"
        assert norm._memory_has_name("Other_File") is False, "false positive on other"
        assert norm._memory_has_name("") is False, "false positive on empty"
    finally:
        norm._memory_db_path = orig_db_path
        norm.client_memory_dir = orig_mem_dir
        shutil.rmtree(tmp, ignore_errors=True)


def test_orchestrator_returns_empty_shape_for_no_refs():
    """extract_and_ingest_files contract: prompts with no detected
    refs return ingested=[], unresolved=[], platform_note=''.
    Caller's 'if unresolved: continue' branch must NOT fire on
    plain prompts."""
    r = norm.extract_and_ingest_files(
        "what time is it in Paris", prompt_user=False
    )
    assert r["ingested"] == []
    assert r["unresolved"] == []
    assert r["platform_note"] == ""


def test_orchestrator_reports_unresolved_when_prompt_user_false():
    """When prompt_user=False (test mode), references that can't
    resolve from the prompt alone go to `unresolved` rather than
    triggering interactive follow-up. This is the contract the
    test harness relies on; production always uses prompt_user=True."""
    r = norm.extract_and_ingest_files(
        'summarize "User_Guide"', prompt_user=False
    )
    assert r["ingested"] == []
    assert "User_Guide" in r["unresolved"]
    assert r["platform_note"] == ""


def test_orchestrator_emits_platform_note_on_success():
    """Q3 contract (session 17): on successful ingestion, platform_note
    is a one-line '[platform: ingested X — content available in memory]'
    string. Caller injects this into Sam's user_input so he doesn't
    plan a redundant Cliff-ingestion step."""
    tmp = Path(tempfile.mkdtemp(prefix="layer1_c25_"))
    orig_db_path = norm._memory_db_path
    orig_mem_dir = norm.client_memory_dir
    try:
        norm._memory_db_path = lambda: str(tmp / "test_memory.db")
        norm.client_memory_dir = lambda: tmp
        norm.memory_init()
        tf = tmp / "smoke.txt"
        tf.write_text("session 17 smoke content " * 30)
        r = norm.extract_and_ingest_files(
            f"summarize {tf}", prompt_user=False
        )
        assert len(r["ingested"]) == 1, f"expected 1 ingest, got {r}"
        assert r["unresolved"] == [], f"expected empty unresolved, got {r}"
        assert "smoke.txt" in r["platform_note"]
        assert r["platform_note"].startswith("[platform:")
        assert "content available in memory" in r["platform_note"]
    finally:
        norm._memory_db_path = orig_db_path
        norm.client_memory_dir = orig_mem_dir
        shutil.rmtree(tmp, ignore_errors=True)


def test_handle_ingest_command_callable_with_empty_arg():
    """Sanity: /ingest with no arg prints usage and returns without
    raising. Production REPL relies on this for the 'user typed
    /ingest by itself' case (see norm.py dispatcher)."""
    # Should not raise
    norm.handle_ingest_command("")


def test_ingest_slash_command_dispatched_before_catchall():
    """Static text check on norm.py source. /ingest must be
    dispatched in the slash-command elif chain BEFORE the
    `cmd.startswith('/')` catchall (which treats unknown / commands
    as agent slug lookups). Without this ordering, /ingest gets
    looked up as an agent name and prints 'Sorry, I don't know that
    regular yet' — exactly the session-16 failure mode that prompted
    Option B."""
    src = (Path(norm.__file__)).read_text(encoding='utf-8-sig')
    pos_ingest = src.find('/ingest ')
    pos_catchall = src.find('elif cmd.startswith("/"):')
    assert pos_ingest > 0, "could not locate /ingest dispatch in source"
    assert pos_catchall > 0, "could not locate slash catchall in source"
    # Find the dispatcher /ingest, not just any mention
    pos_ingest_dispatch = src.find('elif cmd.startswith("/ingest ")')
    assert pos_ingest_dispatch > 0, "/ingest slash dispatch missing"
    assert pos_ingest_dispatch < pos_catchall, (
        "/ingest dispatch must come before the slash-catchall — "
        "otherwise /ingest gets treated as an unknown agent slug. "
        "See session-17 Priority 1 Option B."
    )


def test_help_text_mentions_ingest_command():
    """The /help output must mention /ingest. Discoverability
    matters: users who try /ingest (the operator did during the
    session-16 incident) shouldn't have to read source to find it."""
    help_text = norm._build_help(norm.Mode.CUSTOMER)
    assert "/ingest" in help_text, (
        "/help output does not mention /ingest — users won't discover "
        "the command. See session-17 Priority 1 Option B + _build_help."
    )


CONTRACTS = [
    ("Contract 1 — handler gate mechanics", [
        ("rejects stub spec", test_handler_rejects_stub_spec),
        ("saves complete spec", test_handler_saves_complete_spec),
        ("bypass saves stub with warnings", test_handler_bypass_saves_stub_with_warnings),
        ("bypass flag inert on complete spec", test_handler_accepts_complete_spec_with_bypass_flag),
    ]),
    ("Contract 2 — _rubric_critical_issues filtering", [
        ("audit stub returns A-prefix issues", test_filter_operational_audit_stub_returns_A_issues),
        ("complete spec returns no issues", test_filter_complete_spec_returns_empty),
        ("degenerate inputs don't raise", test_filter_handles_degenerate_inputs),
    ]),
    ("Contract 3 — rejection message content", [
        ("starts with sentinel", test_rejection_message_contains_sentinel_first),
        ("has actionable structure", test_rejection_message_has_actionable_structure),
        ("bypass warning lists issues", test_bypass_warning_lines_include_issues),
    ]),
    ("Contract 4 — dispatcher 3-tuple", [
        ("success path: text + banner + False", test_dispatch_success_returns_clean_text_and_banner),
        ("rejection path: text + None + True", test_dispatch_rejection_returns_is_error_and_strips_sentinel),
        ("unknown tool: error + None + True", test_dispatch_unknown_tool_returns_is_error),
    ]),
    ("Contract 5 — bypass-kwarg routing", [
        ("bypass flag reaches docx handler", test_dispatch_bypass_flag_reaches_docx_handler),
        ("bypass flag reaches pptx handler (session 10)", test_dispatch_bypass_flag_reaches_pptx_handler),
        ("bypass flag reaches xlsx handler (session 10)", test_dispatch_bypass_flag_reaches_xlsx_handler),
        ("bypass flag NOT passed to non-allowlisted tools", test_dispatch_bypass_flag_NOT_passed_to_non_allowlisted_tools),
        ("_BYPASS_CAPABLE_TOOLS allow-list pins content", test_bypass_capable_tools_allowlist_sanity),
        ("N threshold constant is exposed and sane", test_gate_rejection_threshold_constant),
    ]),
    ("Contract 6 — builder robustness (session 3)", [
        ("string priority entries — save",           test_builder_survives_string_priority_entries),
        ("string priority entries — warn",           test_builder_emits_warning_for_string_priority_entries),
        ("string roi_math — save + warn",            test_builder_survives_string_roi_math),
        ("string executive_summary — save + warn",   test_builder_survives_string_executive_summary),
        ("list meta — save + warn",                  test_builder_survives_list_meta),
        ("list diagnosis — save + warn",             test_builder_survives_list_diagnosis),
        ("empty priority dict — save, no warnings",  test_builder_empty_priority_dict_no_warnings),
        ("complete spec — zero builder-warnings",    test_builder_complete_spec_produces_zero_warnings),
        ("warning shape is parseable",               test_builder_warning_shape_is_parseable),
    ]),
    ("Contract 7 — client_proposal Layer 1 (session 4)", [
        ("CP stub spec — rejected",                  test_handler_rejects_client_proposal_stub_spec),
        ("CP complete spec — saves",                 test_handler_saves_complete_client_proposal_spec),
        ("CP bypass saves stub with P-warnings",     test_handler_bypass_saves_client_proposal_stub_with_warnings),
        ("CP stub filter returns P3 + P5",           test_filter_client_proposal_stub_returns_P_issues),
        ("CP string approach entries — save + warn", test_cp_builder_survives_string_approach_entries),
        ("CP string pricing — save + warn",          test_cp_builder_survives_string_pricing),
        ("CP list scope — save + warn",              test_cp_builder_survives_list_scope),
        ("CP list meta — save + warn",               test_cp_builder_survives_list_meta),
        ("CP dict exec_summary — save + warn",       test_cp_builder_survives_dict_executive_summary),
        ("CP empty approach dict — no warnings",     test_cp_builder_empty_approach_dict_no_warnings),
        ("CP complete spec — zero warnings",         test_cp_builder_complete_spec_produces_zero_warnings),
    ]),
    ("Contract 8 — research_report Layer 1 (session 5)", [
        ("RR stub spec — rejected",                     test_handler_rejects_research_report_stub_spec),
        ("RR complete spec — saves",                    test_handler_saves_complete_research_report_spec),
        ("RR bypass saves stub with R-warnings",        test_handler_bypass_saves_research_report_stub_with_warnings),
        ("RR stub filter returns R2 + R3 + R5 + R6",    test_filter_research_report_stub_returns_R_issues),
        ("RR string findings_detail entries",           test_rr_builder_survives_string_findings_detail_entries),
        ("RR string key_findings entry",                test_rr_builder_survives_string_key_findings_entry),
        ("RR string synthesis",                         test_rr_builder_survives_string_synthesis),
        ("RR list meta",                                test_rr_builder_survives_list_meta),
        ("RR string executive_summary",                 test_rr_builder_survives_string_executive_summary),
        ("RR malformed nested evidence item",           test_rr_builder_survives_malformed_nested_evidence),
        ("RR malformed nested source field (3 levels)", test_rr_builder_survives_malformed_nested_source_field),
        ("RR empty findings dict — no warnings",        test_rr_builder_empty_findings_dict_no_warnings),
        ("RR complete spec — zero warnings",            test_rr_builder_complete_spec_produces_zero_warnings),
        ("bypass save emits both warning blocks",       test_handler_bypass_saves_malformed_spec_with_both_warning_blocks),
    ]),
    ("Contract 9 — tool_choice forcing (session 6)", [
        ("force_tool helper shape",                     test_tool_choice_force_tool_helper_shape),
        ("override reaches first create only",          test_run_tool_use_loop_passes_override_to_first_create_only),
        ("TOOL_CHOICE_ANY constant reaches create",     test_run_tool_use_loop_passes_any_mode_constant_to_first_create),
        ("override absent on rejected-tool retry",      test_tool_choice_override_absent_when_rejected_tool_retries),
        ("default omits tool_choice",                   test_run_tool_use_loop_default_omits_tool_choice),
    ]),
    ("Contract 11 — forcing deployment conjunction (session 9)", [
        ("truth table — all 4 conjunction rows",      test_force_conjunction_truth_table),
        ("missing mode defaults to no-force",         test_force_conjunction_missing_mode_defaults_to_no_force),
        ("malformed mode defaults to no-force",       test_force_conjunction_malformed_mode_defaults_to_no_force),
    ]),
    ("Contract 10 — preflight absence + dead-spot + isinstance (session 7)", [
        ("A4b — audit with no roi_math anywhere rejected",    test_audit_collective_absence_of_roi_math_fires_A4b),
        ("P4b — CP with absent pricing rejected (not P3)",    test_cp_absent_pricing_fires_P4b_not_P3),
        ("R3b — RR with absent findings_detail rejected",     test_rr_absent_findings_detail_fires_R3b_not_R3),
        ("P5 dead-spot — title-only CP now caught",           test_cp_title_only_now_fires_P5_dead_spot_fix),
        ("A3/A4 isinstance skip — audit preflight clean",     test_preflight_audit_malformed_priorities_does_not_silence_later_checks),
        ("R3/R4 isinstance skip — RR preflight clean",        test_preflight_rr_malformed_findings_does_not_silence_later_checks),
    ]),
    ("Contract 12 — Deck (executive_review_deck) Layer 1 (session 10)", [
        ("Deck stub spec — rejected",                         test_handler_rejects_deck_stub_spec),
        ("Deck complete spec — saves + TASK COMPLETE",        test_handler_saves_complete_deck_spec),
        ("Deck bypass saves stub with D-warnings",            test_handler_bypass_saves_deck_stub_with_warnings),
        ("Deck stub filter returns D2 + D3 + D4",             test_filter_deck_stub_returns_D_issues),
    ]),
    ("Contract 13 — MBR (monthly_business_review) Layer 1 (session 10)", [
        ("MBR stub spec — rejected",                          test_handler_rejects_mbr_stub_spec),
        ("MBR variance-no-commentary — rejected (M3)",        test_handler_rejects_mbr_variance_no_commentary),
        ("MBR complete spec — saves + TASK COMPLETE",         test_handler_saves_complete_mbr_spec),
        ("MBR bypass saves stub with M-warnings",             test_handler_bypass_saves_mbr_stub_with_warnings),
        ("MBR stub filter returns M2 only",                   test_filter_mbr_stub_returns_M_issues),
        ("MBR variance filter returns M3 only",               test_filter_mbr_variance_no_commentary_returns_M3),
    ]),
    ("Contract 14 — xlsx builder code-path coverage (session 11)", [
        ("_looks_like_unequals_formula — pos + neg",          test_looks_like_unequals_formula_positive_and_negative),
        ("_check_formula G1 — missing '=' warning",           test_check_formula_flags_string_without_equals),
        ("_check_formula G2 — unknown sheet warning",         test_check_formula_flags_unknown_sheet),
        ("_check_formula G3 — out-of-range row warning",      test_check_formula_flags_out_of_range_row),
        ("_check_formula clean formula — zero warnings",      test_check_formula_clean_formula_produces_no_warnings),
        ("_font(italic=True) — regression pin",               test_font_accepts_italic_true_and_preserves_defaults),
        ("MBR builder TBD-commentary path — saves on bypass", test_mbr_builder_renders_tbd_commentary_stubs_on_bypass),
    ]),
    ("Contract 15 — pptx builder code-path coverage (session 11)", [
        ("_render_kpis populated — saves",                    test_pptx_builder_renders_kpis_slide_populated),
        ("_render_kpis empty — TBD branch saves",             test_pptx_builder_renders_kpis_slide_empty_tbd),
        ("_render_table populated — saves",                   test_pptx_builder_renders_table_slide_populated),
        ("_render_table empty — TBD branch saves",            test_pptx_builder_renders_table_slide_empty_tbd),
        ("_render_closing empty-bullets — TBD branch saves",  test_pptx_builder_renders_closing_tbd_when_bullets_empty),
        ("_set_notes with text — notes attach + readback",    test_pptx_builder_attaches_speaker_notes),
    ]),
    ("Contract 16 — bypass preamble wording pins (session 11 + session 12 ext)", [
        ("pptx bypass preamble — stop-command tokens present", test_pptx_bypass_preamble_contains_stop_command_tokens),
        ("xlsx bypass preamble — stop-command tokens present", test_xlsx_bypass_preamble_contains_stop_command_tokens),
        ("docx bypass preamble — stop-command tokens present (session 12)", test_docx_bypass_preamble_contains_stop_command_tokens),
    ]),
    ("Contract 17 — agent-dict slug keying + tool-gating (session 11)", [
        ("agents dict keyed by slug not name (finding 1)",      test_agents_dict_keys_by_slug_not_name),
        ("agent_slug derivation prefers slug over name",        test_agent_slug_derivation_prefers_slug_over_name),
        ("first-party tools resolve for Rebecca slugs",         test_first_party_tools_resolve_for_rebecca_slugs),
    ]),
    ("Contract 19 — auto-link on tool-handler save (session 12)", [
        ("docx client_proposal — writes latest_client_proposal_path",     test_autolink_docx_client_proposal_writes_latest_path),
        ("docx operational_audit — writes latest_operational_audit_path", test_autolink_docx_operational_audit_writes_latest_path),
        ("docx research_report — writes latest_research_report_path",     test_autolink_docx_research_report_writes_latest_path),
        ("pptx exec_review_deck — writes latest_executive_review_deck_path", test_autolink_pptx_executive_review_deck_writes_latest_path),
        ("xlsx MBR — writes latest_monthly_business_review_path",         test_autolink_xlsx_monthly_business_review_writes_latest_path),
        ("bypass save — still writes latest_<template>_path",             test_autolink_bypass_save_still_writes_latest_path),
        ("second save — overwrites key (latest = latest)",                test_autolink_second_save_overwrites_key),
        ("USER_DIR-relative input → workspace-relative stored (s12a)",    test_autolink_normalizes_userdir_relative_path_to_workspace_relative),
    ]),
    ("Contract 20 — deliverable sentinel 5-field format (session 12)", [
        ("sentinel has five tab fields",                         test_deliverable_sentinel_has_five_tab_fields),
        ("template field matches spec",                          test_deliverable_sentinel_template_field_matches_spec),
        ("dispatcher skips auto-link on 4-field (back-compat)",  test_dispatcher_skips_autolink_on_four_field_sentinel),
    ]),
    ("Contract 21 — artifact_gate shared formatters (session 12)", [
        ("rejection message — sentinel first line, body",        test_gate_rejection_message_has_sentinel_first_line),
        ("rejection message — tool_name interpolation",          test_gate_rejection_message_injects_tool_name),
        ("rejection message — drafted_keeper_line verbatim",     test_gate_rejection_message_injects_drafted_keeper_line),
        ("bypass warning — Contract 16 tokens pinned here",      test_gate_bypass_warning_lines_contain_session11_tokens),
        ("builder warning — default + custom intro both work",   test_gate_builder_warning_lines_lists_all_warnings),
    ]),
    ("Contract 22 — tmp-workspace path discipline (session 12)", [
        ("pptx save under tmp, not ~/.tavernos",                 test_pptx_save_under_temp_workspace_not_home),
        ("xlsx save under tmp, not ~/.tavernos",                 test_xlsx_save_under_temp_workspace_not_home),
    ]),
    ("Contract 23 — MBR→Deck consumer-side gate (session 13)", [
        ("context block surfaces MBR path when present",         test_client_context_block_surfaces_mbr_path_when_present),
        ("context block omits MBR line when absent",             test_client_context_block_omits_mbr_line_when_absent),
        ("CLARIFY forced on MBR-signal trigger + absent key",    test_mode_forced_clarify_on_mbr_signal_trigger_when_manifest_lacks_key),
        ("mode unchanged on non-MBR trigger",                    test_mode_unchanged_when_non_mbr_trigger),
        ("mode unchanged when MBR-signal trigger + key present", test_mode_unchanged_when_mbr_signal_and_manifest_has_key),
        ("mbr_context_triggers strict subset of triggers (s15)", test_mbr_context_triggers_is_strict_subset_of_triggers),
    ]),
    ("Contract 24 — rebecca-umbrella collision pinned out (session 16)", [
        ("rebecca.json umbrella does not exist",                 test_rebecca_umbrella_does_not_exist),
    ]),
    ("Contract 25 — file ingestion architecture (session 17)", [
        ("strict regex still catches paths with extension",      test_strict_extract_file_paths_still_catches_path_with_ext),
        ("quoted bare names detected as kind=name",              test_detector_catches_quoted_bare_name),
        ("Windows directory paths detected",                     test_detector_catches_windows_directory_path),
        ("Unix directory paths detected",                        test_detector_catches_unix_directory_path),
        ("bare slash-command tokens NOT misread as paths",       test_detector_rejects_bare_slash_command_token_as_path),
        ("explicit file-noun phrases detected",                  test_detector_catches_explicit_file_noun_phrase),
        ("lowercase descriptors rejected via filename-shape",    test_detector_rejects_lowercase_descriptor_in_phrase),
        ("plain prompts produce empty ref list",                 test_detector_returns_empty_for_plain_prompt),
        ("repeated value de-duped to single ref",                test_detector_dedupes_same_value),
        ("memory-has-name matches stem and full filename",       test_memory_has_name_handles_stem_and_full_filename),
        ("orchestrator empty shape on no-refs prompt",           test_orchestrator_returns_empty_shape_for_no_refs),
        ("orchestrator reports unresolved when non-interactive", test_orchestrator_reports_unresolved_when_prompt_user_false),
        ("orchestrator emits platform note on success",          test_orchestrator_emits_platform_note_on_success),
        ("handle_ingest_command callable with empty arg",        test_handle_ingest_command_callable_with_empty_arg),
        ("/ingest dispatched before slash catchall",             test_ingest_slash_command_dispatched_before_catchall),
        ("help text mentions /ingest",                           test_help_text_mentions_ingest_command),
    ]),
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--verbose", "-v", action="store_true")
    args = ap.parse_args()

    tmp = setup_temp_workspace()
    runner = TestRunner(verbose=args.verbose)

    try:
        print("=" * 70)
        print("Layer 1 mechanism test — Goal A session 2 (Apr 23 2026)")
        print("=" * 70)
        for contract_name, tests in CONTRACTS:
            print(f"\n{contract_name}")
            for test_name, test_fn in tests:
                runner.run(test_name, test_fn)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    return runner.summary()


if __name__ == "__main__":
    sys.exit(main())