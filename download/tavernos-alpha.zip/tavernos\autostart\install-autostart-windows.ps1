# install-autostart-windows.ps1
# Registers TavernOS web UI (norm --web) to auto-start at user login and
# auto-restart if it crashes. Uses Windows Task Scheduler.
#
# Run from PowerShell:
#   .\install-autostart-windows.ps1
# (Right-click → Run with PowerShell is fine — no admin needed for a
# per-user task.)

$ErrorActionPreference = "Stop"
$TaskName = "TavernOS-Web"

Write-Host ""
Write-Host "  TavernOS — Installing autostart for web UI" -ForegroundColor Cyan
Write-Host "  ──────────────────────────────────────────" -ForegroundColor DarkCyan
Write-Host ""

# ── Locate the 'norm' command ─────────────────────────────────────────────
$NormCmd = Get-Command norm -ErrorAction SilentlyContinue
if (-not $NormCmd) {
    Write-Host "  ✗ 'norm' command not found on PATH." -ForegroundColor Red
    Write-Host "    Install TavernOS first: pip install tavernos" -ForegroundColor DarkGray
    Write-Host ""
    exit 1
}
$NormPath = $NormCmd.Source
Write-Host "  Found norm at:  $NormPath" -ForegroundColor DarkGray

# ── Remove any existing task with the same name ───────────────────────────
$Existing = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if ($Existing) {
    Write-Host "  Replacing existing TavernOS-Web task..." -ForegroundColor DarkYellow
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
}

# ── Build the task ────────────────────────────────────────────────────────
# Use a hidden PowerShell window so there's no console flash at login.
# The inner command is: & 'C:\path\to\norm' --web
$InnerCommand = "& '$NormPath' --web"
$PSArgs = "-WindowStyle Hidden -NoProfile -ExecutionPolicy Bypass -Command `"$InnerCommand`""

$Action = New-ScheduledTaskAction `
    -Execute "powershell.exe" `
    -Argument $PSArgs

$Trigger = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME

# Crash-recovery directives: if the task exits unexpectedly, restart up to 3
# times at 1-minute intervals. This is Part C from the plan — the OS handles
# the supervision, norm.py doesn't need its own restart loop.
$Settings = New-ScheduledTaskSettingsSet `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries `
    -StartWhenAvailable `
    -RestartCount 3 `
    -RestartInterval (New-TimeSpan -Minutes 1) `
    -ExecutionTimeLimit (New-TimeSpan -Hours 0)   # 0 = no time limit

$Principal = New-ScheduledTaskPrincipal `
    -UserId $env:USERNAME `
    -LogonType Interactive `
    -RunLevel Limited

Register-ScheduledTask `
    -TaskName $TaskName `
    -Action $Action `
    -Trigger $Trigger `
    -Settings $Settings `
    -Principal $Principal `
    -Force | Out-Null

Write-Host ""
Write-Host "  ✓ TavernOS web UI will auto-start at login." -ForegroundColor Green
Write-Host "  ✓ If it crashes, Windows will restart it (up to 3x/minute)." -ForegroundColor Green
Write-Host ""
Write-Host "  Start it right now without logging out?" -ForegroundColor Cyan
$Answer = Read-Host "  [Y/n]"
if ($Answer -eq "" -or $Answer -like "y*") {
    Start-ScheduledTask -TaskName $TaskName
    Start-Sleep -Seconds 2
    Write-Host "  → Web UI should be available at http://127.0.0.1:7777" -ForegroundColor Green
    Write-Host "    Check status anytime with:  norm --web-status" -ForegroundColor DarkGray
}
Write-Host ""
Write-Host "  To remove autostart later:  .\uninstall-autostart-windows.ps1" -ForegroundColor DarkGray
Write-Host ""
