# verify-live.ps1
# Run AFTER pushing the new ZIP to tavernos-test on GitHub.
# Waits for Cloudflare to deploy, downloads the live ZIP, SHA256-compares to local.
# ASCII-only, PowerShell 5 compatible.

$ErrorActionPreference = "Stop"
$local = Join-Path $HOME "Downloads\tavernos-alpha.zip"
if (-not (Test-Path $local)) {
    Write-Host "  ! Local ZIP not found at $local" -ForegroundColor Red
    exit 1
}

$liveUrl = "https://tavernos.ai/download/tavernos-alpha.zip"
$liveCopy = Join-Path $env:TEMP "live-friend-zip.zip"

Write-Host "=== Downloading live ZIP from $liveUrl ===" -ForegroundColor Cyan
$attempts = 0
$maxAttempts = 4
$waitSecs = 20

while ($attempts -lt $maxAttempts) {
    $attempts++
    if (Test-Path $liveCopy) { Remove-Item $liveCopy }
    try {
        Invoke-WebRequest -Uri $liveUrl -OutFile $liveCopy -UseBasicParsing -TimeoutSec 30
    } catch {
        Write-Host ("  ! Download attempt " + $attempts + " failed: " + $_.Exception.Message) -ForegroundColor Yellow
        if ($attempts -lt $maxAttempts) {
            Write-Host ("    Retrying in " + $waitSecs + "s...") -ForegroundColor Yellow
            Start-Sleep -Seconds $waitSecs
            continue
        } else {
            Write-Host "  Giving up. Cloudflare may still be deploying - try again in a minute." -ForegroundColor Red
            exit 1
        }
    }

    $localHash = (Get-FileHash $local    -Algorithm SHA256).Hash
    $liveHash  = (Get-FileHash $liveCopy -Algorithm SHA256).Hash
    $localSize = (Get-Item $local).Length
    $liveSize  = (Get-Item $liveCopy).Length

    Write-Host ""
    Write-Host ("  Local:  " + $localHash + "  (" + $localSize + " bytes)")
    Write-Host ("  Live:   " + $liveHash  + "  (" + $liveSize  + " bytes)")
    Write-Host ""

    if ($localHash -eq $liveHash) {
        Write-Host "=== MATCH - live ZIP matches local ===" -ForegroundColor Green
        Write-Host "Friends downloading from tavernos.ai/access now get the clean ZIP." -ForegroundColor Green
        Remove-Item $liveCopy
        exit 0
    } else {
        Write-Host ("  ! Hash mismatch (attempt " + $attempts + " of " + $maxAttempts + ")") -ForegroundColor Yellow
        if ($attempts -lt $maxAttempts) {
            Write-Host ("    Cloudflare likely still deploying. Waiting " + $waitSecs + "s and retrying...") -ForegroundColor Yellow
            Start-Sleep -Seconds $waitSecs
        }
    }
}

Write-Host ""
Write-Host "=== MISMATCH after " -ForegroundColor Red -NoNewline
Write-Host ($maxAttempts.ToString() + " attempts ===") -ForegroundColor Red
Write-Host "Possible causes:" -ForegroundColor Yellow
Write-Host "  - Cloudflare cache still serving old version (wait a few more minutes, rerun)" -ForegroundColor Yellow
Write-Host "  - Push to GitHub did not complete - check github.com/TavernOS/tavernos-test" -ForegroundColor Yellow
Write-Host "  - Worker deploy failed - check Cloudflare dashboard" -ForegroundColor Yellow
if (Test-Path $liveCopy) { Remove-Item $liveCopy }
exit 1
