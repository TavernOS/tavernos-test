"""artifact_gate — shared preflight-gate machinery for first-party tool modules.

Session 12 priority 1 sub-item 3: extracted from artifact_docx.py,
artifact_pptx.py, and artifact_xlsx.py. The three artifact modules were
shipping parallel copies of REJECTED_SENTINEL, DELIVERABLE_SENTINEL, and
the rejection/bypass/builder-warning formatters — with one drift risk
already manifest (docx still had the session-5 bypass wording while
pptx + xlsx got the session-11 Contract 16 rewrite).

This module is the single source of truth for:

    - REJECTED_SENTINEL / DELIVERABLE_SENTINEL constants
    - format_deliverable_sentinel()   — 5-field tab-delimited header
    - format_rejection_message()      — rubric-critical rejection guidance
    - format_bypass_warning_lines()   — Contract 16 stop-command preamble
    - format_builder_warning_lines()  — build-time warning preamble

Per-module surface that stays local:

    - TOOL_NAME constants
    - _REQUIRED_SECTION_HINTS dicts (template-specific)
    - _rubric_critical_issues(spec) (template-specific gate rules)
    - _tool_handler wiring

Design: each artifact module keeps its _tool_handler unchanged in shape;
the module-level private wrappers (_format_rejection_message, etc.)
delegate here with the per-module flavoring injected. No test imports
change; the module-level symbols stay where they were.

Don't-reintroduce (session 12): do not define REJECTED_SENTINEL,
DELIVERABLE_SENTINEL, or any of the four formatter functions inside an
artifact module. Import from here. Adding a new artifact module means
adding one more caller to this file — not copy-pasting the formatter
machinery.
"""

from __future__ import annotations

# ═══════════════════════════════════════════════════════════════════════════════
#  SENTINELS — shared contract with norm.py's _dispatch_first_party_tool.
# ═══════════════════════════════════════════════════════════════════════════════

REJECTED_SENTINEL = "__TAVERNOS_REJECTED__"
DELIVERABLE_SENTINEL = "__TAVERNOS_DELIVERABLE__"


# ═══════════════════════════════════════════════════════════════════════════════
#  DELIVERABLE SENTINEL — success-path header.
#
#  Session 12 priority 1 sub-item 2: template added as 5th tab-delimited field
#  so norm.py's dispatcher can write latest_<template>_path into client.json
#  without parsing the per-template text trailer. Dispatcher defensively skips
#  auto-link if fewer than 5 fields are present (back-compat for any future
#  tool that emits the old 4-field format).
# ═══════════════════════════════════════════════════════════════════════════════

def format_deliverable_sentinel(
    filename: str,
    path: str,
    size_bytes: int,
    template: str,
) -> str:
    """Produce the tab-delimited sentinel header emitted on successful save.

    Format:
        __TAVERNOS_DELIVERABLE__\\t<filename>\\t<path>\\t<bytes>\\t<template>

    All five fields are stringified. `path` is whatever the builder's
    build_from_spec() returned (client-relative when resolvable to
    Path.home() / ".tavernos", absolute otherwise). `template` is the
    spec's template slug and drives client.json's latest_<template>_path
    auto-link in norm.py's dispatcher.
    """
    return (
        f"{DELIVERABLE_SENTINEL}\t{filename}\t{path}\t{size_bytes}\t{template}"
    )


# ═══════════════════════════════════════════════════════════════════════════════
#  REJECTION MESSAGE — structured retry guidance surfaced as is_error=True.
#
#  Session-1 failure-mode shape (extracted verbatim from session-11 state of
#  artifact_docx.py + artifact_pptx.py + artifact_xlsx.py):
#
#    1. Reuse preflight() issue strings verbatim — already rubric-anchored.
#    2. Name what's needed (required_sections), not only what's missing —
#       agents retry better with an explicit target state.
#    3. End with "don't restart, just extend" — session-1 failure mode
#       included agents re-classifying rather than extending on retry.
#
#  The trailing drafted_keeper_line differs per module because the noun
#  differs (sections / slides / data) and grammar follows ("does" vs "do").
#  Callers supply the full line; the formatter does not try to parametrize
#  the grammar.
# ═══════════════════════════════════════════════════════════════════════════════

def format_rejection_message(
    template: str,
    critical_issues: list[str],
    tool_name: str,
    required_sections: tuple[str, ...],
    drafted_keeper_line: str,
) -> str:
    """Structured retry guidance for a preflight-rejected save.

    Parameters
    ----------
    template
        The template slug being rejected (e.g. "monthly_business_review").
    critical_issues
        Preflight issue strings that tripped the rubric-critical gate.
        Reproduced verbatim; do not paraphrase.
    tool_name
        The first-party tool name ("generate_docx_report" /
        "generate_pptx_deck" / "generate_xlsx_report"). Interpolated into
        the retry directive so the agent sees the correct call to repeat.
    required_sections
        Tuple of hint strings describing what the template needs. May be
        empty; the "Required sections" line is still emitted for
        consistency so the agent has a stable shape to parse.
    drafted_keeper_line
        Full single-line closing sentence, including grammar. The three
        canonical values as of session 12:
            docx: "The sections you already drafted do not need to be
                   thrown away — extend your spec with the missing
                   sections and call the tool again."
            pptx: "The slides you already drafted do not need to be
                   thrown away — extend your spec with the missing
                   slides and call the tool again."
            xlsx: "The data you already drafted does not need to be
                   thrown away — extend your spec with the missing
                   sections and call the tool again."

    Returns a single-string payload. First line is REJECTED_SENTINEL;
    norm.py's dispatcher strips it before forwarding to the agent.
    """
    lines = [
        REJECTED_SENTINEL,
        f"Spec rejected — {template} cannot be saved with rubric-critical",
        "sections missing. The following preflight checks failed:",
        "",
    ]
    lines.extend(f"  - {i}" for i in critical_issues)
    lines.append("")
    lines.append(
        f"Retry by calling {tool_name} again with a complete spec. "
        f"Required sections for {template}:"
    )
    lines.extend(f"  - {hint}" for hint in required_sections)
    lines.append("")
    lines.append(drafted_keeper_line)
    return "\n".join(lines)


# ═══════════════════════════════════════════════════════════════════════════════
#  BYPASS WARNING — preamble prepended to a successful save when the gate
#  was skipped after repeated rejections.
#
#  Session 11 priority 2 (Contract 16) established the three load-bearing
#  tokens this preamble must carry:
#
#    - "TASK COMPLETE"
#    - "do not invoke <tool_name> again"
#    - "second file, not a revision"
#
#  Origin of each: session-10 Rebecca-Deck Meridian QBR runs produced 2-3
#  saves per run because the previous session-5 preamble's "save succeeded
#  with known gaps; do not immediately retry" framing read as a status
#  report + soft caveat — the model inferred the issue list as a to-do
#  and kept invoking the tool. Session-11 rewrite leads with the stop-
#  command mirroring the success-trailer's TASK COMPLETE phrasing, names
#  the "retry produces a second file, not a revision" misconception
#  explicitly, and reframes the issue list as evaluator context rather
#  than implied to-do.
#
#  Session-11 Contract 16 pinned the token set for pptx + xlsx. Session 12
#  priority 1 sub-item 3 harmonized docx to the same wording and extended
#  Contract 16 to cover docx; this extraction makes the harmonization
#  structural — there is one formatter now, and it owns the token set.
#
#  Don't-reintroduce: do not soften, shorten, or reword this preamble
#  without updating Contract 16 first and stating the token-set
#  justification. Session-10 Meridian regression is the cost of silent
#  softening.
# ═══════════════════════════════════════════════════════════════════════════════

def format_bypass_warning_lines(
    critical_issues: list[str],
    tool_name: str,
) -> list[str]:
    """Warning lines prepended to a successful save when the preflight
    gate was bypassed after repeated rejections.

    Parameters
    ----------
    critical_issues
        The unresolved rubric-critical issues that tripped the gate on
        each prior rejection.
    tool_name
        The first-party tool name to interpolate into the stop-command.

    Returns
    -------
    list[str]
        Line-by-line output. Caller appends to its success-trailer lines
        before the "Document saved." / "Deck saved." / "Workbook saved."
        header. Final element is "" to give visual breathing room before
        the success trailer begins.
    """
    out = [
        "Preflight gate bypassed after repeated rejections. The deliverable",
        "was saved despite unresolved rubric-critical issues listed below.",
        "",
        f"TASK COMPLETE — do not invoke {tool_name} again for this task.",
        "The save is final; the post-save evaluator grades the current file",
        "using the issue list below as context. Do not regenerate to 'fix'",
        "the listed issues — a retry produces a second file, not a revision.",
        "Respond with a brief confirmation to the user (one or two sentences)",
        "referencing the filename and noting the unresolved gaps, then end",
        "your turn.",
        "",
        "Unresolved rubric-critical issues (post-save evaluator context):",
    ]
    out.extend(f"  - {i}" for i in critical_issues)
    out.append("")
    return out


# ═══════════════════════════════════════════════════════════════════════════════
#  BUILDER WARNING — preamble prepended to a successful save when the
#  builder had to coerce malformed spec fields (TBD placeholders) or when
#  the xlsx formula-guard channel surfaced issues.
#
#  Intro lines differ by module (xlsx has a formula-guard specific
#  framing; docx + pptx share a TBD-placeholder framing that differs only
#  in "deliverable" vs "deck"). Callers that want the default framing
#  pass intro_lines=None; callers that want custom framing pass their own
#  list. Template-specific wording stays per-module; the bullet-iteration
#  machinery stays here.
# ═══════════════════════════════════════════════════════════════════════════════

_DEFAULT_BUILDER_WARNING_INTRO: tuple[str, ...] = (
    "The following fields in the spec were malformed and rendered as",
    "TBD placeholders; the deliverable saved but these fields need",
    "corrected types on the next call to replace the placeholders:",
)


def format_builder_warning_lines(
    builder_warnings: list[str],
    intro_lines: list[str] | tuple[str, ...] | None = None,
) -> list[str]:
    """Warning lines prepended to a successful save when the builder
    channel surfaced issues.

    Parameters
    ----------
    builder_warnings
        Warning strings from build_from_spec()'s result["warnings"].
        Already formatted for human reading; reproduced verbatim.
    intro_lines
        Optional override for the intro lines above the bullet list. If
        None, uses the default TBD-placeholder framing (docx's wording).
        pptx passes "deck saved" variant; xlsx passes its formula-guard
        variant.

    Returns
    -------
    list[str]
        Line-by-line output. Caller appends to its success-trailer lines.
        Final element is "" for visual breathing room.
    """
    if intro_lines is None:
        intro_lines = _DEFAULT_BUILDER_WARNING_INTRO
    out = list(intro_lines)
    out.extend(f"  - {w}" for w in builder_warnings)
    out.append("")
    return out
