#!/bin/bash
# uninstall-autostart-mac.sh
# Removes the TavernOS web UI launchd agent.

LABEL="ai.tavernos.web"
PLIST_PATH="$HOME/Library/LaunchAgents/$LABEL.plist"

echo ""
if [ ! -f "$PLIST_PATH" ]; then
    echo "  ℹ No TavernOS autostart agent found — nothing to remove."
    echo ""
    exit 0
fi

launchctl unload "$PLIST_PATH" 2>/dev/null || true
rm -f "$PLIST_PATH"

echo "  ✓ TavernOS web UI autostart removed."
echo "    The web UI won't start at login anymore."
echo "    You can still run it manually with:  norm --web"
echo ""
