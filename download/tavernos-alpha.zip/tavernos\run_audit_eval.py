"""Phase 4B dogfood runner — score the Hypothetica operational audit.

Run locally on the TavernOS box (where ANTHROPIC_API_KEY is set). This
sandbox has no network; the evaluator LLM call has to happen on Dan's
side.

Usage:
    python run_audit_eval.py

Expects:
    - evaluator.py (patched with the document-order _extract_docx fix)
    - The deliverable at _self/deliverables/audits/hypothetica-ops-audit.docx
    - Its sidecar at _self/deliverables/audits/hypothetica-ops-audit.spec.json

Prints the score banner to stdout and drops a JSON dump of the EvalResult
to _self/eval_runs/ for iteration history. Does NOT persist to the perf
database — that's the regen loop's job, this is a one-shot score.
"""
from __future__ import annotations
import json
import os
import sys
from datetime import datetime
from pathlib import Path

from anthropic import Anthropic

import evaluator as ev

# ──────────────────────────────────────────────────────────────────────────
# Inputs. Adjust paths if this runner moves outside /home/claude.
# ──────────────────────────────────────────────────────────────────────────
DOCX_PATH = Path(
    "C:/Users/danco/.tavernos/clients/_self/deliverables/audits/"
    "hypothetica-ops-audit.docx"
)
SPEC_PATH = DOCX_PATH.with_suffix(".spec.json")
RUN_LOG_DIR = Path("C:/Users/danco/.tavernos/clients/_self/eval_runs")
RUN_LOG_DIR.mkdir(parents=True, exist_ok=True)

# Evaluator model — same tier as the generator (Opus evaluates Opus for the
# audit deliverables per the standing pattern). If your available_models
# registry differs, swap in pick_evaluator_model() here.
EVALUATOR_MODEL = os.environ.get(
    "TAVERNOS_EVAL_MODEL", "claude-opus-4-6"
)


def main() -> int:
    if not DOCX_PATH.exists():
        print(f"ERROR: deliverable not found at {DOCX_PATH}", file=sys.stderr)
        return 2
    if not SPEC_PATH.exists():
        print(f"ERROR: sidecar spec not found at {SPEC_PATH}", file=sys.stderr)
        return 2

    client = Anthropic()  # reads ANTHROPIC_API_KEY from env

    text = ev._extract_docx(DOCX_PATH)
    spec = json.loads(SPEC_PATH.read_text())
    rubric = ev.RUBRIC_OPERATIONAL_AUDIT

    print(f"Scoring {DOCX_PATH.name}")
    print(f"  extracted: {len(text):,} chars, {text.count(chr(10))+1} lines")
    print(f"  rubric:    {rubric.name} "
          f"(threshold {rubric.threshold_avg}, "
          f"hard floors: {rubric.threshold_hard})")
    print(f"  evaluator: {EVALUATOR_MODEL}")
    print()

    result = ev.score_deliverable(
        client=client,
        provider="anthropic",
        evaluator_model_id=EVALUATOR_MODEL,
        rubric=rubric,
        deliverable_text=text,
        spec_context=spec,
    )

    print(chr(10).join(ev.format_score_banner(result, rubric, 1)))

    if result.error:
        print(f"\nERROR: {result.error}", file=sys.stderr)
        return 1

    # Persist run log for iteration history.
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    run_path = RUN_LOG_DIR / f"audit-{ts}.json"
    run_path.write_text(json.dumps({
        "timestamp":          datetime.now().isoformat(),
        "deliverable":        str(DOCX_PATH),
        "evaluator_model":    result.evaluator_model,
        "scores":             result.scores,
        "critiques":          result.critiques,
        "weighted_avg":       result.weighted_avg,
        "pass_threshold":     result.pass_threshold,
        "failing_dims":       result.failing_dims,
        "overall_critique":   result.overall_critique,
    }, indent=2, default=str))
    print(f"\nRun log: {run_path}")
    return 0 if result.pass_threshold else 1


if __name__ == "__main__":
    sys.exit(main())
