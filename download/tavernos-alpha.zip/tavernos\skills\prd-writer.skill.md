---
name: PRD Writer
agent: coach
description: Writes product requirements documents from briefs, conversations, or feature requests. Use when user mentions "PRD", "requirements doc", "feature spec", "product brief", or "write up what we need to build".
triggers:
  - PRD
  - requirements doc
  - feature spec
  - product brief
  - what we need to build
  - write up requirements
chaining: true
version: 1.0.0
---

# PRD Writer

## Output structure
1. **Overview** — what this is and why it matters
2. **Problem statement** — what problem, for whom
3. **Goals & success metrics** — what done looks like
4. **User stories** — As a [user], I want [action] so that [outcome]
5. **Functional requirements** — numbered, each testable
6. **Non-functional requirements** — performance, security, accessibility
7. **Out of scope** — explicit exclusions
8. **Open questions** — what needs to be answered before work starts
9. **Timeline** — rough phases if known

## Guidelines
- Every requirement must be testable — no vague words like "fast" or "easy"
- Flag assumptions explicitly
- If input is thin, ask 3 clarifying questions before writing
- Chain to Frasier for architectural decisions
- Chain to Carla for quality review before sharing
