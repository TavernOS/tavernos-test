"""tavernos_audit.py - TavernOS health check suite.

Run from the repo root:
    python tavernos_audit.py              # default weekly run, stdout + email
    python tavernos_audit.py --full       # include expensive Tiers (2, deeper 1)
    python tavernos_audit.py --notifier stdout    # stdout only (smoke test)
    python tavernos_audit.py --notifier email     # email only
    python tavernos_audit.py --help

Config:  ~/.tavernos/config.json  (key: "audit")
Output:  ~/.tavernos/audit_runs/audit_<ts>.json  (always written)
         stdout markdown report (always)
         email (if "audit.notifier" in config is "email" or "both")

Phase 6 session 1 scope (April 22, 2026):
    Tier 0 real     - static / import / DB schema / errors.jsonl
    Tier 1 real     - fixture preflight + in-memory build, baseline drift on --full
    Tier 2 stub     - deferred to session 2 (MBR weekly)
    Tier 3 stub     - deferred to session 2 (preflight break-fixture regression)
    Tier 4 real     - tavernos.ai reachability + Dan Cooper scrub, norm handler probe
    Tier 5 real     - calibration health, drift, coverage
    Tier 6 stub     - INFO_DEFERRED to Phase 5b (agent-prompt E2E)

Design decisions logged in v7 handoff:
    - single weekly run, always dispatches (no daily/weekly split)
    - email via Resend API (Gmail SMTP fallback if configured)
    - ungated: this is an operator tool, not a customer surface
    - no hardcoded /root paths; everything under Path.home() / ".tavernos"
"""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
import sqlite3
import subprocess
import sys
import time
import traceback
import urllib.request
import urllib.error
from dataclasses import dataclass, asdict, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable


# ═══════════════════════════════════════════════════════════════════════════════
#  CONSTANTS - paths mirror norm.py's USER_DIR layout. The audit script
#  deliberately duplicates the base path so it can run even if norm.py fails
#  to import; Tier 0 then reports the import failure as a FAIL finding rather
#  than crashing the whole suite at module load.
# ═══════════════════════════════════════════════════════════════════════════════

REPO_ROOT       = Path(__file__).parent.resolve()
USER_DIR        = Path.home() / ".tavernos"
CONFIG_FILE     = USER_DIR / "config.json"
AUDIT_RUNS_DIR  = USER_DIR / "audit_runs"
DIAG_DIR        = USER_DIR / "diagnostics"
ERRORS_JOURNAL  = DIAG_DIR / "errors.jsonl"
CLIENTS_DIR     = USER_DIR / "clients"
GLOBAL_DB       = USER_DIR / "skill_performance_global.db"

DEFAULT_CLIENT_SLUG = "_self"

# Schema expectations - per-client DB
PER_CLIENT_TABLES = {
    "skill_usage",
    "skill_summary",
    "deliverable_scores",
    "deliverable_calibration",
}

# Schema expectations - global DB
GLOBAL_TABLES = {
    "skill_usage",
    "skill_summary",
    "deliverable_scores",
}

# Baselines from v7 context doc (April 22, 2026). Delta thresholds from handoff.
# NOTE: v7 labeled two of these as "financial_model" and "slide_deck" but the
# actual evaluator.RUBRICS keys are "monthly_business_review" and
# "executive_review_deck" - v7 doc drift from code. Audit keys off code truth.
V7_BASELINES: dict[str, float] = {
    "client_proposal":         4.85,
    "research_report":         4.875,
    "operational_audit":       4.725,   # v7 midpoint of 4.6-4.85 range
    "monthly_business_review": 4.73,    # v7 labeled this "financial_model"
    "executive_review_deck":   4.50,    # v7 labeled this "slide_deck"
}
BASELINE_DRIFT_WARN = 0.2
BASELINE_DRIFT_FAIL = 0.5

# Counts we expect at import time
EXPECTED_RUBRICS        = 7   # confirmed from evaluator.RUBRICS keys
EXPECTED_BUILDERS       = 3   # confirmed from artifact_docx.BUILDERS
MIN_FIRST_PARTY_TOOLS   = 3   # xlsx + docx + pptx register one each

# Tier 4 external reachability
TAVERNOS_AI_URL         = "https://tavernos.ai"
FORBIDDEN_STRINGS_IN_HTML = ["dan cooper", "dancooper"]

# Tier 5 calibration thresholds
CALIBRATION_N_FLOOR     = 5     # drift stats need at least this many ratings
CALIBRATION_STALE_DAYS  = 14    # INFO threshold
CALIBRATION_DRIFT_WARN  = 0.3   # weighted_mean_delta above this surfaces WARN

# Email via Resend
RESEND_API_URL          = "https://api.resend.com/emails"

# Severity ordering for sorting / exit codes
LEVELS             = ("PASS", "INFO", "INFO_DEFERRED", "WARN", "FAIL")
_LEVEL_SEVERITY    = {"PASS": 0, "INFO": 1, "INFO_DEFERRED": 1, "WARN": 2, "FAIL": 3}


# ═══════════════════════════════════════════════════════════════════════════════
#  FINDING - the unit of audit output. Suites return list[Finding]. The
#  orchestrator assembles, sorts, persists, and notifies.
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class Finding:
    category: str                   # tier name, e.g. "tier0_static"
    level: str                      # one of LEVELS
    title: str                      # short headline
    detail: str = ""                # longer explanation
    recommendation: str = ""        # optional, attached by RECOMMENDATIONS engine

    def severity(self) -> int:
        return _LEVEL_SEVERITY.get(self.level, 1)

    def hash_key(self) -> str:
        """Stable hash over (category, level, title). Used in session 2 for
        state-change dedupe. Detail is excluded on purpose - 'errors.jsonl
        had 3 entries' vs '5 entries' is the same finding category-wise."""
        raw = f"{self.category}|{self.level}|{self.title}"
        return hashlib.sha1(raw.encode("utf-8")).hexdigest()[:12]


# ═══════════════════════════════════════════════════════════════════════════════
#  RECOMMENDATIONS - rule-based, keyed off (category substring, title
#  substring). First match wins. Extend freely; these are suggestions, not
#  assertions. ~20 rules target per handoff.
# ═══════════════════════════════════════════════════════════════════════════════

RECOMMENDATIONS: list[tuple[str, str, str]] = [
    ("tier0_static", "AST parse",
     "Unfinished edit. Try: python -m py_compile <file> to see the syntax error."),
    ("tier0_static", "RUBRICS count",
     "A rubric was added or removed. Update EXPECTED_RUBRICS in tavernos_audit.py to match intent."),
    ("tier0_static", "BUILDERS count",
     "A docx builder was added or removed. Update EXPECTED_BUILDERS. If this is Phase 5a PRD, expected."),
    ("tier0_static", "FIRST_PARTY_TOOLS",
     "An artifact module failed to register. Check that xlsx/docx/pptx import cleanly from repo root."),
    ("tier0_static", "weight sum",
     "A RubricSpec's dimension weights don't sum to 1.0. Edit evaluator.py and fix the dimension list."),
    ("tier0_static", "import failure",
     "Top-level import failed. Check Python version (3.14 target) and dependency installs."),
    ("tier0_static", "per-client DB missing",
     "Run `python norm.py` once to trigger perf_db_init, or check the slug exists in ~/.tavernos/clients/."),
    ("tier0_static", "global DB missing",
     "Run norm once to initialize ~/.tavernos/skill_performance_global.db."),
    ("tier0_static", "missing tables",
     "DB schema drift. Re-run perf_db_init - it's idempotent and additive."),
    ("tier0_static", "errors.jsonl",
     "Recent errors logged. Inspect with: Get-Content ~/.tavernos/diagnostics/errors.jsonl -Tail 20"),
    ("tier1_fixture", "preflight failed",
     "A preflight gate is firing that didn't before. Check recent edits to artifact_docx.py."),
    ("tier1_fixture", "build failed",
     "Builder regression. Reproduce with: python -c \"import artifact_docx; artifact_docx.build_from_spec({...})\""),
    ("tier1_fixture", "no fixture",
     "No eval_logs/*.json for this deliverable_type. Normal until agents produce real deliverables (Phase 5b)."),
    ("tier1_fixture", "baseline drift",
     "Score drift exceeds threshold. Check evaluator prompt edits. If intentional, update V7_BASELINES."),
    ("tier4_integration", "tavernos.ai unreachable",
     "Landing page down. Check hosting dashboard and DNS. v7 flags this as deferred Phase 1."),
    ("tier4_integration", "placeholder leaked",
     "Forbidden string ('Dan Cooper') still on landing page. Scrub + redeploy."),
    ("tier4_integration", "norm handler",
     "A norm command handler import failed. Check norm.py for signature changes."),
    ("tier5_calibration", "no ratings",
     "Operator calibration is stale. Run `/eval calibrate` on a recent deliverable."),
    ("tier5_calibration", "below n=5",
     "Calibration below reporting floor for this type. Drift numbers aren't trustworthy yet."),
    ("tier5_calibration", "coverage gap",
     "Deliverable type has no row in deliverable_scores. Backfill from eval_logs or produce via agent."),
    ("tier5_calibration", "drift",
     "Operator-vs-evaluator drift exceeds threshold. Review `/eval calibration` output; consider rubric tuning."),
    ("tier6_agent_e2e", "deferred",
     "Tier 6 wires in Phase 5b when agent-prompt reliability work ships. No action required."),
]


def attach_recommendation(finding: Finding) -> None:
    """Attach the first matching recommendation. Mutates in place. No-op
    if a recommendation is already set (tier author wanted a specific one)."""
    if finding.recommendation:
        return
    title_lc = finding.title.lower()
    cat_lc = finding.category.lower()
    for cat_sub, title_sub, rec in RECOMMENDATIONS:
        if cat_sub.lower() in cat_lc and title_sub.lower() in title_lc:
            finding.recommendation = rec
            return


# ═══════════════════════════════════════════════════════════════════════════════
#  SUITE - base class. Each tier subclasses and implements run().
#  The orchestrator wraps every run() in try/except so one tier crashing
#  never breaks another. Uncaught exceptions become FAIL findings.
# ═══════════════════════════════════════════════════════════════════════════════

class Suite:
    name: str = "base"

    def __init__(self, repo_root: Path, full: bool = False) -> None:
        self.repo_root = repo_root
        self.full = full

    def run(self) -> list[Finding]:
        raise NotImplementedError


# ═══════════════════════════════════════════════════════════════════════════════
#  TIER 0 - STATIC (<5s). No LLM, no network, no subprocess. Pure import
#  and inspection. This is the suite that should always run and always
#  be fast; it's the canary for "something structural broke."
# ═══════════════════════════════════════════════════════════════════════════════

class Tier0Static(Suite):
    name = "tier0_static"

    def run(self) -> list[Finding]:
        out: list[Finding] = []
        out += self._ast_parse_repo()
        out += self._import_checks()
        out += self._db_schema_checks()
        out += self._errors_jsonl_scan()
        return out

    def _ast_parse_repo(self) -> list[Finding]:
        """Parse every .py at repo root. Does NOT recurse - convention."""
        findings: list[Finding] = []
        py_files = sorted(self.repo_root.glob("*.py"))
        if not py_files:
            return [Finding(
                category=self.name, level="WARN",
                title="No Python files at repo root",
                detail=f"Expected .py files in {self.repo_root}. Wrong working directory?",
            )]
        parsed = 0
        for path in py_files:
            try:
                ast.parse(path.read_text(encoding="utf-8"))
                parsed += 1
            except SyntaxError as e:
                findings.append(Finding(
                    category=self.name, level="FAIL",
                    title=f"AST parse failed: {path.name}",
                    detail=f"Line {e.lineno}: {e.msg}",
                ))
            except Exception as e:
                findings.append(Finding(
                    category=self.name, level="FAIL",
                    title=f"AST parse failed: {path.name}",
                    detail=f"{type(e).__name__}: {e}",
                ))
        if not findings:
            findings.append(Finding(
                category=self.name, level="PASS",
                title="AST parse clean",
                detail=f"{parsed} .py files at repo root parsed without error.",
            ))
        return findings

    def _import_checks(self) -> list[Finding]:
        """Import evaluator, artifact_docx, norm. Check headline counts."""
        findings: list[Finding] = []
        # Ensure repo root is on sys.path for the audit run
        if str(self.repo_root) not in sys.path:
            sys.path.insert(0, str(self.repo_root))

        modules: dict[str, Any] = {}
        for name in ("evaluator", "artifact_docx", "norm"):
            try:
                modules[name] = __import__(name)
            except Exception as e:
                findings.append(Finding(
                    category=self.name, level="FAIL",
                    title=f"Import failure: {name}",
                    detail=f"{type(e).__name__}: {e}",
                ))
        if "evaluator" not in modules or "artifact_docx" not in modules or "norm" not in modules:
            # Without these we can't check counts, weight sums, or DB schema.
            # Bail early with what we have.
            return findings

        evaluator = modules["evaluator"]
        artifact_docx = modules["artifact_docx"]
        norm = modules["norm"]

        # RUBRICS count
        n_rubrics = len(getattr(evaluator, "RUBRICS", {}))
        if n_rubrics == EXPECTED_RUBRICS:
            findings.append(Finding(
                category=self.name, level="PASS",
                title=f"RUBRICS count == {EXPECTED_RUBRICS}",
            ))
        else:
            findings.append(Finding(
                category=self.name, level="WARN",
                title=f"RUBRICS count drift: {n_rubrics} (expected {EXPECTED_RUBRICS})",
                detail=f"Keys present: {sorted(evaluator.RUBRICS.keys())}",
            ))

        # BUILDERS count
        n_builders = len(getattr(artifact_docx, "BUILDERS", {}))
        if n_builders == EXPECTED_BUILDERS:
            findings.append(Finding(
                category=self.name, level="PASS",
                title=f"BUILDERS count == {EXPECTED_BUILDERS}",
            ))
        else:
            findings.append(Finding(
                category=self.name, level="WARN",
                title=f"BUILDERS count drift: {n_builders} (expected {EXPECTED_BUILDERS})",
                detail=f"Keys present: {sorted(artifact_docx.BUILDERS.keys())}",
            ))

        # FIRST_PARTY_TOOLS - populated by _register_first_party_tools, idempotent
        try:
            if hasattr(norm, "_register_first_party_tools"):
                norm._register_first_party_tools()
            n_tools = len(getattr(norm, "FIRST_PARTY_TOOLS", {}))
            if n_tools >= MIN_FIRST_PARTY_TOOLS:
                findings.append(Finding(
                    category=self.name, level="PASS",
                    title=f"FIRST_PARTY_TOOLS registered: {n_tools}",
                ))
            else:
                findings.append(Finding(
                    category=self.name, level="WARN",
                    title=f"FIRST_PARTY_TOOLS underpopulated: {n_tools} (expected >= {MIN_FIRST_PARTY_TOOLS})",
                    detail=f"Names: {sorted(norm.FIRST_PARTY_TOOLS.keys())}",
                ))
        except Exception as e:
            findings.append(Finding(
                category=self.name, level="WARN",
                title="FIRST_PARTY_TOOLS registration raised",
                detail=f"{type(e).__name__}: {e}",
            ))

        # Per-rubric weight sum ~ 1.0
        for key, rubric in getattr(evaluator, "RUBRICS", {}).items():
            try:
                total = sum(d.weight for d in rubric.dimensions)
                if 0.99 <= total <= 1.01:
                    continue  # PASS - don't spam individual PASS lines
                findings.append(Finding(
                    category=self.name, level="FAIL",
                    title=f"Rubric weight sum: {key}",
                    detail=f"Dimension weights sum to {total:.4f}, expected 1.0 (tolerance 0.01).",
                ))
            except Exception as e:
                findings.append(Finding(
                    category=self.name, level="WARN",
                    title=f"Rubric weight inspection failed: {key}",
                    detail=f"{type(e).__name__}: {e}",
                ))

        # Aggregate PASS for weight sums if no FAILs
        rubric_fails = [f for f in findings if "weight sum" in f.title.lower()]
        if not rubric_fails and n_rubrics > 0:
            findings.append(Finding(
                category=self.name, level="PASS",
                title=f"Rubric weight sums all ~1.0 ({n_rubrics} rubrics)",
            ))

        return findings

    def _db_schema_checks(self) -> list[Finding]:
        """Check per-client DB (_self) and global DB exist and have expected tables."""
        findings: list[Finding] = []

        # Per-client for _self (canonical dogfood)
        per_client = CLIENTS_DIR / DEFAULT_CLIENT_SLUG / "memory" / "skill_performance.db"
        if not per_client.exists():
            findings.append(Finding(
                category=self.name, level="WARN",
                title=f"per-client DB missing: {DEFAULT_CLIENT_SLUG}",
                detail=f"Expected {per_client}. Run norm once to initialize.",
            ))
        else:
            missing = self._missing_tables(per_client, PER_CLIENT_TABLES)
            if missing:
                findings.append(Finding(
                    category=self.name, level="WARN",
                    title=f"per-client DB missing tables: {DEFAULT_CLIENT_SLUG}",
                    detail=f"Missing: {sorted(missing)}. Expected all of: {sorted(PER_CLIENT_TABLES)}",
                ))
            else:
                findings.append(Finding(
                    category=self.name, level="PASS",
                    title=f"per-client DB schema OK: {DEFAULT_CLIENT_SLUG}",
                ))

        # Global DB
        if not GLOBAL_DB.exists():
            findings.append(Finding(
                category=self.name, level="WARN",
                title="global DB missing",
                detail=f"Expected {GLOBAL_DB}. Run norm once to initialize.",
            ))
        else:
            missing = self._missing_tables(GLOBAL_DB, GLOBAL_TABLES)
            if missing:
                findings.append(Finding(
                    category=self.name, level="WARN",
                    title="global DB missing tables",
                    detail=f"Missing: {sorted(missing)}. Expected all of: {sorted(GLOBAL_TABLES)}",
                ))
            else:
                findings.append(Finding(
                    category=self.name, level="PASS",
                    title="global DB schema OK",
                ))

        # List all client DBs that exist, surface as INFO
        if CLIENTS_DIR.exists():
            slugs = []
            for child in sorted(CLIENTS_DIR.iterdir()):
                if not child.is_dir():
                    continue
                if child.name.startswith("_") and child.name not in (DEFAULT_CLIENT_SLUG,):
                    continue  # _archived, _active-file-not-dir, etc.
                db = child / "memory" / "skill_performance.db"
                if db.exists():
                    slugs.append(child.name)
            if slugs and slugs != [DEFAULT_CLIENT_SLUG]:
                findings.append(Finding(
                    category=self.name, level="INFO",
                    title=f"clients on disk: {len(slugs)}",
                    detail=f"Slugs: {slugs}",
                ))

        return findings

    @staticmethod
    def _missing_tables(db_path: Path, expected: set[str]) -> set[str]:
        try:
            con = sqlite3.connect(str(db_path))
            rows = con.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ).fetchall()
            con.close()
            present = {r[0] for r in rows}
            return expected - present
        except Exception:
            return expected  # worst case: treat as all missing

    def _errors_jsonl_scan(self) -> list[Finding]:
        """Scan errors.jsonl for entries in the last 24h. An empty or missing
        journal is fine - it just means nothing has been logged there yet."""
        if not ERRORS_JOURNAL.exists():
            return [Finding(
                category=self.name, level="INFO",
                title="errors.jsonl not yet written",
                detail=f"{ERRORS_JOURNAL} does not exist. Trivially empty.",
            )]
        cutoff = datetime.now(timezone.utc) - timedelta(hours=24)
        recent: list[dict] = []
        malformed = 0
        try:
            for line in ERRORS_JOURNAL.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                except Exception:
                    malformed += 1
                    continue
                ts_str = entry.get("ts") or entry.get("timestamp") or ""
                try:
                    ts = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
                    if ts.tzinfo is None:
                        ts = ts.replace(tzinfo=timezone.utc)
                except Exception:
                    continue
                if ts >= cutoff:
                    recent.append(entry)
        except Exception as e:
            return [Finding(
                category=self.name, level="WARN",
                title="errors.jsonl read failed",
                detail=f"{type(e).__name__}: {e}",
            )]

        findings: list[Finding] = []
        if malformed:
            findings.append(Finding(
                category=self.name, level="INFO",
                title=f"errors.jsonl malformed lines: {malformed}",
                detail="Journal has non-JSON lines. Not critical, but worth a look.",
            ))
        if recent:
            sample = recent[-3:] if len(recent) > 3 else recent
            sample_str = "\n".join(
                f"  - {e.get('ts', '?')} {e.get('kind', '?')}: {str(e)[:120]}"
                for e in sample
            )
            findings.append(Finding(
                category=self.name, level="WARN",
                title=f"errors.jsonl has {len(recent)} recent entries (last 24h)",
                detail=f"Sample:\n{sample_str}",
            ))
        else:
            findings.append(Finding(
                category=self.name, level="PASS",
                title="errors.jsonl clean (last 24h)",
            ))
        return findings


# ═══════════════════════════════════════════════════════════════════════════════
#  TIER 1 - FIXTURE REPLAY (<2 min, --dry-run default). For each deliverable
#  type that has an eval_logs/*.json available, extract the spec, run
#  preflight + in-memory build, and emit regression findings. --full adds
#  baseline drift by comparing the logged score to V7_BASELINES.
# ═══════════════════════════════════════════════════════════════════════════════

class Tier1Fixture(Suite):
    name = "tier1_fixture"

    def run(self) -> list[Finding]:
        out: list[Finding] = []
        eval_logs_dir = self.repo_root / "eval_logs"
        if not eval_logs_dir.exists():
            return [Finding(
                category=self.name, level="INFO",
                title="no fixture source: eval_logs/ missing",
                detail=f"{eval_logs_dir} does not exist. Expected for types without "
                       f"historical runs. Backfill or produce via agent to populate.",
            )]

        # Group logs by deliverable type; pick most recent per type.
        by_type = self._group_latest_per_type(eval_logs_dir)
        if not by_type:
            return [Finding(
                category=self.name, level="INFO",
                title="no fixture source: eval_logs/ empty or unparseable",
                detail=f"{eval_logs_dir} has no parseable *.json files.",
            )]

        # Check for artifact_docx builder availability (fail gracefully if not)
        try:
            sys.path.insert(0, str(self.repo_root))
            import artifact_docx
        except Exception as e:
            return [Finding(
                category=self.name, level="FAIL",
                title="artifact_docx import failed",
                detail=f"{type(e).__name__}: {e}",
            )]

        for dtype, entry in sorted(by_type.items()):
            out += self._replay_one(dtype, entry, artifact_docx)

        # Coverage INFO: which expected types had no fixture
        covered = set(by_type.keys())
        expected_types = set(V7_BASELINES.keys())
        gaps = sorted(expected_types - covered)
        if gaps:
            out.append(Finding(
                category=self.name, level="INFO",
                title=f"no fixture for {len(gaps)} deliverable types",
                detail=f"Types without eval_logs: {gaps}. Expected until agents produce them.",
            ))
        return out

    @staticmethod
    def _group_latest_per_type(eval_logs_dir: Path) -> dict[str, dict]:
        """Read every eval_logs/*.json and pick the most recent per type.
        Tolerates missing fields; skips files that don't look like eval logs."""
        latest: dict[str, tuple[float, Path, dict]] = {}
        for path in eval_logs_dir.glob("*.json"):
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                continue
            dtype = data.get("deliverable_type") or data.get("template")
            if not dtype:
                continue
            mtime = path.stat().st_mtime
            if dtype not in latest or mtime > latest[dtype][0]:
                latest[dtype] = (mtime, path, data)
        return {k: {"path": v[1], "data": v[2]} for k, v in latest.items()}

    def _replay_one(self, dtype: str, entry: dict, artifact_docx: Any) -> list[Finding]:
        """Preflight + in-memory build for one deliverable type. Baseline
        drift check only when --full (requires the logged score, no LLM)."""
        out: list[Finding] = []
        data = entry["data"]
        path = entry["path"]

        # Spec extraction - eval_logs format is not fully specified. Try
        # common shapes; if none match, emit a diagnostic WARN with the
        # actual top-level keys so we can see the real shape without paste.
        spec = (
            data.get("spec")
            or data.get("deliverable_spec")
            or data.get("artifact_spec")
            or data.get("input_spec")
            or data.get("payload")
            or (data.get("request") or {}).get("spec")
            or (data.get("input") or {}).get("spec")
        )
        if spec is None:
            keys_found = sorted(data.keys()) if isinstance(data, dict) else [type(data).__name__]
            return [Finding(
                category=self.name, level="WARN",
                title=f"no fixture spec: {dtype}",
                detail=(f"eval_log {path.name} has no recognizable spec field.\n"
                        f"Top-level keys found: {keys_found}\n"
                        f"Audit tried: spec, deliverable_spec, artifact_spec, "
                        f"input_spec, payload, request.spec, input.spec.\n"
                        f"Fix: add the real key to Tier1Fixture._replay_one, "
                        f"or add a 'spec' alias when writing eval_logs."),
            )]

        # Preflight
        if hasattr(artifact_docx, "preflight") and dtype in getattr(artifact_docx, "BUILDERS", {}):
            try:
                issues = artifact_docx.preflight(spec)
                if issues:
                    out.append(Finding(
                        category=self.name, level="WARN",
                        title=f"preflight failed: {dtype}",
                        detail=f"Issues: {issues}",
                    ))
                else:
                    out.append(Finding(
                        category=self.name, level="PASS",
                        title=f"preflight clean: {dtype}",
                    ))
            except Exception as e:
                out.append(Finding(
                    category=self.name, level="FAIL",
                    title=f"preflight raised: {dtype}",
                    detail=f"{type(e).__name__}: {e}",
                ))

            # In-memory build via BUILDERS dict (bypasses _resolve_output_path)
            try:
                builder = artifact_docx.BUILDERS[dtype]
                doc = builder(spec)
                # Light smoke check: the doc object should exist
                if doc is None:
                    out.append(Finding(
                        category=self.name, level="FAIL",
                        title=f"build returned None: {dtype}",
                    ))
                else:
                    out.append(Finding(
                        category=self.name, level="PASS",
                        title=f"in-memory build OK: {dtype}",
                    ))
            except Exception as e:
                out.append(Finding(
                    category=self.name, level="FAIL",
                    title=f"build failed: {dtype}",
                    detail=f"{type(e).__name__}: {e}\n{traceback.format_exc()[:400]}",
                ))
        else:
            # xlsx/pptx types handled elsewhere; emit INFO not WARN
            out.append(Finding(
                category=self.name, level="INFO",
                title=f"no docx builder for {dtype}",
                detail="Type is served by xlsx/pptx or not yet built. Session-2 Tier 1 expansion covers other modules.",
            ))

        # Baseline drift - only when --full, since it relies on the logged score
        if self.full and dtype in V7_BASELINES:
            logged_score = (
                data.get("weighted_avg")
                or data.get("weighted_average")
                or (data.get("result") or {}).get("weighted_avg")
            )
            if isinstance(logged_score, (int, float)):
                delta = logged_score - V7_BASELINES[dtype]
                if abs(delta) >= BASELINE_DRIFT_FAIL:
                    level = "FAIL"
                elif abs(delta) >= BASELINE_DRIFT_WARN:
                    level = "WARN"
                else:
                    level = "PASS"
                out.append(Finding(
                    category=self.name, level=level,
                    title=f"baseline drift: {dtype} delta={delta:+.3f}",
                    detail=f"Logged={logged_score:.3f}, v7 baseline={V7_BASELINES[dtype]:.3f}. "
                           f"Thresholds: WARN>={BASELINE_DRIFT_WARN}, FAIL>={BASELINE_DRIFT_FAIL}.",
                ))

        return out


# ═══════════════════════════════════════════════════════════════════════════════
#  TIER 2 STUB - MBR weekly variance. Deferred to session 2.
# ═══════════════════════════════════════════════════════════════════════════════

class Tier2MBR(Suite):
    name = "tier2_mbr"

    def run(self) -> list[Finding]:
        return [Finding(
            category=self.name, level="INFO_DEFERRED",
            title="Tier 2 (MBR variance) deferred to session 2",
            detail="3-run MBR per type, spread vs historical bounds. Burns real tokens; "
                   "scheduled weekly. Session 2 wires this + trend analysis.",
        )]


# ═══════════════════════════════════════════════════════════════════════════════
#  TIER 3 STUB - preflight break-fixture regression harness. Deferred.
# ═══════════════════════════════════════════════════════════════════════════════

class Tier3PreflightRegression(Suite):
    name = "tier3_preflight_regression"

    def run(self) -> list[Finding]:
        return [Finding(
            category=self.name, level="INFO_DEFERRED",
            title="Tier 3 (preflight regression) deferred to session 2",
            detail="Deliberately-broken fixture per gate (13 gates: P2/P3/P5, A2-A7, R2-R7). "
                   "Confirms each trips as designed. Session 2 builds the break-fixture set.",
        )]


# ═══════════════════════════════════════════════════════════════════════════════
#  TIER 4 - INTEGRATION. tavernos.ai reachability + Dan Cooper scrub, norm
#  handler probe (direct import, not subprocess - the handoff flagged
#  stdin piping as fiddly on PS 5; session 2 can add subprocess if needed).
# ═══════════════════════════════════════════════════════════════════════════════

class Tier4Integration(Suite):
    name = "tier4_integration"

    def run(self) -> list[Finding]:
        return self._reachability() + self._norm_handlers()

    def _reachability(self) -> list[Finding]:
        out: list[Finding] = []
        try:
            req = urllib.request.Request(
                TAVERNOS_AI_URL,
                headers={"User-Agent": "tavernos-audit/1.0"},
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                status = resp.status
                body = resp.read(200_000).decode("utf-8", errors="replace")
            if status != 200:
                out.append(Finding(
                    category=self.name, level="WARN",
                    title=f"tavernos.ai unreachable: HTTP {status}",
                ))
            else:
                out.append(Finding(
                    category=self.name, level="PASS",
                    title="tavernos.ai reachable (HTTP 200)",
                ))
                body_lc = body.lower()
                found = [s for s in FORBIDDEN_STRINGS_IN_HTML if s in body_lc]
                if found:
                    out.append(Finding(
                        category=self.name, level="WARN",
                        title=f"placeholder leaked in HTML: {found}",
                        detail="Forbidden strings present. Scrub and redeploy.",
                    ))
                else:
                    out.append(Finding(
                        category=self.name, level="PASS",
                        title="tavernos.ai HTML clean (no 'Dan Cooper' substring)",
                    ))
        except urllib.error.URLError as e:
            out.append(Finding(
                category=self.name, level="WARN",
                title="tavernos.ai unreachable",
                detail=f"URLError: {e.reason}. Could be DNS, SSL, or server down.",
            ))
        except Exception as e:
            out.append(Finding(
                category=self.name, level="WARN",
                title="tavernos.ai reachability check raised",
                detail=f"{type(e).__name__}: {e}",
            ))
        return out

    def _norm_handlers(self) -> list[Finding]:
        """Import norm and check that key handler functions still exist. This
        is a shallow smoke test; session 2 can add the full subprocess probe."""
        out: list[Finding] = []
        try:
            sys.path.insert(0, str(self.repo_root))
            import norm
        except Exception as e:
            return [Finding(
                category=self.name, level="FAIL",
                title="norm handler import failed",
                detail=f"{type(e).__name__}: {e}",
            )]

        # Spot-check names that the /scores + /eval calibration surfaces use.
        # Names drawn from the v7 'Command surface' section.
        expected_callables = [
            "handle_eval_calibrate",
            "show_calibration_report",
            "_perf_db_path",
            "_perf_global_db_path",
            "get_active_client_slug",
        ]
        missing = [n for n in expected_callables if not hasattr(norm, n)]
        if missing:
            out.append(Finding(
                category=self.name, level="WARN",
                title=f"norm handler symbols missing: {len(missing)}",
                detail=f"Missing: {missing}. Either renamed or removed - check recent edits.",
            ))
        else:
            out.append(Finding(
                category=self.name, level="PASS",
                title=f"norm handlers present ({len(expected_callables)} checked)",
            ))
        return out


# ═══════════════════════════════════════════════════════════════════════════════
#  TIER 5 - CALIBRATION HEALTH. Total ratings, per-type floors, drift,
#  coverage gaps, staleness.
# ═══════════════════════════════════════════════════════════════════════════════

class Tier5CalibrationHealth(Suite):
    name = "tier5_calibration"

    def run(self) -> list[Finding]:
        out: list[Finding] = []
        try:
            sys.path.insert(0, str(self.repo_root))
            import evaluator
        except Exception as e:
            return [Finding(
                category=self.name, level="FAIL",
                title="evaluator import failed",
                detail=f"{type(e).__name__}: {e}",
            )]

        perf_db = CLIENTS_DIR / DEFAULT_CLIENT_SLUG / "memory" / "skill_performance.db"
        if not perf_db.exists():
            return [Finding(
                category=self.name, level="WARN",
                title="per-client DB missing - calibration data unavailable",
                detail=f"Expected {perf_db}.",
            )]

        # Coverage: which types have a row in deliverable_scores?
        out += self._coverage(perf_db)
        # Drift + n-floor + staleness via compute_calibration_drift
        out += self._drift(perf_db, evaluator)
        return out

    def _coverage(self, perf_db: Path) -> list[Finding]:
        out: list[Finding] = []
        try:
            con = sqlite3.connect(str(perf_db))
            rows = con.execute(
                "SELECT DISTINCT deliverable_type FROM deliverable_scores"
            ).fetchall()
            con.close()
            present = {r[0] for r in rows if r[0]}
        except Exception as e:
            return [Finding(
                category=self.name, level="WARN",
                title="coverage query failed",
                detail=f"{type(e).__name__}: {e}",
            )]

        expected = set(V7_BASELINES.keys())
        gaps = sorted(expected - present)
        if gaps:
            out.append(Finding(
                category=self.name, level="INFO",
                title=f"coverage gap: {len(gaps)} of {len(expected)} types missing",
                detail=f"Missing from deliverable_scores: {gaps}. "
                       f"Backfill from eval_logs or produce via agent (Phase 5b).",
            ))
        else:
            out.append(Finding(
                category=self.name, level="PASS",
                title="coverage complete (all 5 types in deliverable_scores)",
            ))
        return out

    def _drift(self, perf_db: Path, evaluator: Any) -> list[Finding]:
        out: list[Finding] = []
        try:
            drift = evaluator.compute_calibration_drift(
                perf_db, min_n_per_type=CALIBRATION_N_FLOOR
            )
        except Exception as e:
            return [Finding(
                category=self.name, level="WARN",
                title="compute_calibration_drift raised",
                detail=f"{type(e).__name__}: {e}",
            )]

        total = drift.get("total_ratings", 0)
        by_type = drift.get("by_type", {})
        if total == 0:
            out.append(Finding(
                category=self.name, level="INFO",
                title="no ratings: 0 calibrations in DB",
                detail="No operator ratings recorded. Run `/eval calibrate` to start.",
            ))
            return out

        out.append(Finding(
            category=self.name, level="INFO",
            title=f"total calibrations: {total}",
            detail=f"Types with ratings: {sorted(by_type.keys())}.",
        ))

        for dtype, te in by_type.items():
            n = te.get("n", 0)
            below = te.get("below_floor", False)
            wavg_delta = te.get("weighted_mean_delta", 0.0)
            biggest = te.get("biggest_drift_dim")  # (dim_name, delta) or None

            if below:
                out.append(Finding(
                    category=self.name, level="INFO",
                    title=f"{dtype}: below n=5 floor (n={n})",
                    detail="Drift numbers present but not trustworthy until n>=5.",
                ))
            if abs(wavg_delta) >= CALIBRATION_DRIFT_WARN and not below:
                out.append(Finding(
                    category=self.name, level="WARN",
                    title=f"{dtype}: weighted drift {wavg_delta:+.3f}",
                    detail=f"n={n}, biggest drift dim={biggest}. "
                           f"Threshold: WARN at |delta|>={CALIBRATION_DRIFT_WARN}.",
                ))
            elif biggest and not below:
                dim_name, dim_delta = biggest
                if abs(dim_delta) >= CALIBRATION_DRIFT_WARN:
                    out.append(Finding(
                        category=self.name, level="INFO",
                        title=f"{dtype}: per-dim drift on {dim_name} = {dim_delta:+.3f}",
                        detail=f"n={n}, weighted_mean_delta={wavg_delta:+.3f}.",
                    ))

        # Staleness: most recent calibration timestamp
        out += self._staleness(perf_db)
        return out

    def _staleness(self, perf_db: Path) -> list[Finding]:
        try:
            con = sqlite3.connect(str(perf_db))
            row = con.execute(
                "SELECT MAX(ts) FROM deliverable_calibration"
            ).fetchone()
            con.close()
        except Exception:
            return []
        if not row or not row[0]:
            return []
        try:
            last = datetime.fromisoformat(row[0].replace("Z", "+00:00"))
            if last.tzinfo is None:
                last = last.replace(tzinfo=timezone.utc)
        except Exception:
            return []
        days = (datetime.now(timezone.utc) - last).days
        if days >= CALIBRATION_STALE_DAYS:
            return [Finding(
                category=self.name, level="INFO",
                title=f"no ratings in {days} days",
                detail=f"Last calibration: {last.isoformat()}. Consider running `/eval calibrate`.",
            )]
        return [Finding(
            category=self.name, level="PASS",
            title=f"calibration fresh: last rating {days}d ago",
        )]


# ═══════════════════════════════════════════════════════════════════════════════
#  TIER 6 STUB - agent-prompt E2E. Deferred to Phase 5b.
# ═══════════════════════════════════════════════════════════════════════════════

class Tier6AgentE2E(Suite):
    name = "tier6_agent_e2e"

    def run(self) -> list[Finding]:
        return [Finding(
            category=self.name, level="INFO_DEFERRED",
            title="Tier 6 (agent E2E) deferred to Phase 5b",
            detail="Routes a canned request through Sam -> agent -> builder -> eval, "
                   "confirms a persisted deliverable_scores row. Wires when agent-prompt "
                   "production reliability work ships.",
        )]


# ═══════════════════════════════════════════════════════════════════════════════
#  NOTIFIERS - StdoutNotifier always runs. EmailNotifier via Resend when
#  configured. Add SlackNotifier in session 2 if still wanted.
# ═══════════════════════════════════════════════════════════════════════════════

class StdoutNotifier:
    def send(self, markdown: str, subject: str) -> tuple[bool, str]:
        sys.stdout.write(markdown)
        if not markdown.endswith("\n"):
            sys.stdout.write("\n")
        sys.stdout.flush()
        return True, "stdout"


class EmailNotifier:
    """Resend API sender. Config required:
        audit.provider         = "resend"
        audit.resend_api_key   = "re_..."
        audit.from_address     = "onboarding@resend.dev" until DNS verified, then alerts@tavernos.ai
        audit.to_address       = "alerts@tavernos.ai"
    """

    def __init__(self, cfg: dict) -> None:
        self.api_key = cfg.get("resend_api_key", "")
        self.from_addr = cfg.get("from_address", "onboarding@resend.dev")
        self.to_addr = cfg.get("to_address", "")

    def send(self, markdown: str, subject: str) -> tuple[bool, str]:
        if not self.api_key:
            return False, "EmailNotifier: missing resend_api_key in config"
        if not self.to_addr:
            return False, "EmailNotifier: missing to_address in config"

        # Render markdown as plain text + a minimal HTML wrapper so Gmail
        # renders code blocks legibly without a full markdown->HTML pass.
        html = (
            "<html><body><pre style='font-family:Consolas,Menlo,monospace;"
            "font-size:13px;line-height:1.4;white-space:pre-wrap;'>"
            + _html_escape(markdown)
            + "</pre></body></html>"
        )
        payload = json.dumps({
            "from":    self.from_addr,
            "to":      [self.to_addr],
            "subject": subject,
            "text":    markdown,
            "html":    html,
        }).encode("utf-8")
        req = urllib.request.Request(
            RESEND_API_URL, data=payload, method="POST",
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type":  "application/json",
                "User-Agent":    "tavernos-audit/1.0",
            },
        )
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                body = resp.read().decode("utf-8", errors="replace")
                if 200 <= resp.status < 300:
                    return True, f"Resend OK ({resp.status}): {body[:80]}"
                return False, f"Resend HTTP {resp.status}: {body[:200]}"
        except urllib.error.HTTPError as e:
            err_body = ""
            try:
                err_body = e.read().decode("utf-8", errors="replace")[:300]
            except Exception:
                pass
            return False, f"Resend HTTPError {e.code}: {err_body}"
        except Exception as e:
            return False, f"Resend send raised: {type(e).__name__}: {e}"


def _html_escape(s: str) -> str:
    return (s.replace("&", "&amp;").replace("<", "&lt;")
             .replace(">", "&gt;").replace('"', "&quot;"))


# ═══════════════════════════════════════════════════════════════════════════════
#  REPORT ASSEMBLY - markdown for stdout + email, JSON for persistence.
# ═══════════════════════════════════════════════════════════════════════════════

def assemble_markdown(findings: list[Finding], run_id: str, full: bool) -> str:
    counts = {lvl: 0 for lvl in LEVELS}
    for f in findings:
        counts[f.level] = counts.get(f.level, 0) + 1

    overall = "PASS"
    if counts.get("FAIL", 0) > 0:
        overall = "FAIL"
    elif counts.get("WARN", 0) > 0:
        overall = "WARN"

    lines: list[str] = []
    lines.append(f"# TavernOS audit - {run_id}")
    lines.append("")
    lines.append(f"**Overall:** {overall}  |  **Mode:** {'full' if full else 'standard'}")
    lines.append("")
    lines.append(
        f"FAIL: {counts['FAIL']}   WARN: {counts['WARN']}   "
        f"PASS: {counts['PASS']}   INFO: {counts['INFO']}   "
        f"INFO_DEFERRED: {counts['INFO_DEFERRED']}"
    )
    lines.append("")

    # Order: within each category, FAIL > WARN > INFO > INFO_DEFERRED > PASS.
    # Primary sort is category (so each ## header appears exactly once),
    # secondary is severity-descending within the category, tertiary by title.
    sev_order = {"FAIL": 0, "WARN": 1, "INFO": 2, "INFO_DEFERRED": 3, "PASS": 4}
    findings_sorted = sorted(
        findings,
        key=lambda f: (f.category, sev_order.get(f.level, 9), f.title),
    )

    current_cat = None
    for f in findings_sorted:
        if f.category != current_cat:
            current_cat = f.category
            lines.append("")
            lines.append(f"## {current_cat}")
            lines.append("")
        lines.append(f"- **{f.level}**: {f.title}")
        if f.detail:
            for dl in f.detail.splitlines():
                lines.append(f"      {dl}")
        if f.recommendation:
            lines.append(f"      > recommendation: {f.recommendation}")
    lines.append("")
    return "\n".join(lines)


def persist_run(findings: list[Finding], run_id: str, full: bool) -> Path:
    AUDIT_RUNS_DIR.mkdir(parents=True, exist_ok=True)
    path = AUDIT_RUNS_DIR / f"audit_{run_id}.json"
    payload = {
        "run_id":   run_id,
        "ts_utc":   datetime.now(timezone.utc).isoformat(),
        "mode":     "full" if full else "standard",
        "findings": [asdict(f) for f in findings],
    }
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return path


# ═══════════════════════════════════════════════════════════════════════════════
#  ORCHESTRATOR
# ═══════════════════════════════════════════════════════════════════════════════

SUITES: list[type[Suite]] = [
    Tier0Static,
    Tier1Fixture,
    Tier2MBR,
    Tier3PreflightRegression,
    Tier4Integration,
    Tier5CalibrationHealth,
    Tier6AgentE2E,
]


def run_audit(repo_root: Path, full: bool) -> list[Finding]:
    findings: list[Finding] = []
    for cls in SUITES:
        tier_name = getattr(cls, "name", cls.__name__)
        t0 = time.time()
        try:
            suite = cls(repo_root, full=full)
            tier_findings = suite.run()
        except Exception as e:
            tier_findings = [Finding(
                category=tier_name, level="FAIL",
                title="tier runner crashed",
                detail=f"Uncaught: {type(e).__name__}: {e}\n{traceback.format_exc()[:500]}",
            )]
        dt = time.time() - t0
        tier_findings.append(Finding(
            category=tier_name, level="INFO",
            title=f"runtime: {dt:.2f}s",
        ))
        findings.extend(tier_findings)
    for f in findings:
        attach_recommendation(f)
    return findings


def load_config() -> dict:
    if not CONFIG_FILE.exists():
        return {}
    try:
        return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def subject_line(findings: list[Finding], run_id: str) -> str:
    counts = {lvl: 0 for lvl in LEVELS}
    for f in findings:
        counts[f.level] = counts.get(f.level, 0) + 1
    overall = "PASS"
    if counts.get("FAIL", 0) > 0:
        overall = "FAIL"
    elif counts.get("WARN", 0) > 0:
        overall = "WARN"
    return (f"[TavernOS audit] {overall} - "
            f"{counts['FAIL']}F {counts['WARN']}W {counts['PASS']}P - {run_id}")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="tavernos_audit",
        description="TavernOS health check suite. Weekly by default.",
    )
    parser.add_argument(
        "--full", action="store_true",
        help="Run expensive tiers (Tier 1 baseline drift, future Tier 2 MBR).",
    )
    parser.add_argument(
        "--notifier", choices=["stdout", "email", "both"], default=None,
        help="Override config notifier setting. 'stdout' is the safe default for smoke tests.",
    )
    parser.add_argument(
        "--repo", default=None,
        help="Override repo root (default: directory containing this script).",
    )
    args = parser.parse_args(argv)

    repo_root = Path(args.repo).resolve() if args.repo else REPO_ROOT
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")

    findings = run_audit(repo_root, full=args.full)
    md = assemble_markdown(findings, run_id, args.full)

    # Persist JSON unconditionally
    json_path = persist_run(findings, run_id, args.full)

    # Notifier selection: CLI flag > config > stdout
    cfg = load_config().get("audit", {}) or {}
    notifier_kind = args.notifier or cfg.get("notifier") or "stdout"

    dispatches: list[tuple[str, bool, str]] = []
    if notifier_kind in ("stdout", "both"):
        ok, info = StdoutNotifier().send(md, subject_line(findings, run_id))
        dispatches.append(("stdout", ok, info))
    if notifier_kind in ("email", "both"):
        if cfg.get("provider") == "resend":
            ok, info = EmailNotifier(cfg).send(md, subject_line(findings, run_id))
        else:
            ok, info = False, "email notifier requested but 'audit.provider' != 'resend' in config"
        dispatches.append(("email", ok, info))

    # Footer: persistence + dispatch summary. Goes to stderr so it doesn't
    # mix into a captured stdout report.
    sys.stderr.write(f"\n[audit] persisted: {json_path}\n")
    for kind, ok, info in dispatches:
        marker = "OK" if ok else "FAIL"
        sys.stderr.write(f"[audit] notifier {kind}: {marker} - {info}\n")

    # Exit code: 0 on PASS/INFO only, 1 on WARN, 2 on FAIL. Useful for Task
    # Scheduler or CI to detect problems without parsing the report.
    max_sev = max((f.severity() for f in findings), default=0)
    return {0: 0, 1: 0, 2: 1, 3: 2}.get(max_sev, 0)


if __name__ == "__main__":
    sys.exit(main())
