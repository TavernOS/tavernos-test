"""
TavernOS MCP client — Model Context Protocol integration.

Wraps the official `mcp` Python SDK to expose tools from locally-spawned
MCP server subprocesses to the TavernOS agent pipeline in norm.py.

Design notes:
- One daemon thread owns a single persistent asyncio event loop.
- One AsyncExitStack per server manages its stdio_client + ClientSession.
- Sync callers submit coroutines via asyncio.run_coroutine_threadsafe.
- Tool names are normalized to `mcp_{server}_{tool}` to dodge collisions
  with native tools (e.g. Anthropic's `web_search`) and stay inside
  Anthropic's tool-name regex: ^[a-zA-Z0-9_-]{1,64}$

Config file: ~/.tavernos/mcp_servers.json
Format:
{
  "servers": {
    "test": {
      "command": "python",
      "args": ["/absolute/path/to/mcp_test_server.py"],
      "env": {},
      "enabled": true
    }
  }
}

Phase 1 scope:
- Anthropic provider only (OpenAI tool-use shape is different — Phase 6)
- All MCP tools exposed to all agents (per-agent scoping — later)
- Read-only tool calls preferred; write-back tools land in Wave 5
"""

import asyncio
import json
import re
import threading
from contextlib import AsyncExitStack
from pathlib import Path

try:
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
    MCP_SDK_AVAILABLE = True
except ImportError:
    MCP_SDK_AVAILABLE = False


USER_DIR = Path.home() / ".tavernos"
MCP_SERVERS_FILE = USER_DIR / "mcp_servers.json"


def mcp_available() -> bool:
    """True if the mcp SDK is installed and importable."""
    return MCP_SDK_AVAILABLE


# ── Config I/O ────────────────────────────────────────────────────────────────

def load_mcp_config() -> dict:
    """Read ~/.tavernos/mcp_servers.json. Returns {'servers': {}} if absent."""
    if not MCP_SERVERS_FILE.exists():
        return {"servers": {}}
    try:
        with open(MCP_SERVERS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if "servers" not in data or not isinstance(data.get("servers"), dict):
            data["servers"] = {}
        return data
    except Exception:
        return {"servers": {}}


def save_mcp_config(config: dict) -> None:
    """Write ~/.tavernos/mcp_servers.json. UTF-8 without BOM."""
    USER_DIR.mkdir(parents=True, exist_ok=True)
    with open(MCP_SERVERS_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)


# ── Tool-name normalization ──────────────────────────────────────────────────
# Anthropic tool names must match ^[a-zA-Z0-9_-]{1,64}$

_NAME_SANITIZE_RE = re.compile(r'[^a-zA-Z0-9_-]')


def _sanitize_segment(s: str) -> str:
    return _NAME_SANITIZE_RE.sub("_", s)


def _make_tool_name(server_name: str, tool_name: str) -> str:
    name = "mcp_" + _sanitize_segment(server_name) + "_" + _sanitize_segment(tool_name)
    return name[:64]


# ── Manager ──────────────────────────────────────────────────────────────────

class MCPManager:
    """
    Owns the asyncio event loop, the per-server subprocess sessions, and
    the tool catalog. Thread-safe: all sync callers go through `_submit`,
    which trampolines coroutines onto the background loop.
    """

    def __init__(self, error_logger=None):
        if not MCP_SDK_AVAILABLE:
            raise RuntimeError("mcp SDK not installed — run: pip install mcp")
        self._error_logger = error_logger or (lambda kind, **ctx: None)
        self._loop = asyncio.new_event_loop()
        self._thread = threading.Thread(
            target=self._run_loop, daemon=True, name="tavernos-mcp"
        )
        self._thread.start()
        self._sessions = {}        # server_name -> ClientSession
        self._exit_stacks = {}     # server_name -> AsyncExitStack
        self._tool_catalog = {}    # full_tool_name -> (server_name, original_tool_name, schema_dict)
        self._lock = threading.Lock()
        self._shutdown_called = False

    def _run_loop(self):
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_forever()
        finally:
            # Cleanly close the loop after run_forever() is stopped
            try:
                pending = asyncio.all_tasks(self._loop)
                for task in pending:
                    task.cancel()
            except Exception:
                pass
            self._loop.close()

    def _submit(self, coro, timeout: float = 30.0):
        """Run a coroutine on the background loop and block for its result."""
        fut = asyncio.run_coroutine_threadsafe(coro, self._loop)
        return fut.result(timeout=timeout)

    # ─── Server lifecycle ─────────────────────────────────────────────────────

    async def _connect_server_async(self, name: str, cfg: dict):
        command = cfg.get("command")
        args = cfg.get("args", []) or []
        env = cfg.get("env") or None
        if not command:
            raise ValueError("missing 'command' in server config")

        params = StdioServerParameters(command=command, args=list(args), env=env)
        stack = AsyncExitStack()
        # Spawn subprocess with stdio pipes
        read, write = await stack.enter_async_context(stdio_client(params))
        # Open client session over stdio
        session = await stack.enter_async_context(ClientSession(read, write))
        # MCP handshake — version negotiation, capabilities
        await session.initialize()
        # Enumerate tools
        tools_result = await session.list_tools()
        tools = tools_result.tools
        return stack, session, tools

    def connect_server(self, name: str, cfg: dict) -> list:
        """
        Spawn a server, handshake, enumerate tools. Returns the list of
        Anthropic-shaped tool dicts that were registered. Stores the session
        and exit stack for subsequent calls and final cleanup.
        """
        # If this server was previously connected, tear it down first
        if name in self._sessions:
            try:
                self._submit(self._disconnect_server_async(name), timeout=5.0)
            except Exception as e:
                self._error_logger("mcp_server_disconnect_failed", server=name, error=str(e))

        stack, session, tools = self._submit(
            self._connect_server_async(name, cfg), timeout=20.0
        )

        new_schemas = []
        with self._lock:
            self._sessions[name] = session
            self._exit_stacks[name] = stack
            # Purge any stale tool-catalog entries for this server
            for k in [fk for fk, (srv, _, _) in self._tool_catalog.items() if srv == name]:
                del self._tool_catalog[k]
            for t in tools:
                full_name = _make_tool_name(name, t.name)
                schema = {
                    "name": full_name,
                    "description": (t.description or "")[:1024],
                    "input_schema": t.inputSchema or {"type": "object", "properties": {}},
                }
                self._tool_catalog[full_name] = (name, t.name, schema)
                new_schemas.append(schema)
        return new_schemas

    def start_configured_servers(self) -> dict:
        """
        Read mcp_servers.json, connect to each enabled server, return a
        per-server summary: {name: {"status": "connected"|"error"|"disabled",
                                    "tools": int, "error": str}}
        """
        config = load_mcp_config()
        summary = {}
        for name, cfg in config.get("servers", {}).items():
            if not cfg.get("enabled", True):
                summary[name] = {"status": "disabled", "tools": 0, "error": ""}
                continue
            try:
                tools = self.connect_server(name, cfg)
                summary[name] = {"status": "connected", "tools": len(tools), "error": ""}
            except Exception as e:
                self._error_logger("mcp_server_connect_failed", server=name, error=str(e))
                summary[name] = {"status": "error", "tools": 0, "error": str(e)}
        return summary

    # ─── Tool dispatch ────────────────────────────────────────────────────────

    def list_tools_for_anthropic(self) -> list:
        """Return Anthropic-shaped tool schemas for all connected tools."""
        with self._lock:
            return [schema for (_srv, _orig, schema) in self._tool_catalog.values()]

    def is_mcp_tool(self, name: str) -> bool:
        with self._lock:
            return name in self._tool_catalog

    async def _call_tool_async(self, server_name: str, original_tool: str, args: dict):
        session = self._sessions.get(server_name)
        if session is None:
            raise RuntimeError("server " + server_name + " not connected")
        result = await session.call_tool(original_tool, arguments=args or {})
        # MCP tool results are a list of content blocks: text | image | resource.
        # Serialize everything to text for the model. Non-text blocks get a
        # reasonable placeholder the model can still reason about.
        parts = []
        for block in (result.content or []):
            if hasattr(block, "text") and block.text:
                parts.append(block.text)
            elif getattr(block, "type", None) == "image":
                parts.append("[image content returned by tool]")
            elif getattr(block, "type", None) == "resource":
                uri = getattr(block, "uri", "unknown")
                parts.append("[resource: " + str(uri) + "]")
            else:
                parts.append(str(block))
        text = "\n".join(parts) if parts else "(no content)"
        if getattr(result, "isError", False):
            text = "[tool reported error] " + text
        return text

    def call_tool(self, full_tool_name: str, args: dict) -> str:
        """Dispatch by Anthropic-visible tool name. Returns text result."""
        with self._lock:
            entry = self._tool_catalog.get(full_tool_name)
        if entry is None:
            raise KeyError("unknown MCP tool: " + full_tool_name)
        server_name, original_tool, _schema = entry
        return self._submit(
            self._call_tool_async(server_name, original_tool, args), timeout=60.0
        )

    # ─── Shutdown ─────────────────────────────────────────────────────────────

    async def _disconnect_server_async(self, name: str):
        stack = self._exit_stacks.pop(name, None)
        self._sessions.pop(name, None)
        if stack is not None:
            try:
                await stack.aclose()
            except Exception as e:
                self._error_logger("mcp_server_close_failed", server=name, error=str(e))

    async def _shutdown_async(self):
        for name in list(self._exit_stacks.keys()):
            await self._disconnect_server_async(name)
        with self._lock:
            self._tool_catalog.clear()

    def shutdown(self):
        if self._shutdown_called:
            return
        self._shutdown_called = True
        try:
            self._submit(self._shutdown_async(), timeout=10.0)
        except Exception:
            pass
        try:
            self._loop.call_soon_threadsafe(self._loop.stop)
            self._thread.join(timeout=2.0)
        except Exception:
            pass

    # ─── Introspection ────────────────────────────────────────────────────────

    def connected_servers(self) -> list:
        """[(server_name, tool_count)] for everything currently connected."""
        with self._lock:
            counts = {}
            for (srv, _orig, _schema) in self._tool_catalog.values():
                counts[srv] = counts.get(srv, 0) + 1
            return [(n, counts.get(n, 0)) for n in self._sessions.keys()]
