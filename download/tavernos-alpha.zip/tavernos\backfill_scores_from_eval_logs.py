"""backfill_scores_from_eval_logs.py — one-shot Phase 5 bootstrap.

The eval harnesses (run_research_eval.py, run_audit_eval.py, etc.) call
evaluator.score_deliverable directly and write JSON logs to eval_logs/,
but they do NOT call save_eval_result, so the deliverable_scores table
stays empty. /eval calibrate needs rows in that table to rate against.

This script reads eval_logs/*.json and inserts one deliverable_scores row
per unique filename. Dedup is filename-based: re-running is safe, it won't
create duplicates. Writes ONLY to the per-client perf DB, not the global
DB — /eval calibrate only reads from per-client.

Usage (from repo root, PowerShell):
    python backfill_scores_from_eval_logs.py
    python backfill_scores_from_eval_logs.py --client hypothetica
    python backfill_scores_from_eval_logs.py --dry-run

ASCII-only output. No external deps beyond stdlib.
"""

from __future__ import annotations

import argparse
import json
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parent
EVAL_LOGS = REPO_ROOT / "eval_logs"


def _client_perf_db(client_slug: str) -> Path:
    # Matches norm.py's _perf_db_path: clients/<slug>/memory/skill_performance.db
    return (Path.home() / ".tavernos" / "clients" / client_slug
            / "memory" / "skill_performance.db")


def _ensure_table(con: sqlite3.Connection) -> None:
    """Mirror of eval_db_init's per-client deliverable_scores CREATE."""
    con.execute("""CREATE TABLE IF NOT EXISTS deliverable_scores (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT NOT NULL,
        agent TEXT, deliverable_type TEXT,
        filename TEXT, filepath TEXT,
        scores_json TEXT, critiques_json TEXT,
        weighted_avg REAL,
        pass_threshold INTEGER,
        failing_dims TEXT,
        regen_attempts INTEGER DEFAULT 0,
        evaluator_model TEXT,
        overall_critique TEXT
    )""")
    con.execute("""CREATE TABLE IF NOT EXISTS deliverable_calibration (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        deliverable_score_id INTEGER,
        ts TEXT NOT NULL,
        operator_scores_json TEXT,
        operator_notes TEXT,
        evaluator_scores_json TEXT,
        FOREIGN KEY (deliverable_score_id) REFERENCES deliverable_scores(id)
    )""")
    con.commit()


# Best-effort agent inference from deliverable_type. Matches v6 rubric owners.
_AGENT_BY_TYPE = {
    "client_proposal":   "woody",
    "operational_audit": "lilith",
    "research_report":   "cliff",
    "slide_deck":        "rebecca",
    "financial_model":   "rebecca",
    "meeting_summary":   "rebecca",
    "prd":               "coach",
}


def backfill(perf_db: Path, logs_dir: Path, dry_run: bool) -> int:
    """Insert one row per unique filename in eval_logs. Returns inserted count.
    Uses the FIRST run in each log (defensible when MBR variance is low, as in
    4C; for logs with high variance, operator can re-run calibration later)."""
    if not logs_dir.exists():
        print(f"  eval_logs not found at {logs_dir}")
        return 0

    logs = sorted(logs_dir.glob("*.json"))
    if not logs:
        print(f"  no *.json files in {logs_dir}")
        return 0

    print(f"  found {len(logs)} eval log(s) in {logs_dir}")

    if not dry_run:
        perf_db.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(perf_db) if not dry_run else None
    if con is not None:
        _ensure_table(con)

    inserted = 0
    skipped_existing = 0
    skipped_invalid = 0

    for log_path in logs:
        try:
            data = json.loads(log_path.read_text(encoding="utf-8"))
        except Exception as e:
            print(f"    ! {log_path.name}: JSON parse failed ({e})")
            skipped_invalid += 1
            continue

        filename = data.get("filename")
        template = data.get("template")
        runs = data.get("results") or []
        if not filename or not template or not runs:
            print(f"    ! {log_path.name}: missing filename/template/results")
            skipped_invalid += 1
            continue

        # Pick the first valid (non-errored) run
        run = next((r for r in runs
                    if not r.get("error") and r.get("scores")), None)
        if run is None:
            print(f"    ! {log_path.name}: no valid runs (all errored)")
            skipped_invalid += 1
            continue

        # Dedup by filename
        if con is not None:
            existing = con.execute(
                "SELECT id FROM deliverable_scores WHERE filename=? "
                "ORDER BY id DESC LIMIT 1", (filename,)
            ).fetchone()
            if existing:
                print(f"    - {filename}: already in DB (id={existing[0]}), skip")
                skipped_existing += 1
                continue

        ts = data.get("timestamp") or datetime.now(timezone.utc).isoformat()
        scores = run.get("scores") or {}
        critiques = run.get("critiques") or {}
        wavg = run.get("weighted_avg") or 0.0
        pass_t = 1 if run.get("pass_threshold") else 0
        failing = run.get("failing_dims") or []
        if isinstance(failing, list):
            failing = ",".join(failing)
        model = run.get("evaluator_model") or data.get("model") or ""
        overall = run.get("overall_critique") or ""
        agent = _AGENT_BY_TYPE.get(template, "?")
        # filepath note: the original tempdir is gone; point at the log itself
        filepath = f"(tempdir purged; see eval_logs/{log_path.name})"

        print(f"    + {filename} [{template}] wavg={wavg:.2f} model={model}")

        if con is not None:
            con.execute(
                """INSERT INTO deliverable_scores
                   (ts, agent, deliverable_type, filename, filepath,
                    scores_json, critiques_json, weighted_avg,
                    pass_threshold, failing_dims, regen_attempts,
                    evaluator_model, overall_critique)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (ts, agent, template, filename, filepath,
                 json.dumps(scores), json.dumps(critiques),
                 wavg, pass_t, failing, 0, model, overall)
            )
        inserted += 1

    if con is not None:
        con.commit()
        con.close()

    print()
    print(f"  summary: inserted={inserted}  "
          f"skipped_existing={skipped_existing}  "
          f"skipped_invalid={skipped_invalid}")
    if dry_run:
        print("  DRY RUN — no rows actually written.")
    return inserted


def main() -> int:
    ap = argparse.ArgumentParser(
        description="Backfill deliverable_scores from eval_logs/*.json "
                    "for /eval calibrate to have rows to rate.")
    ap.add_argument("--client", default="hypothetica",
                    help="Client slug (default: hypothetica).")
    ap.add_argument("--dry-run", action="store_true",
                    help="Parse and report but don't write to the DB.")
    ap.add_argument("--logs-dir", default=None,
                    help="Override the eval_logs/ directory path.")
    args = ap.parse_args()

    perf_db = _client_perf_db(args.client)
    logs_dir = Path(args.logs_dir) if args.logs_dir else EVAL_LOGS

    print(f"backfill_scores_from_eval_logs")
    print(f"  client:    {args.client}")
    print(f"  perf_db:   {perf_db}")
    print(f"  logs_dir:  {logs_dir}")
    print(f"  dry_run:   {args.dry_run}")
    print()

    n = backfill(perf_db, logs_dir, dry_run=args.dry_run)
    return 0 if n >= 0 else 1


if __name__ == "__main__":
    sys.exit(main())