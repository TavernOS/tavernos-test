"""
test_woody_client_proposal.py — Pipeline regression test for Woody's client_proposal.

Thin wrapper over test_harness.py. Edit this file to change Woody's test
scenarios; the harness handles all the plumbing.

Run:
  python test_woody_client_proposal.py                    # tier 1 only, n=1
  python test_woody_client_proposal.py --tier 1 --n 3     # tier 1, 3 iterations
  python test_woody_client_proposal.py --tier 2 --n 3     # tiers 2a + 2b
  python test_woody_client_proposal.py --tier all --n 3   # all implemented tiers
  python test_woody_client_proposal.py --verbose          # dump plans + tool captures
  python test_woody_client_proposal.py --tier 2 --n 3 --force-2b  # session-7 forcing arm

Baseline expectations (carried from session 1 pattern; specific Woody
numbers not measured until session 9 priority 3):
  Tier 1:  should track Lilith's 100% — router patch applies to all
           deliverable-agents uniformly.
  Tier 2a: should track Lilith's ~100% CLARIFY — same grounding
           discipline, different skill file.
  Tier 2b: session-1 Problem 1 applies to Woody too; expect 0-25%
           invocation on rich prompts in baseline arm. Forced arm
           (--force-2b) should lift to ≥83% per the session-7 result
           for Lilith — priority 3 of session 9 validates this
           generalization.
"""

from test_harness import AgentTestConfig, run_tests


# ═══════════════════════════════════════════════════════════════════════════════
#  TEST SCENARIOS — woody + client_proposal
#
#  SHORT prompts (Mode 3 / CLARIFY target): vague proposal requests with no
#  prospect name, no discovery context, no scope hints. Expected: no tool
#  invocation, substantive prose asking for the missing context.
#
#  RICH prompts (Mode 2 / BOUND target): 4-6 sentences naming prospect,
#  business context, specific pain from a discovery call, desired
#  engagement shape. Expected: generate_docx_report call with
#  template=client_proposal, and a file saved to disk.
#
#  NEGATIVE prompts: must NOT route to Woody. Proposal requests that
#  mention operational audits route to Lilith; research requests route
#  to Cliff; spreadsheet requests route to Rebecca.
# ═══════════════════════════════════════════════════════════════════════════════

SHORT_PROMPTS = [
    "write me a client proposal",
    "I need a proposal draft",
    "help me draft a proposal for Acme Corp",
    "draft a proposal for a consulting engagement",
    "put together a proposal document",
]

RICH_PROMPTS = [
    # SaaS onboarding consulting — clear pain + named prospect + scope hint
    ("We had a discovery call last Tuesday with Meridian Labs, a 45-person "
     "developer-tools SaaS company in Austin. Their CEO Priya said their "
     "activation rate has been stuck at 22% for six months — they suspect "
     "the in-product onboarding flow is the bottleneck but they haven't "
     "done structured user research. They're looking for a 6-8 week "
     "engagement: user interviews, funnel analysis, and a prioritized "
     "list of onboarding-flow changes with expected impact. Budget is "
     "$15-20K. Draft a proposal that frames the problem in Priya's voice, "
     "scopes three phases, and prices at $18K fixed fee."),

    # Ops consulting proposal — detailed discovery notes, specific tools named
    ("Prospect: Northbridge Accounting, a 22-person boutique CPA firm in "
     "Boston. Discovery call with the managing partner, Marcus Chen. He "
     "mentioned they're losing ~6 hours/week per partner to manual "
     "reconciliation between QuickBooks and their practice management "
     "tool (Canopy). Their busy season starts in February and he wants "
     "this solved by January 15. Engagement should be a 4-week discovery "
     "+ build: week 1 workflow mapping, weeks 2-3 build a sync automation "
     "(we'll use Zapier or Make depending on what their IT approves), "
     "week 4 train the team. Price at $12,500. Write me the proposal."),

    # Content strategy engagement — prospect's own framing embedded
    ("Client is Kestrel Advisory, a 14-person boutique M&A firm in "
     "Chicago. On the discovery call their head of marketing, Dana "
     "Wiley, said: 'We publish one thought-leadership piece a quarter "
     "and it lands like a stone in a pond — some of our best deals "
     "have come from random LinkedIn posts instead.' She wants a "
     "6-month content engagement: a voice profile, a publishing "
     "cadence, and a batch of 12 distribution-ready pieces across "
     "LinkedIn + long-form. They're comparing us to two other "
     "consultants so we need to be sharp on scope. Target fee is "
     "$45K for the 6 months. Draft the proposal."),

    # Executive coaching engagement — softer deliverable, still rich
    ("Discovery call with Ellis Park, founder/CEO of Greenshoot "
     "Robotics (32 employees, Series B, agricultural robotics). His "
     "board added two new members in Q4 and the board dynamic has "
     "gotten tense — he's spending 8-10 hours per board cycle on "
     "pre-meeting diplomacy instead of running the company. He wants "
     "a 4-month executive coaching engagement focused on board "
     "communication and structured pre-reads that reduce surprise. "
     "Budget's $24K for the engagement, biweekly 90-minute sessions. "
     "Write the proposal — lead with the diagnosis in his voice."),
]

NEGATIVE_PROMPTS = [
    ("audit operations at a 40-person accounting firm",            "lilith"),
    ("give me current market research on robotics startups",       "cliff"),
    ("build me a monthly business review spreadsheet for Q1",      "rebecca"),
]


CONFIG = AgentTestConfig(
    agent_name="woody",
    tool_name="generate_docx_report",
    template_key="client_proposal",
    short_prompts=SHORT_PROMPTS,
    rich_prompts=RICH_PROMPTS,
    negative_prompts=NEGATIVE_PROMPTS,
)


if __name__ == "__main__":
    run_tests(CONFIG)
