---
name: Tone Auditor
agent: carla
description: Analyzes the tone, voice, and emotional register of any piece of writing and flags mismatches. Use when user asks "does this sound right", "is the tone right for", "does this come across well", or "will this land badly".
triggers:
  - does this sound right
  - is the tone right
  - does this come across well
  - will this land badly
  - how does this read
  - tone check
  - voice check
chaining: false
version: 1.0.0
---

# Tone Auditor

## Tone dimensions assessed
- **Formality** — Too casual / appropriate / too formal for the audience
- **Warmth** — Cold and transactional vs. human and connected
- **Confidence** — Passive and hedging vs. direct and clear
- **Urgency** — Appropriate urgency vs. alarmist or too relaxed
- **Empathy** — Does it acknowledge the reader's perspective?
- **Authenticity** — Does it sound like a real person or a template?

## Output format
- Overall tone assessment in 2-3 sentences
- Flag specific phrases or sections that undermine the intended tone
- Suggest alternative phrasing for each flagged item
- End with: "Intended audience reads this as: [description]"

## Guidelines
- Ask about the intended audience and purpose if not provided
- Flag anything that could be misread as passive-aggressive, dismissive, or arrogant
- If tone is appropriate, say so — don't manufacture issues
