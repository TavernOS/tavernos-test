# patch-woody-rule.ps1
#
# Adds woody "Route ANY proposal/SOW/RFP -> SINGLE step" rule to ROUTER_SYSTEM
# in tavernos/norm.py. Closes the parity gap surfaced by session-34 item-2
# audit: 4 of 5 deliverable agents had explicit "Route ANY ... -> SINGLE step"
# rules; woody was the missing 5th.
#
# Usage:
#   cd C:\TavernOS\tavernos
#   .\patch-woody-rule.ps1
#
# Or with explicit path:
#   .\patch-woody-rule.ps1 -Path C:\TavernOS\tavernos\norm.py
#
# Safety:
#   - Refuses to edit if norm.py hash doesn't match canonical baseline
#     (020E923811D6AED0A9CE74CC2DFE4123C5248440F72CDE2B9D4E852C911446E8).
#   - Creates timestamped backup before editing.
#   - Verifies anchor is unique in the file before replacement.
#   - Verifies line delta is exactly +11 (the new rule's line count).
#   - Preserves UTF-8 BOM and original line endings (CRLF on Windows).

[CmdletBinding()]
param(
    [string]$Path = "norm.py"
)

$ErrorActionPreference = "Stop"

# === Resolve target ===
$target = (Resolve-Path -Path $Path -ErrorAction Stop).Path
Write-Host "[patch-woody-rule] target: $target"

# === Hash check ===
$expectedHash = "020E923811D6AED0A9CE74CC2DFE4123C5248440F72CDE2B9D4E852C911446E8"
$preHash = (Get-FileHash -Path $target -Algorithm SHA256).Hash
Write-Host "[patch-woody-rule] pre-edit hash:  $preHash"
if ($preHash -ne $expectedHash) {
    Write-Host ""
    Write-Host "ERROR: norm.py hash does not match canonical baseline." -ForegroundColor Red
    Write-Host "  expected: $expectedHash"
    Write-Host "  actual:   $preHash"
    Write-Host "  refusing to edit. norm.py may have been modified since the audit."
    Write-Host "  if intentional, revert other changes first or apply this rule manually."
    exit 1
}

# === Backup ===
$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backup = "$target.bak.$stamp"
Copy-Item -Path $target -Destination $backup -Force
Write-Host "[patch-woody-rule] backup: $backup"

# === Read (BOM-aware, line-ending preserving) ===
$rawBytes = [System.IO.File]::ReadAllBytes($target)
$hasBOM = $rawBytes.Length -ge 3 -and $rawBytes[0] -eq 0xEF -and $rawBytes[1] -eq 0xBB -and $rawBytes[2] -eq 0xBF
$content = [System.IO.File]::ReadAllText($target)
$nl = if ($content.Contains("`r`n")) { "`r`n" } else { "`n" }
$bomState = if ($hasBOM) { "present" } else { "absent" }
$nlState  = if ($nl -eq "`r`n") { "CRLF" } else { "LF" }
Write-Host "[patch-woody-rule] BOM: $bomState, line ending: $nlState"

# === Anchor + replacement plan ===
# Anchor: closing line of cliff's rule + start of next rule (Use conversation history).
# We insert the woody rule's 11 lines between them.
$anchorBefore = '    "  [cliff, rebecca-mbr] is the failure mode this rule exists to prevent.\n"'
$anchorAfter  = '    "- Use conversation history to understand follow-ups'
$anchor = $anchorBefore + $nl + $anchorAfter

$matchCount = ([regex]::Matches($content, [regex]::Escape($anchor))).Count
if ($matchCount -ne 1) {
    Write-Host ""
    Write-Host "ERROR: anchor matched $matchCount times (expected 1)." -ForegroundColor Red
    Write-Host "  the file may have been modified or the audit is stale."
    Write-Host "  no changes made. backup at $backup"
    exit 1
}
Write-Host "[patch-woody-rule] anchor matched uniquely. building replacement..."

# === Woody rule lines ===
# Each line is the literal Python source: 4-space indent + opening double-quote +
# content + Python "\n" escape + closing double-quote.
# Em-dash is composed at runtime as [char]0x2014 to keep this script ASCII-only
# (avoids any Windows PowerShell 5.1 codepage interpretation issues).
$em = [char]0x2014
$woodyLines = @(
    "    `"- Route ANY request for a proposal, sales proposal, business proposal,\n`"",
    "    `"  project proposal, RFP response, request-for-proposal response,\n`"",
    "    `"  statement of work, or SOW to woody as a SINGLE step. Do NOT\n`"",
    "    `"  decompose into multiple agents $em woody owns the proposal\n`"",
    "    `"  deliverable end-to-end. When the prompt mentions research the\n`"",
    "    `"  proposal will reference ('include market context', 'with\n`"",
    "    `"  competitive analysis', 'with recent industry data'), that is\n`"",
    "    `"  CONTEXT for woody, not a separate cliff step. Routing as\n`"",
    "    `"  [cliff, woody] is the failure mode this rule exists to prevent\n`"",
    "    `"  $em research framing belongs in the prompt to woody, not as a\n`"",
    "    `"  prior step.\n`""
)
$expectedNewLines = $woodyLines.Count
$woodyBlock = ($woodyLines -join $nl) + $nl

# === Apply replacement ===
$replacement = $anchorBefore + $nl + $woodyBlock + $anchorAfter
$newContent = $content.Replace($anchor, $replacement)

# === Sanity checks ===
if ($newContent -eq $content) {
    Write-Host ""
    Write-Host "ERROR: replacement was a no-op." -ForegroundColor Red
    Write-Host "  this should never happen given anchor matched. backup at $backup"
    exit 1
}
$preLines  = ($content -split "`n").Count
$postLines = ($newContent -split "`n").Count
$lineDelta = $postLines - $preLines
if ($lineDelta -ne $expectedNewLines) {
    Write-Host ""
    Write-Host "ERROR: line delta was $lineDelta (expected $expectedNewLines)." -ForegroundColor Red
    Write-Host "  no changes written. backup at $backup"
    exit 1
}

# === Write back (preserve BOM, preserve line endings) ===
$encoding = New-Object System.Text.UTF8Encoding $hasBOM
[System.IO.File]::WriteAllText($target, $newContent, $encoding)

# === Post-edit report ===
$postHash = (Get-FileHash -Path $target -Algorithm SHA256).Hash
Write-Host ""
Write-Host "[patch-woody-rule] post-edit hash: $postHash"
Write-Host "[patch-woody-rule] line count: $preLines -> $postLines (delta: +$lineDelta)"
Write-Host ""
Write-Host "DONE." -ForegroundColor Green
Write-Host ""
Write-Host "Recommended next steps:"
Write-Host "  1. Review the diff:"
Write-Host "       cd C:\TavernOS"
Write-Host "       git diff tavernos/norm.py"
Write-Host ""
Write-Host "  2. Smoke test (TESTING.md S1-S5 + Woody-route):"
Write-Host "       restart norm --web (Ctrl+C the current process, re-run)"
Write-Host "       hard-refresh the browser (Ctrl+Shift+R)"
Write-Host "       in a fresh chat with Sam routing, ask:"
Write-Host "         write me a SOW for a 25-person fintech company"
Write-Host "         building a budgeting tool, contract terms standard"
Write-Host "       confirm Sam's plan card shows 1 step with agent=woody"
Write-Host ""
Write-Host "  3. If smoke clean, commit:"
Write-Host "       cd C:\TavernOS"
Write-Host "       git add tavernos/norm.py"
Write-Host "       git commit -m `"add woody single-step routing rule (item 2 audit)`""
Write-Host ""
Write-Host "  4. If smoke fails, restore from backup:"
Write-Host "       Copy-Item -Path '$backup' -Destination '$target' -Force"
Write-Host ""
Write-Host "Backup retained: $backup"
