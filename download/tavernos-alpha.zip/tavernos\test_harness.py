"""
test_harness.py — Shared plumbing for per-agent pipeline regression tests.

Usage from a per-agent test file:

    from test_harness import AgentTestConfig, run_tests

    config = AgentTestConfig(
        agent_name="lilith",
        tool_name="generate_docx_report",
        template_key="operational_audit",
        short_prompts=[ ... 5 short, <30-word, non-substantive prompts ... ],
        rich_prompts=[ ... 4 rich, 4-6-sentence, substantive-business prompts ... ],
        negative_prompts=[
            ("write me a proposal for Example Co.", "woody"),
            # (prompt that should NOT route to agent_name, informational expected-route)
        ],
    )

    if __name__ == "__main__":
        run_tests(config)

The harness handles:
- Bootstrapping a norm API client from the user's config
- Loading the target agent's JSON from norm.AGENTS_DIR
- Assembling the agent's system prompt (mirrored from norm.call_execute_streaming
  at norm.py:3734-3760 — see drift warning below)
- Running Tier 1 (routing), Tier 2a (CLARIFY on short prompts), Tier 2b (BOUND
  on rich prompts)
- CLI flags (--tier, --n, --verbose)
- Summary reporting + exit code

Tiers
-----
  Tier 1  — Routing                   (n router calls per prompt)
  Tier 2a — CLARIFY on short prompts  (n full-agent calls per short prompt)
  Tier 2b — BOUND on rich prompts     (n full-agent calls per rich prompt,
                                       writes real deliverables to disk)
  Tier 3  — Preflight                 (not implemented — placeholder)
  Tier 4  — Rubric                    (not implemented — placeholder)

Assertions
----------
  Tier 1 positive: plan has exactly 1 step; first step's agent == agent_name
  Tier 1 negative: first step's agent != agent_name
  Tier 2a:          no tool call; response > 200 chars; response contains "?"
  Tier 2b:          at least one captured tool call where name == tool_name AND
                    args.template == template_key; banner captured (file saved)

Drift warning
-------------
The system-prompt template at _build_agent_system_prompt() mirrors
norm.call_execute_streaming. If norm's prompt assembly changes, this mirror
must change too. Backlog item: extract norm._build_agent_system_prompt as a
shared helper and remove this mirror.
"""

import argparse
import json
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

# Session 9: make stdout Unicode-tolerant on Windows PowerShell. Haiku
# occasionally emits em-dashes, smart quotes, or other non-cp1252 chars
# in responses; those propagate through exception messages into reason
# strings that hit print(). errors='replace' substitutes '?' rather than
# raising. No-op on Python < 3.7 (reconfigure didn't exist) and on
# platforms where stdout is already UTF-8.
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

# Make norm importable when run from repo root
sys.path.insert(0, str(Path(__file__).resolve().parent))
import norm  # noqa: E402


# ═══════════════════════════════════════════════════════════════════════════════
#  CONFIG
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class AgentTestConfig:
    """Per-agent test configuration. Pass to run_tests()."""
    agent_name: str                      # "lilith" — lowercase
    tool_name: str                       # "generate_docx_report"
    template_key: str                    # "operational_audit"
    short_prompts: list                  # list[str] — <30 words, non-substantive
    rich_prompts: list                   # list[str] — 4-6 sentences, substantive
    negative_prompts: list = field(default_factory=list)
                                         # list[tuple[str, str]] — (prompt, expected_other_agent)
    # Hooks for future per-agent overrides (e.g., different max_tokens per agent)
    max_tokens: Optional[int] = None     # None = use norm.EXECUTE_MAX_TOKENS
    # Goal A session 7 — tool_choice forcing opt-in. When set (typically to
    # tool_name via the --force-2b CLI flag), the harness applies
    # tool_choice_override=norm.tool_choice_force_tool(force_tool) to the
    # Tier 2b run_tool_use_loop call ONLY. Tier 2a is never forced regardless
    # of this setting — forcing on Tier 2a would turn every CLARIFY assertion
    # into a deliberate fail. See norm.py TOOL_CHOICE FORCING section.
    force_tool: Optional[str] = None     # None = no forcing (pre-session-7 behavior)


# ═══════════════════════════════════════════════════════════════════════════════
#  AGENT + PROMPT ASSEMBLY
# ═══════════════════════════════════════════════════════════════════════════════

def _load_agent(name):
    """Load an agent's JSON by name. Mirrors the loader at norm.py:4525-4530."""
    path = norm.AGENTS_DIR / (name.lower() + ".json")
    if not path.exists():
        return None
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return None


def _build_agent_system_prompt(agent_name):
    """Assemble the agent's system prompt the same way call_execute_streaming
    does at norm.py:3734-3760. Returns (system_str, tools_param).

    If norm's prompt assembly changes, this mirror must be updated. See
    drift warning in module docstring."""
    agent = _load_agent(agent_name)
    if not agent:
        raise RuntimeError(f"agent '{agent_name}' not loadable from AGENTS_DIR")

    agent_name_lower = agent_name.lower()
    use_search = (any(n in agent_name_lower for n in norm.WEB_SEARCH_AGENTS))
    fp_tools_list = norm._first_party_tools_for_agent(agent_name_lower)
    skill_bodies = norm.load_skill_bodies_for_agent(agent_name_lower)
    file_context = ""  # Tier 2 uses no ingested files

    system = (
        "You are " + agent.get("name", "Norm") + ", a character from TavernOS.\n"
        "Personality: " + agent.get("personality", "") + "\n"
        "Quip style: " + agent.get("quip_style", "") + "\n"
        "Skills: " + ", ".join(agent.get("skills", [])) + "\n\n"
        "Stay in character. Lead with a brief quip, then do the work."
        + norm._client_context_block()
        + (("\n\n## Skill playbooks (detailed guidance)\n\n" + skill_bodies)
           if skill_bodies else "")
        + (("\n\n" + file_context) if file_context else "")
        + ("\n\nYou have access to real-time web search. Use it proactively "
           "when the question requires current information, recent events, "
           "or facts that may have changed. Cite your sources inline."
           if use_search else "")
        + ("\n\nIMPORTANT — ARTIFACT TOOLS. You have tool(s) available to "
           "generate real binary deliverables ("
           + ", ".join(sorted(t["name"] for t in fp_tools_list)) + "). "
           "When the user asks for a spreadsheet, workbook, report, monthly "
           "business review, KPI dashboard, variance analysis, financial "
           "model, or any deliverable that would normally be an .xlsx, .docx, "
           "or .pptx file, you MUST call the appropriate tool. Do NOT write "
           "the contents of the file in chat as markdown tables, ASCII charts, "
           "or build instructions as a substitute — that is not the "
           "deliverable, that is a replacement for the deliverable, and it "
           "is wrong. The tool takes a JSON spec, writes a real file to "
           "the active client's workspace, and returns the saved path. Your "
           "narration should happen AFTER the tool returns, referencing the "
           "saved file and calling out the 2-3 most important findings."
           if fp_tools_list else "")
        + "\n\n" + norm.OUTPUT_CONTRACT
    )
    return system, fp_tools_list


# ═══════════════════════════════════════════════════════════════════════════════
#  ROUTER WRAPPER
# ═══════════════════════════════════════════════════════════════════════════════

def _run_router(client, provider, model_id, prompt):
    """Call norm.call_router with empty history."""
    history = norm.ConversationHistory()
    return norm.call_router(client, provider, model_id, history, prompt)


# ═══════════════════════════════════════════════════════════════════════════════
#  TIER 1 — ROUTING
# ═══════════════════════════════════════════════════════════════════════════════

def _assess_positive(plan, agent_name):
    """Tier 1 positive: 1 step, first agent == agent_name."""
    if not isinstance(plan, dict) or "steps" not in plan:
        return False, "plan missing or malformed"
    steps = plan.get("steps") or []
    if len(steps) != 1:
        agents = [s.get("agent", "?") for s in steps]
        return False, f"expected 1 step, got {len(steps)}: {agents}"
    agent = (steps[0].get("agent") or "").lower()
    if agent != agent_name.lower():
        return False, f"routed to '{agent}', expected '{agent_name.lower()}'"
    return True, "ok"


def _assess_negative(plan, agent_name, expected_other_agent):
    """Tier 1 negative: first agent != agent_name."""
    if not isinstance(plan, dict) or "steps" not in plan:
        return False, "plan missing or malformed"
    steps = plan.get("steps") or []
    if not steps:
        return False, "plan has zero steps"
    agent = (steps[0].get("agent") or "").lower()
    if agent == agent_name.lower():
        return False, (f"incorrectly routed to {agent_name.lower()} "
                       f"(expected ~{expected_other_agent})")
    return True, f"routed to {agent} (expected ~{expected_other_agent})"


def run_tier_1(config, client, provider, model_id, n, verbose):
    """Tier 1 routing — positives should route to config.agent_name,
    negatives should not. Returns (passed, total, details)."""
    print("=" * 78)
    print(f"TIER 1 — ROUTING  ({config.agent_name}, model: {model_id}, n={n})")
    print("=" * 78)

    details = []
    passed = 0
    total = 0

    def _run_case(label, prompt, assess_fn, *assess_args):
        nonlocal passed, total
        print(f"\n[{label}] {prompt[:80] + ('...' if len(prompt) > 80 else '')}")
        for i in range(n):
            total += 1
            try:
                plan = _run_router(client, provider, model_id, prompt)
            except Exception as e:
                print(f"  run {i+1}: ERROR — {e}")
                details.append((label, prompt, i+1, False, f"exception: {e}"))
                continue
            ok, reason = assess_fn(plan, config.agent_name, *assess_args)
            passed += 1 if ok else 0
            mark = "PASS" if ok else "FAIL"
            print(f"  run {i+1}: {mark} — {reason}")
            if verbose:
                steps_summary = [
                    {"agent": s.get("agent"),
                     "mode": s.get("mode"),  # session 9 — measurement capture
                     "task": (s.get("task") or "")[:70]}
                    for s in (plan.get("steps") or [])
                ]
                print(f"         plan.steps = {json.dumps(steps_summary, indent=2)}")
            details.append((label, prompt, i+1, ok, reason))

    print("\n--- POSITIVE CASES: SHORT PROMPTS ---")
    for prompt in config.short_prompts:
        _run_case("POS-S", prompt, _assess_positive)
    print("\n--- POSITIVE CASES: RICH PROMPTS ---")
    for prompt in config.rich_prompts:
        _run_case("POS-R", prompt, _assess_positive)
    print("\n--- NEGATIVE CASES ---")
    for prompt, expected in config.negative_prompts:
        _run_case("NEG", prompt, _assess_negative, expected)

    return passed, total, details


# ═══════════════════════════════════════════════════════════════════════════════
#  TIER 2 — INVOCATION (2a CLARIFY + 2b BOUND)
# ═══════════════════════════════════════════════════════════════════════════════

def _execute_and_capture(config, client, provider, model_id, system, tools_param,
                         prompt, verbose, force_this_call=False):
    """Run prompt through router + full agent tool-loop. Returns a dict
    with route_ok, first_agent, text, tool_calls, tool_results, banners, error.

    force_this_call: when True AND config.force_tool is set, applies
    tool_choice_override=norm.tool_choice_force_tool(config.force_tool) to
    the run_tool_use_loop call. Both conditions required — if force_this_call
    is True but config.force_tool is None, override stays None (no-op). Goal A
    session 7. See norm.py TOOL_CHOICE FORCING section for first-call-only
    semantics.

    Session 9 — production forcing deployment path. When
    force_this_call is True AND config.force_tool is NOT set AND the target
    agent's JSON declares a `force_tool` field, the harness falls through
    to norm._compute_force_tool_override(agent_dict, step_mode) using the
    mode Sam actually emitted for this prompt. This exercises the same
    conjunction helper that call_execute_streaming uses in production CLI,
    validating end-to-end that:
      (a) Sam's per-prompt mode classification drives forcing correctly
      (b) the agent dict's force_tool field opts the agent in
      (c) the helper's truth table behaves as pinned by Contract 11
    Session-7's --force-2b path takes precedence (back-compat); session-9
    path activates only when session-7 path doesn't."""
    result = {
        "route_ok": False, "first_agent": "", "plan_step_count": 0,
        "text": "", "tool_calls": [], "tool_results": [], "banners": [],
        "error": None,
    }

    # Session 9: load agent dict once so the conjunction can inspect
    # agent.force_tool. None if agent JSON doesn't exist — falls back to
    # session-7 --force-2b path or no-force default.
    try:
        agent_dict = _load_agent(config.agent_name)
    except Exception:
        agent_dict = None

    try:
        plan = _run_router(client, provider, model_id, prompt)
    except Exception as e:
        result["error"] = f"router exception: {e}"
        return result

    steps = plan.get("steps") or []
    result["plan_step_count"] = len(steps)
    first_agent = (steps[0].get("agent") or "").lower() if steps else ""
    result["first_agent"] = first_agent
    # Session 9: mode the router emitted for this step — drives the
    # production conjunction below. None for pre-session-9 router outputs.
    step_mode = steps[0].get("mode") if steps else None
    if first_agent != config.agent_name.lower():
        return result
    result["route_ok"] = True

    task = steps[0].get("task") or prompt

    def on_tool_call(tname, args):
        result["tool_calls"].append({"name": tname, "args": args})
        if verbose:
            template = (args or {}).get("template", "?")
            print(f"         [capture] tool_call: {tname} (template={template})")

    def on_tool_result(tname, text, is_error):
        result["tool_results"].append({
            "name": tname, "text": text, "is_error": is_error,
        })
        if verbose:
            # Print the first 200 chars of the tool's response so we can see
            # WHY a call failed (preflight rejection, schema error, etc.).
            # Critical for diagnosing Mode B failures (invoked but no banner).
            err_marker = "[ERROR]" if is_error else "[result]"
            preview = (text or "")[:200].replace("\n", " ")
            print(f"         [capture] {err_marker} {tname}: {preview}")

    def on_banner(banner):
        result["banners"].append(banner)

    messages = [{"role": "user", "content": task}]
    max_tokens = config.max_tokens or norm.EXECUTE_MAX_TOKENS

    # Session 7: --force-2b direct path (takes precedence for back-compat
    # with existing measurements). Forces regardless of mode — useful for
    # isolating forcing-vs-gate behavior when Sam's classification isn't
    # the variable of interest.
    # Session 9: production deployment path (fallback when session-7 path
    # isn't configured). Applies the conjunction helper using the agent
    # dict's force_tool field and the mode Sam actually emitted for this
    # prompt. Fires iff BOTH (agent opted in) AND (Sam said BOUND). Tier
    # 2a runs receive force_this_call=False and never force regardless —
    # session-7 invariant preserved.
    tool_choice_override = None
    if force_this_call:
        if config.force_tool:
            tool_choice_override = norm.tool_choice_force_tool(config.force_tool)
        elif agent_dict is not None:
            tool_choice_override = norm._compute_force_tool_override(
                agent_dict, step_mode)

    try:
        text = norm.run_tool_use_loop(
            client=client, model_id=model_id,
            system=system, messages=messages,
            tools_param=tools_param,
            max_tokens=max_tokens,
            agent_name=config.agent_name.lower(),
            tool_choice_override=tool_choice_override,
            on_tool_call=on_tool_call,
            on_tool_result=on_tool_result,
            on_banner=on_banner,
        )
        result["text"] = text or ""
    except Exception as e:
        result["error"] = f"tool_loop exception: {type(e).__name__}: {e}"

    return result


def _assess_tier_2a_clarify(config, exec_result):
    """Tier 2a: short prompt → expect CLARIFY, not tool call."""
    if exec_result["error"]:
        return False, exec_result["error"]
    if not exec_result["route_ok"]:
        return False, (f"tier-1 prereq failed: routed to "
                       f"'{exec_result['first_agent']}'")
    tool_calls = exec_result["tool_calls"]
    text = exec_result["text"]
    if tool_calls:
        names = [tc["name"] for tc in tool_calls]
        return False, (f"invoked tool(s) {names} on short prompt — "
                       f"grounding discipline expected CLARIFY")
    if len(text) < 200:
        return False, f"response only {len(text)} chars; CLARIFY should be substantive"
    if "?" not in text:
        return False, "no '?' in response — CLARIFY should ask questions"
    return True, f"CLARIFY response ({len(text)} chars, question-bearing)"


def _assess_tier_2b_bound(config, exec_result):
    """Tier 2b: rich prompt → expect tool call with config.tool_name and
    config.template_key. PASS requires banner too (file actually saved).
    Previous tier-2b revisions PASSed on invocation alone, which counted
    preflight-failed retries as passes — tightened here.

    Session 7: reason strings enriched with gate-rejection count so the
    analysis can distinguish three states on the fly:
      (A) invoked + saved                        → PASS (Problem 1 solved)
      (B) invoked + all gate-rejected            → FAIL (Problem 3 dominates)
      (C) not invoked                            → FAIL (Problem 1 still open)
    Previously B and C were both 'FAIL' with only-partially-distinct reasons;
    now the is_error distribution is surfaced in the reason string itself."""
    if exec_result["error"]:
        return False, exec_result["error"]
    if not exec_result["route_ok"]:
        return False, (f"tier-1 prereq failed: routed to "
                       f"'{exec_result['first_agent']}'")
    tool_calls = exec_result["tool_calls"]
    banners = exec_result["banners"]

    matching_calls = [
        tc for tc in tool_calls
        if tc["name"] == config.tool_name
        and (tc["args"] or {}).get("template") == config.template_key
    ]

    # Session 7: gate-rejection count drawn from tool_results is_error flags.
    # Dispatcher sets is_error=True on preflight rejections; is_error=False on
    # success or bypass-save-with-warnings. Counts results for config.tool_name
    # only so unrelated tool failures don't pollute the signal.
    gate_rejected = sum(
        1 for tr in exec_result["tool_results"]
        if tr.get("name") == config.tool_name and tr.get("is_error")
    )

    if not matching_calls:
        observed = [tc["name"] for tc in tool_calls] or ["(none)"]
        return False, (f"no {config.tool_name} with template={config.template_key}; "
                       f"observed={observed}  [invoked=0, gate_rejected={gate_rejected}]")

    if not banners:
        return False, (f"{len(matching_calls)} tool call(s) made but zero files "
                       f"saved — likely preflight/schema failures on every attempt  "
                       f"[invoked={len(matching_calls)}, gate_rejected={gate_rejected}]")

    return True, (f"{len(matching_calls)} tool call(s), {len(banners)} file(s) saved  "
                  f"[invoked={len(matching_calls)}, gate_rejected={gate_rejected}]")


def run_tier_2(config, client, provider, model_id, n, verbose):
    """Tier 2 invocation — 2a CLARIFY + 2b BOUND. Returns (passed, total, details)."""
    print("=" * 78)
    print(f"TIER 2 — INVOCATION  ({config.agent_name}, model: {model_id}, n={n})")
    print("=" * 78)
    print(f"  Tool under test: {config.tool_name} with template={config.template_key}")
    # Session 7: make forcing state visible at the top of the run so Dan can
    # tell from the output whether the --force-2b arm was active. Avoids
    # misreading a "Tier 2b invocation 10/12" result as the baseline later.
    # Session 9: also report when the agent JSON's force_tool field is
    # active (production deployment path). The two arms are mutually
    # exclusive at runtime — session-7 --force-2b takes precedence when
    # both are set — so the header reports whichever will actually fire.
    if config.force_tool:
        print(f"  TIER 2b forcing: ON (session-7 --force-2b) — "
              f"tool_choice_force_tool({config.force_tool!r})")
    else:
        try:
            _harness_agent_dict = _load_agent(config.agent_name)
        except Exception:
            _harness_agent_dict = None
        _agent_force_tool = (_harness_agent_dict or {}).get("force_tool")
        if _agent_force_tool:
            print(f"  TIER 2b forcing: ON (session-9 production conjunction) — "
                  f"agent.force_tool={_agent_force_tool!r}, fires when Sam "
                  f"classifies step mode=BOUND")
        else:
            print(f"  TIER 2b forcing: off (baseline — no tool_choice override)")
    print(f"  Note: each 2b run may write a real deliverable to the active client's dir.")

    try:
        norm.ensure_self_client_exists()
    except Exception as e:
        print(f"  WARNING: ensure_self_client_exists failed: {e}")

    try:
        system, tools_param = _build_agent_system_prompt(config.agent_name)
    except Exception as e:
        print(f"ERROR: could not build system prompt for {config.agent_name}: {e}")
        return 0, 0, []

    tool_names = [t["name"] for t in tools_param]
    print(f"  Tools available to {config.agent_name}: {tool_names}")
    if config.tool_name not in tool_names:
        print(f"  WARNING: config.tool_name={config.tool_name!r} is not in the "
              f"agent's available tools. Tier 2b will fail all runs.")

    details = []
    passed = 0
    total = 0

    def _run_section(label, prompts, assess_fn, show_banner_on_pass,
                     force_this_section=False):
        # force_this_section: Tier 2b passes True when --force-2b is set;
        # Tier 2a always passes False. Carried through to _execute_and_capture
        # as force_this_call, where it combines with config.force_tool.
        nonlocal passed, total
        for prompt in prompts:
            preview = prompt if len(prompt) <= 80 else prompt[:77] + "..."
            print(f"\n[{label}] {preview}")
            for i in range(n):
                total += 1
                exec_result = _execute_and_capture(
                    config, client, provider, model_id, system, tools_param,
                    prompt, verbose, force_this_call=force_this_section)
                ok, reason = assess_fn(config, exec_result)
                passed += 1 if ok else 0
                mark = "PASS" if ok else "FAIL"
                extra = ""
                if ok and show_banner_on_pass and exec_result["banners"]:
                    b = exec_result["banners"][0]
                    extra = f" → {b.get('filename', '?')} ({b.get('bytes', 0)} B)"
                print(f"  run {i+1}: {mark} — {reason}{extra}")
                if not ok and verbose and exec_result["text"]:
                    print(f"         text (first 300 chars): "
                          f"{exec_result['text'][:300]!r}")
                details.append((label, prompt, i+1, ok, reason))

    print("\n--- TIER 2a — CLARIFY BEHAVIOR (short prompts, expect no tool call) ---")
    # Explicit force_this_section=False on 2a even though it's the default —
    # documentation at the call site that Tier 2a forcing is deliberately
    # excluded. Forcing on CLARIFY prompts would make every assertion fail.
    _run_section("TIER2a", config.short_prompts,
                 _assess_tier_2a_clarify, show_banner_on_pass=False,
                 force_this_section=False)

    print("\n--- TIER 2b — BOUND BEHAVIOR (rich prompts, expect tool invocation + file) ---")
    # Tier 2b forces iff config.force_tool is set (via --force-2b CLI flag).
    # The per-call check in _execute_and_capture handles the conjunction.
    _run_section("TIER2b", config.rich_prompts,
                 _assess_tier_2b_bound, show_banner_on_pass=True,
                 force_this_section=True)

    return passed, total, details


# ═══════════════════════════════════════════════════════════════════════════════
#  ENTRY POINT / DRIVER
# ═══════════════════════════════════════════════════════════════════════════════

TIER_FNS = {
    "1": run_tier_1,
    "2": run_tier_2,
}


def run_tests(config, argv=None):
    """Main entry point called from per-agent test files."""
    ap = argparse.ArgumentParser(
        description=f"Pipeline regression test for {config.agent_name}")
    ap.add_argument("--tier", default="1",
                    help="Tier to run: 1, 2, or 'all'. Default: 1.")
    ap.add_argument("--n", type=int, default=1,
                    help="Iterations per prompt (default 1).")
    ap.add_argument("--verbose", action="store_true",
                    help="Dump router plans and tool captures.")
    ap.add_argument("--force-2b", action="store_true",
                    help="Apply tool_choice_force_tool(config.tool_name) to "
                         "the Tier 2b run_tool_use_loop call. Measures whether "
                         "forcing moves Lilith's session-1 0-25%% invocation "
                         "baseline. Tier 2a is never forced regardless. Goal A "
                         "session 7.")
    args = ap.parse_args(argv)

    # Session 7: --force-2b opts the Tier 2b arm into tool_choice forcing.
    # The tool name already lives in config.tool_name, so the CLI flag just
    # toggles whether it's used; no string arg needed.
    if args.force_2b:
        config.force_tool = config.tool_name

    cfg = norm.load_config()
    client, provider, model_id = norm.build_client(cfg)
    if client is None:
        print(f"ERROR: no API client available for provider={provider}. "
              f"Check ~/.tavernos/config.json.")
        sys.exit(2)

    tiers_to_run = ["1", "2"] if args.tier == "all" else [args.tier]
    if any(t not in TIER_FNS for t in tiers_to_run):
        print(f"ERROR: unknown tier(s) in {tiers_to_run}. "
              f"Valid: {list(TIER_FNS.keys()) + ['all']}")
        sys.exit(2)

    # Cost preview
    n_tier1_prompts = (len(config.short_prompts) + len(config.rich_prompts)
                       + len(config.negative_prompts))
    n_tier2_prompts = len(config.short_prompts) + len(config.rich_prompts)
    t1_calls = n_tier1_prompts * args.n if "1" in tiers_to_run else 0
    t2_calls = n_tier2_prompts * args.n * 2 if "2" in tiers_to_run else 0  # router+agent
    print()
    print(f"(Cost preview: tier 1 = {t1_calls} router calls, "
          f"tier 2 = ~{t2_calls} total API calls including full agent runs.)")
    print(f" Agent: {config.agent_name}  ·  Model: {provider}/{model_id}")
    print()

    t0 = time.time()
    total_passed = 0
    total_runs = 0
    all_details = []

    for tier in tiers_to_run:
        fn = TIER_FNS[tier]
        try:
            passed, total, details = fn(config, client, provider, model_id,
                                        args.n, args.verbose)
            total_passed += passed
            total_runs += total
            all_details.extend(details)
        except NotImplementedError as e:
            print(f"\n[TIER {tier}] SKIPPED — {e}")

    elapsed = time.time() - t0

    print("\n" + "=" * 78)
    print(f"SUMMARY — {config.agent_name}")
    print("=" * 78)
    print(f"Runs: {total_passed}/{total_runs} passed  ·  {elapsed:.1f}s elapsed")

    fails = [d for d in all_details if not d[3]]
    if fails:
        print(f"\nFailures ({len(fails)}):")
        for label, prompt, iteration, _, reason in fails:
            prompt_short = prompt if len(prompt) <= 60 else prompt[:57] + "..."
            print(f"  [{label}] run {iteration}  ·  {prompt_short}")
            print(f"        {reason}")

    sys.exit(0 if total_passed == total_runs else 1)