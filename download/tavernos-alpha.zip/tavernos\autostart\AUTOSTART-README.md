# TavernOS Web UI — Autostart & Reliability

This directory contains install scripts that make the TavernOS web UI
(`norm --web`, at http://127.0.0.1:7777) **available whenever the machine is
on** — without the customer having to open a terminal first.

## What the scripts do

- Register `norm --web` to launch automatically when the user logs in.
- Tell the OS to **restart the process if it crashes** (Windows Task
  Scheduler retries up to 3×/minute; macOS launchd's `KeepAlive` restarts
  the process whenever it exits).
- Run silently — no console or terminal window appears at login.

Together with the resilience logic in `norm.py` (`--web-status`, port
conflict detection, "already running" handling, auto-open browser), this
gives customers **a web UI that "just works"** — always running, always at
the same URL, auto-recovers from crashes.

## Installation

### Windows

Open PowerShell in the folder containing the scripts, then run:

```powershell
.\install-autostart-windows.ps1
```

No admin rights needed — this creates a **per-user** scheduled task.

### macOS

Open Terminal in the folder containing the scripts, then run:

```bash
chmod +x install-autostart-mac.sh
./install-autostart-mac.sh
```

## Checking status

At any time, from any terminal:

```
norm --web-status
```

You'll get one of three answers:
- `✓ Web UI is running at http://127.0.0.1:7777`
- `⚠ Web UI is not running` (plus how to start it)
- `⚠ Port 7777 is in use but not by TavernOS` (plus how to diagnose)

## Where logs go

**Windows:** logs are captured by Task Scheduler itself — view them in
Task Scheduler UI under **TavernOS-Web → History**.

**macOS:** logs are streamed to:
- `~/.tavernos/web.log`  (stdout)
- `~/.tavernos/web.err.log`  (stderr)

Tail them live with:
```bash
tail -f ~/.tavernos/web.log
```

## Uninstall

### Windows
```powershell
.\uninstall-autostart-windows.ps1
```

### macOS
```bash
./uninstall-autostart-mac.sh
```

Either script safely removes the autostart registration without touching
your TavernOS install or data. You can still run `norm --web` manually
afterwards.

## Troubleshooting

**"I installed but nothing happens at login."**
- Windows: open Task Scheduler, find `TavernOS-Web`, right-click → Run. If
  it errors, History will show why.
- Mac: run `launchctl list | grep tavernos`. If the `PID` column shows `-`
  and the `Status` is non-zero, check `~/.tavernos/web.err.log` for the
  crash reason.

**"Port 7777 is already in use."**
- Something else (Google Drive, a dev server, another copy of Norm) is
  squatting the port. Run `norm --web-status` — it'll tell you whether the
  squatter is another Norm instance or something else, and give you the
  command to find it.

**"I want to use a different port."**
- Not supported yet — `norm --web` always binds to 7777. If this blocks
  you, file feedback from inside Norm with `/feedback 3 port-conflict`.
