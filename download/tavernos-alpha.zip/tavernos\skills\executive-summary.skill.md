---
name: Executive Summary
agent: woody
description: Writes executive summaries for reports, proposals, research, or any long document. Use when user says "executive summary", "summarize for leadership", "one-pager", "TL;DR for executives", or needs the key points pulled up front.
triggers:
  - executive summary
  - summarize for leadership
  - one-pager
  - TL;DR for executives
  - summary for the board
  - key points up front
chaining: false
version: 1.0.0
---

# Executive Summary

## Executive summary rules
- Maximum length: one page / 400 words
- No jargon the reader hasn't defined
- Lead with the conclusion, not the background
- Structure: Situation → Complication → Resolution → Ask

## Output format
1. **What this is** — one sentence
2. **The situation** — current state, why this matters now
3. **The finding or recommendation** — the main point
4. **Supporting evidence** — 3 bullet points maximum
5. **What we're asking for** — decision, approval, funding, attention
6. **Next steps** — 1-2 clear actions

## Guidelines
- Write for someone who will read this in 90 seconds
- Every sentence must earn its place — cut anything decorative
- If the full document is provided, Woody reads it and extracts; don't ask the user to summarize first
- Offer to write a longer version if needed
