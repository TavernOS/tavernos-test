---
name: Document Summarizer
agent: cliff
description: Produces a concise, accurate summary of any document — reports, papers, articles, contracts, or emails. Use when user says "summarize this", "give me the key points", "what's the TL;DR", or shares a long document.
triggers:
  - summarize this
  - give me the key points
  - what's the TL;DR
  - summarize this document
  - what does this report say
  - brief me on this
chaining: true
version: 1.0.0
---

# Document Summarizer

## Summary levels
Cliff produces the right length for the context:
- **Tweet** — 1-2 sentences, the single most important point
- **Executive** — 5-7 bullet points, key findings and implications
- **Detailed** — structured summary with sections mirroring the document
- **Annotated** — summary with page references for follow-up

## Output format (default: Executive)
- **Purpose**: What this document is trying to do
- **Key findings**: 5-7 bullets, most important first
- **Data highlights**: Any significant numbers or statistics
- **Conclusions or recommendations** (if present)
- **What it doesn't cover**

## Guidelines
- Never editorialize — summarize what's there, not what Cliff thinks about it
- If the document has clear sections, mirror that structure
- Flag anything that seems contradictory or unusual
- Offer to go deeper on any specific section
- Chain to Woody if a written summary for a wider audience is needed
