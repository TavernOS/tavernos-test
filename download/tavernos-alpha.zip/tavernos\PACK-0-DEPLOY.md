# Pack 0 — Deploy & Test Checklist

All 5 phases of the multi-client framework are live in `norm.py`.
File grew from 1,795 → 2,380 lines (+585). No new dependencies.

---

## Install

1. **Back up your current file** (in case you want to roll back):
   ```powershell
   Copy-Item C:\TavernOS\tavernos\norm.py C:\TavernOS\tavernos\norm.py.pre-pack0
   ```

2. **Drop the new file in place:**
   ```
   C:\TavernOS\tavernos\norm.py
   ```
   (Overwrite the existing file.)

3. **No pip install needed.** Pack 0 uses only stdlib modules already in use (`shutil`, `sqlite3`, `zipfile`, `subprocess`, `json`, `re`, `datetime`).

---

## First-run expected behavior

Open a fresh PowerShell and run `norm`. You should see:

```
  ████████╗ █████╗ ██╗   ██╗███████╗██████╗ ███╗  ██╗ ██████╗ ███████╗
  ...
               Norm! Yeah, yeah... what'll it be today?

  ◆ Multi-client mode enabled.
  Your existing data is now under workspace: _self
  Add your first paying client with: /client new

  ✓  claude-haiku-4-5 [ANTHROPIC] — streaming enabled · v0.1.0 · semantic search
  /model to switch · /help for all commands
  Type /help for commands, or just tell the tavern what you need.

❯
```

The "Multi-client mode enabled" banner only shows once — the first run that does the migration.

**What happened under the hood:**
- `~/.tavernos/clients/_self/` was created with the full folder structure (`memory/`, `intake/`, `notes/`, `deliverables/{audits,blueprints,content,reports}/`)
- Your existing `~/.tavernos/memory/*.db` files moved into `~/.tavernos/clients/_self/memory/`
- A `MIGRATED.txt` breadcrumb was left in the old location
- `~/.tavernos/clients/_active` was created with contents `_self`
- A new `~/.tavernos/skill_performance_global.db` was initialized (empty)

---

## Test checklist — run through these in order

### 1. Sanity — no regressions
```
❯ /help
❯ /files
❯ What's 2+2?
```
Everything should work exactly as before. Your files, history, and agents are intact.

### 2. See the new commands
```
❯ /help
```
Scan for `/client`, `/who`, `/save` — they should all be listed now (or at minimum, should work when invoked; the help text itself wasn't modified in Pack 0).

### 3. You're currently in `_self` (the TavernOS workspace)
```
❯ /who
❯ /client
❯ /client list
```
`/who` shows a one-line reminder. `/client` opens the info box. `/client list` shows only `_self` for now (the ● marker shows it's active).

### 4. Create your first real client
```
❯ /client new
```
Fill in: name, slug (auto-suggested), industry, size, contact, services (comma-separated), notes. You're testing the wizard flow — nothing is sent anywhere, it just writes to `~/.tavernos/clients/<slug>/client.json`.

### 5. Switch into the new workspace
```
❯ /client switch <slug>
❯ /who
```
Confirms the active workspace changed. Conversation history was cleared on the switch (that's intentional — different client, different conversation).

### 6. Verify context injection is live
```
❯ Write a one-paragraph intro email for a new prospect
```
The agent (Woody, probably) should address your test client by name if you filled in the services. This tests Phase 4 — the `CURRENT CLIENT CONTEXT` block is being injected into the system prompt.

### 7. Save a deliverable
```
❯ /save content intro-email.md
```
After a response lands, save it into `deliverables/content/`. Then:
```
❯ /client deliver
```
Should list the file you just saved.

### 8. Switch back to `_self` and verify isolation
```
❯ /client switch _self
❯ /files
❯ /history
```
You should see your original files from `_self`, not the test client's. Data isolation is working.

### 9. Archive and restore (cleanup)
```
❯ /client archive <test-client-slug>
❯ /client list
❯ /client restore <test-client-slug>
❯ /client list
```

### 10. Launch directly into a client
Close the session, then from PowerShell:
```
norm --client <slug>
```
You boot straight into that workspace. If `<slug>` doesn't exist you get a warning and fall back to the last-active workspace.

### 11. Perf scoring (dev mode only)
```
norm --dev
❯ /scores
❯ /scores --global
```
`/scores` shows current client's skill performance. `/scores --global` shows cross-client aggregate with a "Client" column.

---

## Command reference — new in Pack 0

| Command | What it does |
|---|---|
| `norm --client <slug>` | Boot into a specific workspace |
| `/who` | One-line "you're in: X" |
| `/client` or `/client info` | Full info card on current client |
| `/client list` | Table of all clients (active + archived) |
| `/client new` | Interactive wizard to create a client |
| `/client switch <slug>` | Change active workspace |
| `/client edit` | Open `client.json` in `$EDITOR` (falls back to `notepad` on Windows) |
| `/client archive <slug>` | Soft-delete — moves to `clients/_archived/` |
| `/client restore <slug>` | Move back from archive |
| `/client deliver` | List deliverables in current workspace |
| `/client package` | Zip current workspace to `Desktop/TavernOS-<slug>-handoff-<date>.zip` |
| `/save <category> <filename>` | Save the last assistant response into `deliverables/<category>/` |
| `/scores --global` | Cross-client performance aggregate |

Categories for `/save`: `audits`, `blueprints`, `content`, `reports` (unknown ones fall through to `reports`).

---

## Rollback

If anything goes sideways:
```powershell
Copy-Item C:\TavernOS\tavernos\norm.py.pre-pack0 C:\TavernOS\tavernos\norm.py -Force
```

Your data isn't lost by rolling back — the old `~/.tavernos/memory/*.db` files *moved* to `~/.tavernos/clients/_self/memory/` during migration. If you roll back the code, you'd also want to move those dbs back to the old location:

```powershell
Move-Item $env:USERPROFILE\.tavernos\clients\_self\memory\*.db $env:USERPROFILE\.tavernos\memory\
```

---

## Notification for the other chat

Once you've confirmed Pack 0 works end-to-end, paste this into your skill-building chat:

> **Pack 0 has shipped — every Norm install is now multi-client.**
>
> Every skill now receives a `CURRENT CLIENT CONTEXT` block automatically injected into its system prompt (except when the active workspace is `_self`, which is the consultant's own workspace).
>
> The block includes: client name, slug, industry, company size, active services, current tools, active workflows, primary contact, voice profile path, audit doc path, and operator notes — whichever fields are populated.
>
> **What to update in Pack 1 (Implementation) and Pack 2 (Content Ops) skill prompts:**
> 1. Address the client by name in deliverables ("This audit is for ABC Corp...")
> 2. Reference the client's known tools and services in recommendations
> 3. At the end of major outputs, suggest a save path like:
>    `_Save this deliverable to:_ \`clients/<slug>/deliverables/<category>/<filename>.md\``
>    Valid categories: `audits`, `blueprints`, `content`, `reports`.
> 4. For content skills specifically: check if `voice_profile_path` is set in the context and load from there if available; otherwise produce neutral drafts.
>
> No code-level skill changes needed — just prompt updates.
>
> New skills going forward should follow the same conventions from the start.

---

## What's not done yet (future phases)

- **Web UI multi-client support** (`norm --web`) — the FastAPI server at `localhost:7777` doesn't have a workspace selector yet. Framework doc section 9. Out of scope for Pack 0.
- **`/help` text update** — the help output doesn't list the new commands. Small cosmetic follow-up.
- **Customer setup (`norm --setup`) adaptation** — currently builds a single-workspace customer zip. Eventually should support per-client packaging for Mode 2 handoffs. Framework doc section 10.
