# verify-friend-zip.ps1
# Unzips the friend ZIP to a throwaway folder and runs 5 checks:
#   1) File-count summary
#   2) Leak scan across all shipped files (with suppression for audit check logic)
#   3) Absence check (things that must NOT be in the ZIP)
#   4) Presence check (things that MUST be in the ZIP)
#   5) Python compile check on norm.py
# ASCII-only, PowerShell 5 compatible.

$ErrorActionPreference = "Stop"
$zip = Join-Path $HOME "Downloads\tavernos-alpha.zip"
if (-not (Test-Path $zip)) {
    Write-Host "  ! ZIP not found at $zip. Run .\refresh-friend-zip.ps1 first." -ForegroundColor Red
    exit 1
}

$test = Join-Path $env:TEMP "tavernos-friend-test"
if (Test-Path $test) { Remove-Item -Recurse -Force $test }
Expand-Archive -Path $zip -DestinationPath $test

Write-Host ("=== Unzipped to " + $test + " ===") -ForegroundColor Cyan
$allPass = $true

Write-Host ""
Write-Host "=== 1. File count by folder ===" -ForegroundColor Cyan
Get-ChildItem $test -Recurse -File |
    Group-Object { ($_.DirectoryName -replace [regex]::Escape($test), '').TrimStart('\') } |
    Sort-Object Name |
    Format-Table Count, Name -AutoSize

Write-Host ""
Write-Host "=== 2. Leak scan across all shipped files ===" -ForegroundColor Cyan
$patterns = 'hypothetica','maya chen','maya rodriguez','jamie patel','meridian ventures','foldco','dan cobb','dan cooper','dan@tavernos','brightwave','zephyr','@maya'
$rescanSuppressions = @('FORBIDDEN_STRINGS_IN_HTML')

$hits = Get-ChildItem $test -Recurse -File -Include *.py,*.json,*.md,*.txt,*.html -ErrorAction SilentlyContinue |
    Select-String -Pattern $patterns

# Filter out known false positives (audit check logic)
$suppressedCount = 0
if ($hits) {
    $filtered = New-Object System.Collections.ArrayList
    foreach ($hit in $hits) {
        $isSuppressed = $false
        foreach ($s in $rescanSuppressions) {
            if ($hit.Line.Contains($s)) { $isSuppressed = $true; break }
        }
        if ($isSuppressed) { $suppressedCount++ }
        else { [void]$filtered.Add($hit) }
    }
    $hits = $filtered.ToArray()
}

if ($suppressedCount -gt 0) {
    Write-Host ("  (suppressed " + $suppressedCount + " known false positive(s) - audit check logic)") -ForegroundColor DarkGray
}

if ($hits -and $hits.Count -gt 0) {
    Write-Host "  ! LEAKS:" -ForegroundColor Red
    $hits | ForEach-Object {
        $rel = $_.Path.Replace($test + '\', '')
        Write-Host ("    " + $rel + ":" + $_.LineNumber + "  " + $_.Line.Trim())
    }
    $allPass = $false
} else {
    Write-Host "  + no leaks" -ForegroundColor Green
}

Write-Host ""
Write-Host "=== 3. Absence check (must NOT be in ZIP) ===" -ForegroundColor Cyan
$mustBeAbsent = @(
    'hypothetica.py',
    'hypothetica_audit_spec.py',
    'hypothetica_research_report_spec.py',
    'eval_logs',
    'autostart',
    'PACK-0-DEPLOY.md',
    'docs.html',
    'backfill_scores_from_eval_logs.py',
    'run_audit_eval.py',
    'run_eval.py',
    'run_research_eval.py',
    'web\access.html',
    'web\wip.html',
    'web\_redirects',
    'web\index.html'
)
$violations = @()
foreach ($item in $mustBeAbsent) {
    if (Test-Path (Join-Path $test $item)) { $violations += $item }
}
if ($violations.Count -gt 0) {
    Write-Host "  ! STILL PRESENT:" -ForegroundColor Red
    $violations | ForEach-Object { Write-Host ("    " + $_) }
    $allPass = $false
} else {
    Write-Host "  + all absent" -ForegroundColor Green
}

Write-Host ""
Write-Host "=== 4. Presence check (MUST be in ZIP) ===" -ForegroundColor Cyan
$mustBePresent = @(
    'norm.py',
    'evaluator.py',
    'artifact_docx.py',
    'artifact_xlsx.py',
    'artifact_pptx.py',
    'mcp_client.py',
    'server.py',
    'tavernos_audit.py',
    'tavernos_ux.py',
    'requirements.txt',
    'agents\sam.json',
    'agents\woody.json',
    'agents\rebecca.json',
    'skills\ops-audit.skill.md',
    'skills\rebecca-monthly-business-review.skill.md',
    'web\__init__.py',
    'web\static'
)
$missing = @()
foreach ($item in $mustBePresent) {
    if (-not (Test-Path (Join-Path $test $item))) { $missing += $item }
}
if ($missing.Count -gt 0) {
    Write-Host "  ! MISSING:" -ForegroundColor Red
    $missing | ForEach-Object { Write-Host ("    " + $_) }
    $allPass = $false
} else {
    Write-Host "  + all present" -ForegroundColor Green
}

Write-Host ""
Write-Host "=== 5. Python compile check on norm.py ===" -ForegroundColor Cyan
Push-Location $test
try {
    $out = & python -m py_compile norm.py 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Host "  + norm.py compiles" -ForegroundColor Green
    } else {
        Write-Host "  ! norm.py compile failed:" -ForegroundColor Red
        $out | ForEach-Object { Write-Host ("    " + $_) }
        $allPass = $false
    }
} finally {
    Pop-Location
}

Write-Host ""
if ($allPass) {
    Write-Host "=== ALL CHECKS PASSED ===" -ForegroundColor Green
    Write-Host "ZIP is clean. Safe to push to site repo." -ForegroundColor Green
} else {
    Write-Host "=== ONE OR MORE CHECKS FAILED ===" -ForegroundColor Red
    Write-Host "Do not push. Fix the issues above and re-run .\refresh-friend-zip.ps1" -ForegroundColor Red
}
Write-Host ""
Write-Host ("Throwaway test folder: " + $test + " (delete when done)") -ForegroundColor DarkGray
