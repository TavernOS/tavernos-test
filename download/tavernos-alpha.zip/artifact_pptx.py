"""
tavernos/artifact_pptx.py — branded PowerPoint deck generator.

Shipped as part of Phase 2 (artifact generation), sibling to artifact_xlsx.py
and artifact_docx.py. Same "domain module next to norm.py" pattern, same
sentinel-line contract with norm.py's tool dispatcher.

Architecture notes
------------------
Agent handoff is a first-party tool call (`generate_pptx_deck`) registered
into norm.py's existing tool-use loop. Rebecca calls the tool with a JSON
spec, the tool writes the .pptx, returns the saved path. Rebecca owns both
xlsx and pptx — the data-focused deliverables.

Builder scope
-------------
Phase 2 ships one template: `executive_review_deck`. Slides are a typed
sequence in the spec (title / section / content / kpis / table / closing),
so Rebecca can assemble arbitrary decks without the builder hardcoding
deck structure.

Brand tokens mirror the strategy-doc stack: teal #009688, navy #0F2236,
Arial body, Consolas mono. Widescreen 16:9 (13.333" × 7.5").

Fabrication posture
-------------------
Same as artifact_docx: the builder does not inject placeholder prose. If a
slide's content is sparse, that's the agent's choice under the grounding
discipline. One exception — a `content` slide with no bullets renders a
single "[TBD — content]" grey italic placeholder so the slide isn't blank.
"""

from __future__ import annotations

import json
import re
import traceback
from datetime import datetime
from pathlib import Path
from typing import Any

# ═══════════════════════════════════════════════════════════════════════════════
#  PYTHON-PPTX IMPORT — hard dependency. Missing = clean ImportError callers
#  can catch (same contract as the xlsx/docx siblings).
# ═══════════════════════════════════════════════════════════════════════════════

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Emu, Inches, Pt


# ═══════════════════════════════════════════════════════════════════════════════
#  BRAND TOKENS — consolidated. Parity with artifact_xlsx / artifact_docx.
# ═══════════════════════════════════════════════════════════════════════════════

TEAL = RGBColor(0x00, 0x96, 0x88)
NAVY = RGBColor(0x0F, 0x22, 0x36)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
INK = RGBColor(0x0F, 0x22, 0x36)
SUBTLE = RGBColor(0xE8, 0xEE, 0xF1)
GREY = RGBColor(0x6B, 0x7A, 0x88)

FONT_BODY = "Arial"
FONT_MONO = "Consolas"

# Widescreen 16:9 — the modern default. 10"x7.5" was 4:3 and looks dated
# projected to anyone's current monitor.
SLIDE_WIDTH = Inches(13.333)
SLIDE_HEIGHT = Inches(7.5)


# ═══════════════════════════════════════════════════════════════════════════════
#  SPEC VALIDATION — same posture as siblings. Actionable error messages get
#  returned to the agent verbatim via tool_result.
# ═══════════════════════════════════════════════════════════════════════════════

class PptxSpecError(ValueError):
    """Raised when a spec fails validation. Surfaced verbatim to the agent."""


_FILENAME_SAFE = re.compile(r"[^A-Za-z0-9._-]")
_VALID_SLIDE_TYPES = {"title", "section", "content", "kpis", "table", "closing"}

def _sanitize_filename(name: str) -> str:
    if not name or not isinstance(name, str):
        raise PptxSpecError("filename must be a non-empty string")
    name = name.strip()
    if ".." in name or "/" in name or "\\" in name:
        raise PptxSpecError("filename must not contain path separators or '..'")
    if name.lower().endswith(".pptx"):
        name = name[:-5]
    name = _FILENAME_SAFE.sub("-", name).strip("-")
    if not name:
        raise PptxSpecError("filename reduces to empty after sanitization")
    return name + ".pptx"


def _validate_spec(spec: Any) -> None:
    """Structural check. Slides list may be empty — produces a deck with just
    the implicit title slide from `meta`. That's a legitimate BOUND output."""
    if not isinstance(spec, dict):
        raise PptxSpecError("spec must be a JSON object")
    if spec.get("artifact") != "pptx":
        raise PptxSpecError("spec.artifact must equal 'pptx'")
    template = spec.get("template")
    if template not in BUILDERS:
        valid = ", ".join(sorted(BUILDERS.keys()))
        raise PptxSpecError(
            f"spec.template must be one of: {valid}. Got: {template!r}"
        )
    if not spec.get("filename"):
        raise PptxSpecError("spec.filename is required")
    slides = spec.get("slides")
    if slides is not None:
        if not isinstance(slides, list):
            raise PptxSpecError("spec.slides must be a list")
        for i, sl in enumerate(slides):
            if not isinstance(sl, dict):
                raise PptxSpecError(f"slides[{i}] must be an object")
            t = sl.get("type")
            if t not in _VALID_SLIDE_TYPES:
                valid = ", ".join(sorted(_VALID_SLIDE_TYPES))
                raise PptxSpecError(
                    f"slides[{i}].type must be one of: {valid}. Got: {t!r}"
                )


# ═══════════════════════════════════════════════════════════════════════════════
#  LOW-LEVEL HELPERS — shape factories and text styling. python-pptx's model
#  is less verbose than docx's but still benefits from factoring.
# ═══════════════════════════════════════════════════════════════════════════════

def _blank_slide(prs: Presentation):
    """Return a blank slide. We avoid built-in layouts because they inject
    placeholders with fonts and colors we didn't choose."""
    return prs.slides.add_slide(prs.slide_layouts[6])  # layout[6] is the blank layout


def _add_rect(slide, left, top, width, height, fill: RGBColor,
              line: RGBColor = None):
    """Draw a filled rectangle. Used for title bars, section bands, KPI tiles."""
    shape = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE, left, top, width, height
    )
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill
    if line is None:
        shape.line.fill.background()   # no visible line
    else:
        shape.line.color.rgb = line
    shape.shadow.inherit = False  # kill the default PowerPoint drop shadow
    return shape


def _add_text(slide, left, top, width, height, text: str, *,
              size: int = 18, bold: bool = False, italic: bool = False,
              color: RGBColor = INK, font: str = FONT_BODY,
              align: int = PP_ALIGN.LEFT, anchor: int = MSO_ANCHOR.TOP):
    """Add a standalone text box. Returns the shape so caller can append more
    paragraphs for multi-line content."""
    tb = slide.shapes.add_textbox(left, top, width, height)
    tf = tb.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = anchor
    tf.margin_left = Inches(0.1)
    tf.margin_right = Inches(0.1)
    tf.margin_top = Inches(0.05)
    tf.margin_bottom = Inches(0.05)
    p = tf.paragraphs[0]
    p.alignment = align
    r = p.add_run()
    r.text = text
    r.font.name = font
    r.font.size = Pt(size)
    r.font.bold = bold
    r.font.italic = italic
    r.font.color.rgb = color
    return tb


def _add_bullets(slide, left, top, width, height, items: list[str], *,
                 size: int = 20, color: RGBColor = INK):
    """Add a bulleted list. Each item is a paragraph with a bullet glyph
    prepended — simpler than wrestling with python-pptx's list formatting
    which requires xml-level list-style paragraphs and renders inconsistently
    across PowerPoint versions."""
    tb = slide.shapes.add_textbox(left, top, width, height)
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = Inches(0.1)
    tf.margin_right = Inches(0.1)
    tf.margin_top = Inches(0.05)
    tf.margin_bottom = Inches(0.05)
    for i, item in enumerate(items):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = PP_ALIGN.LEFT
        p.space_after = Pt(10)
        r = p.add_run()
        r.text = f"•  {item}"
        r.font.name = FONT_BODY
        r.font.size = Pt(size)
        r.font.color.rgb = color
    return tb


def _set_notes(slide, notes_text: str) -> None:
    """Attach speaker notes to a slide. python-pptx auto-creates the notes
    slide lazily — first access to notes_slide creates it."""
    if not notes_text:
        return
    ns = slide.notes_slide
    tf = ns.notes_text_frame
    tf.clear()
    p = tf.paragraphs[0]
    r = p.add_run()
    r.text = notes_text
    r.font.name = FONT_BODY
    r.font.size = Pt(11)


# ═══════════════════════════════════════════════════════════════════════════════
#  SLIDE RENDERERS — one per slide type. Each takes (prs, slide_spec) and
#  appends a fully-rendered slide. Keeping these small and named makes it
#  easy to add a seventh/eighth type later.
# ═══════════════════════════════════════════════════════════════════════════════

def _render_title(prs: Presentation, s: dict) -> None:
    """Big title slide. Navy full-bleed background, teal accent bar, white
    text. Used as slide 0 OR any time the agent wants a separator that
    opens a new major section with weight."""
    slide = _blank_slide(prs)

    # Full-bleed navy background
    _add_rect(slide, Emu(0), Emu(0), SLIDE_WIDTH, SLIDE_HEIGHT, NAVY)

    # Teal accent bar — thin horizontal line left-of-title
    _add_rect(slide, Inches(1), Inches(2.9), Inches(1.2), Inches(0.08), TEAL)

    title = s.get("title") or "Executive Review"
    _add_text(slide, Inches(1), Inches(3.1), Inches(11.3), Inches(1.4),
              title, size=44, bold=True, color=WHITE, anchor=MSO_ANCHOR.TOP)

    subtitle = s.get("subtitle") or ""
    if subtitle:
        _add_text(slide, Inches(1), Inches(4.4), Inches(11.3), Inches(0.6),
                  subtitle, size=20, color=WHITE, anchor=MSO_ANCHOR.TOP)

    # Metadata strip along the bottom: prepared_by · date · client_name
    meta_bits = []
    for key in ("prepared_by", "date", "client_name"):
        val = s.get(key)
        if val:
            meta_bits.append(str(val))
    if meta_bits:
        _add_text(slide, Inches(1), Inches(6.7), Inches(11.3), Inches(0.4),
                  " · ".join(meta_bits), size=12, color=WHITE)

    _set_notes(slide, s.get("notes") or "")


def _render_section(prs: Presentation, s: dict) -> None:
    """Section divider. Teal full-bleed, white title — visually loud, short."""
    slide = _blank_slide(prs)
    _add_rect(slide, Emu(0), Emu(0), SLIDE_WIDTH, SLIDE_HEIGHT, TEAL)

    title = s.get("title") or "Section"
    _add_text(slide, Inches(1), Inches(3.1), Inches(11.3), Inches(1.4),
              title, size=40, bold=True, color=WHITE, anchor=MSO_ANCHOR.TOP)

    subtitle = s.get("subtitle") or ""
    if subtitle:
        _add_text(slide, Inches(1), Inches(4.4), Inches(11.3), Inches(0.6),
                  subtitle, size=18, color=WHITE, italic=True)

    _set_notes(slide, s.get("notes") or "")


def _render_content(prs: Presentation, s: dict) -> None:
    """The workhorse: title + bulleted body. Empty bullet list → TBD
    placeholder so the slide isn't visually empty (matches artifact_docx)."""
    slide = _blank_slide(prs)

    # Thin teal bar along the top as a branded frame element
    _add_rect(slide, Emu(0), Emu(0), SLIDE_WIDTH, Inches(0.12), TEAL)

    title = s.get("title") or ""
    _add_text(slide, Inches(0.7), Inches(0.4), Inches(12), Inches(0.9),
              title, size=28, bold=True, color=NAVY)

    # Optional subtitle under the title, italic grey
    subtitle = s.get("subtitle") or ""
    if subtitle:
        _add_text(slide, Inches(0.7), Inches(1.1), Inches(12), Inches(0.4),
                  subtitle, size=14, italic=True, color=GREY)
        body_top = Inches(1.7)
    else:
        body_top = Inches(1.4)

    bullets = s.get("bullets") or []
    if bullets:
        _add_bullets(slide, Inches(0.7), body_top, Inches(12),
                     SLIDE_HEIGHT - body_top - Inches(0.5),
                     bullets, size=20, color=INK)
    else:
        _add_text(slide, Inches(0.7), body_top, Inches(12), Inches(0.6),
                  "[TBD — content]", size=16, italic=True, color=GREY)

    _set_notes(slide, s.get("notes") or "")


def _render_kpis(prs: Presentation, s: dict) -> None:
    """Big-number strip. Up to 4 KPI tiles across the slide. Pairs visually
    with Rebecca's MBR xlsx Summary sheet."""
    slide = _blank_slide(prs)
    _add_rect(slide, Emu(0), Emu(0), SLIDE_WIDTH, Inches(0.12), TEAL)

    title = s.get("title") or "Key Metrics"
    _add_text(slide, Inches(0.7), Inches(0.4), Inches(12), Inches(0.9),
              title, size=28, bold=True, color=NAVY)

    kpis = (s.get("kpis") or [])[:4]  # clamp — visually won't fit more
    if not kpis:
        _add_text(slide, Inches(0.7), Inches(1.7), Inches(12), Inches(0.6),
                  "[TBD — KPI tiles]", size=16, italic=True, color=GREY)
        _set_notes(slide, s.get("notes") or "")
        return

    # Tile layout: evenly distribute across the usable 12" width
    n = len(kpis)
    gap = Inches(0.3)
    margin = Inches(0.7)
    usable = SLIDE_WIDTH - 2 * margin - gap * (n - 1) if n > 1 else SLIDE_WIDTH - 2 * margin
    tile_w = Emu(int(usable / n)) if n > 0 else usable
    tile_h = Inches(3.4)
    tile_top = Inches(2.1)

    for i, k in enumerate(kpis):
        left = margin + (tile_w + gap) * i if n > 1 else margin
        # Subtle fill tile
        _add_rect(slide, left, tile_top, tile_w, tile_h, SUBTLE)
        # Teal top border (thin filled rect inside the tile)
        _add_rect(slide, left, tile_top, tile_w, Inches(0.08), TEAL)

        value = str(k.get("value") or "—")
        label = str(k.get("label") or "")
        delta = k.get("delta")

        # Big number — use mono font for alignment consistency
        _add_text(slide, left, tile_top + Inches(0.6), tile_w, Inches(1.6),
                  value, size=48, bold=True, color=NAVY,
                  font=FONT_MONO, align=PP_ALIGN.CENTER,
                  anchor=MSO_ANCHOR.MIDDLE)
        # Label
        _add_text(slide, left, tile_top + Inches(2.2), tile_w, Inches(0.5),
                  label, size=14, color=INK, align=PP_ALIGN.CENTER)
        # Optional delta line (e.g. "+12% vs plan")
        if delta:
            _add_text(slide, left, tile_top + Inches(2.7), tile_w, Inches(0.4),
                      str(delta), size=12, italic=True, color=GREY,
                      align=PP_ALIGN.CENTER)

    _set_notes(slide, s.get("notes") or "")


def _render_table(prs: Presentation, s: dict) -> None:
    """Title + pptx-native table. Columns derived from the first row's keys
    OR an explicit 'columns' list. Empty rows → single TBD row."""
    slide = _blank_slide(prs)
    _add_rect(slide, Emu(0), Emu(0), SLIDE_WIDTH, Inches(0.12), TEAL)

    title = s.get("title") or ""
    _add_text(slide, Inches(0.7), Inches(0.4), Inches(12), Inches(0.9),
              title, size=28, bold=True, color=NAVY)

    rows = s.get("rows") or []
    columns = s.get("columns")
    if not columns:
        if rows:
            # Derive column order from first row's keys
            columns = list(rows[0].keys())
        else:
            columns = []

    if not columns or not rows:
        _add_text(slide, Inches(0.7), Inches(1.7), Inches(12), Inches(0.6),
                  "[TBD — table rows]", size=16, italic=True, color=GREY)
        _set_notes(slide, s.get("notes") or "")
        return

    n_rows = len(rows) + 1  # +1 for header
    n_cols = len(columns)
    tbl_left = Inches(0.7)
    tbl_top = Inches(1.7)
    tbl_width = Inches(12)
    tbl_height = Inches(5.0)

    table_shape = slide.shapes.add_table(n_rows, n_cols, tbl_left, tbl_top,
                                         tbl_width, tbl_height)
    table = table_shape.table

    # Header row — teal fill, white bold text
    for c, col_name in enumerate(columns):
        cell = table.cell(0, c)
        cell.fill.solid()
        cell.fill.fore_color.rgb = TEAL
        tf = cell.text_frame
        tf.clear()
        p = tf.paragraphs[0]
        p.alignment = PP_ALIGN.LEFT
        r = p.add_run()
        r.text = str(col_name).replace("_", " ").title()
        r.font.name = FONT_BODY
        r.font.size = Pt(14)
        r.font.bold = True
        r.font.color.rgb = WHITE

    # Data rows
    for row_idx, row_data in enumerate(rows, start=1):
        for c, col_name in enumerate(columns):
            cell = table.cell(row_idx, c)
            cell.fill.solid()
            cell.fill.fore_color.rgb = WHITE if row_idx % 2 == 1 else SUBTLE
            tf = cell.text_frame
            tf.clear()
            p = tf.paragraphs[0]
            p.alignment = PP_ALIGN.LEFT
            r = p.add_run()
            r.text = str(row_data.get(col_name, ""))
            r.font.name = FONT_BODY
            r.font.size = Pt(12)
            r.font.color.rgb = INK

    _set_notes(slide, s.get("notes") or "")


def _render_closing(prs: Presentation, s: dict) -> None:
    """Summary / next-steps slide. Same frame as content but with a softer
    color palette — navy title on subtle fill background."""
    slide = _blank_slide(prs)
    # Soft subtle band along the top, no teal bar (visually differentiates
    # from content slides)
    _add_rect(slide, Emu(0), Emu(0), SLIDE_WIDTH, Inches(2.0), SUBTLE)

    title = s.get("title") or "Next Steps"
    _add_text(slide, Inches(0.7), Inches(0.5), Inches(12), Inches(1.2),
              title, size=32, bold=True, color=NAVY, anchor=MSO_ANCHOR.MIDDLE)

    bullets = s.get("bullets") or []
    if bullets:
        _add_bullets(slide, Inches(0.7), Inches(2.5), Inches(12),
                     Inches(4.5), bullets, size=22, color=INK)
    else:
        _add_text(slide, Inches(0.7), Inches(2.5), Inches(12), Inches(0.6),
                  "[TBD — closing bullets]", size=16, italic=True, color=GREY)

    _set_notes(slide, s.get("notes") or "")


_SLIDE_RENDERERS = {
    "title":   _render_title,
    "section": _render_section,
    "content": _render_content,
    "kpis":    _render_kpis,
    "table":   _render_table,
    "closing": _render_closing,
}


# ═══════════════════════════════════════════════════════════════════════════════
#  BUILDER — executive_review_deck. Renders the deck from a slides[] sequence.
# ═══════════════════════════════════════════════════════════════════════════════

def _build_executive_review_deck(spec: dict) -> Presentation:
    """Render a deck. Slides come from spec.slides. If slides is empty or
    missing, the deck gets a single implicit title slide from spec.meta —
    enough scaffold for a BOUND-path response without hardcoding structure."""
    prs = Presentation()
    prs.slide_width = SLIDE_WIDTH
    prs.slide_height = SLIDE_HEIGHT

    slides = spec.get("slides") or []

    # BOUND-path fallback — no slides supplied but spec.meta might have a title.
    # Render a single title slide so the deck isn't empty, and caller still
    # gets a valid .pptx to open.
    if not slides:
        meta = spec.get("meta") or {}
        _render_title(prs, {
            "type":        "title",
            "title":       meta.get("title") or "[TBD — deck title]",
            "subtitle":    meta.get("subtitle") or "",
            "prepared_by": meta.get("prepared_by") or "",
            "date":        meta.get("date") or datetime.now().strftime("%B %d, %Y"),
            "client_name": meta.get("client_name") or "",
        })
        return prs

    for sl in slides:
        renderer = _SLIDE_RENDERERS[sl["type"]]
        renderer(prs, sl)

    return prs


BUILDERS: dict[str, Any] = {
    "executive_review_deck": _build_executive_review_deck,
}


# ═══════════════════════════════════════════════════════════════════════════════
#  PATH RESOLUTION — injected resolver, same pattern as siblings.
# ═══════════════════════════════════════════════════════════════════════════════

_PATH_RESOLVER = None

def set_path_resolver(resolver) -> None:
    """norm.py calls this at import, passing a callable
        (slug_or_None) -> Path of <active_client>/deliverables/"""
    global _PATH_RESOLVER
    _PATH_RESOLVER = resolver


def _resolve_output_path(client_slug: str | None, category: str,
                         filename: str) -> Path:
    if category not in {"reports", "audits", "blueprints", "content"}:
        raise PptxSpecError(
            f"invalid category {category!r}; must be one of "
            "reports, audits, blueprints, content"
        )
    safe_name = _sanitize_filename(filename)
    if _PATH_RESOLVER is None:
        base = (
            Path.home() / ".tavernos" / "clients"
            / (client_slug or "_self") / "deliverables"
        )
    else:
        base = _PATH_RESOLVER(client_slug)
    base = base.resolve()
    final = (base / category / safe_name).resolve()
    try:
        final.relative_to(base)
    except ValueError:
        raise PptxSpecError("path escaped client sandbox")
    return final


# ═══════════════════════════════════════════════════════════════════════════════
#  MAIN ENTRY — build_from_spec. Returns the deliverable-shaped dict matching
#  the sibling contract so norm.py's dispatcher needs no special-casing.
# ═══════════════════════════════════════════════════════════════════════════════

def build_from_spec(spec: dict, client_slug: str | None = None) -> dict:
    """Validate spec, build the deck, write it + a sidecar .spec.json, return
    the deliverable dict. On validation failure, raises PptxSpecError."""
    _validate_spec(spec)
    template = spec["template"]
    builder = BUILDERS[template]
    category = spec.get("category", "reports")

    prs = builder(spec)

    final_path = _resolve_output_path(client_slug, category, spec["filename"])
    final_path.parent.mkdir(parents=True, exist_ok=True)
    prs.save(str(final_path))

    spec_copy = dict(spec)
    spec_copy["_generated_at"] = datetime.now().isoformat(timespec="seconds")
    spec_path = final_path.with_suffix(".spec.json")
    spec_path.write_text(
        json.dumps(spec_copy, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    user_dir = Path.home() / ".tavernos"
    try:
        rel = final_path.relative_to(user_dir).as_posix()
    except ValueError:
        rel = final_path.as_posix()

    return {
        "ok":       True,
        "filename": final_path.name,
        "path":     rel,
        "abs_path": str(final_path),
        "category": category,
        "template": template,
        "bytes":    final_path.stat().st_size,
        "warnings": [],
    }


# ═══════════════════════════════════════════════════════════════════════════════
#  PRE-FLIGHT — Phase 3 addition. Mirrors the xlsx/docx preflight pattern.
# ═══════════════════════════════════════════════════════════════════════════════

def preflight(spec: dict, result: dict | None = None) -> list[str]:
    """Mechanical sanity checks for pptx decks. Returns a list of issue
    strings. Never raises.

    Checks:
      P1. Template recognized
      P2. At least 3 slides (a 1-slide deck is a "just title" BOUND output
          and flags as an issue — operator probably wants more)
      P3. No content slide has empty bullets AND no TBD marker
          (caught by the builder's TBD placeholder injection, but worth
          flagging so evaluator knows to expect TBDs)
      P4. File size sanity — pptx under 15KB is empty-ish
      P5. At least one non-section slide (a deck of only dividers is broken)"""
    issues = []
    try:
        if not isinstance(spec, dict):
            issues.append("preflight: spec is not a dict")
            return issues
        template = spec.get("template")
        if template not in BUILDERS:
            issues.append(f"preflight P1: unknown template {template!r}")
        slides = spec.get("slides") or []
        if len(slides) < 3:
            issues.append(f"preflight P2: deck has only {len(slides)} slide(s) — "
                          "typical review decks have 5+")
        # P3 — content / kpis / table slides with empty bodies
        thin_slides = []
        for i, sl in enumerate(slides):
            t = sl.get("type")
            if t == "content" and not (sl.get("bullets") or []):
                thin_slides.append(f"#{i+1} content no bullets")
            elif t == "kpis" and not (sl.get("kpis") or []):
                thin_slides.append(f"#{i+1} kpis no tiles")
            elif t == "table" and not (sl.get("rows") or []):
                thin_slides.append(f"#{i+1} table no rows")
        if thin_slides:
            issues.append("preflight P3: thin slides with only TBD placeholders: "
                          + ", ".join(thin_slides))
        # P5 — all-section (divider) decks
        non_section = [sl for sl in slides
                       if sl.get("type") not in ("section", "title")]
        if slides and not non_section:
            issues.append("preflight P5: deck has no content slides — only "
                          "title/section dividers")
        if result is not None and result.get("bytes", 0) < 15000:
            issues.append(f"preflight P4: deck is only {result.get('bytes', 0)} "
                          "bytes — likely near-empty")
    except Exception as e:
        issues.append(f"preflight crashed: {type(e).__name__}: {e}")
    return issues


# ═══════════════════════════════════════════════════════════════════════════════
#  TOOL REGISTRATION
# ═══════════════════════════════════════════════════════════════════════════════

TOOL_NAME = "generate_pptx_deck"
ALLOWED_AGENTS = {"rebecca"}

TOOL_SCHEMA = {
    "name": TOOL_NAME,
    "description": (
        "Generate a branded PowerPoint (.pptx) deck — executive reviews, "
        "quarterly updates, audit findings, project kickoffs — saved to the "
        "active client's workspace. Slides are a typed sequence: title, "
        "section (divider), content (title + bullets), kpis (up to 4 big-number "
        "tiles), table (pptx-native table from rows), closing (summary / next "
        "steps). Every slide accepts an optional `notes` field for speaker "
        "notes. If the user hasn't supplied the material for a slide's body "
        "(per grounding discipline), pass an empty bullets array or omit the "
        "slide entirely — the builder will render a [TBD — ...] placeholder "
        "rather than you inventing content."
    ),
    "input_schema": {
        "type": "object",
        "required": ["artifact", "template", "filename"],
        "properties": {
            "artifact": {"type": "string", "enum": ["pptx"]},
            "template": {
                "type": "string",
                "enum": list(BUILDERS.keys()),
                "description": "Template key. Phase 2 ships 'executive_review_deck'.",
            },
            "filename": {
                "type": "string",
                "description": (
                    "Kebab-case filename. The .pptx extension is added "
                    "automatically if omitted."
                ),
            },
            "category": {
                "type": "string",
                "enum": ["reports", "audits", "blueprints", "content"],
                "description": "Deliverables subfolder. Defaults to 'reports'.",
            },
            "meta": {
                "type": "object",
                "description": (
                    "Fallback metadata used only when `slides` is empty — "
                    "provides material for an implicit title slide."
                ),
                "properties": {
                    "title":       {"type": "string"},
                    "subtitle":    {"type": "string"},
                    "prepared_by": {"type": "string"},
                    "date":        {"type": "string"},
                    "client_name": {"type": "string"},
                },
            },
            "slides": {
                "type": "array",
                "description": (
                    "Ordered list of slide specs. Each item must have a `type` "
                    "key matching one of: title, section, content, kpis, table, "
                    "closing. Other keys depend on the type — see description."
                ),
                "items": {
                    "type": "object",
                    "required": ["type"],
                    "properties": {
                        "type": {
                            "type": "string",
                            "enum": sorted(_VALID_SLIDE_TYPES),
                        },
                        "title":       {"type": "string"},
                        "subtitle":    {"type": "string"},
                        "prepared_by": {"type": "string"},
                        "date":        {"type": "string"},
                        "client_name": {"type": "string"},
                        "bullets": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "For content and closing slides.",
                        },
                        "kpis": {
                            "type": "array",
                            "maxItems": 4,
                            "items": {
                                "type": "object",
                                "properties": {
                                    "label": {"type": "string"},
                                    "value": {"type": ["string", "number", "null"]},
                                    "delta": {"type": "string"},
                                },
                            },
                            "description": "For kpis slides only.",
                        },
                        "columns": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": (
                                "For table slides — explicit column order. "
                                "If omitted, derived from first row's keys."
                            ),
                        },
                        "rows": {
                            "type": "array",
                            "items": {"type": "object"},
                            "description": "For table slides — row data as key→value dicts.",
                        },
                        "notes": {
                            "type": "string",
                            "description": "Speaker notes. Optional for all slide types.",
                        },
                    },
                },
            },
        },
    },
}


def get_tool_registration() -> dict:
    return {
        "name":           TOOL_NAME,
        "schema":         TOOL_SCHEMA,
        "allowed_agents": ALLOWED_AGENTS,
        "handler":        _tool_handler,
    }


def _tool_handler(tool_args: dict, agent_name: str,
                  client_slug: str | None) -> str:
    """Tool dispatcher. Returns plain text with the sentinel on success."""
    try:
        result = build_from_spec(tool_args, client_slug=client_slug)
    except PptxSpecError as e:
        return f"Spec error: {e}"
    except Exception as e:
        return (
            "Unexpected error while generating deck: "
            f"{type(e).__name__}: {e}\n"
            + traceback.format_exc(limit=3)
        )

    lines = [
        f"__TAVERNOS_DELIVERABLE__\t{result['filename']}\t{result['path']}"
        f"\t{result['bytes']}",
        "Deck saved.",
        f"Filename: {result['filename']}",
        f"Path:     {result['path']}",
        f"Template: {result['template']}",
        f"Size:     {result['bytes']} bytes",
    ]
    return "\n".join(lines)
