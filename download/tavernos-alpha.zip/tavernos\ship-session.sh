#!/usr/bin/env bash
# ship-session.sh — End-of-session workflow for TavernOS Goal A.
#
# Phases, in order. Any failure aborts before the next phase:
#   1. Preflight      — verify paths, show diff of outgoing files.
#   2. Copy + test    — copy modified files into the repo, run Tier 0.
#   3. Git            — commit, tag, push (branch + tag).
#   4. Zip rebuild    — rebuild tavernos-alpha.zip from the pushed repo.
#   5. Release upload — upload the zip as a release asset via gh CLI.
#   6. Post-flight    — download the pushed zip into a temp dir and
#                       re-run Tier 0 against it; verifies the zip on
#                       GitHub actually matches what was pushed.
#
# Designed to be re-runnable per session. Set SESSION=6 (or whatever)
# before running, or edit the default below.
#
# USAGE
#   ./ship-session.sh                 # end-to-end, prompts at each
#                                     # destructive step
#   ./ship-session.sh --yes           # skip all prompts (CI mode)
#   ./ship-session.sh --test-only     # Phase 1+2 only
#   ./ship-session.sh --no-upload     # stop after zip build, no upload
#   ./ship-session.sh --help
#
# CUSTOMIZE ME
#   Edit the CONFIG block below to match your local setup. Everything
#   there can also be set via environment variables.

set -euo pipefail

# ─── CONFIG ───────────────────────────────────────────────────────────────────

: "${SESSION:=6}"

# Where you dropped this session's outputs locally (the files downloaded
# from the chat: norm.py, test_layer1_mechanism.py, goal-a-session-N-handoff.md).
: "${SOURCE_DIR:=$HOME/Downloads/tavernos-session-${SESSION}}"

# Your local clone of github.com/TavernOS/tavernos-test.
: "${REPO_DIR:=$HOME/code/tavernos-test}"

# Package subdirectory inside the repo where the .py files live. If the
# repo root IS the package root, set this to ".".
: "${REPO_PKG_SUBDIR:=tavernos}"

# Where the handoff markdown lives in the repo. Defaults to repo root.
: "${REPO_HANDOFF_DIR:=.}"

# Release asset name and tag.
: "${ZIP_NAME:=tavernos-alpha.zip}"
: "${RELEASE_TAG:=alpha}"

: "${REMOTE:=origin}"
: "${BRANCH:=main}"

# Commit message template. $SESSION expands.
: "${COMMIT_MSG:=Goal A session ${SESSION}: tool_choice forcing plumbing (Contract 9)}"

# Files modified THIS session, paths relative to REPO_PKG_SUBDIR. Keep
# explicit so a typo or missing file trips at Phase 1 rather than Phase 6.
# Edit per session.
MODIFIED_FILES=(
    "norm.py"
    "test_layer1_mechanism.py"
)

# What to include in the zip, paths relative to REPO_DIR. Mirror whatever
# session 5's zip contained; update if the repo grows new top-level
# artifacts that belong in the distribution.
ZIP_INCLUDE=(
    "${REPO_PKG_SUBDIR}"
    "README.md"
)

# ─── FLAG PARSING ─────────────────────────────────────────────────────────────

AUTO_YES=0
TEST_ONLY=0
NO_UPLOAD=0

for arg in "$@"; do
    case "$arg" in
        --yes)        AUTO_YES=1 ;;
        --test-only)  TEST_ONLY=1 ;;
        --no-upload)  NO_UPLOAD=1 ;;
        -h|--help)
            awk '/^# USAGE$/,/^$/' "$0" | sed 's/^# \{0,1\}//'
            exit 0
            ;;
        *) echo "unknown flag: $arg" >&2 ; exit 2 ;;
    esac
done

# ─── OUTPUT HELPERS ───────────────────────────────────────────────────────────

c_teal=$'\033[36m'; c_red=$'\033[31m'; c_amber=$'\033[33m'
c_dim=$'\033[2m';  c_rst=$'\033[0m'

info()  { printf "%s▸%s %s\n" "$c_teal"  "$c_rst" "$*"; }
warn()  { printf "%s⚠%s %s\n" "$c_amber" "$c_rst" "$*"; }
ok()    { printf "%s✓%s %s\n" "$c_teal"  "$c_rst" "$*"; }
die()   { printf "%s✗%s %s\n" "$c_red"   "$c_rst" "$*" 1>&2; exit 1; }

confirm() {
    local msg="$1"
    if [[ "$AUTO_YES" == "1" ]]; then return 0; fi
    read -r -p "$(printf "%s?%s %s [y/N] " "$c_amber" "$c_rst" "$msg")" ans
    [[ "$ans" =~ ^[Yy]$ ]]
}

# ─── PHASE 1: preflight ───────────────────────────────────────────────────────

info "Phase 1 — preflight (session ${SESSION})"

[[ -d "$SOURCE_DIR" ]] || die "SOURCE_DIR does not exist: $SOURCE_DIR"
[[ -d "$REPO_DIR"   ]] || die "REPO_DIR does not exist: $REPO_DIR"
[[ -d "$REPO_DIR/$REPO_PKG_SUBDIR" ]] \
    || die "package subdir not found: $REPO_DIR/$REPO_PKG_SUBDIR"
command -v python >/dev/null || die "python not on PATH"
command -v git    >/dev/null || die "git not on PATH"
command -v zip    >/dev/null || die "zip not on PATH"

# For each modified file, show a portable diff against the repo copy.
for f in "${MODIFIED_FILES[@]}"; do
    src="$SOURCE_DIR/$f"
    dst="$REPO_DIR/$REPO_PKG_SUBDIR/$f"
    [[ -f "$src" ]] || die "source file missing: $src"
    if [[ ! -f "$dst" ]]; then
        warn "new file (will be created): $f"
    else
        printf "%s── %s ──%s\n" "$c_dim" "$f" "$c_rst"
        # git diff --no-index works on any two files, no repo context needed,
        # and honors color.ui. Cap the output so a large diff doesn't drown
        # the preflight summary.
        git --no-pager diff --no-index --stat -- "$dst" "$src" || true
    fi
done

# Preflight handoff check (advisory — missing is a warning, not a die).
handoff="goal-a-session-${SESSION}-handoff.md"
if [[ -f "$SOURCE_DIR/$handoff" ]]; then
    ok "handoff present: $handoff"
else
    warn "handoff not found in SOURCE_DIR: $handoff (will not be copied)"
fi

confirm "Proceed with copy + Tier 0 test" || die "aborted"

# ─── PHASE 2: copy + test ─────────────────────────────────────────────────────

info "Phase 2 — copy + Tier 0"

for f in "${MODIFIED_FILES[@]}"; do
    cp "$SOURCE_DIR/$f" "$REPO_DIR/$REPO_PKG_SUBDIR/$f"
    ok "copied $f"
done

if [[ -f "$SOURCE_DIR/$handoff" ]]; then
    cp "$SOURCE_DIR/$handoff" "$REPO_DIR/$REPO_HANDOFF_DIR/$handoff"
    ok "copied $handoff"
fi

# Run Tier 0 from the repo's copy, not from SOURCE_DIR, so we test what
# was actually installed. Abort before any git/zip work if it fails.
info "running test_layer1_mechanism.py from repo"
(
    cd "$REPO_DIR/$REPO_PKG_SUBDIR"
    python test_layer1_mechanism.py --verbose
) || die "Tier 0 failed — no git or zip operations performed"
ok "Tier 0 passed (see count in the output above)"

if [[ "$TEST_ONLY" == "1" ]]; then
    info "--test-only set; stopping here"
    exit 0
fi

# ─── PHASE 3: git commit + tag + push ─────────────────────────────────────────

info "Phase 3 — git"

cd "$REPO_DIR"

cur_branch="$(git rev-parse --abbrev-ref HEAD)"
[[ "$cur_branch" == "$BRANCH" ]] \
    || die "on branch '$cur_branch', expected '$BRANCH' (switch first)"

# Fetch but do NOT auto-merge. If the remote moved, the user should see
# that and resolve manually rather than have this script surprise them.
git fetch "$REMOTE" "$BRANCH"
ahead="$(git rev-list --count "$REMOTE/$BRANCH..$BRANCH")"
behind="$(git rev-list --count "$BRANCH..$REMOTE/$BRANCH")"
if [[ "$behind" -gt 0 ]]; then
    die "local $BRANCH is behind $REMOTE/$BRANCH by $behind commit(s); rebase or merge first"
fi
[[ "$ahead" -gt 0 ]] && warn "local is already ahead of remote by $ahead commit(s)"

# Stage only the session's files — don't sweep up unrelated working-copy changes.
for f in "${MODIFIED_FILES[@]}"; do
    git add "$REPO_PKG_SUBDIR/$f"
done
if [[ -f "$REPO_DIR/$REPO_HANDOFF_DIR/$handoff" ]]; then
    git add "$REPO_HANDOFF_DIR/$handoff"
fi

git status --short

if git diff --cached --quiet; then
    warn "no staged changes — skipping commit"
else
    confirm "Commit with message: '$COMMIT_MSG'" || die "aborted"
    git commit -m "$COMMIT_MSG"
    ok "committed"
fi

# Annotated tag — makes the session-to-session history easy to read.
tag_name="session-${SESSION}"
if git rev-parse "$tag_name" >/dev/null 2>&1; then
    warn "tag $tag_name already exists — skipping tag step"
else
    git tag -a "$tag_name" -m "Goal A session ${SESSION} close"
    ok "tagged $tag_name"
fi

confirm "Push $BRANCH and $tag_name to $REMOTE" || die "aborted before push"
git push "$REMOTE" "$BRANCH"
git push "$REMOTE" "$tag_name" || warn "tag push failed (maybe already pushed?)"
ok "pushed"

# ─── PHASE 4: zip rebuild ─────────────────────────────────────────────────────

info "Phase 4 — rebuild $ZIP_NAME from repo"

cd "$REPO_DIR"
zip_out="/tmp/$ZIP_NAME"
rm -f "$zip_out"
zip -r "$zip_out" "${ZIP_INCLUDE[@]}" \
    -x "*.pyc" "*/__pycache__/*" "*.DS_Store" "*/.git/*" \
    > /dev/null

# Cross-platform size (Linux vs macOS stat flag difference).
if stat -c%s "$zip_out" >/dev/null 2>&1; then
    zip_size="$(stat -c%s "$zip_out")"
else
    zip_size="$(stat -f%z "$zip_out")"
fi
ok "built $zip_out (${zip_size} bytes)"

if [[ "$NO_UPLOAD" == "1" ]]; then
    info "--no-upload set; zip is at $zip_out"
    exit 0
fi

# ─── PHASE 5: release upload ──────────────────────────────────────────────────

info "Phase 5 — upload $ZIP_NAME to release '$RELEASE_TAG'"

if ! command -v gh >/dev/null; then
    warn "gh CLI not installed — manual upload required"
    warn "  1. https://github.com/TavernOS/tavernos-test/releases/tag/$RELEASE_TAG"
    warn "  2. Edit release, delete old $ZIP_NAME, re-upload from $zip_out"
    exit 0
fi

# Create the release if it doesn't exist yet (first-session safety net);
# otherwise just upload with --clobber to replace the asset.
if ! gh release view "$RELEASE_TAG" >/dev/null 2>&1; then
    confirm "Release '$RELEASE_TAG' does not exist. Create it?" || die "aborted"
    gh release create "$RELEASE_TAG" \
        --title "TavernOS alpha — session ${SESSION}" \
        --notes "See ${handoff} for the shipped changes and next-session priorities."
    ok "created release $RELEASE_TAG"
fi

gh release upload "$RELEASE_TAG" "$zip_out" --clobber
ok "uploaded $ZIP_NAME to $RELEASE_TAG"

# ─── PHASE 6: post-flight verify ──────────────────────────────────────────────

info "Phase 6 — download pushed zip and re-run Tier 0 against it"

verify_dir="$(mktemp -d)"
trap "rm -rf '$verify_dir'" EXIT

gh release download "$RELEASE_TAG" \
    --pattern "$ZIP_NAME" \
    --dir "$verify_dir" \
    --clobber

unzip -q "$verify_dir/$ZIP_NAME" -d "$verify_dir/unpacked"

(
    cd "$verify_dir/unpacked/$REPO_PKG_SUBDIR"
    python test_layer1_mechanism.py
) || die "verification run FAILED — the pushed zip's tests do not pass locally"

ok "verification run passed — zip on GitHub matches repo"

# ─── DONE ─────────────────────────────────────────────────────────────────────

printf "\n"
ok "Session ${SESSION} shipped."
printf "   %stag:     %s%s\n" "$c_dim" "$tag_name" "$c_rst"
printf "   %srelease: %s%s\n" "$c_dim" "$RELEASE_TAG" "$c_rst"
printf "   %sasset:   %s%s\n" "$c_dim" "$ZIP_NAME" "$c_rst"
printf "   %scommit:  %s%s\n" "$c_dim" "$(git rev-parse --short HEAD)" "$c_rst"
printf "\nNext: open a new chat and paste the session-$((SESSION+1)) kickoff prompt.\n"
