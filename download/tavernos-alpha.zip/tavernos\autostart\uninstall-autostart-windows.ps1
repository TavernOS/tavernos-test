# uninstall-autostart-windows.ps1
# Removes the TavernOS web UI auto-start task.

$ErrorActionPreference = "Stop"
$TaskName = "TavernOS-Web"

Write-Host ""
$Existing = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if (-not $Existing) {
    Write-Host "  ℹ No TavernOS-Web task registered — nothing to remove." -ForegroundColor DarkGray
    Write-Host ""
    exit 0
}

# Stop the task if it's currently running
try { Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue } catch {}

Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
Write-Host "  ✓ TavernOS web UI autostart removed." -ForegroundColor Green
Write-Host "    The web UI won't start at login anymore." -ForegroundColor DarkGray
Write-Host "    You can still run it manually with:  norm --web" -ForegroundColor DarkGray
Write-Host ""
