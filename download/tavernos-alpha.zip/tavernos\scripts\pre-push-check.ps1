# TavernOS pre-push Tier 0 check — Goal A session 7 priority 3
#
# Runs test_layer1_mechanism.py (the mechanism-level gate + builder-robustness
# + tool_choice-plumbing regression suite) and blocks the push on non-zero
# exit. Tier 0 is deterministic, API-free, and runs in <5s — safe for a
# pre-push hook.
#
# INSTALLATION
# ============
# Copy this file to .git/hooks/pre-push (no extension on that path):
#
#     Copy-Item scripts\pre-push-check.ps1 .git\hooks\pre-push
#
# On Windows + Git-for-Windows, git invokes hooks through its bundled bash
# (ignoring the .ps1 extension). If the hook doesn't fire, check that
# .git/hooks/pre-push exists and that your git install includes the bash
# shim; "git config core.hooksPath" reports the active hook directory.
#
# BYPASS
# ======
# Standard git bypass applies: `git push --no-verify` skips all hooks.
# Use sparingly — the whole point of Tier 0 is that it's cheap enough to
# run on every push.

$ErrorActionPreference = "Stop"

$repo = Split-Path -Parent (Split-Path -Parent $PSCommandPath)
Set-Location $repo

Write-Host "pre-push: running Tier 0 (test_layer1_mechanism.py)..."
python test_layer1_mechanism.py
$code = $LASTEXITCODE

if ($code -ne 0) {
    Write-Host ""
    Write-Host "pre-push: Tier 0 FAILED (exit $code). Push blocked." -ForegroundColor Red
    Write-Host "  Fix the failing test(s) or bypass with 'git push --no-verify'."
    exit $code
}

Write-Host "pre-push: Tier 0 passed. Push allowed."
exit 0
