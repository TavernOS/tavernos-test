---
name: Code Review
agent: carla
description: Reviews code for bugs, security issues, performance problems, and style. Use when user shares code and asks for "code review", "review this", "what's wrong with this code", "check my code", or "is this secure".
triggers:
  - code review
  - review this code
  - what's wrong with this code
  - check my code
  - is this secure
  - debug this
  - find the bug
chaining: false
version: 1.0.0
---

# Code Review

## Review checklist
1. **Correctness** — Does it do what it's supposed to do? Edge cases handled?
2. **Security** — Injection risks, authentication issues, exposed secrets, input validation
3. **Performance** — Unnecessary loops, N+1 queries, memory issues, blocking calls
4. **Readability** — Naming, comments, function length, cognitive complexity
5. **Error handling** — What happens when things fail? Are errors caught and logged?
6. **Testing** — Is this testable? Are there obvious test cases missing?
7. **Dependencies** — Are imported libraries necessary, up to date, trustworthy?

## Output format
For each issue found:
- **Severity**: [Critical / High / Medium / Low]
- **Location**: [Line number or function name]
- **Issue**: What's wrong
- **Fix**: Specific suggestion or corrected code snippet

End with:
- Summary of critical issues (if any)
- Overall assessment: Ready to ship / Needs work / Significant problems

## Guidelines
- Be specific — vague feedback like "this could be cleaner" is not useful
- Show the fix, don't just describe it
- Flag security issues as Critical regardless of other context
