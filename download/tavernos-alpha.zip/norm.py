﻿import sys
import os
import json
import re
import sqlite3
import argparse
import urllib.request
import zipfile
import shutil
import time
import threading
import email as email_lib
import struct
from datetime import datetime, timezone
from pathlib import Path


# ═══════════════════════════════════════════════════════════════════════════════
#  MCP CLIENT — optional. If mcp_client.py or the `mcp` SDK is missing,
#  norm runs without MCP tool support. Every other feature still works.
# ═══════════════════════════════════════════════════════════════════════════════

try:
    from .mcp_client import (
        MCPManager, mcp_available,
        load_mcp_config, save_mcp_config, MCP_SERVERS_FILE,
    )
except ImportError:
    try:
        from mcp_client import (
            MCPManager, mcp_available,
            load_mcp_config, save_mcp_config, MCP_SERVERS_FILE,
        )
    except ImportError:
        MCPManager = None
        MCP_SERVERS_FILE = Path.home() / ".tavernos" / "mcp_servers.json"
        def mcp_available(): return False
        def load_mcp_config(): return {"servers": {}}
        def save_mcp_config(cfg): pass

_MCP_MANAGER = None  # Singleton — see ensure_mcp_manager() below. Populated
                     # by main() for the CLI path and by server.py for the web
                     # UI path (Phase 2 pass 2). Both go through the same
                     # function so we don't accumulate duplicated init logic.

# atexit hook — unconditional at module load. The hook itself no-ops when
# _MCP_MANAGER is None, so registering before we know if MCP will start is
# safe. Being at module level means it's registered in both the CLI process
# (via `norm` entry point) and the web UI process (which imports norm).
import atexit as _atexit
def _mcp_shutdown_hook():
    global _MCP_MANAGER
    if _MCP_MANAGER:
        try: _MCP_MANAGER.shutdown()
        except Exception: pass
_atexit.register(_mcp_shutdown_hook)


def ensure_mcp_manager(provider: str, on_about_to_start=None):
    """Start the _MCP_MANAGER singleton if conditions permit. Idempotent —
    safe to call multiple times; a second call while the manager is already
    up returns the existing manager and None summary.

    Returns (manager_or_None, connect_summary_or_None). Any of these make
    the result (None, None):
      - MCP SDK not installed
      - provider is not 'anthropic' (Phase 1 scope)
      - no servers configured in ~/.tavernos/mcp_servers.json
      - manager init raised (logged via _log_error)

    `on_about_to_start` fires exactly once, just before we call into the SDK
    to actually start subprocesses. CLI passes a lambda that updates the
    thinking indicator; server.py will pass an SSE-emitting callable in the
    web UI wiring. Both are safe to omit."""
    global _MCP_MANAGER
    if _MCP_MANAGER is not None:
        return _MCP_MANAGER, None
    if MCPManager is None or provider != "anthropic":
        return None, None
    cfg = load_mcp_config()
    if not cfg.get("servers"):
        return None, None
    if on_about_to_start is not None:
        try: on_about_to_start()
        except Exception: pass
    try:
        mgr = MCPManager(error_logger=_log_error)
        summary = mgr.start_configured_servers()
        _MCP_MANAGER = mgr
        return mgr, summary
    except Exception as _mcp_e:
        _log_error("mcp_manager_init_failed", error=str(_mcp_e))
        _MCP_MANAGER = None
        return None, None


def shutdown_mcp_manager():
    """Gracefully shut down the _MCP_MANAGER singleton. Idempotent — no-op
    if the manager was never started or has already been shut down. Errors
    are logged but not raised; shutdown must not crash the caller."""
    global _MCP_MANAGER
    if _MCP_MANAGER is None:
        return
    try: _MCP_MANAGER.shutdown()
    except Exception as _se: _log_error("mcp_shutdown_failed", error=str(_se))
    _MCP_MANAGER = None


# ═══════════════════════════════════════════════════════════════════════════════
#  ARTIFACT GENERATION — optional. artifact_xlsx.py provides Rebecca's
#  xlsx builder. Missing module = no xlsx tool registered; norm still runs.
#  _artifact_xlsx_import_error exposes the reason when import fails, so
#  sanity-check probes can distinguish "never registered" from "registered
#  with no artifacts loaded".
# ═══════════════════════════════════════════════════════════════════════════════

_artifact_xlsx_import_error = None
try:
    from . import artifact_xlsx as _artifact_xlsx
except ImportError as _e1:
    try:
        import artifact_xlsx as _artifact_xlsx
    except ImportError as _e2:
        _artifact_xlsx = None
        _artifact_xlsx_import_error = "relative: " + str(_e1) + " | absolute: " + str(_e2)

# artifact_docx.py — Woody's branded .docx builder. Same optional-import
# posture as artifact_xlsx. If python-docx or the module itself is missing,
# the docx tool is skipped and norm keeps running.
_artifact_docx_import_error = None
try:
    from . import artifact_docx as _artifact_docx
except ImportError as _e1:
    try:
        import artifact_docx as _artifact_docx
    except ImportError as _e2:
        _artifact_docx = None
        _artifact_docx_import_error = "relative: " + str(_e1) + " | absolute: " + str(_e2)

# artifact_pptx.py — Rebecca's second builder, branded decks. Same posture.
_artifact_pptx_import_error = None
try:
    from . import artifact_pptx as _artifact_pptx
except ImportError as _e1:
    try:
        import artifact_pptx as _artifact_pptx
    except ImportError as _e2:
        _artifact_pptx = None
        _artifact_pptx_import_error = "relative: " + str(_e1) + " | absolute: " + str(_e2)

# evaluator.py — Phase 3 rubric-driven scoring. Same optional-import posture
# as the artifact modules. If the module is missing, evaluation is skipped
# silently and deliverables ship unscored. Also covers the case where
# python-docx / openpyxl / python-pptx aren't installed (text extraction
# would fail), though those are effectively required anyway for the
# artifact modules to work.
_evaluator_import_error = None
try:
    from . import evaluator as _evaluator
except ImportError as _e1:
    try:
        import evaluator as _evaluator
    except ImportError as _e2:
        _evaluator = None
        _evaluator_import_error = "relative: " + str(_e1) + " | absolute: " + str(_e2)


# ═══════════════════════════════════════════════════════════════════════════════
#  SILENCE ML NOISE
#  Must run BEFORE sentence_transformers / transformers / huggingface_hub
#  are imported anywhere in the process. The embedding model load is lazy
#  (see _get_embed_model below), so defining + calling this at module load
#  time is sufficient.
# ═══════════════════════════════════════════════════════════════════════════════

def _silence_ml_noise():
    """Suppress HuggingFace Hub / transformers / tqdm chatter on model load.

    Kills:
      * 'You are sending unauthenticated requests to the HF Hub…' warning
      * tqdm 'Loading weights: 100%' progress bar
      * 'BertModel LOAD REPORT … UNEXPECTED: embeddings.position_ids' notice
        (harmless — position_ids changed from tensor to buffer in newer
        transformers versions, triggers a false 'unexpected key' report)
      * Assorted FutureWarning / UserWarning noise from the ML stack
    """
    import logging, warnings
    os.environ.setdefault("HF_HUB_DISABLE_IMPLICIT_TOKEN", "1")
    os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")
    os.environ.setdefault("TRANSFORMERS_VERBOSITY",       "error")
    os.environ.setdefault("TOKENIZERS_PARALLELISM",       "false")
    warnings.filterwarnings("ignore", category=FutureWarning)
    warnings.filterwarnings("ignore", category=UserWarning)
    for name in ("transformers", "sentence_transformers",
                 "huggingface_hub", "urllib3", "filelock"):
        logging.getLogger(name).setLevel(logging.ERROR)

_silence_ml_noise()


# ═══════════════════════════════════════════════════════════════════════════════
#  TERMINAL COLOR SYSTEM
# ═══════════════════════════════════════════════════════════════════════════════

def _detect_color_level() -> int:
    if not sys.stdout.isatty(): return 0
    if os.environ.get("NO_COLOR") or os.environ.get("TERM") == "dumb": return 0
    if sys.platform == "win32":
        if os.environ.get("COLORTERM") in ("truecolor","24bit"): return 2
        if os.environ.get("WT_SESSION"): return 2
        if os.environ.get("ConEmuANSI")=="ON" or os.environ.get("TERM_PROGRAM"): return 2
        try:
            import ctypes
            ctypes.windll.kernel32.SetConsoleMode(ctypes.windll.kernel32.GetStdHandle(-11),7)
            return 1
        except Exception: return 0
    colorterm = os.environ.get("COLORTERM","").lower()
    if colorterm in ("truecolor","24bit"): return 2
    term = os.environ.get("TERM","")
    if "256color" in term or "24bit" in term: return 2
    if term in ("xterm","screen","vt100","linux"): return 1
    return 1

COLOR_LEVEL = _detect_color_level()

class C:
    RESET = "\033[0m"  if COLOR_LEVEL > 0 else ""
    BOLD  = "\033[1m"  if COLOR_LEVEL > 0 else ""
    DIM   = "\033[2m"  if COLOR_LEVEL > 0 else ""
    if COLOR_LEVEL == 2:
        TEAL    = "\033[38;2;0;212;200m"
        NAVY    = "\033[38;2;10;37;64m"
        WHITE   = "\033[38;2;248;249;250m"
        GRAY    = "\033[38;2;138;155;176m"
        AMBER   = "\033[38;2;251;191;36m"
        RED     = "\033[38;2;252;129;129m"
        GREEN   = "\033[38;2;52;211;153m"
        BG_NAVY = "\033[48;2;10;37;64m"
        BG_TEAL = "\033[48;2;0;212;200m"
    elif COLOR_LEVEL == 1:
        TEAL="\033[96m"; NAVY="\033[34m"; WHITE="\033[97m"; GRAY="\033[37m"
        AMBER="\033[93m"; RED="\033[91m"; GREEN="\033[92m"
        BG_NAVY="\033[44m"; BG_TEAL="\033[46m"
    else:
        TEAL=NAVY=WHITE=GRAY=AMBER=RED=GREEN=BG_NAVY=BG_TEAL=""

def tc(color,text): return color+text+C.RESET if color else text
def tbc(text): return C.TEAL+C.BOLD+text+C.RESET
def dim(text): return C.DIM+C.GRAY+text+C.RESET


# ═══════════════════════════════════════════════════════════════════════════════
#  RUN MODE
# ═══════════════════════════════════════════════════════════════════════════════

class Mode:
    DEV="dev"; STAGING="staging"; CUSTOMER="customer"

def _resolve_mode(args_dev,args_staging):
    if args_dev: return Mode.DEV
    if args_staging: return Mode.STAGING
    return Mode.CUSTOMER

def mode_allows(mode,feature):
    dev_only={"update","setup","scores","diagnostics","registry_push","verbose_errors"}
    return mode==Mode.DEV if feature in dev_only else True

def mode_banner(mode,company=""):
    if mode==Mode.DEV:
        return "  "+tc(C.AMBER,"[ DEV MODE ]")+" "+tc(C.GRAY+C.DIM,"all features enabled")
    if mode==Mode.STAGING:
        sim=(" — simulating: "+tc(C.WHITE,company)) if company else ""
        return "  "+tc(C.TEAL,"[ STAGING ]")+" "+tc(C.GRAY+C.DIM,"customer view"+sim)
    return ""

def mode_greeting(mode,company):
    if mode==Mode.STAGING:
        return (tbc("Norm!")+" "+dim("Staging mode — simulating customer experience for")+
                " "+tc(C.WHITE+C.BOLD,company)+dim("."))
    # 15 leading spaces centers the 40-char greeting under the 70-char ASCII banner
    return " "*15+tbc("Norm!")+" "+dim("Yeah, yeah... what'll it be today?")

def mode_version(mode):
    base="v0.1.0"
    if mode==Mode.DEV:     return base+tc(C.AMBER,"-dev")
    if mode==Mode.STAGING: return base+tc(C.TEAL,"-staging")
    return base

def _blocked_msg(feature):
    msgs={"update":"Updates are managed by TavernOS. Contact support@tavernos.ai.",
          "setup":"Customer package generation is not available in this mode.",
          "scores":"Skill performance scores are an internal feature.",
          "diagnostics":"Diagnostics are an internal feature."}
    return msgs.get(feature,"This feature is not available in your current plan.")


# ═══════════════════════════════════════════════════════════════════════════════
#  BOX DRAWING
# ═══════════════════════════════════════════════════════════════════════════════

def _term_width():
    try: return min(os.get_terminal_size().columns,88)
    except: return 72

def _visible_len(text): return len(re.sub(r'\033\[[0-9;]*m','',text))
def _box_width(): return _term_width()-6

def _truncate(text,width):
    return text if len(text)<=width else text[:width-1]+"…"

def box_top(label=""):
    w=_term_width(); bw=w-2
    if label:
        ls=" "+label+" "; d=bw-len(ls)
        inner="═"*(d//2)+ls+"═"*(d-d//2)
    else: inner="═"*bw
    return tc(C.TEAL,"╔"+inner+"╗")

def box_row(content):
    w=_term_width(); bw=w-6; vl=_visible_len(content)
    if vl>bw:
        content=re.sub(r'\033\[[0-9;]*m','',content)[:bw-1]+"…"; vl=_visible_len(content)
    return tc(C.TEAL,"║")+"  "+content+" "*(bw-vl)+"  "+tc(C.TEAL,"║")

def box_divider(): return tc(C.TEAL,"╠"+"═"*(_term_width()-2)+"╣")
def box_bottom():  return tc(C.TEAL,"╚"+"═"*(_term_width()-2)+"╝")

def agent_box_top(name):
    w=_term_width()
    return tc(C.TEAL,"┌─ ")+tbc(name)+" "+tc(C.TEAL,"─"*max(0,w-2-len(name)-3))

def agent_box_row(content): return tc(C.TEAL,"│")+"  "+content
def agent_box_bottom(): return tc(C.TEAL,"└"+"─"*(_term_width()-2))

def agent_thinking_header(name,task):
    w=_term_width()
    label=tc(C.TEAL+C.BOLD,"─── "+name+" is on it")
    task_short=_truncate(task,w-_visible_len(label)-8)
    print(); print(label+dim(" — "+task_short)+" "+tc(C.TEAL,"─"*max(0,w-_visible_len(label)-len(task_short)-5))); print()


# ═══════════════════════════════════════════════════════════════════════════════
#  THINKING INDICATOR
# ═══════════════════════════════════════════════════════════════════════════════

class ThinkingIndicator:
    FRAMES=["●○○","●●○","●●●","○●●","○○●","○○○"]
    def __init__(self):
        self._stop=threading.Event(); self._thread=None; self._msg=""; self._lock=threading.Lock()
    def start(self,message):
        with self._lock: self._msg=message
        self._stop.clear(); self._thread=threading.Thread(target=self._run,daemon=True); self._thread.start()
    def update(self,message):
        with self._lock: self._msg=message
    def stop(self):
        self._stop.set()
        if self._thread: self._thread.join(timeout=1)
        sys.stdout.write("\r"+" "*_term_width()+"\r"); sys.stdout.flush()
    def _run(self):
        i=0
        while not self._stop.is_set():
            with self._lock: msg=self._msg
            sys.stdout.write("\r"+C.TEAL+C.BOLD+"  "+msg+"  "+self.FRAMES[i%6]+C.RESET)
            sys.stdout.flush(); i+=1; time.sleep(0.35)

_indicator=ThinkingIndicator()

# ── Constants ──────────────────────────────────────────────────────────────────
ROUTER_MAX_TOKENS  = 1000
EXECUTE_MAX_TOKENS = 4000

WEB_SEARCH_AGENTS = {"cliff"}
WEB_SEARCH_TOOL   = {"type":"web_search_20250305","name":"web_search"}

USER_DIR            = Path.home()/".tavernos"
CONFIG_FILE         = USER_DIR/"config.json"
STAGING_CONFIG_FILE = USER_DIR/"staging_config.json"
MEMORY_DIR          = USER_DIR/"memory"
DIAG_DIR            = USER_DIR/"diagnostics"
ERRORS_JOURNAL      = DIAG_DIR/"errors.jsonl"
PKG_DIR             = Path(__file__).parent
AGENTS_DIR          = PKG_DIR/"agents"
SKILLS_DIR          = PKG_DIR/"skills"

# Pack 0 — multi-client workspace paths
CLIENTS_DIR         = USER_DIR/"clients"
ACTIVE_CLIENT_FILE  = CLIENTS_DIR/"_active"
ARCHIVED_DIR        = CLIENTS_DIR/"_archived"
DEFAULT_CLIENT_SLUG = "_self"
DELIVERABLE_DIRS    = ["audits","blueprints","content","reports"]

MODELS_DEV_URL     = "https://models.dev/api.json"
LOCAL_VERSION_FILE = USER_DIR/"installed_version.txt"
GITHUB_USER        = "TavernOS"
GITHUB_REPO        = "tavernos-skills"
GITHUB_BRANCH      = "main"
CUSTOMER_TOKEN_KEY = "customer_registry_token"
RAILWAY_URL        = "https://web-production-c5160.up.railway.app"

FALLBACK_MODELS=[
    {"provider":"anthropic","id":"claude-opus-4-5",  "name":"Claude Opus 4.5",  "context":200000,"input_cost":15.0,"output_cost":75.0,"tier":1},
    {"provider":"anthropic","id":"claude-sonnet-4-6","name":"Claude Sonnet 4.6","context":200000,"input_cost":3.0, "output_cost":15.0,"tier":2},
    {"provider":"anthropic","id":"claude-haiku-4-5", "name":"Claude Haiku 4.5", "context":200000,"input_cost":1.0, "output_cost":5.0, "tier":3},
    {"provider":"openai",   "id":"gpt-4o",           "name":"GPT-4o",           "context":128000,"input_cost":5.0, "output_cost":15.0,"tier":1},
    {"provider":"openai",   "id":"gpt-4o-mini",      "name":"GPT-4o Mini",      "context":128000,"input_cost":0.15,"output_cost":0.6, "tier":2},
]

AGENT_NAMES=["sam","norm","coach","carla","woody","cliff","frasier","rebecca"]
MAX_HISTORY=10
SUPPORTED_EXT={".txt",".md",".pdf",".docx",".xlsx",".pptx",".msg",".eml"}
FILE_TYPE_LABELS={".txt":"Plain text",".md":"Markdown",".pdf":"PDF",".docx":"Word",
                  ".xlsx":"Excel",".pptx":"PowerPoint",".msg":"Outlook email",".eml":"Email"}
FILE_ICONS={".pdf":"📄",".docx":"📝",".xlsx":"📊",".pptx":"📋",".msg":"📧",".eml":"📧",".txt":"📃",".md":"📃"}

def _now_iso(): return datetime.now(timezone.utc).isoformat()


# ═══════════════════════════════════════════════════════════════════════════════
#  MULTI-CLIENT WORKSPACE (Pack 0)
#  Scaffolding only — Phase 1 of the Pack 0 integration. These helpers exist
#  but nothing else in norm.py calls them yet. Phase 2 rewires memory paths
#  and wires these into main(); Phase 3 adds the /client command surface.
# ═══════════════════════════════════════════════════════════════════════════════

def _slugify_client(name: str) -> str:
    """Turn a company name into a filesystem-safe slug: 'ABC Corp!' -> 'abc-corp'."""
    s = (name or "").strip().lower()
    s = re.sub(r"[^a-z0-9]+", "-", s)
    s = re.sub(r"-+", "-", s).strip("-")
    return s or "client"

def get_active_client_slug() -> str:
    """Return the slug of the currently active client. Falls back to DEFAULT_CLIENT_SLUG."""
    try:
        if ACTIVE_CLIENT_FILE.exists():
            slug = ACTIVE_CLIENT_FILE.read_text(encoding="utf-8").strip()
            if slug:
                return slug
    except Exception:
        pass
    return DEFAULT_CLIENT_SLUG

def set_active_client_slug(slug: str) -> None:
    """Persist the active client slug to clients/_active."""
    CLIENTS_DIR.mkdir(parents=True, exist_ok=True)
    ACTIVE_CLIENT_FILE.write_text(slug, encoding="utf-8")

def client_workspace_path(slug: str = None) -> Path:
    """Return the absolute path to a client's workspace folder."""
    return CLIENTS_DIR / (slug or get_active_client_slug())

def client_memory_dir(slug: str = None) -> Path:
    return client_workspace_path(slug) / "memory"

def client_deliverables_dir(slug: str = None) -> Path:
    return client_workspace_path(slug) / "deliverables"

def client_intake_dir(slug: str = None) -> Path:
    return client_workspace_path(slug) / "intake"

def client_notes_dir(slug: str = None) -> Path:
    return client_workspace_path(slug) / "notes"

def client_manifest_path(slug: str = None) -> Path:
    return client_workspace_path(slug) / "client.json"

def client_exists(slug: str) -> bool:
    return client_manifest_path(slug).exists()

def client_load_manifest(slug: str = None) -> dict:
    """Return the client.json contents, or {} if missing/unreadable."""
    p = client_manifest_path(slug)
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}

def client_save_manifest(data: dict, slug: str = None) -> None:
    """Write client.json, creating parent dirs if needed. Always bumps last_active."""
    p = client_manifest_path(slug)
    p.parent.mkdir(parents=True, exist_ok=True)
    data = dict(data)  # don't mutate caller's dict
    data["last_active"] = _now_iso()
    p.write_text(json.dumps(data, indent=2), encoding="utf-8")


# ═══════════════════════════════════════════════════════════════════════════════
#  FIRST-PARTY TOOL REGISTRY — artifact generators (xlsx, and later docx/pptx)
#  register here. Registered tools appear in the generalized tool-use loop
#  alongside web_search and MCP tools, with per-agent gating.
# ═══════════════════════════════════════════════════════════════════════════════

FIRST_PARTY_TOOLS = {}  # name -> {"name","schema","allowed_agents","handler"}

def _register_first_party_tools():
    """Idempotent — safe to call multiple times. Populates FIRST_PARTY_TOOLS
    from every artifact module that imported successfully, and wires each
    module's path resolver to client_deliverables_dir so writes land in the
    active client's sandbox."""
    if _artifact_xlsx is not None:
        reg = _artifact_xlsx.get_tool_registration()
        FIRST_PARTY_TOOLS[reg["name"]] = reg
        _artifact_xlsx.set_path_resolver(client_deliverables_dir)
    if _artifact_docx is not None:
        reg = _artifact_docx.get_tool_registration()
        FIRST_PARTY_TOOLS[reg["name"]] = reg
        _artifact_docx.set_path_resolver(client_deliverables_dir)
    if _artifact_pptx is not None:
        reg = _artifact_pptx.get_tool_registration()
        FIRST_PARTY_TOOLS[reg["name"]] = reg
        _artifact_pptx.set_path_resolver(client_deliverables_dir)

def _first_party_tools_for_agent(agent_name):
    """Return the Anthropic-format tool schemas this agent is allowed to use."""
    agent_lower = (agent_name or "").lower()
    out = []
    for entry in FIRST_PARTY_TOOLS.values():
        if agent_lower in entry["allowed_agents"]:
            out.append(entry["schema"])
    return out

def _is_first_party_tool(name):
    return name in FIRST_PARTY_TOOLS

# Sentinel emitted by artifact handlers as the first line of a successful
# result payload. The tool-use dispatcher parses + strips it so the agent
# receives clean text and the CLI banner fires post-stream.
_DELIVERABLE_SENTINEL = "__TAVERNOS_DELIVERABLE__"

# Sentinel emitted by artifact handlers when a spec fails rubric-critical
# preflight checks (Goal A Layer 1, session 2). Symmetric with the success
# sentinel above — handler emits, dispatcher detects and strips, but
# classification flips: is_error=True, no banner. The agent sees the
# rejection text as an errored tool_result and retries with a complete
# spec. See artifact_docx.py's RUBRIC-CRITICAL PREFLIGHT GATE section.
_DELIVERABLE_REJECTED_SENTINEL = "__TAVERNOS_REJECTED__"

# Max rubric-critical rejections per tool-name, per run_tool_use_loop call,
# before the gate is bypassed on the next attempt. The bypassed attempt
# still surfaces a warning preamble to the agent (and to the post-save
# evaluator) but the file saves, preventing runaway retry loops against
# the uncapped `while True` tool-use loop. N=2 is a guess calibrated to
# session-1 telemetry; tune in session 3 once we have Layer-1 data.
_PREFLIGHT_GATE_MAX_REJECTIONS = 2

def _dispatch_first_party_tool(name, args, agent_name, bypass_gates=False):
    """Run the tool. Returns (text_for_agent, banner_dict_or_None, is_error).
    banner_dict has keys: filename, path, bytes.

    bypass_gates
        When True, handlers that support the skip_preflight_gate kwarg are
        invoked with it set to True, causing rubric-critical gates to be
        skipped and the deliverable to save despite critical issues. Only
        the docx handler recognizes this kwarg today; other handlers
        (xlsx, pptx) are invoked unchanged regardless of the flag."""
    entry = FIRST_PARTY_TOOLS.get(name)
    if not entry:
        return ("Unknown first-party tool: " + name, None, True)

    # Only generate_docx_report currently supports the gate bypass. Adding
    # templates to _RUBRIC_CRITICAL_PREFLIGHT in artifact_docx.py — or
    # equivalent gates in other artifact modules (session 3+) — will
    # require extending this switch.
    handler_kwargs = {}
    if bypass_gates and name == "generate_docx_report":
        handler_kwargs["skip_preflight_gate"] = True

    raw = entry["handler"](args, agent_name, get_active_client_slug(),
                           **handler_kwargs)

    # Rubric-critical rejection — strip the sentinel line, return the
    # remainder as is_error so the tool-use loop flips it to is_error=True
    # on the Anthropic tool_result block. No banner on the reject path.
    if raw.startswith(_DELIVERABLE_REJECTED_SENTINEL):
        _, _, rest = raw.partition("\n")
        return (rest, None, True)

    if raw.startswith(_DELIVERABLE_SENTINEL):
        header, _, rest = raw.partition("\n")
        parts = header[len(_DELIVERABLE_SENTINEL):].strip().split("\t")
        banner = None
        if len(parts) >= 3:
            try:
                banner = {"filename": parts[0], "path": parts[1],
                          "bytes": int(parts[2])}
            except (ValueError, IndexError):
                banner = None
        return (rest, banner, False)
    return (raw, None, False)


# Register tools at module-import time. Idempotent — main() calls this again
# as a belt-and-suspenders. Running here means: (1) the sanity-check probe
# `python -c "from tavernos import norm; print(norm.FIRST_PARTY_TOOLS)"`
# actually reflects registration state, and (2) the web UI path (which may
# not go through main()) sees tools too.
try:
    _register_first_party_tools()
except Exception as _fpr_import_e:
    # Can't use _log_error yet (journal dir may not exist). Stash for probes.
    _artifact_xlsx_register_error = str(_fpr_import_e)
else:
    _artifact_xlsx_register_error = None


def client_init_workspace(slug: str, name: str = None) -> None:
    """Create the folder structure + an initial client.json if none exists.

    Idempotent — safe to call on an existing workspace."""
    base = client_workspace_path(slug)
    base.mkdir(parents=True, exist_ok=True)
    (base / "memory").mkdir(exist_ok=True)
    (base / "intake").mkdir(exist_ok=True)
    (base / "notes").mkdir(exist_ok=True)
    deliv = base / "deliverables"
    deliv.mkdir(exist_ok=True)
    for sub in DELIVERABLE_DIRS:
        (deliv / sub).mkdir(exist_ok=True)

    if not client_manifest_path(slug).exists():
        default_name = name or ("TavernOS" if slug == DEFAULT_CLIENT_SLUG else slug)
        manifest = {
            "slug":            slug,
            "name":            default_name,
            "company_size":    "",
            "industry":        "",
            "primary_contact": {"name":"", "email":"", "role":""},
            "services":        [],
            "status":          "active",
            "kickoff_date":    "",
            "retainer_amount": 0,
            "billing_cycle":   "",
            "current_tools":   [],
            "voice_profile_path": "",
            "audit_path":      "",
            "active_workflows":[],
            "notes":           "",
            "created_at":      _now_iso(),
            "last_active":     _now_iso(),
        }
        client_save_manifest(manifest, slug)

def client_list_all(include_archived: bool = False) -> list:
    """Return a list of manifest dicts for every client. Sorted by last_active desc."""
    out = []
    if not CLIENTS_DIR.exists():
        return out
    for entry in CLIENTS_DIR.iterdir():
        if not entry.is_dir():
            continue
        if entry.name.startswith("_") and entry.name != DEFAULT_CLIENT_SLUG:
            continue  # skip _archived, _active (file not dir anyway), etc.
        manifest = client_load_manifest(entry.name)
        if manifest:
            out.append(manifest)
    if include_archived and ARCHIVED_DIR.exists():
        for entry in ARCHIVED_DIR.iterdir():
            if entry.is_dir() and (entry/"client.json").exists():
                try:
                    m = json.loads((entry/"client.json").read_text(encoding="utf-8"))
                    m["_archived"] = True
                    out.append(m)
                except Exception:
                    pass
    out.sort(key=lambda m: m.get("last_active",""), reverse=True)
    return out

def ensure_self_client_exists() -> bool:
    """Called on every launch (by Phase 2). Creates _self workspace if missing,
    migrates pre-Pack-0 memory data into it, and returns True if a migration
    actually ran (so the caller can print a first-run banner)."""
    CLIENTS_DIR.mkdir(parents=True, exist_ok=True)
    ARCHIVED_DIR.mkdir(parents=True, exist_ok=True)

    self_path = client_workspace_path(DEFAULT_CLIENT_SLUG)
    migration_ran = False

    if not self_path.exists() or not client_manifest_path(DEFAULT_CLIENT_SLUG).exists():
        client_init_workspace(DEFAULT_CLIENT_SLUG, name="TavernOS")

        # Migrate any pre-existing ~/.tavernos/memory/*.db into clients/_self/memory/
        old_memory = USER_DIR / "memory"
        new_memory = client_memory_dir(DEFAULT_CLIENT_SLUG)
        if old_memory.exists() and old_memory.is_dir():
            new_memory.mkdir(parents=True, exist_ok=True)
            moved_any = False
            for db_file in old_memory.glob("*.db"):
                dest = new_memory / db_file.name
                if not dest.exists():
                    try:
                        shutil.move(str(db_file), str(dest))
                        moved_any = True
                    except Exception:
                        pass
            if moved_any:
                try:
                    (old_memory / "MIGRATED.txt").write_text(
                        "Data migrated to clients/_self/memory/ on " + _now_iso() + "\n",
                        encoding="utf-8",
                    )
                except Exception:
                    pass
                migration_ran = True

    if not ACTIVE_CLIENT_FILE.exists():
        set_active_client_slug(DEFAULT_CLIENT_SLUG)

    return migration_ran


# ── Pack 0 — /client command surface (Phase 3) ────────────────────────────────

def _human_ago(iso_ts: str) -> str:
    """Turn an ISO timestamp into 'just now', '5m ago', '3h ago', '2d ago'."""
    if not iso_ts: return "—"
    try:
        dt = datetime.fromisoformat(iso_ts.replace("Z","+00:00"))
        delta = datetime.now(timezone.utc) - dt
        s = int(delta.total_seconds())
        if s < 60:      return "just now"
        if s < 3600:    return str(s//60)+"m ago"
        if s < 86400:   return str(s//3600)+"h ago"
        if s < 86400*30:return str(s//86400)+"d ago"
        return iso_ts[:10]
    except Exception:
        return iso_ts[:10] if len(iso_ts) >= 10 else iso_ts

def client_status_line(config: dict = None) -> str:
    """One-line status showing current client + key facts. Used after splash."""
    m = client_load_manifest() or {}
    slug = m.get("slug", get_active_client_slug())
    name = m.get("name", "TavernOS")
    services = m.get("services", [])
    svc = ", ".join(s.title() for s in services) if services else "—"
    return ("  "+tc(C.TEAL,"◆")+" Client: "+tbc(name)+"  "
            +dim("(")+tc(C.TEAL,slug)+dim(")")+"   "
            +tc(C.TEAL,"◆")+" Services: "+dim(svc))

def show_who():
    m = client_load_manifest() or {}
    slug = m.get("slug", get_active_client_slug())
    name = m.get("name", "TavernOS")
    print("  "+tc(C.TEAL,"◆")+" You're in: "+tbc(name)+"  "+dim("("+slug+")")); print()

def show_client_info():
    m = client_load_manifest() or {}
    slug = m.get("slug", get_active_client_slug())
    print(); print(box_top("CLIENT — "+slug.upper()))
    def row(k,v):
        v = v if v not in (None,"",[]) else dim("—")
        print(box_row(tc(C.TEAL,k.ljust(16))+"  "+str(v)))
    row("Name",           m.get("name",""))
    row("Slug",           slug)
    row("Status",         m.get("status",""))
    row("Industry",       m.get("industry",""))
    row("Size",           m.get("company_size",""))
    services = m.get("services",[])
    row("Services",       ", ".join(services) if services else "")
    pc = m.get("primary_contact",{}) or {}
    if pc.get("name") or pc.get("email"):
        row("Contact",    pc.get("name","")+((" <"+pc.get("email","")+">") if pc.get("email") else "")+((" — "+pc.get("role","")) if pc.get("role") else ""))
    row("Kickoff",        m.get("kickoff_date",""))
    row("Retainer",       ("$"+format(m.get("retainer_amount",0),",")+"/"+m.get("billing_cycle","mo")) if m.get("retainer_amount") else "")
    tools = m.get("current_tools",[])
    row("Tools",          ", ".join(tools) if tools else "")
    wf = m.get("active_workflows",[])
    row("Workflows",      ", ".join(wf) if wf else "")
    if m.get("notes"):
        row("Notes",      m.get("notes",""))
    row("Created",        m.get("created_at","")[:10])
    row("Last active",    _human_ago(m.get("last_active","")))
    print(box_bottom()); print()

def _count_deliverables_by_category() -> dict:
    """Return {category: (count, latest_filename_or_None)} for the active client.
    Recurses into subfolders so Pack 3/4/5 nested deliverables are included."""
    base = client_deliverables_dir()
    result = {}
    for category in DELIVERABLE_DIRS:
        cat_dir = base / category
        if not cat_dir.exists():
            result[category] = (0, None); continue
        files = [f for f in cat_dir.rglob("*") if f.is_file()]
        if not files:
            result[category] = (0, None); continue
        files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        # Show the relative sub-path for the latest so you know WHICH bucket it's in
        latest = files[0].relative_to(cat_dir).as_posix()
        result[category] = (len(files), latest)
    return result

def _count_notes() -> int:
    """Count bullet-style notes in the current client's operator-notes.md."""
    try:
        path = _notes_file_path()
        if not path.exists(): return 0
        return sum(1 for ln in path.read_text(encoding="utf-8").splitlines()
                   if ln.startswith("- **") or ln.startswith("## 2"))
    except Exception:
        return 0

def _count_memory_files() -> int:
    try:
        return len(memory_list_files())
    except Exception:
        return 0

def _top_skills(limit: int = 5) -> list:
    """Pull top skills from the active client's perf db, sorted by invocations."""
    try:
        con = sqlite3.connect(_perf_db_path())
        rows = con.execute(
            "SELECT agent,skill,invocations,avg_score FROM skill_summary "
            "ORDER BY invocations DESC LIMIT ?", (limit,)
        ).fetchall()
        con.close()
        return [{"agent":r[0],"skill":r[1],"uses":r[2],"score":r[3] or 0} for r in rows]
    except Exception:
        return []

def _days_since(iso_date: str) -> int:
    """Return number of days since an ISO date string (YYYY-MM-DD). -1 on parse error."""
    if not iso_date: return -1
    try:
        d = datetime.fromisoformat(iso_date[:10])
        return (datetime.now() - d).days
    except Exception:
        return -1

def show_client_summary() -> None:
    """One-screen dashboard for the active client — services, deliverables,
    intake, activity, and skill highlights. Works for _self too."""
    m = client_load_manifest() or {}
    slug = get_active_client_slug()
    name = m.get("name", slug)
    is_self = (slug == DEFAULT_CLIENT_SLUG)

    print(); print(box_top("CLIENT SUMMARY — "+slug.upper()))

    # Header — name + industry + size + kickoff/retainer
    print(box_row(tbc(name)))
    bits = []
    if m.get("industry"):     bits.append(m["industry"])
    if m.get("company_size"): bits.append(m["company_size"])
    if bits: print(box_row(dim(" — ".join(bits))))
    meta = []
    if m.get("kickoff_date"):
        d = _days_since(m["kickoff_date"])
        kickoff_str = "Kickoff: "+m["kickoff_date"]
        if d >= 0: kickoff_str += "  ("+str(d)+" day"+("s" if d!=1 else "")+" ago)"
        meta.append(kickoff_str)
    if m.get("retainer_amount"):
        meta.append("Retainer: $"+format(m["retainer_amount"],",")+"/"+(m.get("billing_cycle") or "mo"))
    if meta: print(box_row(dim("  ·  ".join(meta))))

    # Services
    services = m.get("services", [])
    if services:
        print(box_row(""))
        print(box_row(tc(C.TEAL,"▸ SERVICES")))
        print(box_row("  "+" · ".join(s.replace("-"," ").title() for s in services)))

    # Deliverables
    counts = _count_deliverables_by_category()
    total_deliv = sum(c for c,_ in counts.values())
    print(box_row(""))
    print(box_row(tc(C.TEAL,"▸ DELIVERABLES")+"  "+dim("("+str(total_deliv)+" total)")))
    icons = {"audits":"📋","blueprints":"🗺️ ","content":"✍️ ","reports":"📊"}
    if total_deliv == 0:
        print(box_row("  "+dim("None yet. Save with /save or /export conversation.")))
    else:
        for category in DELIVERABLE_DIRS:
            count, latest = counts[category]
            if count == 0: continue
            icon = icons.get(category, "·")
            line = "  "+icon+" "+category.title().ljust(12)+"  "+tc(C.WHITE,str(count).rjust(2))
            if latest: line += "   "+dim("latest: "+latest)
            print(box_row(line))

    # Intake
    try:
        unseen = _intake_unseen_files()
    except Exception:
        unseen = []
    if unseen:
        print(box_row(""))
        print(box_row(tc(C.AMBER,"▸ INTAKE")))
        print(box_row("  📥 "+tc(C.AMBER,str(len(unseen)))+" file"+("s" if len(unseen)!=1 else "")
                      +" pending — run "+tc(C.TEAL,"/client scan")))

    # Activity
    files_n = _count_memory_files()
    notes_n = _count_notes()
    last_active = _human_ago(m.get("last_active",""))
    print(box_row(""))
    print(box_row(tc(C.TEAL,"▸ ACTIVITY")))
    print(box_row("  📄 "+tc(C.WHITE,str(files_n))+" file"+("s" if files_n!=1 else "")+" in memory"))
    print(box_row("  📝 "+tc(C.WHITE,str(notes_n))+" operator note"+("s" if notes_n!=1 else "")))
    print(box_row("  ⏱  Last active: "+dim(last_active)))

    # Skill highlights
    top = _top_skills(limit=5)
    if top:
        print(box_row(""))
        print(box_row(tc(C.TEAL,"▸ SKILL HIGHLIGHTS")))
        for s in top:
            score = s["score"]
            dot = "🟢" if score >= 4 else ("🟡" if score >= 3 else "🔴")
            sc_color = C.GREEN if score >= 4 else (C.AMBER if score >= 3 else C.RED)
            label = _truncate(s["agent"]+" · "+s["skill"], 32)
            line = "  "+dot+" "+label.ljust(32)+"  "+tc(sc_color,str(round(score,1))+"/5")+"  "+dim("("+str(s["uses"])+" uses)")
            print(box_row(line))

    # Contact (only if populated and not _self)
    pc = m.get("primary_contact", {}) or {}
    if not is_self and (pc.get("name") or pc.get("email")):
        print(box_row(""))
        print(box_row(tc(C.TEAL,"▸ CONTACT")))
        contact_line = "  "+pc.get("name","")
        if pc.get("role"):  contact_line += "  "+dim("("+pc["role"]+")")
        if pc.get("email"): contact_line += "   "+tc(C.WHITE,pc["email"])
        print(box_row(contact_line))

    print(box_bottom()); print()

def show_client_list():
    clients = client_list_all(include_archived=True)
    if not clients:
        print("  "+dim("No clients yet. Create one with: ")+tc(C.TEAL,"/client new")); print(); return
    print(); print(box_top("CLIENTS"))
    print(box_row(
        dim("Slug").ljust(16)+dim("Name").ljust(24)+dim("Status").ljust(12)
        +dim("Services").ljust(24)+dim("Last active")
    )); print(box_divider())
    active_slug = get_active_client_slug()
    for m in clients:
        slug = m.get("slug","?")
        marker = tc(C.TEAL,"●") if slug == active_slug else " "
        if m.get("_archived"): marker = tc(C.GRAY2,"⌧") if hasattr(C,"GRAY2") else tc(C.GRAY,"⌧")
        name = _truncate(m.get("name","?"),22)
        status = _truncate(m.get("status","active"),10)
        services = _truncate(", ".join(m.get("services",[])) or "—",22)
        last = _human_ago(m.get("last_active",""))
        print(box_row(
            marker+" "+tc(C.TEAL,_truncate(slug,14)).ljust(14)+"  "
            +name.ljust(22)+"  "+status.ljust(10)+"  "
            +services.ljust(22)+"  "+dim(last)
        ))
    print(box_bottom())
    print("  "+dim("● = active · ⌧ = archived")); print()

def _switch_client(new_slug: str, history=None) -> bool:
    """Switch the active client workspace. Returns True on success."""
    new_slug = (new_slug or "").strip().lower()
    if not new_slug:
        print("  "+tc(C.RED,"✗")+" Usage: /client switch <slug>"); return False
    if not client_exists(new_slug):
        print("  "+tc(C.RED,"✗")+" Client not found: "+tc(C.WHITE,new_slug))
        print("  "+dim("See available clients with ")+tc(C.TEAL,"/client list")); return False
    set_active_client_slug(new_slug)
    if history is not None:
        try: history.clear()
        except Exception: pass
    # Re-init DBs against the new workspace (idempotent)
    try: memory_init(); perf_db_init(); vector_db_init(); feedback_db_init()
    except Exception: pass
    m = client_load_manifest() or {}
    print(); print("  "+tc(C.GREEN,"✓")+" Switched to "+tbc(m.get("name",new_slug))+"  "+dim("("+new_slug+")"))
    notice = intake_notice_one_liner()
    if notice: print(notice)
    print()
    return True

def interactive_client_create():
    """Minimal intake for a new client. Runs inside the REPL."""
    print(); print("  "+tbc("New client — a few quick questions"))
    try:
        name = input("  "+tc(C.TEAL,"Client name: ")).strip()
        if not name:
            print("  "+tc(C.AMBER,"⚠")+" Cancelled (no name)."); return
        suggested = _slugify_client(name)
        slug_in = input("  "+tc(C.TEAL,"Slug [")+tc(C.WHITE,suggested)+tc(C.TEAL,"]: ")).strip()
        slug = _slugify_client(slug_in) if slug_in else suggested
        if client_exists(slug):
            print("  "+tc(C.AMBER,"⚠")+" A client with slug "+tc(C.WHITE,slug)+" already exists."); return
        industry     = input("  "+tc(C.TEAL,"Industry (optional): ")).strip()
        company_size = input("  "+tc(C.TEAL,"Company size (e.g. '25 people') (optional): ")).strip()
        contact_name = input("  "+tc(C.TEAL,"Primary contact name (optional): ")).strip()
        contact_email= input("  "+tc(C.TEAL,"Primary contact email (optional): ")).strip()
        services_raw = input("  "+tc(C.TEAL,"Services (comma-separated, e.g. 'implementation, content-ops'): ")).strip()
        services = [s.strip() for s in services_raw.split(",") if s.strip()]
        notes        = input("  "+tc(C.TEAL,"Notes (optional): ")).strip()
    except (EOFError,KeyboardInterrupt):
        print(); print("  "+tc(C.AMBER,"⚠")+" Cancelled."); return

    client_init_workspace(slug, name=name)
    m = client_load_manifest(slug)
    m["industry"]        = industry
    m["company_size"]    = company_size
    m["primary_contact"] = {"name":contact_name, "email":contact_email, "role":""}
    m["services"]        = services
    m["notes"]           = notes
    client_save_manifest(m, slug)
    print()
    print("  "+tc(C.GREEN,"✓")+" Created client: "+tbc(name))
    print("  "+dim("Slug:          ")+tc(C.WHITE,slug))
    print("  "+dim("Workspace:     ")+dim(str(client_workspace_path(slug))))
    print()
    print("  "+tc(C.TEAL,"→")+" Switch to it now with:  "+tbc("/client switch "+slug))
    print()

def edit_client_manifest():
    path = client_manifest_path()
    editor = os.environ.get("EDITOR") or ("notepad" if sys.platform=="win32" else "nano")
    print("  "+dim("Opening ")+tc(C.TEAL,str(path))+dim(" in ")+tc(C.TEAL,editor))
    try:
        import subprocess
        subprocess.call([editor, str(path)])
    except Exception as e:
        print("  "+tc(C.RED,"✗")+" Couldn't open editor: "+str(e))
        print("  "+dim("Edit this file manually: ")+str(path))

def client_archive_action(slug: str):
    slug = (slug or "").strip().lower()
    if not slug: print("  "+tc(C.RED,"✗")+" Usage: /client archive <slug>"); return
    if slug == DEFAULT_CLIENT_SLUG:
        print("  "+tc(C.AMBER,"⚠")+" Can't archive "+tc(C.WHITE,"_self")+"."); return
    src = client_workspace_path(slug)
    if not src.exists():
        print("  "+tc(C.RED,"✗")+" Client not found: "+slug); return
    ARCHIVED_DIR.mkdir(parents=True, exist_ok=True)
    dest = ARCHIVED_DIR / slug
    if dest.exists():
        print("  "+tc(C.AMBER,"⚠")+" Already archived at "+str(dest)); return
    try:
        shutil.move(str(src), str(dest))
        if get_active_client_slug() == slug:
            set_active_client_slug(DEFAULT_CLIENT_SLUG)
            print("  "+dim("(Active client reset to _self since you archived the current one.)"))
        print("  "+tc(C.GREEN,"✓")+" Archived "+tbc(slug))
    except Exception as e:
        print("  "+tc(C.RED,"✗")+" Archive failed: "+str(e))

def client_restore_action(slug: str):
    slug = (slug or "").strip().lower()
    if not slug: print("  "+tc(C.RED,"✗")+" Usage: /client restore <slug>"); return
    src = ARCHIVED_DIR / slug
    if not src.exists():
        print("  "+tc(C.RED,"✗")+" No archived client: "+slug); return
    dest = client_workspace_path(slug)
    if dest.exists():
        print("  "+tc(C.AMBER,"⚠")+" An active client with slug "+slug+" already exists."); return
    try:
        shutil.move(str(src), str(dest))
        print("  "+tc(C.GREEN,"✓")+" Restored "+tbc(slug))
    except Exception as e:
        print("  "+tc(C.RED,"✗")+" Restore failed: "+str(e))

def list_deliverables():
    base = client_deliverables_dir()
    if not base.exists():
        print("  "+dim("No deliverables folder yet for this client.")); return
    any_found = False
    print(); print(box_top("DELIVERABLES — "+get_active_client_slug().upper()))
    for category in DELIVERABLE_DIRS:
        cat_dir = base / category
        if not cat_dir.exists(): continue
        # Recurse so nested packs (lead-intel/, support/, internal-ops/, ops/) are visible
        files = sorted([p for p in cat_dir.rglob("*") if p.is_file()])
        if not files: continue
        any_found = True
        print(box_row(tc(C.TEAL,"▸ "+category.upper())))
        for f in files:
            if f.is_file():
                size_kb = max(1, f.stat().st_size // 1024)
                # Show the path relative to the category dir so subfolders are obvious
                rel = f.relative_to(cat_dir).as_posix()
                print(box_row("    "+tc(C.WHITE,rel).ljust(44)+"  "+dim(str(size_kb)+" KB")))
    if not any_found:
        print(box_row(dim("No deliverables saved yet.")))
        print(box_row(dim("Save with: ")+tc(C.TEAL,"/save <category> <filename.md>")))
    print(box_bottom()); print()

def package_current_client():
    slug = get_active_client_slug()
    src = client_workspace_path(slug)
    if not src.exists():
        print("  "+tc(C.RED,"✗")+" No workspace to package."); return
    stamp = datetime.now().strftime("%Y-%m-%d")
    zip_name = "TavernOS-"+slug+"-handoff-"+stamp+".zip"
    dest = Path.home()/"Desktop"/zip_name
    try:
        with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as zf:
            for entry in src.rglob("*"):
                if entry.is_file():
                    zf.write(entry, entry.relative_to(src.parent))
        print("  "+tc(C.GREEN,"✓")+" Packaged: "+tbc(str(dest)))
    except Exception as e:
        print("  "+tc(C.RED,"✗")+" Package failed: "+str(e))


# ── Pack 0 — operator notes (/note, /notes) ───────────────────────────────────

def _notes_file_path(slug: str = None) -> Path:
    """Path to the current (or given) client's running notes file."""
    return client_notes_dir(slug) / "operator-notes.md"

def _notes_ensure_header(path: Path, client_name: str) -> None:
    """Create the notes file with a friendly header if it doesn't exist yet."""
    if path.exists(): return
    path.parent.mkdir(parents=True, exist_ok=True)
    header = "# Operator Notes — " + client_name + "\n\n"
    header += "_Timestamped notes captured with `/note` during live client work._\n\n"
    path.write_text(header, encoding="utf-8")

def append_note(text: str) -> Path:
    """Append a timestamped bullet to the current client's operator-notes.md.

    Returns the file path. Creates the file (with header) if it doesn't exist."""
    manifest = client_load_manifest() or {}
    client_name = manifest.get("name", get_active_client_slug())
    path = _notes_file_path()
    _notes_ensure_header(path, client_name)
    ts = datetime.now().strftime("%Y-%m-%d %H:%M")
    # Single-line notes get a compact bullet; multi-line notes get their own block.
    cleaned = text.strip()
    if "\n" in cleaned:
        block = "\n## " + ts + "\n\n" + cleaned + "\n"
    else:
        block = "- **" + ts + "** — " + cleaned + "\n"
    with open(path, "a", encoding="utf-8") as f:
        f.write(block)
    return path

def handle_note_command(raw: str) -> None:
    """Handle '/note <text>' — append a one-liner to operator-notes.md.

    If invoked with no text, shows usage + the last 3 notes for quick recall."""
    parts = raw.split(None, 1)  # ["/note", "<rest...>"]
    if len(parts) < 2 or not parts[1].strip():
        print("  "+tc(C.AMBER,"⚠")+" Usage: "+tc(C.TEAL,"/note <text>")+dim("   (appends a timestamped line to this client's notes)"))
        # Show last 3 notes as context if any exist
        path = _notes_file_path()
        if path.exists():
            try:
                lines = [ln for ln in path.read_text(encoding="utf-8").splitlines() if ln.startswith("- **")]
                if lines:
                    print("  "+dim("Recent notes:"))
                    for ln in lines[-3:]:
                        print("    "+dim(ln[2:]))  # strip the "- " prefix for display
            except Exception: pass
        return
    text = parts[1].strip()
    try:
        path = append_note(text)
        print("  "+tc(C.GREEN,"✓")+" Noted. "+dim("("+str(path)+")"))
    except Exception as e:
        print("  "+tc(C.RED,"✗")+" Couldn't save note: "+str(e))

def show_notes() -> None:
    """Display the current client's operator notes, or a helpful prompt if empty."""
    path = _notes_file_path()
    slug = get_active_client_slug()
    if not path.exists():
        print("  "+dim("No notes yet for ")+tc(C.WHITE,slug)+dim(". Capture one with: ")+tc(C.TEAL,"/note <text>")); return
    try:
        content = path.read_text(encoding="utf-8").strip()
    except Exception as e:
        print("  "+tc(C.RED,"✗")+" Couldn't read notes: "+str(e)); return
    if not content:
        print("  "+dim("Notes file is empty.")); return
    print(); print(box_top("OPERATOR NOTES — "+slug.upper()))
    for line in content.splitlines():
        if not line.strip():
            print(box_row(""))
        elif line.startswith("# "):
            print(box_row(tbc(line[2:])))
        elif line.startswith("## "):
            print(box_row(tc(C.TEAL,line[3:])))
        elif line.startswith("- **"):
            # Highlight the timestamp
            try:
                ts_end = line.index("**", 4)
                ts = line[4:ts_end]
                rest = line[ts_end+2:].lstrip(" —-")
                print(box_row(tc(C.TEAL,ts)+"  "+rest))
            except Exception:
                print(box_row(line))
        else:
            print(box_row(dim(line)))
    print(box_bottom())
    print("  "+dim("Full file: ")+str(path)); print()


# ── Pack 0 — intake folder auto-ingestion ─────────────────────────────────────

def _intake_unseen_files(slug: str = None) -> list:
    """Return sorted list of Path objects in the current client's intake/ folder
    that have a supported extension and are NOT already in the memory db
    (matched by absolute path)."""
    intake = client_intake_dir(slug)
    if not intake.exists():
        return []
    # Already-ingested paths, compared as strings
    try:
        already = {r["path"] for r in memory_list_files()}
    except Exception:
        already = set()
    unseen = []
    for p in sorted(intake.rglob("*")):
        if not p.is_file(): continue
        if p.suffix.lower() not in SUPPORTED_EXT: continue
        if str(p.resolve()) in already or str(p) in already: continue
        unseen.append(p)
    return unseen

def intake_notice_one_liner() -> str:
    """Short status hint about unseen intake files. Returns '' if nothing to do.
    Used after /client switch so the user knows there's pending intake."""
    unseen = _intake_unseen_files()
    if not unseen:
        return ""
    n = len(unseen)
    return ("  "+tc(C.TEAL,"📥")+" "+str(n)+" new file"+("s" if n!=1 else "")
            +" in intake/ — run "+tc(C.TEAL,"/client scan")+" to ingest")

def scan_intake_interactive():
    """List unseen intake files and offer to ingest them."""
    slug = get_active_client_slug()
    intake = client_intake_dir()
    if not intake.exists():
        print("  "+dim("No intake folder for ")+tc(C.WHITE,slug)+dim(" yet. Creating it…"))
        intake.mkdir(parents=True, exist_ok=True)
    unseen = _intake_unseen_files()
    if not unseen:
        print("  "+tc(C.GREEN,"✓")+" Intake folder is empty or fully ingested.")
        print("  "+dim("Drop files here to ingest: ")+tc(C.WHITE,str(intake)))
        return
    print(); print(box_top("INTAKE SCAN — "+slug.upper()))
    print(box_row(tc(C.TEAL,str(len(unseen)))+" new file"+("s" if len(unseen)!=1 else "")+" ready to ingest:"))
    for p in unseen:
        try: size_kb = max(1, p.stat().st_size // 1024)
        except Exception: size_kb = 0
        icon = FILE_ICONS.get(p.suffix.lower(), "📄")
        print(box_row("  "+icon+" "+tc(C.WHITE,p.name).ljust(46)+"  "+dim(str(size_kb)+" KB")))
    print(box_bottom())
    try:
        ans = input("  "+tc(C.TEAL,"Ingest all now? ")+dim("(y/N): ")).strip().lower()
    except (EOFError,KeyboardInterrupt):
        print(); print("  "+dim("Cancelled.")); return
    if ans not in ("y","yes"):
        print("  "+dim("Skipped. Run ")+tc(C.TEAL,"/client scan")+dim(" again whenever you're ready.")); return
    print(); print("  "+tc(C.TEAL,"⟳")+" Ingesting "+str(len(unseen))+" file(s)…")
    ok_count = 0
    for p in unseen:
        try:
            result = ingest_file(p)
            if result: ok_count += 1
        except Exception as e:
            print("  "+tc(C.RED,"✗")+" "+p.name+": "+str(e))
    print()
    print("  "+tc(C.GREEN,"✓")+" Ingested "+tbc(str(ok_count))+"/"+str(len(unseen))+" files into "+tbc(slug)+" memory.")
    if ok_count < len(unseen):
        print("  "+dim("Some files failed — check errors above."))
    print()


# ── Pack 0 — agent prompt context injection (Phase 4) ──────────────────────────

def _touch_active_client() -> None:
    """Bump last_active on the current client's manifest. Called every REPL turn.
    Cheap and failure-tolerant — never raises."""
    try:
        m = client_load_manifest()
        if m:
            m["last_active"] = _now_iso()
            client_save_manifest(m)
    except Exception: pass


def _client_context_block() -> str:
    """Return a system-prompt fragment describing the active client. Empty for _self."""
    manifest = client_load_manifest()
    if not manifest or manifest.get("slug") == DEFAULT_CLIENT_SLUG:
        return ""
    services = ", ".join(manifest.get("services", [])) or "none yet"
    tools    = ", ".join(manifest.get("current_tools", [])) or "unspecified"
    workflows= ", ".join(manifest.get("active_workflows", [])) or "none"
    voice_path = manifest.get("voice_profile_path","") or ""
    audit_path = manifest.get("audit_path","") or ""
    pc = manifest.get("primary_contact",{}) or {}
    contact = pc.get("name","") + ((" <"+pc.get("email","")+">") if pc.get("email") else "")

    block  = "\n\n## CURRENT CLIENT CONTEXT\n"
    block += "You are operating for: " + manifest.get("name","Unknown") + "\n"
    block += "Client slug: "            + manifest.get("slug","?") + "\n"
    if manifest.get("industry"):     block += "Industry: "          + manifest["industry"] + "\n"
    if manifest.get("company_size"): block += "Size: "              + manifest["company_size"] + "\n"
    block += "Active services: "        + services + "\n"
    block += "Current tools: "          + tools + "\n"
    block += "Active workflows: "       + workflows + "\n"
    if contact:               block += "Primary contact: "  + contact + "\n"
    if voice_path:            block += "Voice profile at: " + voice_path + "\n"
    if audit_path:            block += "Audit doc at: "     + audit_path + "\n"
    if manifest.get("notes"): block += "Operator notes: "   + manifest["notes"] + "\n"
    block += (
        "\nAddress the client by name in deliverables. "
        "When you produce a major output worth saving, suggest a save path at the end like:\n"
        "    _Save this deliverable to:_ `clients/" + manifest.get("slug","?") + "/deliverables/<category>/<filename>.md`\n"
        "Valid categories: " + ", ".join(DELIVERABLE_DIRS) + ".\n"
    )
    return block


# ═══════════════════════════════════════════════════════════════════════════════
#  MODEL ORDERING
# ═══════════════════════════════════════════════════════════════════════════════

def _model_sort_key(m):
    tier=m.get("tier",2); release_date=m.get("release_date","")
    if release_date:
        try: return (tier,-int(release_date.replace("-","")))
        except ValueError: pass
    numbers=re.findall(r'\d+',m.get("id",""))
    return (tier,-max(int(n) for n in numbers)) if numbers else (tier,0)


# ═══════════════════════════════════════════════════════════════════════════════
#  MODELS.DEV
# ═══════════════════════════════════════════════════════════════════════════════

_models_cache=[]

def fetch_models_dev():
    global _models_cache
    if _models_cache: return _models_cache
    try:
        req=urllib.request.Request(MODELS_DEV_URL,headers={"User-Agent":"TavernOS/0.1.0"})
        with urllib.request.urlopen(req,timeout=5) as r: raw=json.loads(r.read().decode())
        models=[]
        for pid,pd in raw.items():
            if not isinstance(pd,dict): continue
            for mid,md in pd.get("models",{}).items():
                if not isinstance(md,dict): continue
                pr=md.get("pricing",{})
                tier=(1 if any(x in mid.lower() for x in ["opus","gpt-4o","gpt-5"])
                      else 3 if any(x in mid.lower() for x in ["haiku","mini","nano"]) else 2)
                models.append({"provider":pid,"id":mid,"name":md.get("name",mid),
                                "context":md.get("context",0),"input_cost":pr.get("input",0),
                                "output_cost":pr.get("output",0),"tier":tier,
                                "release_date":md.get("release_date","")})
        _models_cache=models; return models
    except Exception: return []

def get_available_models(config):
    providers=get_providers(config)
    if not providers: return []
    all_models=fetch_models_dev() or FALLBACK_MODELS
    available=[m for m in all_models if m["provider"] in providers]
    available.sort(key=_model_sort_key)
    return available

def build_client(config):
    provider,model_id=get_active_model(config)
    providers=get_providers(config); api_key=providers.get(provider,"")
    if not api_key: return None,provider,model_id
    try:
        if provider=="anthropic":
            import anthropic; return anthropic.Anthropic(api_key=api_key),provider,model_id
        else:
            import openai; return openai.OpenAI(api_key=api_key),provider,model_id
    except ImportError as e: print("  "+tc(C.AMBER,"⚠")+" Missing library: "+str(e)); return None,provider,model_id
    except Exception as e:   print("  "+tc(C.AMBER,"⚠")+" Client error: "+str(e));   return None,provider,model_id

def model_selector(config,mode=Mode.CUSTOMER):
    models=get_available_models(config)
    if not models: print("No models available. Add a provider with /provider add"); return False
    provider_active,model_active=get_active_model(config)
    current_idx=next((i for i,m in enumerate(models) if m["provider"]==provider_active and m["id"]==model_active),0)
    try:
        import curses
        def _draw(stdscr,idx):
            stdscr.clear(); h,w=stdscr.getmaxyx()
            stdscr.addstr(0,0,"  SELECT MODEL  (up/down, Enter select, s save, q cancel)",curses.A_BOLD)
            stdscr.addstr(1,0,"-"*min(w-1,72))
            last_provider=None; row=2; vs=max(0,idx-(h-5)//2)
            for i in range(vs,min(len(models),vs+h-4)):
                m=models[i]
                if m["provider"]!=last_provider:
                    if row<h-1: stdscr.addstr(row,0,"  -- "+m["provider"].upper()+" --"); row+=1
                    last_provider=m["provider"]
                cost="$"+str(m["input_cost"])+"/$"+str(m["output_cost"])+"/MTok"
                mark=">" if i==idx else " "
                line=("  "+mark+" "+m["name"]+" "*max(0,32-len(m["name"]))+cost)[:w-2]
                if row<h-1:
                    if i==idx: stdscr.addstr(row,0,line,curses.A_REVERSE|curses.A_BOLD)
                    else:       stdscr.addstr(row,0,line)
                    row+=1
            if h-1>0: stdscr.addstr(h-1,0,"  s = save as default")
            stdscr.refresh()
        def _selector(stdscr):
            curses.curs_set(0); idx=current_idx; result=None; save=False
            while True:
                _draw(stdscr,idx); key=stdscr.getch()
                if key in (curses.KEY_UP,ord("k")) and idx>0: idx-=1
                elif key in (curses.KEY_DOWN,ord("j")) and idx<len(models)-1: idx+=1
                elif key in (curses.KEY_ENTER,10,13): result=models[idx]; break
                elif key==ord("s"):                   result=models[idx]; save=True; break
                elif key in (ord("q"),27):            break
            return result,save
        chosen,save=curses.wrapper(_selector)
    except Exception:
        print(); print("  "+tbc("Available models:")); print()
        last_provider=None
        for i,m in enumerate(models):
            if m["provider"]!=last_provider:
                print("  "+tc(C.TEAL,"──")+" "+tbc(m["provider"].upper())+" "+tc(C.TEAL,"──"))
                last_provider=m["provider"]
            marker=tc(C.TEAL,"▶") if (m["provider"]==provider_active and m["id"]==model_active) else " "
            cost=dim("$"+str(m["input_cost"])+"/$"+str(m["output_cost"])+"/MTok")
            print("  "+marker+" "+str(i+1).rjust(2)+". "+tc(C.WHITE,m["name"])+"  "+cost)
        print()
        raw_in=input("  Enter number (or Enter to cancel): ").strip()
        if not raw_in: return False
        try:
            chosen=models[int(raw_in)-1]; save=input("  Save as default? [y/n]: ").strip().lower()=="y"
        except (ValueError,IndexError): print("  "+tc(C.RED,"✗")+" Invalid selection."); return False
    if chosen is None: print("  No change."); return False
    set_active_model(config,chosen["provider"],chosen["id"],save=save,mode=mode)
    note=" (saved)" if save else " "+dim("(session only)")
    print(); print("  "+tc(C.GREEN,"✓")+" Switched to "+tbc(chosen["name"])+" ["+dim(chosen["provider"].upper())+"]"+note); print()
    return True

def handle_model_command(raw,config,mode=Mode.CUSTOMER):
    parts=raw.strip().split(maxsplit=1); sub=parts[1].strip() if len(parts)>1 else ""
    if sub=="": return model_selector(config,mode)
    elif sub=="list":
        models=get_available_models(config); provider_active,model_active=get_active_model(config)
        if not models: print("No models available."); return False
        print(); last_provider=None
        for m in models:
            if m["provider"]!=last_provider:
                print("  "+tc(C.TEAL,"──")+" "+tbc(m["provider"].upper())+" "+"─"*38); last_provider=m["provider"]
            active=tc(C.TEAL,"▶") if (m["provider"]==provider_active and m["id"]==model_active) else " "
            cost=dim("$"+str(m["input_cost"])+"/$"+str(m["output_cost"])+"/MTok")
            ctx=dim(str(m["context"]//1000)+"K ctx") if m["context"] else ""
            print("  "+active+" "+tc(C.WHITE,m["id"])+"  "+cost+"  "+ctx)
        print(); return False
    elif sub=="save":
        save_config(config,mode); provider_active,model_active=get_active_model(config)
        print("  "+tc(C.GREEN,"✓")+" "+model_active+" ["+provider_active+"] saved."); return False
    else:
        models=get_available_models(config)
        for m in models:
            if m["id"].lower()==sub.lower() or m["name"].lower()==sub.lower():
                set_active_model(config,m["provider"],m["id"],mode=mode)
                print("  "+tc(C.GREEN,"✓")+" Switched to "+tbc(m["name"])+" (session only)"); return True
        print("  "+tc(C.RED,"✗")+" Model '"+sub+"' not found. Try /model list"); return False

def add_provider(config,mode=Mode.CUSTOMER):
    print(); print("  "+tbc("Add a new provider API key."))
    provider=input("  Provider name (e.g. anthropic, openai): ").strip().lower()
    if not provider: print("  Cancelled."); return
    api_key=input("  API key for "+provider+": ").strip()
    if not api_key: print("  Cancelled."); return
    if "providers" not in config: config["providers"]={}
    config["providers"][provider]=api_key; save_config(config,mode)
    models=get_available_models(config); best=next((m for m in models if m["provider"]==provider),None)
    if best:
        set_active_model(config,best["provider"],best["id"],mode=mode)
        print("  "+tc(C.GREEN,"✓")+" "+provider+" added. Active model: "+tbc(best["name"])+".")
    else: print("  "+tc(C.GREEN,"✓")+" "+provider+" added.")
    save_config(config,mode)


# ═══════════════════════════════════════════════════════════════════════════════
#  ONBOARDING WIZARD
# ═══════════════════════════════════════════════════════════════════════════════

WIZARD_AGENTS=[
    ("Sam",    "Chief of Staff — orchestrates the crew and routes your requests"),
    ("Norm",   "Cornerstone regular — reliable fallback for any task"),
    ("Coach",  "Meetings, PRDs, action items, requirements"),
    ("Carla",  "QA, code review, editorial critique"),
    ("Woody",  "Proposals, content, documentation, emails"),
    ("Cliff",  "Research, data analysis, PDF and file analysis, live web search"),
    ("Frasier","Strategy, architecture, high-level planning"),
    ("Rebecca","Excel, slide decks, charts, data visualization"),
]

def _wizard_prompt(label,hint="",secret=False,default="",required=True):
    while True:
        label_str=tc(C.TEAL,"  ❯ ")+tc(C.WHITE+C.BOLD,label)
        if default: label_str+=dim("  ["+default+"]")
        print(label_str)
        if hint: print(dim("    "+hint))
        try:
            if secret:
                import getpass; value=getpass.getpass(tc(C.TEAL,"    → "))
            else: value=input(tc(C.TEAL,"    → ")).strip()
        except (EOFError,KeyboardInterrupt): print(); print(dim("  Setup cancelled.")); sys.exit(0)
        if not value and default: value=default
        if not value and required: print(tc(C.AMBER,"    ⚠  This field is required.")); print(); continue
        return value

def _wizard_confirm(question,default_yes=True):
    suffix=dim("  [Y/n]") if default_yes else dim("  [y/N]")
    print(tc(C.TEAL,"  ❯ ")+tc(C.WHITE,question)+suffix)
    try: val=input(tc(C.TEAL,"    → ")).strip().lower()
    except (EOFError,KeyboardInterrupt): print(); sys.exit(0)
    return default_yes if not val else val.startswith("y")

def _validate_api_key(key,provider):
    if provider=="anthropic":
        if not key.startswith("sk-ant-"): return False,"Anthropic keys start with 'sk-ant-'. Double-check you copied the full key."
        if len(key)<40: return False,"That key looks too short."
    elif provider=="openai":
        if not key.startswith("sk-"): return False,"OpenAI keys start with 'sk-'."
        if len(key)<30: return False,"That key looks too short."
    return True,""

def _test_api_key(key,provider):
    try:
        if provider=="anthropic":
            import anthropic; client=anthropic.Anthropic(api_key=key)
            client.messages.create(model="claude-haiku-4-5-20251001",max_tokens=10,messages=[{"role":"user","content":"Hi"}])
            return True,""
        elif provider=="openai":
            import openai; client=openai.OpenAI(api_key=key)
            client.chat.completions.create(model="gpt-4o-mini",max_tokens=10,messages=[{"role":"user","content":"Hi"}])
            return True,""
    except Exception as e:
        msg=str(e)
        if "401" in msg or "authentication" in msg.lower() or "invalid" in msg.lower(): return False,"Key rejected — it may be invalid or not yet active."
        if "429" in msg or "quota" in msg.lower(): return False,"Key is valid but has no credits. Add billing at console.anthropic.com."
        return False,"Could not connect: "+msg[:80]
    return False,"Unknown error"

def _wizard_pick_provider():
    print(); print(box_top("CHOOSE YOUR AI PROVIDER"))
    print(box_row(tc(C.TEAL,"1")+"  "+tc(C.WHITE+C.BOLD,"Anthropic (Claude)")+"  "+dim("— Recommended. Includes live web search for Cliff.")))
    print(box_row(tc(C.TEAL,"2")+"  "+tc(C.WHITE,"OpenAI (GPT)")+"       "+dim("— Works if you already have an OpenAI key.")))
    print(box_bottom()); print()
    while True:
        choice=_wizard_prompt("Enter 1 or 2",default="1")
        if choice in ("1","2"): return "anthropic" if choice=="1" else "openai"
        print(tc(C.AMBER,"    ⚠  Please enter 1 or 2.")); print()

def _wizard_pick_model(provider,key):
    tmp={"providers":{provider:key}}; models=get_available_models(tmp)
    if not models: models=[{"id":m["id"],"name":m["name"],"input_cost":m["input_cost"],"output_cost":m["output_cost"],"tier":m["tier"]} for m in FALLBACK_MODELS if m["provider"]==provider]
    print(); print(box_top("CHOOSE YOUR DEFAULT MODEL"))
    print(box_row(dim("Newest and most capable models are listed first.")))
    print(box_row(dim("You can change this any time with /model inside TavernOS.")))
    print(box_divider())
    for i,m in enumerate(models[:8],1):
        cost="$"+str(m["input_cost"])+"/$"+str(m["output_cost"])+"/MTok"
        tier_label=dim("⭐ Recommended") if m["tier"]==1 else (dim("balanced") if m["tier"]==2 else dim("fast/light"))
        print(box_row(tc(C.TEAL,str(i))+"  "+tc(C.WHITE+C.BOLD if m["tier"]==1 else C.WHITE,_truncate(m["name"],30).ljust(32))+dim(cost.ljust(22))+tier_label))
    print(box_bottom()); print()
    while True:
        choice=_wizard_prompt("Enter a number",hint="Press Enter for the recommended option (1)",default="1")
        try:
            idx=int(choice)-1
            if 0<=idx<min(8,len(models)): chosen=models[idx]; return chosen["id"],chosen["name"]
        except ValueError: pass
        print(tc(C.AMBER,"    ⚠  Please enter a number from the list.")); print()

def run_onboarding_wizard():
    print(_splash()); print()
    print(box_top("WELCOME TO TAVERNOS"))
    print(box_row(tc(C.WHITE+C.BOLD,"Let's get you set up.")+dim("  Takes about 2 minutes.")))
    print(box_row(dim("We'll ask for your name, your AI provider key, and your preferred model.")))
    print(box_row(dim("Everything is saved locally on your machine. Nothing is shared.")))
    print(box_bottom()); print()
    print(tc(C.TEAL+C.BOLD,"  Your crew:")); print()
    for name,desc in WIZARD_AGENTS: print("  "+tc(C.TEAL,"◆")+" "+tc(C.WHITE+C.BOLD,name.ljust(10))+dim(desc))
    print(); print(dim("  "+"─"*(_term_width()-4))); print()

    print(tc(C.TEAL+C.BOLD,"  STEP 1 OF 4  ")+dim("What should we call you?")); print()
    company=_wizard_prompt("Your name or company name",hint="This is how TavernOS will greet you each session.")
    print(); print("  "+tc(C.GREEN,"✓")+"  "+dim("Got it — welcome, ")+tc(C.WHITE+C.BOLD,company)+dim(".")); print()

    print(tc(C.TEAL+C.BOLD,"  STEP 2 OF 4  ")+dim("Which AI provider are you using?"))
    provider=_wizard_pick_provider(); provider_label="Anthropic" if provider=="anthropic" else "OpenAI"

    print(tc(C.TEAL+C.BOLD,"  STEP 3 OF 4  ")+dim("Enter your "+provider_label+" API key")); print()
    if provider=="anthropic":
        print(dim("  Don't have a key yet? Get one free at:")); print(tc(C.TEAL,"  https://console.anthropic.com")+dim(" → API Keys → Create Key")); print()
    else:
        print(dim("  Don't have a key yet? Get one at:")); print(tc(C.TEAL,"  https://platform.openai.com/api-keys")); print()

    api_key=""
    while True:
        api_key=_wizard_prompt(provider_label+" API key",hint="Your key will not be shown as you type.",secret=True)
        valid,err=_validate_api_key(api_key,provider)
        if not valid: print(); print(tc(C.AMBER,"    ⚠  "+err)); print(dim("    Please try again.")); print(); continue
        print(); _indicator.start("Verifying key with "+provider_label+"…")
        ok,err=_test_api_key(api_key,provider); _indicator.stop()
        if ok: print("  "+tc(C.GREEN,"✓")+"  Key verified successfully."); print(); break
        else:
            print(tc(C.AMBER,"  ⚠  "+err)); print()
            if not _wizard_confirm("Try a different key?",default_yes=True):
                print(); print(dim("  Saving key anyway — update later with /provider add")); print(); break

    print(tc(C.TEAL+C.BOLD,"  STEP 4 OF 4  ")+dim("Choose your default AI model"))
    model_id,model_name=_wizard_pick_model(provider,api_key)
    print(); print("  "+tc(C.GREEN,"✓")+"  "+dim("Default model: ")+tc(C.WHITE+C.BOLD,model_name)); print()

    print(dim("  "+"─"*(_term_width()-4))); print()
    print(tc(C.TEAL+C.BOLD,"  OPTIONAL EXTRAS")); print()
    print(dim("  Semantic document search:")); print(); print(tc(C.TEAL,"  pip install sentence-transformers")); print()
    print(dim("  Word, Excel, PowerPoint, Outlook support:")); print(); print(tc(C.TEAL,"  pip install python-docx openpyxl python-pptx extract-msg pymupdf")); print()

    config={"company_name":company,"providers":{provider:api_key},
            "active_model":{"provider":provider,"model_id":model_id},
            "max_tokens":1000,"onboarded":True,"onboarded_at":_now_iso()}
    USER_DIR.mkdir(parents=True,exist_ok=True)
    with open(CONFIG_FILE,"w",encoding="utf-8") as f: json.dump(config,f,indent=2)

    print(); print(box_top("YOU'RE ALL SET"))
    print(box_row(tc(C.GREEN+C.BOLD,"✓  TavernOS is ready.")))
    print(box_row(dim("Config saved to: ")+tc(C.WHITE,str(CONFIG_FILE))))
    print(box_divider())
    print(box_row(dim("Start by typing what you need — Sam will handle the rest.")))
    print(box_row(dim("Type ")+tbc("/help")+dim(" to see all commands.")))
    print(box_bottom()); print()
    return config


# ═══════════════════════════════════════════════════════════════════════════════
#  PERFORMANCE SCORING
# ═══════════════════════════════════════════════════════════════════════════════

def _perf_db_path():        return client_memory_dir()/"skill_performance.db"
def _feedback_db_path():    return client_memory_dir()/"feedback.db"
def _perf_global_db_path(): return USER_DIR/"skill_performance_global.db"

SCORE_SYSTEM="""You are a silent quality evaluator for TavernOS agent responses.
Return ONLY valid JSON:
{"clarity":<1-5>,"completeness":<1-5>,"relevance":<1-5>,"notes":"<one sentence>"}
Scoring: 5=Excellent 4=Good 3=Adequate 2=Weak 1=Poor"""

def perf_db_init():
    client_memory_dir().mkdir(parents=True,exist_ok=True)
    con=sqlite3.connect(_perf_db_path())
    con.execute("""CREATE TABLE IF NOT EXISTS skill_usage (
        id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL,
        agent TEXT, skill TEXT, task TEXT, response TEXT,
        clarity REAL, completeness REAL, relevance REAL, avg_score REAL, notes TEXT)""")
    con.execute("""CREATE TABLE IF NOT EXISTS skill_summary (
        agent TEXT, skill TEXT, invocations INTEGER DEFAULT 0,
        avg_clarity REAL DEFAULT 0, avg_completeness REAL DEFAULT 0,
        avg_relevance REAL DEFAULT 0, avg_score REAL DEFAULT 0, last_used TEXT,
        PRIMARY KEY (agent, skill))""")
    con.commit(); con.close()
    # Pack 0 Phase 5 — global aggregate db at USER_DIR level
    USER_DIR.mkdir(parents=True,exist_ok=True)
    gcon=sqlite3.connect(_perf_global_db_path())
    gcon.execute("""CREATE TABLE IF NOT EXISTS skill_usage (
        id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, client_slug TEXT,
        agent TEXT, skill TEXT, task TEXT, response TEXT,
        clarity REAL, completeness REAL, relevance REAL, avg_score REAL, notes TEXT)""")
    gcon.execute("""CREATE TABLE IF NOT EXISTS skill_summary (
        client_slug TEXT, agent TEXT, skill TEXT, invocations INTEGER DEFAULT 0,
        avg_clarity REAL DEFAULT 0, avg_completeness REAL DEFAULT 0,
        avg_relevance REAL DEFAULT 0, avg_score REAL DEFAULT 0, last_used TEXT,
        PRIMARY KEY (client_slug, agent, skill))""")
    gcon.commit(); gcon.close()
    # Phase 3 — evaluator DB tables (deliverable_scores + deliverable_calibration).
    # Idempotent migration; existing tables untouched. Silent no-op if the
    # evaluator module couldn't be imported.
    if _evaluator is not None:
        try: _evaluator.eval_db_init(_perf_db_path(), _perf_global_db_path())
        except Exception as _ee: _log_error("eval_db_init_failed", error=str(_ee))

def _perf_score(client,provider,model_id,agent,skill,task,response):
    prompt="AGENT: "+agent+"\nSKILL: "+(skill or "general")+"\n\nTASK:\n"+task[:800]+"\n\nRESPONSE:\n"+response[:2000]
    try:
        if provider=="anthropic":
            r=client.messages.create(model=model_id,max_tokens=200,system=SCORE_SYSTEM,messages=[{"role":"user","content":prompt}])
            raw=r.content[0].text.strip()
        else:
            r=client.chat.completions.create(model=model_id,max_tokens=200,messages=[{"role":"system","content":SCORE_SYSTEM},{"role":"user","content":prompt}])
            raw=r.choices[0].message.content.strip()
        raw=re.sub(r"^```[a-z]*\n?","",raw); raw=re.sub(r"\n?```$","",raw)
        return json.loads(raw)
    except Exception: return {"clarity":3,"completeness":3,"relevance":3,"notes":"scoring unavailable"}

def _perf_save(agent,skill,task,response,scores):
    avg=round((scores.get("clarity",3)+scores.get("completeness",3)+scores.get("relevance",3))/3,2)
    con=sqlite3.connect(_perf_db_path())
    con.execute("""INSERT INTO skill_usage (ts,agent,skill,task,response,clarity,completeness,relevance,avg_score,notes)
        VALUES (?,?,?,?,?,?,?,?,?,?)""",
        (_now_iso(),agent,skill or "general",task[:500],response[:500],
         scores.get("clarity",3),scores.get("completeness",3),scores.get("relevance",3),avg,scores.get("notes","")))
    con.execute("DELETE FROM skill_usage WHERE id NOT IN (SELECT id FROM skill_usage ORDER BY id DESC LIMIT 1000)")
    existing=con.execute("SELECT invocations,avg_clarity,avg_completeness,avg_relevance,avg_score FROM skill_summary WHERE agent=? AND skill=?",(agent,skill or "general")).fetchone()
    if existing:
        n=existing[0]; n1=n+1
        con.execute("""UPDATE skill_summary SET invocations=?,avg_clarity=?,avg_completeness=?,avg_relevance=?,avg_score=?,last_used=? WHERE agent=? AND skill=?""",
            (n1,round((existing[1]*n+scores.get("clarity",3))/n1,2),round((existing[2]*n+scores.get("completeness",3))/n1,2),
             round((existing[3]*n+scores.get("relevance",3))/n1,2),round((existing[4]*n+avg)/n1,2),_now_iso(),agent,skill or "general"))
    else:
        con.execute("""INSERT INTO skill_summary (agent,skill,invocations,avg_clarity,avg_completeness,avg_relevance,avg_score,last_used) VALUES (?,?,1,?,?,?,?,?)""",
            (agent,skill or "general",scores.get("clarity",3),scores.get("completeness",3),scores.get("relevance",3),avg,_now_iso()))
    con.commit(); con.close()

    # Pack 0 Phase 5 — dual-write to global aggregate (tagged with client_slug)
    try:
        slug = get_active_client_slug()
        gcon=sqlite3.connect(_perf_global_db_path())
        gcon.execute("""INSERT INTO skill_usage (ts,client_slug,agent,skill,task,response,clarity,completeness,relevance,avg_score,notes)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (_now_iso(),slug,agent,skill or "general",task[:500],response[:500],
             scores.get("clarity",3),scores.get("completeness",3),scores.get("relevance",3),avg,scores.get("notes","")))
        gcon.execute("DELETE FROM skill_usage WHERE id NOT IN (SELECT id FROM skill_usage ORDER BY id DESC LIMIT 5000)")
        gexist=gcon.execute("SELECT invocations,avg_clarity,avg_completeness,avg_relevance,avg_score FROM skill_summary WHERE client_slug=? AND agent=? AND skill=?",(slug,agent,skill or "general")).fetchone()
        if gexist:
            n=gexist[0]; n1=n+1
            gcon.execute("""UPDATE skill_summary SET invocations=?,avg_clarity=?,avg_completeness=?,avg_relevance=?,avg_score=?,last_used=? WHERE client_slug=? AND agent=? AND skill=?""",
                (n1,round((gexist[1]*n+scores.get("clarity",3))/n1,2),round((gexist[2]*n+scores.get("completeness",3))/n1,2),
                 round((gexist[3]*n+scores.get("relevance",3))/n1,2),round((gexist[4]*n+avg)/n1,2),_now_iso(),slug,agent,skill or "general"))
        else:
            gcon.execute("""INSERT INTO skill_summary (client_slug,agent,skill,invocations,avg_clarity,avg_completeness,avg_relevance,avg_score,last_used) VALUES (?,?,?,1,?,?,?,?,?)""",
                (slug,agent,skill or "general",scores.get("clarity",3),scores.get("completeness",3),scores.get("relevance",3),avg,_now_iso()))
        gcon.commit(); gcon.close()
    except Exception: pass

def perf_score_async(client,provider,model_id,agent,skill,task,response):
    def _run():
        try: _perf_save(agent,skill,task,response,_perf_score(client,provider,model_id,agent,skill,task,response))
        except Exception: pass
    threading.Thread(target=_run,daemon=True).start()


# ═══════════════════════════════════════════════════════════════════════════════
#  FEEDBACK LOOP
# ═══════════════════════════════════════════════════════════════════════════════

def feedback_db_init():
    client_memory_dir().mkdir(parents=True,exist_ok=True)
    con=sqlite3.connect(_feedback_db_path())
    con.execute("""CREATE TABLE IF NOT EXISTS feedback (
        id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL,
        agent TEXT, task TEXT, response TEXT, rating INTEGER, note TEXT, company TEXT, posted INTEGER DEFAULT 0)""")
    con.commit(); con.close()

def feedback_save_local(agent,task,response,rating,note,company):
    con=sqlite3.connect(_feedback_db_path())
    cur=con.execute("INSERT INTO feedback (ts,agent,task,response,rating,note,company) VALUES (?,?,?,?,?,?,?)",
        (_now_iso(),agent,task[:500],response[:500],rating,note,company))
    row_id=cur.lastrowid; con.commit(); con.close(); return row_id

def feedback_mark_posted(row_id):
    con=sqlite3.connect(_feedback_db_path()); con.execute("UPDATE feedback SET posted=1 WHERE id=?",(row_id,)); con.commit(); con.close()

def feedback_post_to_railway(agent,task,response,rating,note,company):
    payload=json.dumps({"company":company,"agent":agent,"task":task[:500],"response":response[:500],"rating":rating,"note":note,"ts":_now_iso()}).encode("utf-8")
    try:
        req=urllib.request.Request(RAILWAY_URL+"/webhook/feedback",data=payload,
            headers={"Content-Type":"application/json","User-Agent":"TavernOS/0.1.0"},method="POST")
        with urllib.request.urlopen(req,timeout=6) as r: return r.status==200
    except Exception: return False

def feedback_post_async(agent,task,response,rating,note,company,row_id):
    def _run():
        if feedback_post_to_railway(agent,task,response,rating,note,company): feedback_mark_posted(row_id)
    threading.Thread(target=_run,daemon=True).start()

def handle_feedback(raw,history,agents,config):
    parts=raw.strip().split(maxsplit=2)
    if len(parts)<2:
        print(); print("  "+tc(C.AMBER,"Usage:")+"  /feedback <1-5> [optional note]")
        print("  "+dim("Example: /feedback 2 the proposal missed the pricing section")); print(); return
    try:
        rating=int(parts[1])
        if not 1<=rating<=5: raise ValueError
    except ValueError: print(); print("  "+tc(C.AMBER,"⚠")+"  Rating must be a number from 1 to 5."); print(); return
    note=parts[2].strip() if len(parts)>2 else ""
    if not history._pairs: print(); print("  "+dim("No recent response to give feedback on. Ask something first.")); print(); return
    last_user,last_assistant=history._pairs[-1]
    detected_agent="unknown"
    for name in AGENT_NAMES:
        agent_obj=agents.get(name,{}); agent_name=agent_obj.get("name",name).lower()
        if agent_name in last_assistant.lower()[:300]: detected_agent=agent_obj.get("name",name.title()); break
    stars="★"*rating+"☆"*(5-rating)
    star_color=C.GREEN if rating>=4 else (C.AMBER if rating==3 else C.RED)
    print(); print(box_top("FEEDBACK LOGGED"))
    print(box_row(tc(star_color,stars)+"  "+dim(str(rating)+" / 5")))
    if detected_agent!="unknown": print(box_row(dim("Agent : ")+tc(C.WHITE,detected_agent)))
    print(box_row(dim("Task  : ")+_truncate(last_user,_box_width()-12)))
    if note: print(box_row(dim("Note  : ")+_truncate(note,_box_width()-12)))
    print(box_divider()); print(box_row(dim("Saved locally · posting to TavernOS in background…"))); print(box_bottom()); print()
    company=config.get("company_name","unknown")
    row_id=feedback_save_local(detected_agent,last_user,last_assistant,rating,note,company)
    feedback_post_async(detected_agent,last_user,last_assistant,rating,note,company,row_id)


# ═══════════════════════════════════════════════════════════════════════════════
#  SEMANTIC SEARCH
# ═══════════════════════════════════════════════════════════════════════════════

def _vector_db_path(): return client_memory_dir()/"vectors.db"
CHUNK_SIZE=2048; CHUNK_OVERLAP=200
_embed_model=None; _embed_lock=threading.Lock()

def _get_embed_model():
    global _embed_model
    if _embed_model is not None: return _embed_model
    with _embed_lock:
        if _embed_model is not None: return _embed_model
        # Silence HF Hub warnings, tqdm progress bars, and the BertModel LOAD
        # REPORT by redirecting stdout/stderr during the model load. Logger-
        # and warning-based silencing is done in _silence_ml_noise() above;
        # this catches direct print/write-to-stderr output that slips past.
        import io, contextlib
        _err_buf, _out_buf = io.StringIO(), io.StringIO()
        try:
            with contextlib.redirect_stderr(_err_buf), contextlib.redirect_stdout(_out_buf):
                from sentence_transformers import SentenceTransformer
                _embed_model = SentenceTransformer("all-MiniLM-L6-v2")
            return _embed_model
        except Exception:
            # On failure, surface captured stderr so debugging is possible
            captured = _err_buf.getvalue()
            if captured:
                sys.stderr.write(captured)
            return None

def _vec_to_blob(vec): return struct.pack(f"{len(vec)}f",*vec)
def _blob_to_vec(blob): return list(struct.unpack(f"{len(blob)//4}f",blob))
def _cosine_sim(a,b): return max(-1.0,min(1.0,sum(x*y for x,y in zip(a,b))))

def vector_db_init():
    client_memory_dir().mkdir(parents=True,exist_ok=True)
    con=sqlite3.connect(_vector_db_path())
    con.execute("""CREATE TABLE IF NOT EXISTS chunks (
        id INTEGER PRIMARY KEY AUTOINCREMENT, file_path TEXT NOT NULL, file_name TEXT NOT NULL,
        chunk_idx INTEGER NOT NULL, text TEXT NOT NULL, embedding BLOB, indexed_at TEXT)""")
    con.execute("CREATE INDEX IF NOT EXISTS idx_chunks_path ON chunks(file_path)")
    con.commit(); con.close()

def _chunk_text(text):
    chunks=[]; start=0
    while start<len(text):
        end=start+CHUNK_SIZE; chunk=text[start:end]
        if chunk.strip(): chunks.append(chunk)
        if end>=len(text): break
        start=end-CHUNK_OVERLAP
    return chunks

def vector_index_file(file_path,file_name,content):
    def _run():
        try:
            model=_get_embed_model()
            if model is None: return
            chunks=_chunk_text(content)
            if not chunks: return
            con=sqlite3.connect(_vector_db_path())
            con.execute("DELETE FROM chunks WHERE file_path=?",(file_path,)); con.commit()
            embeddings=model.encode(chunks,normalize_embeddings=True,show_progress_bar=False)
            rows=[(file_path,file_name,i,chunk,_vec_to_blob(emb.tolist()),_now_iso()) for i,(chunk,emb) in enumerate(zip(chunks,embeddings))]
            con.executemany("INSERT INTO chunks (file_path,file_name,chunk_idx,text,embedding,indexed_at) VALUES (?,?,?,?,?,?)",rows)
            con.commit(); con.close()
        except Exception: pass
    threading.Thread(target=_run,daemon=True).start()

def vector_search(query,limit=5):
    model=_get_embed_model()
    if model is None: return []
    try:
        qv=model.encode(query,normalize_embeddings=True).tolist()
        con=sqlite3.connect(_vector_db_path())
        rows=con.execute("SELECT file_path,file_name,chunk_idx,text,embedding FROM chunks WHERE embedding IS NOT NULL").fetchall()
        con.close()
        if not rows: return []
        scored=[{"path":r[0],"name":r[1],"chunk_idx":r[2],"text":r[3],"score":_cosine_sim(qv,_blob_to_vec(r[4])),"source":"semantic"} for r in rows if r[4]]
        scored.sort(key=lambda x:x["score"],reverse=True); return scored[:limit]
    except Exception: return []

def merge_search_results(fts,semantic,limit=6):
    seen=set(); merged=[]; sem_paths={r["path"] for r in semantic}
    for r in fts:
        if r["path"] not in seen: seen.add(r["path"]); r["boosted"]=r["path"] in sem_paths; merged.append(r)
    for r in semantic:
        if r["path"] not in seen: seen.add(r["path"]); r["boosted"]=False; merged.append(r)
    merged.sort(key=lambda x:(not x.get("boosted",False),-x.get("score",0))); return merged[:limit]

def semantic_available(): return _get_embed_model() is not None


# ═══════════════════════════════════════════════════════════════════════════════
#  SPLASH & HELP
# ═══════════════════════════════════════════════════════════════════════════════

def _splash():
    t=C.TEAL+C.BOLD; r=C.RESET; w=C.WHITE
    return ("\n"
        +t+"  ████████╗ █████╗ ██╗   ██╗███████╗██████╗ ███╗  ██╗ ██████╗ ███████╗"+r+"\n"
        +t+"     ██║   ██╔══██╗██║   ██║██╔════╝██╔══██╗████╗ ██║██╔═══██╗██╔════╝"+r+"\n"
        +t+"     ██║   ███████║██║   ██║█████╗  ██████╔╝██╔██╗██║██║   ██║███████╗"+r+"\n"
        +t+"     ██║   ██╔══██║╚██╗ ██╔╝██╔══╝  ██╔══██╗██║╚████║██║   ██║╚════██║"+r+"\n"
        +t+"     ██║   ██║  ██║ ╚████╔╝ ███████╗██║  ██║██║ ╚███║╚██████╔╝███████║"+r+"\n"
        +t+"     ╚═╝   ╚═╝  ╚═╝  ╚═══╝  ╚══════╝╚═╝  ╚═╝╚═╝  ╚══╝ ╚═════╝ ╚══════╝"+r+"\n")

def _build_help(mode):
    T=C.TEAL; B=C.BOLD; R=C.RESET; G=C.GRAY+C.DIM; pipe=T+"║"+R
    def cmd(c,desc,feature=""):
        if feature and not mode_allows(mode,feature): return ""
        return pipe+"  "+T+c+R+"  "+G+desc+R+"\n"
    out =T+B+"╔══ TAVERNOS COMMAND REFERENCE ══════════════════════════════════╗"+R+"\n"
    out+=pipe+"\n"
    out+=pipe+"  "+T+B+"NATURAL LANGUAGE"+R+"\n"
    out+=pipe+"  "+G+"Just type what you need — Sam routes it to the right regular."+R+"\n"
    out+=pipe+"\n"
    out+=pipe+"  "+T+B+"AGENTS"+R+"\n"
    out+=cmd("/sam     ","Chief of Staff & orchestrator")
    out+=cmd("/norm    ","Cornerstone regular — reliable fallback")
    out+=cmd("/coach   ","Meetings, PRDs, requirements")
    out+=cmd("/carla   ","QA, code review, ruthless editing")
    out+=cmd("/woody   ","Proposals, content, documentation")
    out+=cmd("/cliff   ","Research, analysis, files + live web search 🌐")
    out+=cmd("/frasier ","Strategy, architecture, planning")
    out+=cmd("/rebecca ","Excel, slide decks, data visualization")
    out+=pipe+"\n"
    out+=pipe+"  "+T+B+"FILES — mention a path and the task"+R+"\n"
    out+=pipe+"  "+G+"Supported: .txt .md .pdf .docx .xlsx .pptx .msg .eml"+R+"\n"
    out+=cmd("search <query>          ","Search files (keyword + semantic)")
    out+=cmd("/files                  ","List all ingested files")
    out+=pipe+"\n"
    out+=pipe+"  "+T+B+"SESSION"+R+"\n"
    out+=cmd("/history                ","Show conversation history")
    out+=cmd("/clear                  ","Clear conversation history")
    out+=cmd("/feedback <1-5> [note]  ","Rate the last response")
    out+=pipe+"\n"
    if mode_allows(mode,"scores"):
        out+=pipe+"  "+T+B+"PERFORMANCE"+R+"\n"
        out+=cmd("/scores                 ","Show skill performance (current client)","scores")
        out+=cmd("/scores --global        ","Cross-client aggregate with per-client rows","scores")
        out+=cmd("/scores --deliverables  ","Show rubric scores for recent artifacts","scores")
        out+=cmd("/eval                   ","Show full critique for the most recent scored deliverable","scores")
        out+=cmd("/eval <filename>        ","Show full critique for a specific deliverable","scores")
        out+=cmd("/eval calibrate         ","Rate a scored deliverable manually (operator calibration)","scores")
        out+=cmd("/eval calibration       ","Show drift between operator ratings and MBR scores","scores")
        out+=cmd("/eval mode [async|sync] ","Get or set eval mode (sync enables auto-regen)","scores")
        out+=pipe+"\n"
    out+=pipe+"  "+T+B+"CLIENTS"+R+"\n"
    out+=cmd("/who                    ","One-line reminder of active workspace")
    out+=cmd("/client                 ","Show info on current client")
    out+=cmd("/client summary         ","Dashboard view — deliverables, activity, skills")
    out+=cmd("/client list            ","Table of all clients (active + archived)")
    out+=cmd("/client new             ","Create a new client workspace")
    out+=cmd("/client switch <slug>   ","Change active workspace")
    out+=cmd("/client edit            ","Open current client.json in editor")
    out+=cmd("/client archive <slug>  ","Soft-delete — move to _archived/")
    out+=cmd("/client restore <slug>  ","Restore from _archived/")
    out+=cmd("/client deliver         ","List this client's deliverables")
    out+=cmd("/client package         ","Zip current workspace for handoff")
    out+=pipe+"\n"
    out+=pipe+"  "+T+B+"NOTES"+R+"\n"
    out+=cmd("/note <text>            ","Jot a timestamped note into this client's notes/")
    out+=cmd("/notes                  ","Show all operator notes for this client")
    out+=pipe+"\n"
    out+=pipe+"  "+T+B+"DELIVERABLES"+R+"\n"
    out+=cmd("/save <cat> <file.md>   ","Save last response — cat: audits/blueprints/content/reports")
    out+=cmd("/export conversation    ","Save full chat history as Markdown → deliverables/reports/")
    out+=pipe+"\n"
    out+=pipe+"  "+T+B+"MODELS"+R+"\n"
    out+=cmd("/model                  ","Interactive model selector (newest first)")
    out+=cmd("/model list             ","List all available models")
    out+=cmd("/provider add           ","Add a new API key/provider")
    out+=pipe+"\n"
    out+=pipe+"  "+T+B+"SKILLS & UPDATES"+R+"\n"
    out+=cmd("/skill list             ","List installed skills")
    out+=cmd("/skill search <q>       ","Search registry for skills")
    out+=cmd("/skill install <s>      ","Install from registry")
    out+=cmd("/update                 ","Pull latest from registry","update")
    out+=pipe+"\n"
    out+=pipe+"  "+T+B+"MCP TOOLS"+R+"\n"
    out+=cmd("/mcp                    ","List configured MCP servers and status")
    out+=cmd("/mcp add                ","Interactive — add a new MCP server")
    out+=cmd("/mcp remove <n>         ","Remove a configured server")
    out+=cmd("/mcp tools              ","List tools available from connected servers")
    out+=cmd("/mcp restart            ","Tear down and respawn configured servers")
    out+=pipe+"\n"
    out+=pipe+"  "+T+B+"OTHER"+R+"\n"
    out+=cmd("grill me <idea>         ","Ruthless critique from Carla")
    out+=cmd("/help                   ","Show this reference card")
    out+=cmd("exit                    ","Close the tavern")
    out+=T+B+"╚════════════════════════════════════════════════════════════════╝"+R
    return out


# ═══════════════════════════════════════════════════════════════════════════════
#  CONVERSATION HISTORY
# ═══════════════════════════════════════════════════════════════════════════════

class ConversationHistory:
    def __init__(self,max_pairs=MAX_HISTORY):
        self._pairs=[]; self._max_pairs=max_pairs; self._pending_user=""
    def add_user(self,msg): self._pending_user=msg
    def add_assistant(self,msg):
        if self._pending_user:
            self._pairs.append((self._pending_user,msg))
            if len(self._pairs)>self._max_pairs: self._pairs=self._pairs[-self._max_pairs:]
            self._pending_user=""
    def to_messages(self):
        msgs=[]
        for u,a in self._pairs: msgs.append({"role":"user","content":u}); msgs.append({"role":"assistant","content":a})
        return msgs
    def clear(self): self._pairs=[]; self._pending_user=""
    def display(self):
        if not self._pairs: print("  "+dim("No conversation history yet.")); return
        print(); print(box_top("CONVERSATION HISTORY"))
        for i,(u,a) in enumerate(self._pairs,1):
            print(box_row(tc(C.TEAL,str(i))+". "+dim("You: ")+tc(C.WHITE,_truncate(u,_box_width()-12))))
            print(box_row("   "+dim("→  ")+_truncate(a.replace("\n"," "),_box_width()-8)))
        print(box_bottom()); print()


# ═══════════════════════════════════════════════════════════════════════════════
#  CONFIG
# ═══════════════════════════════════════════════════════════════════════════════

def _config_file_for_mode(mode): return STAGING_CONFIG_FILE if mode==Mode.STAGING else CONFIG_FILE

def load_config(mode=Mode.CUSTOMER):
    config_path=_config_file_for_mode(mode)
    if not config_path.exists():
        if mode==Mode.STAGING and CONFIG_FILE.exists():
            with open(CONFIG_FILE,"r",encoding="utf-8") as f: base=json.load(f)
            staging=dict(base); staging.pop("registry_token",None)
            staging["company_name"]=staging.get("company_name","TavernOS")+" (staging)"; return staging
        return {}
    with open(config_path,"r",encoding="utf-8") as f: return json.load(f)

def save_config(config,mode=Mode.CUSTOMER):
    config_path=_config_file_for_mode(mode); USER_DIR.mkdir(parents=True,exist_ok=True)
    with open(config_path,"w",encoding="utf-8") as f: json.dump(config,f,indent=2)

def migrate_config(config,mode=Mode.CUSTOMER):
    if "api_key" in config and "providers" not in config:
        old_key=config.pop("api_key"); config["providers"]={"anthropic":old_key}
        if "model" in config: config["active_model"]={"provider":"anthropic","model_id":config.pop("model")}
        save_config(config,mode)
    return config

def get_providers(config):
    if "providers" in config: return config["providers"]
    if "api_key"   in config: return {"anthropic":config["api_key"]}
    return {}

def get_active_model(config):
    active=config.get("active_model",{})
    if active: return active.get("provider","anthropic"),active.get("model_id","claude-opus-4-5")
    return "anthropic",config.get("model","claude-opus-4-5")

def set_active_model(config,provider,model_id,save=False,mode=Mode.CUSTOMER):
    config["active_model"]={"provider":provider,"model_id":model_id}
    if save: save_config(config,mode)

def get_registry_token(config): return config.get("registry_token","")
def get_customer_registry_token(config): return config.get(CUSTOMER_TOKEN_KEY,"") or config.get("registry_token","")

def create_staging_config(dev_config):
    staging={"company_name":dev_config.get("company_name","TavernOS"),"providers":dev_config.get("providers",{}),
              "active_model":dev_config.get("active_model",{"provider":"anthropic","model_id":"claude-opus-4-5"}),
              "max_tokens":dev_config.get("max_tokens",1000),"onboarded":True,
              CUSTOMER_TOKEN_KEY:dev_config.get(CUSTOMER_TOKEN_KEY,"")}
    save_config(staging,Mode.STAGING); return staging


# ═══════════════════════════════════════════════════════════════════════════════
#  SQLITE MEMORY
# ═══════════════════════════════════════════════════════════════════════════════

def _memory_db_path(): return client_memory_dir()/"tavern_memory.db"

def memory_init():
    client_memory_dir().mkdir(parents=True,exist_ok=True)
    con=sqlite3.connect(_memory_db_path())
    con.execute("""CREATE TABLE IF NOT EXISTS conversations (
        id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, input TEXT, intent TEXT, agents TEXT, outcome TEXT)""")
    con.execute("""CREATE TABLE IF NOT EXISTS files (
        path TEXT PRIMARY KEY, name TEXT, type TEXT, word_count INTEGER, page_count INTEGER,
        content TEXT, preview TEXT, toc TEXT, indexed_at TEXT, file_mtime REAL)""")
    try: con.execute("ALTER TABLE files ADD COLUMN file_mtime REAL")
    except Exception: pass
    try: con.execute("CREATE VIRTUAL TABLE IF NOT EXISTS files_fts USING fts5(path,name,content,tokenize='porter ascii')")
    except Exception: pass
    con.commit(); con.close()

def memory_save_conversation(input_text,intent="",agents=None):
    con=sqlite3.connect(_memory_db_path())
    con.execute("INSERT INTO conversations (ts,input,intent,agents) VALUES (?,?,?,?)",(_now_iso(),input_text,intent,json.dumps(agents or [])))
    con.execute("DELETE FROM conversations WHERE id NOT IN (SELECT id FROM conversations ORDER BY id DESC LIMIT 100)")
    con.commit(); con.close()

def memory_save_file(data):
    con=sqlite3.connect(_memory_db_path())
    con.execute("""INSERT OR REPLACE INTO files (path,name,type,word_count,page_count,content,preview,toc,indexed_at,file_mtime) VALUES (?,?,?,?,?,?,?,?,?,?)""",
        (data["path"],data["name"],data["type"],data.get("word_count",0),data.get("page_count",0),
         data.get("content",""),data.get("preview",""),json.dumps(data.get("toc",[])),_now_iso(),data.get("file_mtime",0)))
    try:
        con.execute("DELETE FROM files_fts WHERE path=?",(data["path"],))
        con.execute("INSERT INTO files_fts (path,name,content) VALUES (?,?,?)",(data["path"],data["name"],data.get("content","")))
    except Exception: pass
    con.commit(); con.close()

def memory_get_file_record(path):
    con=sqlite3.connect(_memory_db_path())
    row=con.execute("SELECT path,name,type,word_count,page_count,content,preview,toc,indexed_at,file_mtime FROM files WHERE path=?",(path,)).fetchone()
    con.close()
    if not row: return None
    return {"path":row[0],"name":row[1],"type":row[2],"word_count":row[3],"page_count":row[4],
            "content":row[5],"preview":row[6],"toc":json.loads(row[7] or "[]"),"indexed_at":row[8],"file_mtime":row[9]}

def memory_fts_search(query,limit=5):
    con=sqlite3.connect(_memory_db_path())
    try:
        rows=con.execute("""SELECT f.path,f.name,f.type,f.word_count,f.page_count,snippet(files_fts,2,'[',']','...',20)
            FROM files_fts JOIN files f ON files_fts.path=f.path WHERE files_fts MATCH ? ORDER BY rank LIMIT ?""",(query,limit)).fetchall()
        con.close()
        return [{"path":r[0],"name":r[1],"type":r[2],"word_count":r[3],"page_count":r[4],"excerpt":r[5],"source":"keyword"} for r in rows]
    except Exception: con.close(); return []

def memory_search_files(query,limit=6):
    fts=memory_fts_search(query,limit=limit); sem=vector_search(query,limit=limit)
    if not sem: return fts
    return merge_search_results(fts,sem,limit=limit)

def memory_list_files():
    con=sqlite3.connect(_memory_db_path())
    rows=con.execute("SELECT path,name,type,word_count,page_count,indexed_at FROM files ORDER BY indexed_at DESC").fetchall()
    con.close()
    return [{"path":r[0],"name":r[1],"type":r[2],"word_count":r[3],"page_count":r[4],"indexed_at":r[5]} for r in rows]

def memory_build_file_context(query=""):
    files=memory_list_files()
    if not files: return ""
    context="\n\nINGESTED DOCUMENTS IN MEMORY:\n"
    if query:
        results=memory_search_files(query,limit=3)
        if results:
            context+="\nRelevant sections for this query:\n"
            for r in results:
                excerpt=r.get("text","") or r.get("excerpt","")
                source="🔍" if r.get("source")=="semantic" else "🔤"
                context+="\n--- "+r["name"]+" "+source+" ---\n"+excerpt+"\n"
            context+="\nAll available files: "+", ".join(f["name"] for f in files); return context
    for f in files[:3]:
        rec=memory_get_file_record(f["path"])
        if rec:
            pages=str(f["page_count"])+" pages" if f.get("page_count") else str(f["word_count"])+" words"
            context+="\n--- "+f["name"]+" ("+pages+") ---\n"+(rec.get("content") or "")[:6000]+"\n[end excerpt]\n"
    if len(files)>3: context+="\n... and "+str(len(files)-3)+" more files. Use: search <query> to find specific content."
    return context


# ═══════════════════════════════════════════════════════════════════════════════
#  FILE INGESTION
# ═══════════════════════════════════════════════════════════════════════════════

def extract_file_paths(raw_input):
    found=[]
    pat=re.compile(r'(?:"([^"]+\.[a-zA-Z]{2,5})"'
        r'|([A-Za-z]:\\[^\s,;]+\.[a-zA-Z]{2,5})'
        r'|(/[^\s,;]+\.[a-zA-Z]{2,5})'
        r'|(\./[^\s,;]+\.[a-zA-Z]{2,5})'
        r'|(\b[\w\-\.]+\.(?:'+'|'.join(e.lstrip('.') for e in SUPPORTED_EXT)+r')\b))')
    for match in pat.finditer(raw_input):
        raw_path=next(g for g in match.groups() if g)
        p=Path(raw_path.strip('"\''))
        if p.suffix.lower() in SUPPORTED_EXT and p not in found: found.append(p)
    return found

def check_already_ingested(file_path):
    rec=memory_get_file_record(str(file_path))
    if not rec: return False,None
    if not file_path.exists(): return True,rec
    mtime=file_path.stat().st_mtime; stored=rec.get("file_mtime",0)
    if stored and abs(mtime-stored)<1.0: return True,rec
    return False,None

def prompt_use_cached(file_path,rec):
    indexed_at=rec.get("indexed_at","unknown")[:10]
    print(); print(box_top("FILE ALREADY INDEXED"))
    print(box_row(tc(C.WHITE,file_path.name)+"  "+dim("last indexed "+indexed_at)))
    print(box_row(dim("File has not been modified since then.")))
    print(box_divider()); print(box_row("Use cached version? "+tc(C.TEAL,"[y]")+" yes  "+tc(C.TEAL,"[n]")+" re-index now")); print(box_bottom())
    try: answer=input(tc(C.TEAL,"❯")+" ").strip().lower()
    except (EOFError,KeyboardInterrupt): answer="y"
    return answer!="n"

def _extract_docx(fp):
    try: from docx import Document
    except ImportError: return {"error":"python-docx not installed. Run: pip install python-docx"}
    doc=Document(str(fp)); headings=[]; tables=[]; paragraphs=[]
    for para in doc.paragraphs:
        if para.style.name.startswith("Heading"):
            lv=int(para.style.name.split()[-1]) if para.style.name.split()[-1].isdigit() else 1
            if para.text.strip(): headings.append({"level":lv,"title":para.text.strip()})
        if para.text.strip(): paragraphs.append(para.text.strip())
    for i,table in enumerate(doc.tables):
        rows=[[c.text.strip() for c in r.cells] for r in table.rows if any(c.text.strip() for c in r.cells)]
        if rows: tables.append({"table":i+1,"rows":rows})
    content="\n\n".join(paragraphs)
    for t in tables: content+="\n\n[TABLE "+str(t["table"])+"]\n"+"\n".join(" | ".join(r) for r in t["rows"])
    return {"content":content[:100000],"preview":"\n".join(paragraphs[:15]),"toc":headings,
            "word_count":len(content.split()),"page_count":0,"extra":{"tables":len(tables),"paragraphs":len(paragraphs)}}

def _extract_xlsx(fp):
    try: import openpyxl
    except ImportError: return {"error":"openpyxl not installed. Run: pip install openpyxl"}
    wb=openpyxl.load_workbook(str(fp),read_only=True,data_only=True)
    sheets=[]; content=""; toc=[]
    for sname in wb.sheetnames:
        ws=wb[sname]
        rows=[[str(c) if c is not None else "" for c in row] for row in ws.iter_rows(max_row=1000,values_only=True) if any(c is not None for c in row)]
        if not rows: continue
        sheets.append({"name":sname,"rows":len(rows),"cols":len(rows[0])}); toc.append({"level":1,"title":sname+" ("+str(len(rows))+" rows)"})
        content+="\n\n[SHEET: "+sname+"]\n"
        if rows:
            content+=" | ".join(rows[0])+"\n"+"-"*40+"\n"
            for row in rows[1:51]: content+=" | ".join(row)+"\n"
            if len(rows)>51: content+="... ("+str(len(rows)-51)+" more rows)\n"
    wb.close()
    return {"content":content[:100000],"preview":content[:1000],"toc":toc,"word_count":len(content.split()),"page_count":len(sheets),"extra":{"sheets":sheets}}

def _extract_pptx(fp):
    try: from pptx import Presentation
    except ImportError: return {"error":"python-pptx not installed. Run: pip install python-pptx"}
    prs=Presentation(str(fp)); slides=[]; toc=[]; content=""
    for i,slide in enumerate(prs.slides,1):
        title=""; body=[]; notes=""
        for shape in slide.shapes:
            if shape.has_text_frame:
                if shape.shape_type==13: title=shape.text_frame.text.strip()
                else:
                    for para in shape.text_frame.paragraphs:
                        if para.text.strip(): body.append(para.text.strip())
        if slide.has_notes_slide:
            nf=slide.notes_slide.notes_text_frame
            if nf: notes=nf.text.strip()
        slides.append({"slide":i,"title":title,"body":body,"notes":notes})
        if title: toc.append({"level":1,"title":"Slide "+str(i)+": "+title})
        content+="\n\n[SLIDE "+str(i)+"]"+(" — "+title if title else "")+"\n"
        if body: content+="\n".join(body)+"\n"
        if notes: content+="[Notes: "+notes+"]\n"
    preview="\n".join("Slide "+str(s["slide"])+": "+(s["title"] or "(no title)") for s in slides[:10])
    return {"content":content[:100000],"preview":preview,"toc":toc,"word_count":len(content.split()),"page_count":len(slides),"extra":{"slides":len(slides)}}

def _extract_pdf(fp):
    try: import fitz
    except ImportError: return {"error":"pymupdf not installed. Run: pip install pymupdf"}
    doc=fitz.open(str(fp)); page_count=len(doc); all_text=[]; toc_entries=[]
    for level,title,page in doc.get_toc()[:15]: toc_entries.append({"level":level,"title":title,"page":page})
    for i in range(page_count):
        text=doc[i].get_text("text")
        if text.strip(): all_text.append("[Page "+str(i+1)+"]\n"+text.strip())
    doc.close(); full="\n\n".join(all_text); wc=len(full.split())
    stored=full[:100000]+("\n\n[… truncated]" if len(full)>100000 else "")
    return {"content":stored,"preview":"\n".join(all_text[:3])[:1500],"toc":toc_entries,"word_count":wc,"page_count":page_count,"extra":{}}

def _extract_msg(fp):
    try:
        import extract_msg; msg=extract_msg.Message(str(fp))
    except ImportError: return {"error":"extract-msg not installed. Run: pip install extract-msg"}
    except Exception as e: return {"error":"Could not open .msg: "+str(e)}
    sender=msg.sender or ""; subject=msg.subject or ""; body=msg.body or ""; date=str(msg.date) if msg.date else ""
    atts=[a.longFilename or a.shortFilename for a in msg.attachments if hasattr(a,'longFilename')]
    content="FROM: "+sender+"\nDATE: "+date+"\nSUBJECT: "+subject+"\n\n"+body
    if atts: content+="\n\nATTACHMENTS:\n"+"\n".join("  - "+a for a in atts if a)
    return {"content":content[:50000],"preview":"From: "+sender+"\nSubject: "+subject+"\n\n"+body[:500],
            "toc":[{"level":1,"title":"Subject: "+subject}],"word_count":len(content.split()),"page_count":0,
            "extra":{"sender":sender,"subject":subject,"attachments":len(atts)}}

def _extract_eml(fp):
    try:
        with open(str(fp),"rb") as f: msg=email_lib.message_from_bytes(f.read())
    except Exception as e: return {"error":"Could not read .eml: "+str(e)}
    sender=msg.get("From",""); subject=msg.get("Subject",""); date=msg.get("Date",""); body=""
    if msg.is_multipart():
        for part in msg.walk():
            if part.get_content_type()=="text/plain":
                try: body=part.get_payload(decode=True).decode("utf-8",errors="replace"); break
                except Exception: pass
    else:
        try: body=msg.get_payload(decode=True).decode("utf-8",errors="replace")
        except Exception: body=str(msg.get_payload())
    content="FROM: "+sender+"\nDATE: "+date+"\nSUBJECT: "+subject+"\n\n"+body
    return {"content":content[:50000],"preview":"From: "+sender+"\nSubject: "+subject+"\n\n"+body[:500],
            "toc":[{"level":1,"title":"Subject: "+subject}],"word_count":len(content.split()),"page_count":0,"extra":{"sender":sender,"subject":subject}}

def _extract_text(fp):
    try: content=fp.read_text(encoding="utf-8")
    except Exception as e: return {"error":"Could not read: "+str(e)}
    lines=content.splitlines(); toc=[]
    if fp.suffix.lower()==".md":
        for line in lines:
            if line.startswith("#"): lv=len(line)-len(line.lstrip("#")); toc.append({"level":lv,"title":line.lstrip("# ").strip()})
    return {"content":content[:100000],"preview":"\n".join(lines[:20]),"toc":toc,"word_count":len(content.split()),"page_count":0,"extra":{"lines":len(lines)}}

EXTRACTORS={".pdf":_extract_pdf,".docx":_extract_docx,".xlsx":_extract_xlsx,
            ".pptx":_extract_pptx,".msg":_extract_msg,".eml":_extract_eml,".txt":_extract_text,".md":_extract_text}

def ingest_file(file_path):
    ext=file_path.suffix.lower()
    if not file_path.exists(): print("  "+tc(C.RED,"✗")+" File not found: "+str(file_path)); return False
    if ext not in SUPPORTED_EXT: print("  "+tc(C.RED,"✗")+" Unsupported type: "+ext); return False
    is_cached,cached_rec=check_already_ingested(file_path)
    if is_cached and cached_rec:
        if prompt_use_cached(file_path,cached_rec): print("  "+tc(C.GREEN,"✓")+" Using cached version of "+tc(C.WHITE,file_path.name)); print(); return True
    icon=FILE_ICONS.get(ext,"📄"); label=FILE_TYPE_LABELS.get(ext,ext)
    print(); print("  "+tc(C.TEAL,icon)+" "+dim("Ingesting ")+tc(C.WHITE,file_path.name)+dim(" ("+label+")…"))
    extractor=EXTRACTORS.get(ext)
    if not extractor: print("  "+tc(C.RED,"✗")+" No extractor for "+ext); return False
    data=extractor(file_path)
    if "error" in data: print("  "+tc(C.RED,"✗")+" "+data["error"]); return False
    bw=_box_width(); print(box_top(label.upper()+" INDEXED"))
    print(box_row(dim("File")+"  : "+tc(C.WHITE,_truncate(file_path.name,bw-10))))
    print(box_row(dim("Path")+"  : "+_truncate(str(file_path),bw-10)))
    if ext==".pdf": print(box_row(dim("Pages")+" : "+tc(C.TEAL,str(data["page_count"]))+"   "+dim("Words")+": "+tc(C.TEAL,str(data["word_count"]))))
    elif ext==".xlsx":
        sheets=data.get("extra",{}).get("sheets",[])
        print(box_row(dim("Sheets")+": "+tc(C.TEAL,str(len(sheets)))+"   "+dim("Words")+": "+tc(C.TEAL,str(data["word_count"]))))
        for sh in sheets[:5]: print(box_row("  "+tc(C.TEAL,"◆")+" "+sh["name"]+"  "+dim(str(sh["rows"])+" rows × "+str(sh["cols"])+" cols")))
    elif ext==".pptx": print(box_row(dim("Slides")+": "+tc(C.TEAL,str(data["page_count"]))+"   "+dim("Words")+": "+tc(C.TEAL,str(data["word_count"]))))
    elif ext==".docx":
        extra=data.get("extra",{})
        print(box_row(dim("Paragraphs")+": "+tc(C.TEAL,str(extra.get("paragraphs",0)))+"   "+dim("Tables")+": "+tc(C.TEAL,str(extra.get("tables",0)))+"   "+dim("Words")+": "+tc(C.TEAL,str(data["word_count"]))))
    elif ext in (".msg",".eml"):
        extra=data.get("extra",{})
        print(box_row(dim("From")+"    : "+_truncate(extra.get("sender",""),bw-12)))
        print(box_row(dim("Subject")+" : "+_truncate(extra.get("subject",""),bw-12)))
    else: print(box_row(dim("Words")+": "+tc(C.TEAL,str(data["word_count"]))))
    if data.get("toc"):
        print(box_divider()); print(box_row(tbc("Structure")))
        for entry in data["toc"][:10]:
            indent="  "*(entry.get("level",1)-1); marker="◆" if entry.get("level",1)==1 else "▸"
            title=_truncate(entry.get("title",""),bw-6-len(indent))
            extra_info="  "+dim("p."+str(entry["page"])) if "page" in entry else ""
            print(box_row(indent+tc(C.TEAL,marker)+" "+title+extra_info))
        if len(data["toc"])>10: print(box_row(dim("… and "+str(len(data["toc"])-10)+" more")))
    print(box_divider()); print(box_row(tbc("Preview")))
    for line in data["preview"].splitlines()[:12]:
        if line.strip(): print(box_row(_truncate(line,bw)))
    print(box_bottom())
    file_mtime=file_path.stat().st_mtime
    memory_save_file({"path":str(file_path),"name":file_path.name,"type":ext,"word_count":data["word_count"],
        "page_count":data.get("page_count",0),"content":data["content"],"preview":data["preview"],
        "toc":data.get("toc",[]),"file_mtime":file_mtime})
    sem_status=" + semantic index" if semantic_available() else " (install sentence-transformers for semantic search)"
    if semantic_available(): vector_index_file(str(file_path),file_path.name,data["content"])
    print(); print("  "+tc(C.GREEN,"✓")+" "+tc(C.WHITE,file_path.name)+" indexed"+sem_status+".")
    print("  "+dim("Use: search <query> to find specific content.")); print(); return True

def handle_search(query):
    if not query: print("  Usage: search <your query>"); return
    results=memory_search_files(query)
    if not results:
        files=memory_list_files()
        if not files: print("  "+dim("No files in memory yet."))
        else: print("  "+dim("No results for '"+query+"'. Try different keywords."))
        return
    search_mode="keyword + semantic" if semantic_available() else "keyword"
    print(); print("  "+tbc("Search results for \""+query+"\"")+" "+dim("("+search_mode+")")); print()
    for r in results:
        icon=FILE_ICONS.get(r.get("type",""),"📄"); pages=str(r.get("page_count",""))+" pages" if r.get("page_count") else str(r.get("word_count",""))+" words"
        source_badge=tc(C.TEAL," 🔍") if r.get("source")=="semantic" else dim(" 🔤")
        boosted=tc(C.GREEN," ★") if r.get("boosted") else ""; excerpt=r.get("text","") or r.get("excerpt","")
        print("  "+icon+" "+tc(C.WHITE,r["name"])+source_badge+boosted+"  "+dim(pages))
        if excerpt: print("    "+dim(re.sub(r'\s+',' ',excerpt).strip()[:120]))
        print()

def list_files():
    files=memory_list_files()
    if not files: print("  "+dim("No files ingested yet.")); return
    try:
        con=sqlite3.connect(_vector_db_path()); vec_paths=set(r[0] for r in con.execute("SELECT DISTINCT file_path FROM chunks").fetchall()); con.close()
    except Exception: vec_paths=set()
    print(); print(box_top("FILES IN MEMORY"))
    for f in files:
        icon=FILE_ICONS.get(f["type"],"📄"); pages=str(f["page_count"])+" pages" if f.get("page_count") else str(f["word_count"])+" words"
        date=f["indexed_at"][:10] if f.get("indexed_at") else ""; sem_badge=tc(C.TEAL," 🔍") if f["path"] in vec_paths else dim(" 🔤")
        print(box_row(icon+" "+tc(C.WHITE,_truncate(f["name"],_box_width()-36))+"  "+dim(pages)+"  "+dim(date)+sem_badge))
    print(box_divider())
    legend="🔍 semantic+keyword  🔤 keyword only"
    if not semantic_available(): legend+="  —  pip install sentence-transformers for semantic search"
    print(box_row(dim(legend))); print(box_bottom()); print()

def show_scores(global_view: bool = False):
    if global_view:
        try:
            con=sqlite3.connect(_perf_global_db_path())
            rows=con.execute("SELECT client_slug,agent,skill,invocations,avg_score,last_used FROM skill_summary ORDER BY client_slug,invocations DESC").fetchall()
            con.close()
        except Exception: print("  "+dim("No global performance data yet.")); return
        if not rows: print("  "+dim("No global performance data yet.")); return
        print(); print(box_top("SKILL PERFORMANCE — ALL CLIENTS"))
        print(box_row(dim("Client").ljust(14)+dim("Agent").ljust(12)+dim("Skill").ljust(24)+dim("Uses").ljust(8)+dim("Avg Score"))); print(box_divider())
        for row in rows:
            score=row[4] or 0; sc=C.GREEN if score>=4 else (C.AMBER if score>=3 else C.RED)
            print(box_row(
                tc(C.TEAL,_truncate(row[0] or "?",12)).ljust(12)+"  "
                +_truncate(row[1] or "?",10).ljust(10)+"  "
                +_truncate(row[2] or "?",22).ljust(22)+"  "
                +str(row[3]).ljust(6)+"  "
                +tc(sc,str(round(score,1))+"/5")
            ))
        print(box_bottom()); print(); return
    try:
        con=sqlite3.connect(_perf_db_path()); rows=con.execute("SELECT agent,skill,invocations,avg_score,last_used FROM skill_summary ORDER BY invocations DESC").fetchall(); con.close()
    except Exception: print("  "+dim("No performance data yet.")); return
    if not rows: print("  "+dim("No performance data yet.")); return
    print(); print(box_top("SKILL PERFORMANCE — "+get_active_client_slug().upper()))
    print(box_row(dim("Agent").ljust(14)+dim("Skill").ljust(28)+dim("Uses").ljust(8)+dim("Avg Score"))); print(box_divider())
    for row in rows:
        score=row[3] or 0; sc=C.GREEN if score>=4 else (C.AMBER if score>=3 else C.RED)
        print(box_row(tc(C.TEAL,_truncate(row[0] or "?",12)).ljust(12)+"  "+_truncate(row[1] or "?",24).ljust(24)+"  "+str(row[2]).ljust(6)+"  "+tc(sc,str(round(score,1))+"/5")))
    print(box_bottom()); print()


def show_deliverable_scores(limit: int = 20):
    """Display recent rubric scores for artifact deliverables (xlsx, docx,
    pptx). Driven by evaluator.list_recent_scores — populated asynchronously
    after each deliverable saves. Empty state on a fresh install is normal;
    scores fill in as the operator produces work."""
    if _evaluator is None:
        print("  "+tc(C.AMBER,"⚠")+" Evaluator module unavailable. Scores are not being recorded.")
        if _evaluator_import_error: print("  "+dim("Import error: "+str(_evaluator_import_error)[:100]))
        return
    rows = _evaluator.list_recent_scores(_perf_db_path(), limit=limit)
    if not rows:
        print()
        print("  "+dim("No deliverable scores yet. Produce a scored deliverable"))
        print("  "+dim("with Rebecca or Woody, then check back."))
        print("  "+dim("(Evaluation runs asynchronously and may take ~10s after save.)"))
        print()
        return
    print(); print(box_top("DELIVERABLE SCORES — "+get_active_client_slug().upper()))
    print(box_row(dim("Agent").ljust(12)+dim("Type").ljust(22)+dim("Filename").ljust(28)+dim("Score").ljust(10)+dim("Status")))
    print(box_divider())
    for r in rows:
        score = r["weighted_avg"] or 0
        sc = C.GREEN if score >= 4.0 else (C.AMBER if score >= 3.0 else C.RED)
        status_str = tc(C.GREEN, "✓ pass") if r["pass_threshold"] else tc(C.AMBER, "⚠ below")
        if r["regen_attempts"] and r["regen_attempts"] > 0:
            status_str += dim(" (×" + str(r["regen_attempts"]) + ")")
        dtype = (r["deliverable_type"] or "?").replace("_", " ")
        print(box_row(
            _truncate(r["agent"] or "?", 10).ljust(10) + "  "
            + _truncate(dtype, 20).ljust(20) + "  "
            + _truncate(r["filename"] or "?", 26).ljust(26) + "  "
            + tc(sc, str(round(score, 1)) + "/5").ljust(14)
            + status_str
        ))
    print(box_bottom())
    print("  "+dim("Full critique for any row: ")+tc(C.TEAL, "/eval <filename>"))
    print()


def show_eval_detail(filename: str):
    """Render the full critique set for a specific scored deliverable.
    Accepts partial filenames — if the argument uniquely matches the tail
    of one scored deliverable, use it; if it matches multiple, show a hint."""
    if _evaluator is None:
        print("  "+tc(C.AMBER,"⚠")+" Evaluator module unavailable."); return
    # Exact match first
    row = _evaluator.get_score_by_filename(_perf_db_path(), filename)
    if row is None:
        # Fallback: fuzzy match over recent scores
        recent = _evaluator.list_recent_scores(_perf_db_path(), limit=50)
        matches = [r for r in recent if filename.lower() in (r["filename"] or "").lower()]
        if len(matches) == 1:
            row = _evaluator.get_score_by_filename(_perf_db_path(), matches[0]["filename"])
        elif len(matches) > 1:
            print("  "+dim("Multiple matches for '"+filename+"'. Choose one:"))
            for m in matches[:8]:
                print("    "+tc(C.TEAL,m["filename"]))
            return
    if row is None:
        print("  "+dim("No score found for '"+filename+"'.")); return

    print(); print(box_top("EVAL — "+(row["filename"] or "?").upper()))
    score = row["weighted_avg"] or 0
    sc = C.GREEN if score >= 4.0 else (C.AMBER if score >= 3.0 else C.RED)
    print(box_row(dim("Deliverable")+" : "+tc(C.WHITE, row["deliverable_type"] or "?")))
    print(box_row(dim("Agent      ")+" : "+tc(C.WHITE, row["agent"] or "?")))
    print(box_row(dim("Weighted   ")+" : "+tc(sc, str(round(score,2))+"/5")+"   "
                  +(tc(C.GREEN,"✓ pass") if row["pass_threshold"] else tc(C.AMBER,"⚠ below threshold"))))
    if row["regen_attempts"]:
        print(box_row(dim("Regens     ")+" : "+tc(C.WHITE, str(row["regen_attempts"]))))
    print(box_row(dim("Evaluator  ")+" : "+tc(C.WHITE, row["evaluator_model"] or "?")))
    print(box_divider())
    for dim_name, score_val in (row["scores"] or {}).items():
        dsc = C.GREEN if score_val >= 4.0 else (C.AMBER if score_val >= 3.0 else C.RED)
        print(box_row(tc(dsc, str(round(score_val,1))+"/5").ljust(8)+"  "+tbc(dim_name)))
        crit = (row["critiques"] or {}).get(dim_name, "")
        if crit:
            # Wrap long critiques at ~70 chars per line inside the box
            for chunk_start in range(0, len(crit), 70):
                print(box_row("          " + dim(crit[chunk_start:chunk_start+70])))
    if row["overall_critique"]:
        print(box_divider())
        print(box_row(dim("Overall: ")+tc(C.WHITE, row["overall_critique"])))
    print(box_bottom()); print()


# ═══════════════════════════════════════════════════════════════════════════════
#  CALIBRATION — operator manual rating flow (Phase 5, April 2026).
#
#  Writes via /eval calibrate [target], reads via /eval calibration.
#  Backing helpers live in evaluator.py alongside eval_db_init and
#  save_eval_result. See that module's CALIBRATION STORAGE section for the
#  schema + drift computation.
#
#  Flow is anchored and single-pass per operator decision Apr 22, 2026 —
#  MBR scores and per-dim critiques are shown while collecting operator
#  scores (keeps fatigue low, trades off against anchoring bias; blind-mode
#  flag is a v2 consideration if drift data looks suspiciously correlated).
# ═══════════════════════════════════════════════════════════════════════════════

def _parse_operator_score(raw: str) -> tuple[float | None, str | None]:
    """Parse operator score input. Returns (score, error_message). A None
    score with None error means 'skip this dim'; a None score with a non-None
    error means retry. Accepts 1.0-5.0 in 0.5 steps."""
    s = (raw or "").strip()
    if not s:
        return (None, None)  # skip
    try:
        val = float(s)
    except ValueError:
        return (None, "not a number")
    if val < 1.0 or val > 5.0:
        return (None, "must be 1.0 - 5.0")
    # Require 0.5 granularity
    if abs((val * 2) - round(val * 2)) > 1e-6:
        return (None, "use 0.5 steps (e.g. 3.5, 4.0)")
    return (round(val * 2) / 2, None)


def _show_calibration_picker(candidates: list[dict]) -> dict | None:
    """Numbered picker for /eval calibrate when multiple unrated candidates
    exist. Returns the selected candidate dict (has 'id', 'filename' etc.),
    or None if the operator quits."""
    print()
    print(box_top("UNRATED DELIVERABLES"))
    print(box_row(dim("#").ljust(4)
                  + dim("Type").ljust(22)
                  + dim("Filename").ljust(32)
                  + dim("MBR").ljust(10)
                  + dim("Status")))
    print(box_divider())
    for i, r in enumerate(candidates, 1):
        score = r.get("weighted_avg") or 0
        sc = C.GREEN if score >= 4.0 else (C.AMBER if score >= 3.0 else C.RED)
        status = tc(C.GREEN, "✓ pass") if r.get("pass_threshold") else tc(C.AMBER, "⚠ below")
        dtype = (r.get("deliverable_type") or "?").replace("_", " ")
        print(box_row(
            str(i).ljust(4)
            + _truncate(dtype, 20).ljust(22)
            + _truncate(r.get("filename") or "?", 30).ljust(32)
            + tc(sc, f"{round(score,1)}/5").ljust(14)
            + status
        ))
    print(box_bottom())
    while True:
        pick = input("  " + tc(C.TEAL,
                     f"Pick 1-{len(candidates)} (or q to quit): ")).strip().lower()
        if pick in ("q", "quit", "exit", ""):
            return None
        try:
            idx = int(pick)
            if 1 <= idx <= len(candidates):
                return candidates[idx - 1]
        except ValueError:
            pass
        print("  " + dim("Not a valid pick. Try again or 'q'."))


def _run_calibration_flow(score_row: dict) -> bool:
    """Single-pass anchored rating flow. Iterates rubric dims, shows MBR
    score + anchors + per-dim MBR critique, collects operator scores, then
    one free-text note, then a confirm-and-save screen. Returns True if a
    row was written to deliverable_calibration, False otherwise."""
    if _evaluator is None:
        print("  " + tc(C.AMBER, "⚠") + " Evaluator module unavailable.")
        return False

    dtype = score_row.get("deliverable_type") or ""
    rubric = _evaluator.RUBRICS.get(dtype)
    if rubric is None:
        print("  " + tc(C.AMBER, "⚠") + f" No rubric registered for '{dtype}'. "
              "Cannot calibrate this deliverable type.")
        return False

    mbr_scores = score_row.get("scores") or {}
    mbr_critiques = score_row.get("critiques") or {}
    wavg = score_row.get("weighted_avg") or 0

    # Header
    print()
    print(box_top("CALIBRATE — " + (score_row.get("filename") or "?").upper()))
    print(box_row(dim("Type       ") + " : "
                  + tc(C.WHITE, dtype.replace("_", " "))))
    print(box_row(dim("Agent      ") + " : "
                  + tc(C.WHITE, score_row.get("agent") or "?")))
    sc = C.GREEN if wavg >= 4.0 else (C.AMBER if wavg >= 3.0 else C.RED)
    print(box_row(dim("MBR wavg   ") + " : "
                  + tc(sc, f"{round(wavg, 2)}/5")))
    fp = score_row.get("filepath") or "?"
    print(box_row(dim("Filepath   ") + " : "
                  + tc(C.WHITE, _truncate(fp, 60))))
    print(box_row(dim("Evaluator  ") + " : "
                  + tc(C.WHITE, score_row.get("evaluator_model") or "?")))
    if score_row.get("overall_critique"):
        print(box_divider())
        crit = score_row["overall_critique"]
        first = True
        for s_off in range(0, len(crit), 70):
            chunk = crit[s_off:s_off+70]
            if first:
                print(box_row(dim("Overall: ") + chunk))
                first = False
            else:
                print(box_row("         " + dim(chunk)))
    print(box_bottom())
    print("  " + dim("Rate each dimension. Anchors 5/3/1 shown for reference. "
                     "Blank = skip."))
    print()

    # Per-dim prompts
    op_scores: dict[str, float] = {}
    for d in rubric.dimensions:
        mbr_score = mbr_scores.get(d.name)
        mbr_crit = (mbr_critiques.get(d.name) or "").strip()
        sc = (C.GREEN if (mbr_score or 0) >= 4.0
              else (C.AMBER if (mbr_score or 0) >= 3.0 else C.RED))
        print("  " + tbc(d.name) + dim(f"  (weight {d.weight:.2f})")
              + "   MBR: "
              + (tc(sc, f"{mbr_score:.1f}/5") if mbr_score is not None
                 else dim("n/a")))
        print("    " + dim("5: " + _truncate(d.anchor_5, 80)))
        print("    " + dim("3: " + _truncate(d.anchor_3, 80)))
        print("    " + dim("1: " + _truncate(d.anchor_1, 80)))
        if mbr_crit:
            print("    " + dim("MBR note: " + _truncate(mbr_crit, 90)))
        while True:
            raw = input("  " + tc(C.TEAL,
                        "your score [1.0-5.0, .5 steps, enter=skip]: "))
            val, err = _parse_operator_score(raw)
            if err is None:
                if val is not None:
                    op_scores[d.name] = val
                break
            print("    " + dim(err + ". Try again."))
        print()

    # Notes
    notes = input("  " + tc(C.TEAL,
                  "notes (one line, enter=skip): ")).strip()

    # Summary diff
    print()
    print(box_top("DIFF — OPERATOR vs MBR"))
    print(box_row(dim("Dim").ljust(28)
                  + dim("OP").ljust(8)
                  + dim("MBR").ljust(8)
                  + dim("Δ")))
    print(box_divider())
    for d in rubric.dimensions:
        op_v = op_scores.get(d.name)
        mbr_v = mbr_scores.get(d.name)
        op_s = f"{op_v:.1f}" if op_v is not None else "-"
        mbr_s = f"{mbr_v:.1f}" if mbr_v is not None else "-"
        if op_v is None or mbr_v is None:
            delta_s = dim("-")
        else:
            delta = op_v - mbr_v
            mag = abs(delta)
            dc = C.RED if mag >= 1.0 else (C.AMBER if mag >= 0.5 else C.GREEN)
            delta_s = tc(dc, f"{delta:+.1f}")
        print(box_row(_truncate(d.name, 26).ljust(28)
                      + op_s.ljust(8)
                      + mbr_s.ljust(8)
                      + delta_s))
    print(box_bottom())
    if notes:
        print("  " + dim("Note: ") + notes)

    # Confirm
    confirm = input("  " + tc(C.TEAL, "Save calibration? ")
                    + dim("(y/N): ")).strip().lower()
    if confirm not in ("y", "yes"):
        print("  " + dim("Cancelled. No row written."))
        return False

    # Save
    try:
        row_id = _evaluator.save_calibration(
            _perf_db_path(),
            deliverable_score_id=score_row["id"],
            operator_scores=op_scores,
            operator_notes=notes,
            evaluator_scores=mbr_scores,
        )
        print("  " + tc(C.GREEN, "✓") + f" Saved calibration #{row_id}.")
        return True
    except Exception as e:
        print("  " + tc(C.RED, "✗")
              + f" Save failed: {type(e).__name__}: {e}")
        return False


def handle_eval_calibrate(arg: str) -> None:
    """Dispatcher for /eval calibrate [target]. Target forms:
      (empty)      -> unrated-deliverables picker; auto-selects if N=1
      last         -> most recent scored deliverable regardless of rating
      <filename>   -> exact or fuzzy filename match (case-insensitive)
      #<id> | <id> -> direct lookup by deliverable_scores.id"""
    if _evaluator is None:
        print("  " + tc(C.AMBER, "⚠") + " Evaluator module unavailable.")
        return

    arg = (arg or "").strip()
    score_row: dict | None = None

    if arg == "":
        candidates = _evaluator.list_unrated_deliverables(_perf_db_path(), limit=10)
        if not candidates:
            print()
            print("  " + dim("No unrated deliverables. Everything recent has "
                             "a calibration row."))
            print("  " + dim("Re-rate a specific deliverable: ")
                  + tc(C.TEAL, "/eval calibrate <filename>"))
            print("  " + dim("Rate most recent regardless:    ")
                  + tc(C.TEAL, "/eval calibrate last"))
            print()
            return
        if len(candidates) == 1:
            score_row = _evaluator.get_deliverable_score_by_id(
                _perf_db_path(), candidates[0]["id"])
        else:
            picked = _show_calibration_picker(candidates)
            if picked is None:
                print("  " + dim("Cancelled."))
                return
            score_row = _evaluator.get_deliverable_score_by_id(
                _perf_db_path(), picked["id"])

    elif arg.lower() == "last":
        recent = _evaluator.list_recent_scores(_perf_db_path(), limit=1)
        if not recent:
            print("  " + dim("No scored deliverables yet."))
            return
        score_row = _evaluator.get_score_by_filename(
            _perf_db_path(), recent[0]["filename"])

    elif arg.isdigit() or (arg.startswith("#") and arg[1:].isdigit()):
        score_id = int(arg.lstrip("#"))
        score_row = _evaluator.get_deliverable_score_by_id(
            _perf_db_path(), score_id)
        if score_row is None:
            print("  " + dim(f"No deliverable_scores row with id={score_id}."))
            return

    else:
        # Fuzzy filename match — mirrors show_eval_detail
        score_row = _evaluator.get_score_by_filename(_perf_db_path(), arg)
        if score_row is None:
            recent = _evaluator.list_recent_scores(_perf_db_path(), limit=50)
            matches = [r for r in recent
                       if arg.lower() in (r["filename"] or "").lower()]
            if len(matches) == 1:
                score_row = _evaluator.get_score_by_filename(
                    _perf_db_path(), matches[0]["filename"])
            elif len(matches) > 1:
                print("  " + dim("Multiple matches for '" + arg + "'. Choose one:"))
                for m in matches[:8]:
                    print("    " + tc(C.TEAL, m["filename"]))
                return
        if score_row is None:
            print("  " + dim("No score found for '" + arg + "'."))
            return

    if score_row is None:
        print("  " + dim("Could not resolve deliverable."))
        return
    if "id" not in score_row:
        print("  " + tc(C.AMBER, "⚠")
              + " Could not resolve deliverable_scores.id; aborting.")
        return

    # Warn (but allow) if already rated — re-calibration is first-class
    existing = _evaluator.list_calibrations(
        _perf_db_path(), deliverable_score_id=score_row["id"])
    if existing:
        print("  " + dim(f"Note: this deliverable has {len(existing)} existing "
                         "calibration row(s). A new one will be appended."))

    _run_calibration_flow(score_row)


def show_calibration_report() -> None:
    """Render the drift-per-dim-per-type summary. Types with fewer than
    min_n_per_type ratings (default 5) appear below a reporting floor and
    don't get full drift stats. Sorts per-dim rows by |mean_delta|
    descending so biggest drift is at the top of each type's box."""
    if _evaluator is None:
        print("  " + tc(C.AMBER, "⚠") + " Evaluator module unavailable.")
        return

    drift = _evaluator.compute_calibration_drift(_perf_db_path(), min_n_per_type=5)
    total = drift.get("total_ratings") or 0
    if total == 0:
        print()
        print("  " + dim("No calibrations yet. Rate a deliverable with:"))
        print("  " + tc(C.TEAL, "/eval calibrate"))
        print()
        return

    print()
    print(box_top("CALIBRATION DRIFT — " + get_active_client_slug().upper()))
    print(box_row(dim("Total ratings: ") + tc(C.WHITE, str(total))
                  + dim("   Reporting floor: n>=5 per type")))
    print(box_bottom())

    by_type = drift.get("by_type") or {}
    below = [(t, e) for t, e in by_type.items() if e.get("below_floor")]
    above = [(t, e) for t, e in by_type.items() if not e.get("below_floor")]

    if below:
        print()
        print("  " + dim("Below reporting floor (need 5+ ratings):"))
        for t, e in below:
            print("    " + _truncate(t.replace("_", " "), 26).ljust(28)
                  + dim(f"n={e['n']}/5"))

    if not above:
        print()
        print("  " + dim("No types above reporting floor yet. Keep rating."))
        print("  " + dim("Progress to first-50 per type:"))
        for t, e in by_type.items():
            bar_n = min(e["n"], 50)
            bar = "#" * (bar_n // 2) + "-" * ((50 - bar_n) // 2)
            print("    " + _truncate(t.replace("_", " "), 26).ljust(28)
                  + dim(f"[{bar}] {e['n']}/50"))
        print()
        return

    for dtype, entry in above:
        print()
        print(box_top("TYPE — " + dtype.replace("_", " ").upper()
                      + "   n=" + str(entry["n"])))
        print(box_row(dim("Dim").ljust(26)
                      + dim("OP").ljust(8)
                      + dim("MBR").ljust(8)
                      + dim("Δ").ljust(10)
                      + dim("σ(Δ)").ljust(8)
                      + dim("compress")))
        print(box_divider())
        dims_sorted = sorted(
            (entry.get("per_dim") or {}).items(),
            key=lambda kv: abs(kv[1].get("mean_delta", 0.0)),
            reverse=True,
        )
        for dim_name, s in dims_sorted:
            delta = s.get("mean_delta", 0.0)
            mag = abs(delta)
            dc = C.RED if mag >= 0.5 else (C.AMBER if mag >= 0.25 else C.GREEN)
            comp = s.get("compression_ratio", 1.0)
            cc = C.RED if comp < 0.5 else (C.AMBER if comp < 0.7 else C.GREEN)
            print(box_row(
                _truncate(dim_name, 24).ljust(26)
                + f"{s['mean_op']:.2f}".ljust(8)
                + f"{s['mean_mbr']:.2f}".ljust(8)
                + tc(dc, f"{delta:+.2f}").ljust(18)
                + f"{s['stdev_delta']:.2f}".ljust(8)
                + tc(cc, f"{comp:.2f}")
            ))
        print(box_divider())
        wdelta = entry.get("weighted_mean_delta", 0.0)
        wc = C.RED if abs(wdelta) >= 0.3 else (C.AMBER if abs(wdelta) >= 0.15 else C.GREEN)
        print(box_row(dim("weighted wavg Δ").ljust(26) + tc(wc, f"{wdelta:+.3f}")))
        big = entry.get("biggest_drift_dim")
        if big:
            print(box_row(dim("biggest drift  ").ljust(26)
                          + tc(C.WHITE, f"{big[0]} ({big[1]:+.2f})")))
        mean_comp = entry.get("mean_compression_ratio")
        if mean_comp is not None:
            flag = entry.get("scale_compression_flag")
            label = tc(C.AMBER, "compressed") if flag else tc(C.GREEN, "ok")
            print(box_row(dim("scale usage    ").ljust(26)
                          + f"mean ratio {mean_comp:.2f}  " + label))
        print(box_bottom())

    print()
    print("  " + dim("Progress to first-50 per type:"))
    for t, e in by_type.items():
        bar_n = min(e["n"], 50)
        bar = "#" * (bar_n // 2) + "-" * ((50 - bar_n) // 2)
        print("    " + _truncate(t.replace("_", " "), 26).ljust(28)
              + dim(f"[{bar}] {e['n']}/50"))
    print()


def show_errors(limit: int = 10):
    """Show the last N entries from the error journal."""
    if not ERRORS_JOURNAL.exists():
        print()
        print("  " + tc(C.GREEN, "✓") + " No errors logged. All clear.")
        print("  " + dim("Journal location: " + str(ERRORS_JOURNAL)))
        print()
        return
    records = []
    try:
        with open(ERRORS_JOURNAL, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    records.append(json.loads(line))
                except Exception:
                    pass
    except Exception as e:
        print("  " + tc(C.RED, "✗") + " Could not read errors journal: " + str(e))
        return
    if not records:
        print("  " + tc(C.GREEN, "✓") + " No errors logged. All clear.")
        return
    recent = records[-limit:]
    print()
    print("  " + tbc("Last " + str(len(recent)) + " error" + ("s" if len(recent) != 1 else "") + ":"))
    print("  " + dim("Journal: " + str(ERRORS_JOURNAL) + " — " + str(len(records)) + " total entries"))
    print()
    for r in recent:
        ts   = (r.get("ts", "?")[:19]).replace("T", " ")
        kind = r.get("kind", "unknown")
        user_input = (r.get("user_input", "") or "")[:72]
        # Kind-appropriate icon
        is_recovered = "recovered" in kind
        icon_color = C.GREEN if is_recovered else C.AMBER
        icon = "✓" if is_recovered else "⚠"
        print("  " + tc(icon_color, icon) + " " + dim(ts) + " · " + tc(C.WHITE, kind))
        if user_input:
            print("    " + dim("input: ") + user_input + (" …" if len(r.get("user_input","")) > 72 else ""))
        err = r.get("error") or r.get("last_error") or ""
        if err:
            err_short = str(err)[:110]
            print("    " + dim("error: ") + err_short + (" …" if len(str(err)) > 110 else ""))
        note = r.get("note")
        if note:
            print("    " + dim("note:  ") + tc(C.TEAL, note[:110]))
        print()

def write_deliverable(category: str, filename: str, content: str) -> Path:
    """Write a deliverable to the current client's folder. Returns the saved path.

    `category` may be a single top-level name ('reports') OR a nested path
    ('reports/lead-intel', 'audits/ops'). The first segment is validated against
    DELIVERABLE_DIRS — if it doesn't match, everything falls through to 'reports'.
    Subsequent segments are preserved as subfolders and created on demand.
    Auto-updates client.json with a reference when it's a known first-of-kind type."""
    cat_raw = (category or "").strip().strip("/")
    segments = [s for s in cat_raw.split("/") if s]
    top = segments[0].lower() if segments else "reports"
    if top not in DELIVERABLE_DIRS:
        top = "reports"
        segments = [top]
    rest = segments[1:]
    base = client_deliverables_dir() / top
    for seg in rest:
        # Guard against path traversal — only allow simple folder names
        if ".." in seg or "\\" in seg:
            continue
        base = base / seg
    base.mkdir(parents=True, exist_ok=True)
    if not filename:
        filename = "untitled-"+datetime.now().strftime("%Y%m%d-%H%M%S")+".md"
    # Filename itself may also carry a sub-path — split if so
    fn_parts = [p for p in filename.split("/") if p and ".." not in p]
    for sub in fn_parts[:-1]:
        base = base / sub
        base.mkdir(parents=True, exist_ok=True)
    path = base / (fn_parts[-1] if fn_parts else filename)
    path.write_text(content, encoding="utf-8")
    # Reflect well-known paths back into client.json
    manifest = client_load_manifest() or {}
    rel = str(path.relative_to(client_workspace_path()))
    if top == "audits" and len(rest) == 0 and not manifest.get("audit_path"):
        manifest["audit_path"] = rel
        client_save_manifest(manifest)
    elif top == "content" and "voice-profile" in path.name.lower() and not manifest.get("voice_profile_path"):
        manifest["voice_profile_path"] = rel
        client_save_manifest(manifest)
    return path

def handle_save_command(raw: str, history) -> None:
    """Handle '/save <category> <filename>' — saves the last assistant response
    into the current client's deliverables folder.

    `category` can be a single name ('reports') or a nested path ('reports/lead-intel').
    `filename` can also contain subfolders."""
    parts = raw.split(None, 2)  # ["/save", "<category>", "<filename>"]
    if len(parts) < 3:
        print("  "+tc(C.AMBER,"⚠")+" Usage: /save <category> <filename.md>")
        print("  "+dim("Categories: ")+", ".join(tc(C.TEAL,c) for c in DELIVERABLE_DIRS))
        print("  "+dim("Nested paths are supported: ")+tc(C.TEAL,"/save reports/lead-intel weekly-01.md")); return
    _, category, filename = parts[0], parts[1].strip().lower(), parts[2].strip()
    # Validate only the TOP-LEVEL segment of the category path
    top = category.split("/", 1)[0]
    if top not in DELIVERABLE_DIRS:
        print("  "+tc(C.AMBER,"⚠")+" Unknown category "+tc(C.WHITE,top)+". Valid top-level: "+", ".join(DELIVERABLE_DIRS)); return
    last = None
    try:
        for msg in reversed(history.to_messages() if history else []):
            if msg.get("role") == "assistant" and msg.get("content","").strip():
                last = msg["content"]; break
    except Exception: last = None
    if not last:
        print("  "+tc(C.AMBER,"⚠")+" No assistant response in history to save."); return
    try:
        path = write_deliverable(category, filename, last)
        print("  "+tc(C.GREEN,"✓")+" Saved to "+tbc(str(path)))
    except Exception as e:
        print("  "+tc(C.RED,"✗")+" Save failed: "+str(e))


def export_conversation(history) -> Path:
    """Render the current conversation history as Markdown and save it into
    the current client's deliverables/reports/ folder. Returns the saved Path,
    or None if there's nothing to export."""
    messages = []
    try:
        messages = history.to_messages() if history else []
    except Exception:
        messages = []
    messages = [m for m in messages if (m.get("content") or "").strip()]
    if not messages:
        return None

    manifest    = client_load_manifest() or {}
    slug        = get_active_client_slug()
    client_name = manifest.get("name", slug)
    ts_file     = datetime.now().strftime("%Y-%m-%d-%H%M")
    ts_display  = datetime.now().strftime("%Y-%m-%d %H:%M")

    lines = [
        "# Session — " + client_name,
        "",
        "_Exported: "  + ts_display + "_  ",
        "_Client: "    + client_name + " (`" + slug + "`)_  ",
        "_Turns: "     + str(len(messages)) + "_",
        "",
        "---",
        "",
    ]
    for msg in messages:
        role    = (msg.get("role") or "").lower()
        content = (msg.get("content") or "").strip()
        if role == "user":
            lines.append("## 👤 You"); lines.append("")
        elif role == "assistant":
            lines.append("## 🍺 Tavern"); lines.append("")
        else:
            lines.append("## " + role.title()); lines.append("")
        lines.append(content); lines.append("")

    output   = "\n".join(lines).rstrip() + "\n"
    filename = "session-" + ts_file + ".md"
    return write_deliverable("reports", filename, output)

def handle_export_command(raw: str, history) -> None:
    """Handle '/export <target>'. Currently supports: conversation."""
    parts = raw.strip().split(None, 1)
    target = parts[1].strip().lower() if len(parts) > 1 else ""
    if not target:
        print("  "+tc(C.AMBER,"⚠")+" Usage: "+tc(C.TEAL,"/export conversation"))
        print("  "+dim("Saves the current chat history to deliverables/reports/ as Markdown.")); return
    if target in ("conversation","convo","chat","history","session"):
        if not history:
            print("  "+tc(C.AMBER,"⚠")+" No conversation to export yet."); return
        try:
            path = export_conversation(history)
        except Exception as e:
            print("  "+tc(C.RED,"✗")+" Export failed: "+str(e)); return
        if path is None:
            print("  "+tc(C.AMBER,"⚠")+" No messages yet — nothing to export."); return
        print("  "+tc(C.GREEN,"✓")+" Exported to "+tbc(str(path)))
    else:
        print("  "+tc(C.AMBER,"⚠")+" Unknown export target: "+tc(C.WHITE,target))
        print("  "+dim("Try: ")+tc(C.TEAL,"/export conversation"))

# ═══════════════════════════════════════════════════════════════════════════════
#  GITHUB UPDATE SYSTEM
# ═══════════════════════════════════════════════════════════════════════════════

def _gh_headers(token):
    return {"Authorization":"token "+token,"User-Agent":"TavernOS/0.1.0","Accept":"application/vnd.github.v3.raw"}

def _fetch_raw(path,config):
    token=get_registry_token(config)
    if not token: return None
    try:
        url="https://raw.githubusercontent.com/"+GITHUB_USER+"/"+GITHUB_REPO+"/"+GITHUB_BRANCH+"/"+path
        req=urllib.request.Request(url,headers=_gh_headers(token))
        with urllib.request.urlopen(req,timeout=8) as r: return r.read().decode("utf-8")
    except Exception: return None

def _fetch_registry(config):
    raw=_fetch_raw("registry.json",config)
    if not raw: return None
    try: return json.loads(raw)
    except Exception: return None

def _clean_version_string(v: str) -> str:
    """Strip BOM + whitespace + trailing nulls from a version string."""
    if v is None: return "0.0.0"
    return v.lstrip("\ufeff").strip().strip("\x00") or "0.0.0"

def get_local_version():
    if not LOCAL_VERSION_FILE.exists(): return "0.0.0"
    try:
        return _clean_version_string(LOCAL_VERSION_FILE.read_text(encoding="utf-8"))
    except Exception:
        return "0.0.0"

def set_local_version(v):
    USER_DIR.mkdir(parents=True, exist_ok=True)
    LOCAL_VERSION_FILE.write_text(_clean_version_string(v), encoding="utf-8")

def _version_tuple(v):
    try: return tuple(int(x) for x in _clean_version_string(v).split("."))
    except Exception: return (0,0,0)

def check_for_updates(config):
    if not get_registry_token(config): return None
    try:
        remote_raw=_fetch_raw("VERSION",config)
        if not remote_raw: return None
        remote_version=remote_raw.strip()
        if _version_tuple(remote_version)>_version_tuple(get_local_version()):
            registry=_fetch_registry(config)
            if registry:
                registry["_remote_version"]=remote_version; registry["_local_version"]=get_local_version(); return registry
    except Exception: pass
    return None

def print_update_notification(registry):
    print(); print(box_top("TAVERNOS UPDATE AVAILABLE"))
    print(box_row(dim(registry.get("_local_version","?"))+" "+tc(C.TEAL,"→")+" "+tc(C.WHITE+C.BOLD,registry.get("_remote_version","?"))))
    print(box_row(_truncate(registry.get("changelog","New updates available"),_box_width())))
    print(box_divider()); print(box_row("Type "+tbc("/update")+" to install · "+tbc("/whats-new")+" to see details")); print(box_bottom()); print()

def do_update(config,registry=None):
    print(); print("  "+tc(C.TEAL,"⟳")+" Pulling latest from TavernOS registry…")
    if registry is None:
        registry=_fetch_registry(config)
        if not registry: print("  "+tc(C.RED,"✗")+" Could not reach registry."); return
    remote_version=registry.get("_remote_version") or (_fetch_raw("VERSION",config) or "").strip()
    ua=0; us=0
    for agent in registry.get("agents",[]):
        slug=agent.get("slug","")
        if not slug: continue
        raw=_fetch_raw("agents/"+slug+".json",config)
        dest=AGENTS_DIR/(slug+".json"); AGENTS_DIR.mkdir(parents=True,exist_ok=True)
        if raw: dest.write_text(raw,encoding="utf-8"); ua+=1
        elif not dest.exists():
            with open(dest,"w",encoding="utf-8") as f:
                json.dump({"name":agent["name"],"personality":agent.get("description",""),"quip_style":"","skills":agent.get("triggers",[])},f,indent=2)
            ua+=1
    for skill in registry.get("skills",[]):
        slug=skill.get("slug","")
        if not slug: continue
        raw=_fetch_raw("skills/"+slug+".skill.md",config)
        if raw:
            dest=SKILLS_DIR/(slug+".skill.md"); SKILLS_DIR.mkdir(parents=True,exist_ok=True); dest.write_text(raw,encoding="utf-8"); us+=1
    cache=USER_DIR/"registry_cache.json"
    with open(cache,"w",encoding="utf-8") as f: json.dump(registry,f,indent=2)
    if remote_version: set_local_version(remote_version)
    print(); print("  "+tc(C.GREEN,"✓")+" Update complete — "+tbc("v"+str(remote_version or "?")))
    print("    "+tc(C.TEAL,str(ua))+" agents · "+tc(C.TEAL,str(us))+" skills updated"); print()

def show_whats_new(config,registry=None):
    if registry is None:
        registry=_fetch_registry(config)
        if not registry:
            cache=USER_DIR/"registry_cache.json"
            if cache.exists():
                with open(cache,"r",encoding="utf-8") as f: registry=json.load(f)
            else: print("  "+tc(C.RED,"✗")+" No registry. Try /update first."); return
    print(); print("  "+tbc("── TavernOS v"+registry.get("version","?")+" ("+registry.get("released","?")+") ─────────────────────"))
    print("  "+registry.get("changelog","No changelog")+"\n")
    for a in registry.get("agents",[]): print("  "+tc(C.TEAL,"▶")+" "+tc(C.WHITE,a["name"])+"  "+dim(a.get("description","")[:50]))
    print()
    for s in registry.get("skills",[]): print("  "+tc(C.TEAL,"★")+"  "+tc(C.WHITE,s["name"])+"  "+tc(C.TEAL,"→")+" "+dim(s.get("agent","?"))+" — "+dim(s.get("description","")[:40]))
    print()

def skill_search(query,config,registry=None):
    if registry is None:
        cache=USER_DIR/"registry_cache.json"
        if cache.exists():
            with open(cache,"r",encoding="utf-8") as f: registry=json.load(f)
        else: registry=_fetch_registry(config)
    if not registry: print("  "+tc(C.AMBER,"⚠")+" No registry. Try /update first."); return
    q=query.lower()
    matches=[s for s in registry.get("skills",[]) if q in (s.get("name","")+s.get("description","")+(" ".join(s.get("triggers",[])))).lower()]
    if not matches: print("  No skills found matching '"+query+"'."); return
    print(); print("  "+tbc("Skills matching \""+query+"\":")+ "\n")
    for s in matches:
        installed=(SKILLS_DIR/(s["slug"]+".skill.md")).exists()
        status=tc(C.GREEN,"✓ installed  ") if installed else tc(C.GRAY,"  not installed")
        print("  "+status+"  "+tc(C.WHITE,s["name"])+"  "+tc(C.TEAL,"→")+" "+dim(s.get("agent","?")))
        print("               "+dim(s.get("description","")))
        if not installed: print("               "+dim("Install: ")+tc(C.TEAL,"/skill install "+s["slug"]))
        print()

def skill_install(slug,config,registry=None):
    if registry is None:
        cache=USER_DIR/"registry_cache.json"
        if cache.exists():
            with open(cache,"r",encoding="utf-8") as f: registry=json.load(f)
        else: registry=_fetch_registry(config)
    if not registry: print("  "+tc(C.AMBER,"⚠")+" No registry. Try /update first."); return
    skill=next((s for s in registry.get("skills",[]) if s.get("slug")==slug),None)
    if not skill: print("  "+tc(C.RED,"✗")+" Skill '"+slug+"' not found."); return
    raw=_fetch_raw("skills/"+slug+".skill.md",config)
    dest=SKILLS_DIR/(slug+".skill.md"); SKILLS_DIR.mkdir(parents=True,exist_ok=True)
    if raw: dest.write_text(raw,encoding="utf-8")
    else:
        content=("---\nname: "+skill["name"]+"\ntrigger: "+slug.replace("-"," ")+"\ndescription: "+skill.get("description","")+
                 "\nagent: "+skill.get("agent","norm")+"\npack: "+skill.get("pack","custom")+"\nsteps:\n  - Understand the request\n  - Apply appropriate skills\n  - Deliver high-quality output\nchaining: true\n---\n\nYou are the "+skill["name"]+" skill.\n")
        dest.write_text(content,encoding="utf-8")
    print(); print("  "+tc(C.GREEN,"✓")+" Installed: "+tbc(skill["name"]))
    print("    "+dim("Agent: ")+tc(C.TEAL,skill.get("agent","?"))); print()


# ═══════════════════════════════════════════════════════════════════════════════
#  VERSION PUSH
# ═══════════════════════════════════════════════════════════════════════════════

def auto_update_skills(config):
    token=get_customer_registry_token(config)
    if not token: return 0
    updated=0
    try:
        headers=_gh_headers(token)
        ver_url="https://raw.githubusercontent.com/"+GITHUB_USER+"/"+GITHUB_REPO+"/"+GITHUB_BRANCH+"/VERSION"
        with urllib.request.urlopen(urllib.request.Request(ver_url,headers=headers),timeout=8) as r:
            remote_version=r.read().decode("utf-8").strip()
        if _version_tuple(remote_version)<=_version_tuple(get_local_version()): return 0
        reg_url="https://raw.githubusercontent.com/"+GITHUB_USER+"/"+GITHUB_REPO+"/"+GITHUB_BRANCH+"/registry.json"
        with urllib.request.urlopen(urllib.request.Request(reg_url,headers=headers),timeout=8) as r:
            registry=json.loads(r.read().decode("utf-8"))
        SKILLS_DIR.mkdir(parents=True,exist_ok=True)
        for skill in registry.get("skills",[]):
            slug=skill.get("slug","")
            if not slug: continue
            skill_url="https://raw.githubusercontent.com/"+GITHUB_USER+"/"+GITHUB_REPO+"/"+GITHUB_BRANCH+"/skills/"+slug+".skill.md"
            try:
                with urllib.request.urlopen(urllib.request.Request(skill_url,headers=headers),timeout=8) as r:
                    raw=r.read().decode("utf-8")
                (SKILLS_DIR/(slug+".skill.md")).write_text(raw,encoding="utf-8"); updated+=1
            except Exception: pass
        if updated>0:
            set_local_version(remote_version)
            cache=USER_DIR/"registry_cache.json"
            with open(cache,"w",encoding="utf-8") as f: json.dump(registry,f,indent=2)
    except Exception: pass
    return updated


# ═══════════════════════════════════════════════════════════════════════════════
#  CUSTOMER SETUP
# ═══════════════════════════════════════════════════════════════════════════════

def run_setup():
    print(_splash()); print("="*64); print(tbc("  TAVERNOS CUSTOMER SETUP"))
    print("  Customer will self-onboard via the wizard when they first run norm."); print("="*64); print()
    company=input("  Customer company name (for the zip filename): ").strip()
    if not company: print("  Cancelled."); return
    slug=company.lower().replace(" ","-").replace("'","")
    dev_config=load_config(Mode.DEV); customer_token=dev_config.get(CUSTOMER_TOKEN_KEY,"")
    if not customer_token:
        print(); print(tc(C.AMBER,"  ⚠  No customer_registry_token found in your dev config.")); print(dim("  Skills will not auto-update for this customer.")); print()
        if input("  Continue without auto-update token? [y/n]: ").strip().lower()!="y": print("  Cancelled."); return
    seed_config={"onboarded":False,"built_for":company,"built_at":_now_iso(),CUSTOMER_TOKEN_KEY:customer_token}
    out_dir=Path.home()/"Desktop"/("TavernOS-"+slug); zip_path=Path.home()/"Desktop"/("TavernOS-"+slug+".zip")
    if out_dir.exists(): shutil.rmtree(out_dir)
    out_dir.mkdir(parents=True)
    config_path=out_dir/"config.json"
    with open(config_path,"w",encoding="utf-8") as f: json.dump(seed_config,f,indent=2)
    with zipfile.ZipFile(zip_path,"w",zipfile.ZIP_DEFLATED) as zf: zf.write(config_path,arcname="config.json")
    shutil.rmtree(out_dir)
    print(); print("="*64)
    print("  "+tc(C.GREEN,"✓")+" Package ready: "+tbc(str(zip_path)))
    print("  "+dim("Customer runs 'norm' — wizard handles setup automatically."))
    if customer_token: print("  "+tc(C.GREEN,"✓")+" Auto-update token included.")
    print("="*64); print()


# ═══════════════════════════════════════════════════════════════════════════════
#  ROUTING
# ═══════════════════════════════════════════════════════════════════════════════

ROUTER_SYSTEM=(
    "You are Sam, the Chief of Staff and orchestrator of TavernOS.\n"
    "Return ONLY valid JSON — no markdown, no explanation:\n"
    '{"intent":"brief description","steps":[{"agent":"agent_name","task":"what to do","skill":null}],'
    '"needs_new_skill":false,"new_skill_name":null,"new_skill_description":null}\n'
    "Agents: sam(orchestration), norm(general), coach(meetings/PRDs), carla(QA/editing),\n"
    "woody(proposals/content), cliff(research/PDFs/data/web search), frasier(strategy), rebecca(Excel/slides/charts),\n"
    "lilith(operational audits/workflow mapping/ops diagnosis)\n"
    "\nRouting rules:\n"
    "- Route document/file questions to cliff\n"
    "- Route chart/graph/visualization requests to rebecca\n"
    "- Route ANY request involving a spreadsheet, workbook, .xlsx file, MBR,\n"
    "  monthly business review, KPI dashboard, variance analysis, financial\n"
    "  model, P&L, revenue/cost reporting, or budget-vs-actual analysis to\n"
    "  rebecca. These are her core deliverables — do NOT route them to\n"
    "  frasier (strategy) or norm (general) even if the request mentions\n"
    "  business planning or numbers in the abstract.\n"
    "- Route ANY request for an operational audit, ops audit, workflow\n"
    "  audit, workflow mapping, operational diagnosis, operational\n"
    "  assessment, 'audit operations', 'audit our operations', 'map our\n"
    "  workflows', or 'find the bottlenecks' to lilith as a SINGLE step.\n"
    "  Do NOT decompose into multiple agents — lilith owns operational\n"
    "  audits end-to-end, and decomposing into frasier/cliff/rebecca/carla\n"
    "  produces unreviewable prose when the deliverable should be a single\n"
    "  structured docx that lilith writes herself. Even if the request\n"
    "  mentions workflows, operations, or business processes in the\n"
    "  abstract, route to lilith unless the user explicitly asks for\n"
    "  strategy (frasier), market research (cliff), or a spreadsheet\n"
    "  (rebecca).\n"
    "- Route requests for current news, recent events, competitor research, market data,\n"
    "  live prices, or any information that may have changed recently to cliff\n"
    "  (cliff has real-time web search available when using Anthropic)\n"
    "- Use conversation history to understand follow-ups like 'it', 'that', 'the previous one'"
)


# ═══════════════════════════════════════════════════════════════════════════════
#  OUTPUT CONTRACT — global formatting rules appended to every agent's system
#  prompt. Defined once here and mirrored in server.py so CLI and web UI
#  stay in sync. If a specific skill ever needs to deviate from this
#  contract, the skill file can override it inline in its body text.
# ═══════════════════════════════════════════════════════════════════════════════

OUTPUT_CONTRACT = (
    "Format all output as Markdown:\n"
    "- Use ## and ### for section headings (not underlines or ASCII rules)\n"
    "- Use | table syntax for any structured/tabular data\n"
    "- Use - or * for bullet lists\n"
    "- Use --- for horizontal rules\n"
    "- Use **bold** and *italic* for emphasis\n"
    "- Use `backticks` for inline code and ``` fences for code blocks\n"
    "Do NOT use ASCII art boxes, rule characters (║ ═ ╔ ╗ ╚ ╝ ─ │ ┌ ┐ └ ┘ ├ ┤ ┬ ┴ ┼), "
    "or hand-drawn dividers for visual structure. These do not render correctly in "
    "variable-width contexts (web UI, email, docs) and make output look broken.\n\n"
    "Grounding discipline — do not invent specific facts the user did not "
    "provide (names, numbers, dates, figures, quotes, client details, "
    "stakeholder identities, tool configurations). When the request lacks "
    "enough detail to produce the deliverable without inventing those "
    "specifics, pick ONE path and say which you chose:\n"
    "  BOUND (DEFAULT for any deliverable request with even partial "
    "substantive detail) — produce the deliverable scoped to what the user "
    "supplied. Use [TBD — <what's needed>] wherever a specific would "
    "otherwise go. For artifact tools, INVOKE the tool with the partial "
    "spec — pass empty arrays or omit optional fields rather than fabricating "
    "data; mark required-but-unknown fields with [TBD] strings. The "
    "deliverable lands; the user iterates. Use BOUND when the user has named "
    "at least three of: {industry or company, headcount or revenue, specific "
    "pain point, current tool/system, named stakeholder or role}. End "
    "narration (after the tool call returns) with a short \"To finalize, I "
    "need:\" list naming what's missing.\n"
    "  CLARIFY (only for genuinely thin prompts) — ask 2–4 focused questions "
    "naming exactly what's missing. Produce nothing else this turn. Use "
    "CLARIFY only when the prompt is BOTH short (under ~30 words) AND names "
    "fewer than three of the substantive criteria above. When an artifact "
    "tool is available and the user has provided substantive detail, "
    "defaulting to CLARIFY is gatekeeping — it blocks demonstration of the "
    "tool, frustrates trial users, and provides no value the user couldn't "
    "have gotten by waiting another turn. Always prefer BOUND when the "
    "criteria are met.\n"
    "Invented specifics are wrong even when plausible and well-structured. "
    "But [TBD — what's needed] placeholders are NOT inventions — they're "
    "honest unknowns, and a deliverable with [TBD]s is more useful than "
    "no deliverable. Tool invocation with [TBD]-marked fields is the correct "
    "BOUND behavior, not a fabrication risk.\n\n"
    "Deliverables — when your response IS a substantive artifact the user will "
    "keep, reuse, or share (proposal, audit, report, guide, spec, PRD, brief, "
    "plan, strategy doc, analysis) AND is longer than ~400 words, end your "
    "response with exactly one marker line on its own:\n"
    "DELIVERABLE_SAVED: <category>/<filename>.md\n"
    "Where <category> is one of: reports, audits, blueprints, content. "
    "Filename is kebab-case and descriptive (e.g. proposal-northstar-q2.md, "
    "audit-ops-acme.md). Do NOT emit this marker for: short responses, chat "
    "replies, Q&A, critiques, grill-me responses, clarifications, status "
    "updates, or anything under ~400 words. Skill files may specify their own "
    "save paths that take priority over these defaults."
)


# ═══════════════════════════════════════════════════════════════════════════════
#  RESILIENCE — error journal + JSON extraction. Mirrored in server.py.
#  Every failure lands in ERRORS_JOURNAL (one JSON object per line) so you can
#  review what broke this week without watching every chat in real time.
#  `_try_extract_json` handles the common case where the router returns JSON
#  with extra commentary or code fences around it.
# ═══════════════════════════════════════════════════════════════════════════════

def _log_error(kind, **context):
    """Append an error record to the diagnostics journal. Never raises —
    logging must not crash the main flow. Use /errors in the CLI or
    GET /api/errors in the web UI to review."""
    try:
        DIAG_DIR.mkdir(parents=True, exist_ok=True)
        rec = {"ts": _now_iso(), "kind": kind, **context}
        with open(ERRORS_JOURNAL, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception:
        pass


def _try_extract_json(text):
    """Progressively strip noise and extract a JSON object. Returns dict or None.
    Order of attempts: (1) parse as-is, (2) strip markdown fences,
    (3) find first balanced {...} block respecting strings."""
    if not text:
        return None
    # (1) Already valid
    try:
        return json.loads(text)
    except Exception:
        pass
    # (2) Strip markdown code fences
    cleaned = re.sub(r"^```[a-zA-Z]*\n?", "", text.strip())
    cleaned = re.sub(r"\n?```\s*$", "", cleaned)
    try:
        return json.loads(cleaned)
    except Exception:
        pass
    # (3) Find the first balanced {...} block. Track strings so braces
    # inside JSON string values don't throw off depth counting.
    start = cleaned.find("{")
    if start < 0:
        return None
    depth = 0
    in_string = False
    escape = False
    for i in range(start, len(cleaned)):
        c = cleaned[i]
        if escape:
            escape = False
            continue
        if c == "\\":
            escape = True
            continue
        if c == '"':
            in_string = not in_string
            continue
        if in_string:
            continue
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                try:
                    return json.loads(cleaned[start:i+1])
                except Exception:
                    return None
    return None


# ═══════════════════════════════════════════════════════════════════════════════
#  DELIVERABLE AUTO-SAVE — detects the DELIVERABLE_SAVED marker in agent output
#  and writes the file into the active client's workspace. The contract above
#  teaches agents to emit the marker; this code enforces the workspace sandbox
#  and writes the file.
# ═══════════════════════════════════════════════════════════════════════════════

DELIVERABLE_MARKER_RE = re.compile(r'^DELIVERABLE_SAVED:\s*(.+?)\s*$', re.MULTILINE)
VALID_DELIVERABLE_CATEGORIES = {"reports", "audits", "blueprints", "content"}

def _resolve_deliverable_path(marker_path, slug=None):
    """Resolve a marker path to an absolute Path inside the active client's
    workspace. Returns None if the path is invalid or would escape the sandbox."""
    if not marker_path:
        return None
    marker_path = marker_path.lstrip("/\\").strip()
    if not marker_path or ".." in Path(marker_path).parts:
        return None
    if not marker_path.lower().endswith(".md"):
        marker_path += ".md"
    parts = Path(marker_path).parts
    # Prepend default category when the first segment isn't one of the valid ones
    if parts[0] not in VALID_DELIVERABLE_CATEGORIES:
        marker_path = "reports/" + marker_path
    base = client_deliverables_dir(slug).resolve()
    final = (base / marker_path).resolve()
    try:
        final.relative_to(base)
    except ValueError:
        return None
    return final

def _process_deliverable_marker(text, agent_name):
    """Scan response text for DELIVERABLE_SAVED marker. If found, strip the
    marker, write the cleaned content to disk, return a dict describing
    what was saved. Returns None if no marker found or save failed."""
    if not text:
        return None
    match = DELIVERABLE_MARKER_RE.search(text)
    if not match:
        return None
    marker_path = match.group(1).strip()
    final_path = _resolve_deliverable_path(marker_path)
    if not final_path:
        return None
    cleaned = DELIVERABLE_MARKER_RE.sub("", text).rstrip() + "\n"
    try:
        final_path.parent.mkdir(parents=True, exist_ok=True)
        final_path.write_text(cleaned, encoding="utf-8")
    except Exception:
        return None
    try:
        rel = final_path.relative_to(USER_DIR).as_posix()
    except ValueError:
        rel = final_path.as_posix()
    return {
        "filename": final_path.name,
        "path":     rel,
        "abs_path": str(final_path),
        "category": final_path.parent.name,
        "agent":    agent_name,
        "bytes":    final_path.stat().st_size,
    }


# ═══════════════════════════════════════════════════════════════════════════════
#  EXECUTE — web search for Cliff, streaming for everyone else
# ═══════════════════════════════════════════════════════════════════════════════

def call_router(client,provider,model_id,history,user_input):
    """Ask Sam to produce a plan. Resilient to JSON parsing failures:
    up to 3 attempts with progressively stricter prompting, then falls
    back to a minimal plan that routes to Norm. User always gets a response.
    Every failure and recovery lands in the error journal."""
    stricter = ("\n\nYour previous response was not parseable JSON. "
                "Return ONLY the JSON object — no markdown fences, no commentary, "
                "nothing before or after the closing brace.")
    raw_responses = []
    last_error = None

    for attempt in range(3):
        try:
            messages = history.to_messages()
            messages.append({"role":"user","content":user_input})
            system = ROUTER_SYSTEM if attempt == 0 else ROUTER_SYSTEM + stricter
            if provider == "anthropic":
                r = client.messages.create(model=model_id, max_tokens=ROUTER_MAX_TOKENS,
                                           system=system, messages=messages)
                raw = r.content[0].text.strip()
            else:
                r = client.chat.completions.create(model=model_id, max_tokens=ROUTER_MAX_TOKENS,
                                                   messages=[{"role":"system","content":system}]+messages)
                raw = r.choices[0].message.content.strip()
            raw_responses.append(raw[:500])

            plan = _try_extract_json(raw)
            if plan and isinstance(plan, dict) and "steps" in plan:
                if attempt > 0:
                    # Recovered on retry — record that for later review
                    _log_error("router_recovered",
                               user_input=user_input,
                               attempts=attempt+1,
                               recovery_strategy=("retry_strict" if attempt == 1 else "json_extract"))
                    _indicator.update("Sam recovered — planning…")
                return plan

            # Parsed but not a valid plan, or parse failed — retry
            last_error = "unparseable or malformed plan"
            if attempt < 2:
                _indicator.update("Sam had trouble — retrying…")

        except Exception as e:
            last_error = str(e)
            if attempt < 2:
                _indicator.update("Sam had trouble — retrying…")
                time.sleep(0.4 * (attempt + 1))

    # All 3 attempts exhausted — log and fall back so the user gets SOMETHING
    _log_error("router_failed_all_retries",
               user_input=user_input,
               last_error=last_error,
               raw_responses=raw_responses)
    print("  " + tc(C.AMBER, "⚠") + " Router had trouble — routing to Norm as fallback."
          + dim(" (logged for review; type /errors to see details)"))
    return {
        "intent": user_input,
        "steps":  [{"agent": "norm", "task": user_input, "skill": None}],
        "needs_new_skill": False,
        "new_skill_name": None,
        "new_skill_description": None,
    }


# Personality-appropriate thinking phrases shown while the LLM API call is in flight.
# Edit freely — any agent not listed here falls back to generic "thinking".
_THINKING_PHRASES = {
    "sam":     "routing this",
    "norm":    "thinking it through",
    "coach":   "organizing the plan",
    "carla":   "sharpening the knife",
    "woody":   "drafting thoughtfully",
    "cliff":   "digging into the research",
    "frasier": "mapping the approach",
    "rebecca": "pulling the numbers",
    "lilith":  "diagnosing",
    "diane":   "reading the tone",
}

def run_tool_use_loop(client, model_id, system, messages, tools_param,
                      max_tokens, agent_name, *,
                      on_token=None, on_tool_call=None, on_tool_result=None,
                      on_banner=None, on_first_response=None):
    """Generalized Anthropic tool-use loop, callable from any surface (CLI,
    SSE, batch). Runs messages.create in a loop until the response has no
    more tool_use blocks. Dispatches each tool call through the module-level
    helpers (_dispatch_first_party_tool, _MCP_MANAGER, web_search ACK) so
    both the CLI and the web UI share one tool-dispatch code path.

    Parameters
    ----------
    client, model_id, system, messages, tools_param, max_tokens:
        Pass-throughs to Anthropic's messages.create. `messages` is mutated
        in place — assistant turns and tool_result turns get appended so the
        caller can inspect the final trace if desired.
    agent_name:
        Lowercased agent name, passed to first-party tool dispatchers for
        allowed-agents checks.
    on_token(text):
        Fires for each chunk of assistant text as it comes out of a response.
        Use this to stream to stdout (CLI) or to an SSE channel (web).
    on_tool_call(tool_name, args):
        Fires before dispatch. UI hook — show "Rebecca is calling
        generate_xlsx_report…" etc.
    on_tool_result(tool_name, result_text, is_error):
        Fires after dispatch. `result_text` is what goes back to the model;
        `is_error` is True for dispatch failures.
    on_banner(banner_dict):
        Fires when a first-party tool emits a deliverable sentinel. The dict
        has keys {filename, path, bytes}. Caller decides how to surface it
        (CLI prints a banner after the stream; web emits an SSE event).
    on_first_response():
        Fires exactly once, right after the first messages.create returns.
        This is the commit point — subsequent failures must not trigger
        retries because tool side effects (MCP calls, file writes) may have
        already happened on subsequent rounds.

    Returns
    -------
    str: the accumulated assistant text across all turns in this call.

    Raises
    ------
    Lets Anthropic SDK exceptions propagate so callers can implement their
    own retry policy around the single-shot first call. Per-tool dispatch
    errors are caught, logged via _log_error, and surfaced to the model as
    error-flagged tool_results so the agent can self-correct on the next
    turn. They do NOT propagate up."""
    full_text = ""
    first_seen = False

    # Per-tool-name rejection counter for the rubric-critical preflight gate.
    # Scoped to this single run_tool_use_loop invocation so counts don't leak
    # across turns. When a tool has been rejected >= _PREFLIGHT_GATE_MAX_REJECTIONS
    # times in this call, the NEXT invocation bypasses the gate and saves the
    # deliverable with a warning preamble. See _dispatch_first_party_tool +
    # artifact_docx._tool_handler for the wiring.
    gate_rejection_counts: dict[str, int] = {}

    response = client.messages.create(
        model=model_id, max_tokens=max_tokens,
        system=system, tools=tools_param, messages=messages)
    if not first_seen:
        first_seen = True
        if on_first_response is not None:
            try: on_first_response()
            except Exception as _cbe: _log_error("tool_loop_callback_failed",
                                                 cb="on_first_response", error=str(_cbe))

    # Single-shape loop. Each iteration:
    #   (1) emit any assistant text blocks from the current response
    #   (2) if no tool_use blocks, we're done
    #   (3) otherwise dispatch each tool_use block, append results, recurse
    # This consolidates what used to be two separate text-emit sites
    # (inside the while, and after it) into one. Behavior is equivalent.
    while True:
        for block in response.content:
            if hasattr(block, "text") and block.text:
                full_text += block.text
                if on_token is not None:
                    try: on_token(block.text)
                    except Exception as _cbe: _log_error("tool_loop_callback_failed",
                                                          cb="on_token", error=str(_cbe))

        # Anthropic can emit multiple parallel tool_use blocks in a single turn
        tool_use_blocks = [b for b in response.content
                           if getattr(b, "type", None) == "tool_use"]
        if not tool_use_blocks:
            break

        messages.append({"role": "assistant", "content": response.content})

        # Dispatch each tool call; build matching tool_result blocks.
        # Per-tool exceptions are caught and surfaced to the model as
        # is_error tool_results so the agent can self-correct.
        tool_results = []
        for tub in tool_use_blocks:
            tname = tub.name
            args = dict(tub.input) if isinstance(tub.input, dict) else (tub.input or {})
            if on_tool_call is not None:
                try: on_tool_call(tname, args)
                except Exception as _cbe: _log_error("tool_loop_callback_failed",
                                                      cb="on_tool_call", error=str(_cbe))

            if tname == "web_search":
                # Server tool — Anthropic already executed it server-side;
                # empty ACK is correct (per Anthropic SDK contract).
                result_text = ""
                is_error = False
                tool_results.append({"type": "tool_result",
                                     "tool_use_id": tub.id, "content": ""})
            elif _is_first_party_tool(tname):
                try:
                    # Bypass the rubric-critical preflight gate once this
                    # tool has already been rejected N times in this loop.
                    # Prevents runaway retries against the uncapped while-True
                    # loop while honoring the post-save evaluator's
                    # "scores are signals, not verdicts" philosophy.
                    bypass_gates = (gate_rejection_counts.get(tname, 0)
                                    >= _PREFLIGHT_GATE_MAX_REJECTIONS)
                    _text, _banner, _is_err = _dispatch_first_party_tool(
                        tname, args, agent_name, bypass_gates=bypass_gates)
                    result_text = _text
                    is_error = _is_err
                    if _is_err:
                        # Rubric-critical rejection — increment counter so
                        # the next attempt on the same tool name triggers
                        # the bypass path if we cross the threshold.
                        gate_rejection_counts[tname] = \
                            gate_rejection_counts.get(tname, 0) + 1
                        tool_results.append({"type": "tool_result",
                                             "tool_use_id": tub.id,
                                             "content": _text,
                                             "is_error": True})
                    else:
                        tool_results.append({"type": "tool_result",
                                             "tool_use_id": tub.id,
                                             "content": _text})
                        if _banner is not None and on_banner is not None:
                            try: on_banner(_banner)
                            except Exception as _cbe: _log_error("tool_loop_callback_failed",
                                                                  cb="on_banner", error=str(_cbe))
                except Exception as _fpe:
                    _log_error("first_party_tool_failed", tool=tname, error=str(_fpe))
                    result_text = "Tool call failed: " + str(_fpe)
                    is_error = True
                    tool_results.append({"type": "tool_result",
                                         "tool_use_id": tub.id,
                                         "content": result_text, "is_error": True})
            elif _MCP_MANAGER is not None and _MCP_MANAGER.is_mcp_tool(tname):
                try:
                    result_text = _MCP_MANAGER.call_tool(tname, args)
                    is_error = False
                    tool_results.append({"type": "tool_result",
                                         "tool_use_id": tub.id, "content": result_text})
                except Exception as _mce:
                    _log_error("mcp_tool_call_failed", tool=tname, error=str(_mce))
                    result_text = "Tool call failed: " + str(_mce)
                    is_error = True
                    tool_results.append({"type": "tool_result",
                                         "tool_use_id": tub.id,
                                         "content": result_text, "is_error": True})
            else:
                _log_error("tool_not_dispatchable", tool=tname)
                result_text = "Tool " + tname + " is not available"
                is_error = True
                tool_results.append({"type": "tool_result",
                                     "tool_use_id": tub.id,
                                     "content": result_text, "is_error": True})

            if on_tool_result is not None:
                try: on_tool_result(tname, result_text, is_error)
                except Exception as _cbe: _log_error("tool_loop_callback_failed",
                                                      cb="on_tool_result", error=str(_cbe))

        messages.append({"role": "user", "content": tool_results})
        response = client.messages.create(
            model=model_id, max_tokens=max_tokens,
            system=system, tools=tools_param, messages=messages)

    return full_text


def call_execute_streaming(client,provider,model_id,agent,task,step_context="",file_context="",history=None):
    agent_name=agent.get("name","Norm").lower()
    use_search=(provider=="anthropic" and any(n in agent_name for n in WEB_SEARCH_AGENTS))
    # MCP tools — available to all agents on the Anthropic provider. Silent
    # no-op if no manager is running.
    mcp_tools_list=[]
    if provider=="anthropic" and _MCP_MANAGER is not None:
        try: mcp_tools_list=_MCP_MANAGER.list_tools_for_anthropic()
        except Exception as _e: _log_error("mcp_list_tools_failed",error=str(_e))
    # First-party artifact tools — xlsx/docx/pptx generators. Per-agent gated
    # via allowed_agents in each tool's registration.
    fp_tools_list = _first_party_tools_for_agent(agent_name) if FIRST_PARTY_TOOLS else []
    use_tools = use_search or bool(mcp_tools_list) or bool(fp_tools_list)

    # Skill playbooks — the actual .md bodies of every skill bound to this
    # agent. The agent.json "skills" list above is trigger strings only;
    # without this the executing model never sees skill authoring intent.
    skill_bodies = load_skill_bodies_for_agent(agent_name)

    system=(
        "You are "+agent.get("name","Norm")+", a character from TavernOS.\n"
        "Personality: "+agent.get("personality","")+"\n"
        "Quip style: "+agent.get("quip_style","")+"\n"
        "Skills: "+", ".join(agent.get("skills",[]))+"\n\n"
        "Stay in character. Lead with a brief quip, then do the work."
        +_client_context_block()
        +(("\n\n## Skill playbooks (detailed guidance)\n\n"+skill_bodies) if skill_bodies else "")
        +(("\n\n"+file_context) if file_context else "")
        +("\n\nYou have access to real-time web search. Use it proactively "
          "when the question requires current information, recent events, "
          "or facts that may have changed. Cite your sources inline." if use_search else "")
        +("\n\nIMPORTANT — ARTIFACT TOOLS. You have tool(s) available to "
          "generate real binary deliverables ("+", ".join(sorted(t["name"] for t in fp_tools_list))+"). "
          "When the user asks for a spreadsheet, workbook, report, monthly "
          "business review, KPI dashboard, variance analysis, financial "
          "model, or any deliverable that would normally be an .xlsx, .docx, "
          "or .pptx file, you MUST call the appropriate tool. Do NOT write "
          "the contents of the file in chat as markdown tables, ASCII charts, "
          "or build instructions as a substitute — that is not the "
          "deliverable, that is a replacement for the deliverable, and it "
          "is wrong. The tool takes a JSON spec, writes a real file to "
          "the active client's workspace, and returns the saved path. Your "
          "narration should happen AFTER the tool returns, referencing the "
          "saved file and calling out the 2-3 most important findings." if fp_tools_list else "")
        +"\n\n"+OUTPUT_CONTRACT
    )
    content=task
    if step_context: content+="\n\nContext from previous steps:\n"+step_context
    messages=(history.to_messages() if history else [])
    messages.append({"role":"user","content":content})
    full_text=""
    # Accumulates deliverable banners from first-party tools that succeeded
    # this turn. Printed after the final stream so the UX matches the
    # text-deliverable path below.
    _pending_banners=[]

    # Start personality-appropriate thinking indicator. Stays up during API
    # latency (1-2s typical) and clears the moment the first token arrives.
    phrase=_THINKING_PHRASES.get(agent_name,"thinking")
    _indicator.start(agent.get("name","Norm")+" is "+phrase+"…")
    first_token=False

    # Retry loop — only retries on failures BEFORE the first token arrives.
    # Once streaming starts, we commit to that response (partial > nothing).
    last_error = None
    for attempt in range(3):
        try:
            if provider=="anthropic":
                if use_tools:
                    # Agentic tool-use loop. Extracted into run_tool_use_loop
                    # so the web UI's SSE path can share the same dispatch
                    # code (Path B pass 2 will wire server.py through this).
                    tools_param = ([WEB_SEARCH_TOOL] if use_search else []) + fp_tools_list + mcp_tools_list

                    # Accumulate full_text INSIDE the token callback rather
                    # than from the return value — preserves partial output
                    # if run_tool_use_loop raises mid-flight (matches the
                    # inline original, where full_text grew in step with
                    # each print rather than at end-of-loop).
                    def _on_token(txt):
                        nonlocal full_text
                        print(txt, end="", flush=True)
                        full_text += txt
                    def _on_first():
                        nonlocal first_token
                        if not first_token:
                            _indicator.stop()
                            first_token = True
                    def _on_banner(b):
                        _pending_banners.append(b)

                    run_tool_use_loop(
                        client, model_id, system, messages, tools_param,
                        EXECUTE_MAX_TOKENS, agent_name,
                        on_token=_on_token,
                        on_first_response=_on_first,
                        on_banner=_on_banner,
                    )
                    print()
                else:
                    # Standard streaming for all other agents
                    with client.messages.stream(model=model_id,max_tokens=EXECUTE_MAX_TOKENS,system=system,messages=messages) as stream:
                        for chunk in stream.text_stream:
                            if not first_token: _indicator.stop(); first_token=True
                            print(chunk,end="",flush=True); full_text+=chunk
                    print()
            else:
                # OpenAI streaming (no web search)
                stream=client.chat.completions.create(
                    model=model_id,max_tokens=EXECUTE_MAX_TOKENS,
                    messages=[{"role":"system","content":system}]+messages,stream=True)
                for chunk in stream:
                    delta=chunk.choices[0].delta
                    if hasattr(delta,"content") and delta.content:
                        if not first_token: _indicator.stop(); first_token=True
                        print(delta.content,end="",flush=True); full_text+=delta.content
                print()
            # Success — record recovery if we had to retry
            if attempt > 0:
                _log_error("agent_recovered",
                           agent=agent.get("name","Norm"),
                           attempts=attempt+1,
                           task=task[:200])
            break
        except Exception as e:
            last_error = e
            if first_token:
                # Already started streaming — don't retry, we have partial output
                _log_error("agent_stream_interrupted",
                           agent=agent.get("name","Norm"),
                           error=str(e),
                           partial_text_bytes=len(full_text))
                print()  # newline so any error-message formatting is clean
                break
            if attempt < 2:
                # Pre-first-token failure — safe to retry
                _indicator.update(agent.get("name","Norm")+" is retrying…")
                time.sleep(0.6 * (attempt + 1))
                continue
            # All retries exhausted
            _log_error("agent_failed_all_retries",
                       agent=agent.get("name","Norm"),
                       error=str(e),
                       task=task[:200])

    # Safety net — indicator off, error message if we have nothing
    if not first_token: _indicator.stop()
    if not full_text and last_error:
        full_text = "⚠  Error: " + str(last_error) + "  (logged — type /errors to review)"
        print(full_text)

    # Detect and save any deliverable marker in the response
    deliverable = _process_deliverable_marker(full_text, agent.get("name","Norm"))
    if deliverable:
        print()
        print("  "+tc(C.GREEN,"✓")+"  Deliverable saved: "+tbc(deliverable["filename"]))
        print("  "+dim("   "+deliverable["path"]+" · "+str(deliverable["bytes"])+" bytes"))
        print("  "+dim("   → ")+tc(C.TEAL, deliverable["abs_path"]))
        # Strip the marker from the returned text so downstream code
        # (session history, next step context) doesn't see it
        full_text = DELIVERABLE_MARKER_RE.sub("", full_text).rstrip()
    # Banners for binary deliverables written via first-party tools this turn.
    # Same visual treatment as the text-deliverable marker block above, for
    # UX consistency between Rebecca's xlsx and everyone else's markdown.
    for _b in _pending_banners:
        print()
        print("  "+tc(C.GREEN,"✓")+"  Deliverable saved: "+tbc(_b["filename"]))
        print("  "+dim("   "+_b["path"]+" · "+str(_b["bytes"])+" bytes"))
        # The first-party banner dict carries 'path' as the client-relative
        # form; for a copy-paste-friendly absolute path, resolve through
        # client_deliverables_dir. 'filename' lets us rebuild the abs path.
        _abs = (client_deliverables_dir() / "reports" / _b["filename"])
        if not _abs.exists():
            # xlsx is reports/; docx defaults to content/; pptx defaults to reports/.
            # Try the other two subfolders before giving up.
            for _sub in ("content", "audits", "blueprints"):
                _alt = client_deliverables_dir() / _sub / _b["filename"]
                if _alt.exists(): _abs = _alt; break
        if _abs.exists():
            print("  "+dim("   → ")+tc(C.TEAL, str(_abs)))
        # Phase 3 — evaluation. Two modes, chosen via config.eval_mode:
        #   "async" (default): fire-and-forget eval on a daemon thread. Banner
        #       appears immediately, score lands in the DB within ~10s. Review
        #       later via /scores --deliverables or /eval <filename>. No regen.
        #   "sync":  block the UI for the eval call. If below threshold, build
        #       a regeneration prompt from the failing dimensions' triggers,
        #       re-invoke run_tool_use_loop with the feedback prepended, and
        #       reassess. Capped at 2 regen attempts, then surface with a
        #       warning banner showing failing dims.
        eval_mode = _get_eval_mode()
        if eval_mode == "sync" and _evaluator is not None:
            _handle_sync_eval_and_regen(
                _b, client, provider, model_id, agent,
                system, messages,
                tools_param if use_tools else [],
            )
        else:
            _trigger_deliverable_eval(_b, client, provider, model_id,
                                      agent.get("name","Norm"), config=None)
    return full_text.strip()


def _handle_sync_eval_and_regen(banner, client, provider, model_id, agent,
                                system, messages, tools_param):
    """Synchronous evaluator pass with up to 2 regeneration attempts.

    Design: runs eval, prints the score banner (pass or fail). If below
    threshold, appends a REGENERATION user turn with feedback derived from
    the failing dimensions' rubric triggers, then re-invokes
    run_tool_use_loop with the same tools so the generator can call the
    artifact tool again. The regenerated deliverable overwrites the prior
    file (same filename → same disk path). Each regen is itself evaluated;
    if after 2 regens the score still fails, the final score surfaces with
    a warning banner and the operator sees what dimensions are weak.

    Why inline here vs. in run_tool_use_loop: regen is a deliverable-level
    concern, not a tool-use-loop concern. The loop's job is to dispatch
    tool calls; the concept of 'this deliverable deserves another pass' is
    rubric-driven and lives at this layer."""
    if _evaluator is None:
        return
    max_attempts = 2
    attempts = 0
    current_banner = banner
    while True:
        ctx = _evaluate_banner_sync(current_banner, client, provider, model_id,
                                     agent.get("name","Norm"))
        if ctx is None:
            # No rubric or no context — nothing to evaluate
            return
        result, template, abs_path, spec_context = ctx
        rubric = _evaluator.RUBRICS[template]

        # Show the one-line score banner regardless of pass/fail
        _print_score_banner(result, rubric, attempts)

        if result.pass_threshold or result.error is not None:
            # Passed, or evaluator errored — no regeneration
            return
        if attempts >= max_attempts:
            print("  "+tc(C.AMBER,"⚠")+"  Still below threshold after "
                  +str(max_attempts)+" regeneration attempt(s). "
                  +dim("Deliverable shipped as-is — manual review recommended."))
            return

        # Build the regeneration prompt and re-invoke the loop
        regen_prompt = _evaluator.build_regeneration_prompt(result, template)
        attempts += 1
        print("  "+tc(C.AMBER,"↻")+"  Regenerating (attempt "+str(attempts)
              +"/"+str(max_attempts)+")…")
        messages.append({"role": "user", "content": regen_prompt})

        # Track new banners from the regen call
        _regen_banners = []
        def _on_banner_regen(b):
            _regen_banners.append(b)

        try:
            run_tool_use_loop(
                client, model_id, system, messages, tools_param,
                EXECUTE_MAX_TOKENS, agent.get("name","Norm").lower(),
                on_token=lambda txt: print(txt, end="", flush=True),
                on_banner=_on_banner_regen,
            )
            print()
        except Exception as _re:
            _log_error("regen_failed", error=str(_re),
                       agent=agent.get("name","Norm"), template=template)
            print("  "+tc(C.AMBER,"⚠")+"  Regeneration raised: "+str(_re)[:120])
            return
        if not _regen_banners:
            print("  "+dim("Regen completed but no new deliverable emitted. "
                           "Keeping prior score."))
            return
        # Pick up the new banner — we re-evaluate the regenerated deliverable
        # on the next loop iteration. If multiple banners came back (rare),
        # evaluate the first and ignore the rest.
        current_banner = _regen_banners[0]


def _print_score_banner(result, rubric, attempts: int) -> None:
    """Render the one-line score banner + failing-dim detail. Operator-facing."""
    lines = _evaluator.format_score_banner(result, rubric, attempts)
    score = result.weighted_avg
    sc = C.GREEN if score >= 4.0 else (C.AMBER if score >= 3.0 else C.RED)
    first = lines[0] if lines else ""
    print("  "+tc(C.TEAL, "▸") + "  " + tc(sc, first))
    for extra in lines[1:]:
        if extra.startswith("⚠"):
            print("  " + tc(C.AMBER, extra))
        else:
            print("  " + dim(extra))


def _trigger_deliverable_eval(banner: dict, client, provider: str, model_id: str,
                              agent_name: str, config=None) -> None:
    """Kick off an evaluator pass on a saved deliverable. Non-blocking —
    spawns a daemon thread and returns immediately. Silently no-ops if
    the evaluator module didn't import or no matching rubric exists for
    the deliverable's template (logged, but not surfaced — this is a
    back-office subsystem)."""
    if _evaluator is None:
        return
    ctx = _resolve_banner_eval_context(banner)
    if ctx is None:
        return
    _abs, spec_context, template = ctx
    available_models = get_available_models({}) or FALLBACK_MODELS
    client_slug = get_active_client_slug() or DEFAULT_CLIENT_SLUG

    _evaluator.evaluate_in_background(
        _evaluator.evaluate_and_persist,
        client, provider, model_id,
        agent_name.lower(), template,
        banner["filename"], _abs,
        spec_context, client_slug,
        _perf_db_path(), _perf_global_db_path(),
        available_models,
        2,  # max_regen_attempts — unused in async path, preserved for sync mode
        _log_error,
    )


def _resolve_banner_eval_context(banner: dict):
    """Shared lookup: given a deliverable banner dict, return
    (abs_path, spec_context, template) or None if we can't find enough
    information to evaluate. Used by both the async trigger and the sync
    regen-capable path so both paths reach rubrics the same way."""
    _abs = None
    for _sub in ("reports", "content", "audits", "blueprints"):
        _cand = client_deliverables_dir() / _sub / banner["filename"]
        if _cand.exists(): _abs = _cand; break
    if _abs is None:
        _log_error("eval_deliverable_not_found", filename=banner["filename"])
        return None
    _sidecar = _abs.with_suffix(".spec.json")
    spec_context = None
    template = None
    if _sidecar.exists():
        try:
            spec_context = json.loads(_sidecar.read_text(encoding="utf-8"))
            template = spec_context.get("template")
        except Exception as _se:
            _log_error("eval_sidecar_read_failed", filename=banner["filename"], error=str(_se))
    if template is None:
        _log_error("eval_template_unknown", filename=banner["filename"])
        return None
    if _evaluator is not None and template not in _evaluator.RUBRICS:
        # No rubric for this type yet — not an error, just a skip
        return None
    return (_abs, spec_context, template)


def _evaluate_banner_sync(banner: dict, client, provider: str, model_id: str,
                          agent_name: str):
    """Run evaluation synchronously and return (EvalResult, template,
    abs_path, spec_context). Persists the score to the DB as a side effect,
    matching the async path. Returns None if the deliverable can't be
    evaluated (no rubric, file missing, etc.) — callers treat that as
    'nothing to regen, ship as-is'."""
    if _evaluator is None:
        return None
    ctx = _resolve_banner_eval_context(banner)
    if ctx is None:
        return None
    _abs, spec_context, template = ctx
    available_models = get_available_models({}) or FALLBACK_MODELS
    client_slug = get_active_client_slug() or DEFAULT_CLIENT_SLUG
    try:
        result = _evaluator.evaluate_and_persist(
            client, provider, model_id,
            agent_name.lower(), template,
            banner["filename"], _abs,
            spec_context, client_slug,
            _perf_db_path(), _perf_global_db_path(),
            available_models,
            2, _log_error,
        )
    except Exception as _ee:
        _log_error("eval_sync_failed", error=str(_ee), filename=banner["filename"])
        return None
    if result is None:
        return None
    return (result, template, _abs, spec_context)


def _get_eval_mode(config=None) -> str:
    """Return the configured evaluation mode. 'async' (default) fires
    evaluator on a daemon thread — non-blocking, no regeneration. 'sync'
    blocks the UI for evaluation, enables regeneration if below threshold.
    Operator switches via /eval mode <async|sync>."""
    if config is None:
        try:
            config = load_config()
        except Exception:
            return "async"
    mode = config.get("eval_mode", "async")
    if mode not in ("async", "sync"): return "async"
    return mode


def execute_plan(client,provider,model_id,agents,plan,original,history,mode=Mode.CUSTOMER):
    intent=plan.get("intent",original); steps=plan.get("steps",[]); bw=_box_width()
    file_context=memory_build_file_context(query=original)
    print(); print(box_top("SAM'S PLAN"))
    print(box_row(dim("Intent")+" : "+tc(C.WHITE,_truncate(intent,bw-12))))
    print(box_row(dim("Model") +"  : "+tc(C.TEAL,_truncate(model_id,30))+" "+dim("["+provider+"]")))
    print(box_row(dim("Steps") +"  : "+tc(C.TEAL,str(len(steps)))))
    print(box_divider())
    for i,s in enumerate(steps,1):
        print(box_row(tc(C.TEAL,str(i))+". ["+tbc(s.get("agent","?").upper())+"] "+dim(_truncate(s.get("task",""),bw-12))))
    print(box_bottom())
    if plan.get("needs_new_skill") and plan.get("new_skill_name"):
        fn=create_skill_file(plan["new_skill_name"],plan.get("new_skill_description") or "New skill")
        print("  "+tc(C.AMBER,"🛠")+"  Sam built a new skill: "+tbc(fn))
    step_context=""; full_response=""
    for i,step in enumerate(steps,1):
        aname=step.get("agent","norm").lower(); task=step.get("task",""); skill=step.get("skill") or aname
        agent=agents.get(aname,agents.get("norm",{})); name=agent.get("name",aname.title())
        _indicator.stop(); agent_thinking_header(name,task)
        result=call_execute_streaming(client,provider,model_id,agent,task,step_context=step_context,file_context=file_context,history=history)
        if mode==Mode.DEV: perf_score_async(client,provider,model_id,agent=name,skill=skill,task=task,response=result)
        step_context="Step "+str(i)+" ("+aname+"):\n"+result
        full_response+=("\n\n" if full_response else "")+result
        if i<len(steps):
            next_name=agents.get(steps[i].get("agent","?"),{}).get("name",steps[i].get("agent","?").title())
            print(); print(tc(C.TEAL,"─"*_term_width())); _indicator.start(next_name+" is reading the above…")
    print()
    print(tc(C.GREEN,"✓")+"  "+tbc("All steps complete. Round's on the house."))
    print("  "+dim("Rate this response: ")+tc(C.TEAL,"/feedback 5")+dim(" (or 1-4) — or just keep going"))
    print()
    history.add_assistant(full_response)
    memory_save_conversation(original,intent,[s.get("agent") for s in steps])


def print_agent(agent,task=""):
    name=agent.get("name","Unknown"); bw=_box_width()
    print(); print(agent_box_top(name))
    print(agent_box_row(dim(agent.get("personality","Ready to help."))))
    if agent.get("quip_style"): print(agent_box_row(tc(C.WHITE,'"'+agent["quip_style"]+'"')))
    if agent.get("skills"): print(agent_box_row(dim("Skills: ")+tc(C.TEAL,_truncate(", ".join(agent["skills"]),bw-12))))
    print(agent_box_bottom())

def create_skill_file(name_raw, description, agent="norm", pack="custom"):
    """Create a new `.skill.md` file with frontmatter that matches the
    pack-authoring convention. `agent` and `pack` default to 'norm' / 'custom'
    for ad-hoc user-created skills (via `sam create a new skill called ...`);
    skills authored for a named service pack should pass the correct values."""
    slug = name_raw.strip().replace(" ","-").lower()
    filename = slug+".skill.md"
    content = (
        "---\n"
        "name: "+name_raw.title()+"\n"
        "trigger: "+slug.replace("-"," ")+"\n"
        "description: "+description+"\n"
        "agent: "+agent+"\n"
        "pack: "+pack+"\n"
        "steps:\n"
        "  - Understand the request\n"
        "  - Apply appropriate skills\n"
        "  - Deliver high-quality output\n"
        "chaining: true\n"
        "---\n\n"
        "You are the "+name_raw.title()+" skill.\n"
    )
    with open(SKILLS_DIR/filename,"w",encoding="utf-8") as f:
        f.write(content)
    return filename

def skill_display_name(path):
    name=path.name; return name[:-len(".skill.md")] if name.endswith(".skill.md") else name

def load_skill_bodies_for_agent(agent_name: str, max_chars: int = 40000) -> str:
    """Concatenate .md bodies of every skill whose frontmatter binds to
    `agent_name` (case-insensitive). Returns "" if nothing matches.

    Skills live at SKILLS_DIR/<slug>.skill.md with YAML frontmatter; the
    authoritative agent→skill binding is the frontmatter `agent:` field
    (what create_skill_file writes), NOT agent.json's "skills" list — that
    one carries trigger strings for the router, not skill identities.

    Bodies are headered by slug, ordered alphabetically, and the total is
    soft-capped at `max_chars` to bound context cost if a skill file goes
    rogue (corrupt, runaway pack). With 32 skills across 10 agents today,
    no agent should push more than ~15KB; the cap is a guard, not a floor."""
    if not SKILLS_DIR.exists(): return ""
    target = agent_name.lower()
    chunks, total, truncated = [], 0, False
    for path in sorted(SKILLS_DIR.glob("*.skill.md")):
        try: text = path.read_text(encoding="utf-8")
        except Exception: continue
        if not text.startswith("---"): continue
        end = text.find("\n---", 3)
        if end < 0: continue
        fm, body = text[3:end], text[end+4:].lstrip()
        bound = ""
        for line in fm.splitlines():
            if line.strip().lower().startswith("agent:"):
                bound = line.split(":",1)[1].strip().lower(); break
        if bound != target: continue
        chunk = "## " + path.name[:-len(".skill.md")] + "\n\n" + body.strip()
        if total + len(chunk) > max_chars: truncated = True; break
        chunks.append(chunk); total += len(chunk) + 2
    if truncated:
        try: _log_error("skill_bodies_truncated", agent=agent_name, cap=max_chars)
        except Exception: pass
    return "\n\n".join(chunks)


# ═══════════════════════════════════════════════════════════════════════════════
#  WEB UI RESILIENCE — port check, already-running detection, browser auto-open
# ═══════════════════════════════════════════════════════════════════════════════

WEB_HOST = "127.0.0.1"
WEB_PORT = 7777
WEB_URL  = "http://" + WEB_HOST + ":" + str(WEB_PORT)

def _check_web_port(host: str = WEB_HOST, port: int = WEB_PORT, timeout: float = 1.5):
    """Probe the web-UI port. Returns a tuple (status, detail) where status is:
      - 'free'  : nothing bound to the port → safe to start
      - 'norm'  : TavernOS is already serving there
      - 'other' : port is in use but not by TavernOS (port conflict)
    `detail` carries a short snippet to help the user diagnose conflicts."""
    import socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(timeout)
    try:
        s.connect((host, port))
    except (socket.timeout, ConnectionRefusedError, OSError):
        try: s.close()
        except Exception: pass
        return ("free", None)
    try: s.close()
    except Exception: pass
    # Port is bound — probe with HTTP to see if it's our server
    try:
        req = urllib.request.Request("http://"+host+":"+str(port)+"/",
                                     headers={"User-Agent":"TavernOS/0.1.0"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            body = r.read(4096).decode("utf-8", errors="replace")
        if "tavernos" in body.lower() or "TavernOS" in body:
            return ("norm", None)
        return ("other", body[:160].replace("\n"," ").strip())
    except Exception as e:
        return ("other", "(bound but not serving HTTP: "+str(e)[:80]+")")

def _open_browser_soon(delay: float = 1.2, url: str = WEB_URL) -> None:
    """Open the user's default browser to `url` after a short delay.
    Skips if stdout is not a TTY (e.g., running under launchd / Task Scheduler)
    so autostart doesn't spam a browser window at every login."""
    if not sys.stdout.isatty():
        return
    try:
        import webbrowser
        threading.Timer(delay, lambda: webbrowser.open(url)).start()
    except Exception:
        pass

def handle_web_status():
    """Implementation of --web-status — check whether the UI is running, report."""
    status, detail = _check_web_port()
    if status == "free":
        print("  "+tc(C.AMBER,"⚠")+"  Web UI is "+tc(C.WHITE,"not running")+".")
        print("  "+dim("Start it with: ")+tc(C.TEAL,"norm --web"))
    elif status == "norm":
        print("  "+tc(C.GREEN,"✓")+"  Web UI is "+tbc("running")+" at "+tc(C.TEAL,WEB_URL))
    else:
        print("  "+tc(C.AMBER,"⚠")+"  Port "+tc(C.WHITE,str(WEB_PORT))+" is in use but "+tc(C.WHITE,"not by TavernOS")+".")
        if detail: print("  "+dim("Response: ")+detail)
        print("  "+dim("Find what's on it — Windows: ")+tc(C.TEAL,"netstat -ano | findstr "+str(WEB_PORT)))
        print("  "+dim("                      Mac:     ")+tc(C.TEAL,"lsof -iTCP:"+str(WEB_PORT)))

def handle_web_start():
    """Implementation of --web — pre-flight check, clean messaging, auto-open browser."""
    status, detail = _check_web_port()
    if status == "norm":
        print("  "+tc(C.GREEN,"✓")+"  Web UI is already running at "+tc(C.TEAL,WEB_URL))
        print("  "+dim("Opening browser…"))
        _open_browser_soon(delay=0.2)
        # Give the Timer a moment to fire before main() returns
        time.sleep(0.5)
        return
    if status == "other":
        print("  "+tc(C.RED,"✗")+"  Port "+tc(C.WHITE,str(WEB_PORT))+" is already in use by another program.")
        if detail: print("  "+dim("Response: ")+detail)
        print("  "+dim("Find and close it — Windows: ")+tc(C.TEAL,"netstat -ano | findstr "+str(WEB_PORT)))
        print("  "+dim("                     Mac:     ")+tc(C.TEAL,"lsof -iTCP:"+str(WEB_PORT)))
        return
    # Port is free — start the server
    try:
        from tavernos.web.server import start
    except Exception as e:
        print("  "+tc(C.RED,"✗")+"  Couldn't import web server module: "+str(e))
        print("  "+dim("Ensure tavernos/web/server.py exists and its deps are installed.")); return
    print("  "+tc(C.TEAL,"⟳")+"  Starting TavernOS web UI at "+tbc(WEB_URL))
    _open_browser_soon()
    try:
        start()
    except KeyboardInterrupt:
        print(); print("  "+dim("Web UI stopped."))
    except Exception as e:
        print("  "+tc(C.RED,"✗")+"  Web UI crashed: "+str(e))
        print("  "+dim("If this keeps happening, check logs at ~/.tavernos/diagnostics/ or run again with --dev."))


# ═══════════════════════════════════════════════════════════════════════════════
#  MCP COMMAND HANDLERS — /mcp subcommands. Live here so all teal/navy
#  terminal styling stays in norm.py; mcp_client.py stays a pure module.
# ═══════════════════════════════════════════════════════════════════════════════

def _handle_mcp_list_cmd(manager):
    cfg=load_mcp_config(); servers=cfg.get("servers",{})
    if not servers:
        print(); print("  "+dim("No MCP servers configured."))
        print("  "+dim("Add one with ")+tc(C.TEAL,"/mcp add")+dim(" or edit ")+tc(C.WHITE,str(MCP_SERVERS_FILE))); print()
        return
    connected={n:c for n,c in (manager.connected_servers() if manager else [])}
    print(); print("  "+tbc("MCP servers ("+str(len(servers))+"):"))
    for name,scfg in servers.items():
        enabled=scfg.get("enabled",True)
        if name in connected:
            status=tc(C.GREEN,"✓ connected"); tools=str(connected[name])+" tool"+("s" if connected[name]!=1 else "")
        elif not enabled:
            status=dim("· disabled"); tools="-"
        else:
            status=tc(C.AMBER,"○ not running"); tools="-"
        print("    "+tc(C.TEAL,"•")+" "+tbc(name)+"  "+status+dim("  · "+tools))
        _argstr=" ".join(scfg.get("args",[]) or [])
        print("      "+dim(scfg.get("command","")+" "+_argstr))
    print()

def _handle_mcp_add_cmd():
    print(); print("  "+tbc("Add an MCP server."))
    print("  "+dim("Writes to ")+tc(C.WHITE,str(MCP_SERVERS_FILE))+dim(". Run /mcp restart after to connect."))
    print()
    try:
        name=input("  Server name (short, alphanumeric): ").strip()
        if not name: print("  "+dim("Cancelled.")); return
        command=input("  Command (e.g. python, npx, node): ").strip()
        if not command: print("  "+dim("Cancelled.")); return
        args_raw=input("  Args (space-separated, use quotes for paths with spaces — one arg per token): ").strip()
    except (EOFError,KeyboardInterrupt):
        print(); print("  "+dim("Cancelled.")); return
    args=args_raw.split() if args_raw else []
    cfg=load_mcp_config(); cfg.setdefault("servers",{})[name]={
        "command":command,"args":args,"env":{},"enabled":True
    }
    save_mcp_config(cfg)
    print(); print("  "+tc(C.GREEN,"✓")+" Saved "+tbc(name)+dim(". Run ")+tc(C.TEAL,"/mcp restart")+dim(" to connect.")); print()

def _handle_mcp_remove_cmd(name):
    if not name: print("  "+tc(C.AMBER,"⚠")+" Usage: "+tc(C.TEAL,"/mcp remove <name>")); return
    cfg=load_mcp_config(); servers=cfg.get("servers",{})
    if name not in servers: print("  "+tc(C.AMBER,"⚠")+" No server named "+tbc(name)); return
    del servers[name]; save_mcp_config(cfg)
    print("  "+tc(C.GREEN,"✓")+" Removed "+tbc(name)+dim(". Run ")+tc(C.TEAL,"/mcp restart")+dim(" to apply."))

def _handle_mcp_tools_cmd(manager):
    if manager is None:
        print("  "+dim("MCP not running. ")+tc(C.TEAL,"/mcp restart")+dim(" to start configured servers.")); return
    tools=manager.list_tools_for_anthropic()
    if not tools:
        print("  "+dim("No tools available from connected servers.")); return
    print(); print("  "+tbc("Available MCP tools ("+str(len(tools))+"):"))
    for t in tools:
        desc=(t.get("description") or "").splitlines()[0][:80]
        print("    "+tc(C.TEAL,"★")+" "+tbc(t["name"]))
        if desc: print("      "+dim(desc))
    print()


# ═══════════════════════════════════════════════════════════════════════════════
#  MAIN
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    parser=argparse.ArgumentParser(description="TavernOS — Norm!")
    parser.add_argument("--web",action="store_true"); parser.add_argument("--version",action="store_true")
    parser.add_argument("--web-status",dest="web_status",action="store_true",help="Check whether the web UI is running")
    parser.add_argument("--setup",action="store_true"); parser.add_argument("--dev",action="store_true")
    parser.add_argument("--staging",action="store_true")
    parser.add_argument("--client",type=str,default=None,help="Boot into a specific client workspace (slug)")
    parser.add_argument("--batch",type=str,default=None,metavar="FILE",help="Non-interactive: run commands from FILE then exit")
    args=parser.parse_args(); mode=_resolve_mode(args.dev,args.staging)

    if args.version: print("TavernOS "+mode_version(mode)); return
    if args.web_status: handle_web_status(); return
    if args.setup:
        if not mode_allows(mode,"setup"): print("  "+tc(C.AMBER,"⚠")+" "+_blocked_msg("setup")); return
        run_setup(); return
    if args.web:
        handle_web_start(); return

    config_path=_config_file_for_mode(mode)
    if not config_path.exists():
        if mode==Mode.STAGING and CONFIG_FILE.exists():
            config=create_staging_config(load_config(Mode.DEV))
            print("  "+tc(C.TEAL,"⟳")+" Created staging config from dev config.")
        elif mode==Mode.CUSTOMER:
            config=run_onboarding_wizard(); time.sleep(1.0)
        else:
            print(_splash()); print("  "+tc(C.AMBER,"⚠")+" No dev config found at "+str(CONFIG_FILE))
            print("  "+dim("Run norm (without --dev) to go through the setup wizard first.")); print(); return
    else:
        config=migrate_config(load_config(mode),mode)

    print(_splash()); company=config.get("company_name","TavernOS")
    print(mode_greeting(mode,company)); banner=mode_banner(mode,company)
    if banner: print(banner); print()

    USER_DIR.mkdir(parents=True,exist_ok=True); DIAG_DIR.mkdir(parents=True,exist_ok=True)

    # Pack 0 — multi-client workspace setup. Runs migration on first launch.
    _pack0_migrated = ensure_self_client_exists()
    if _pack0_migrated:
        print()
        print("  "+tc(C.TEAL,"◆")+" "+tbc("Multi-client mode enabled."))
        print("  "+dim("Your existing data is now under workspace: ")+tc(C.WHITE,"_self"))
        print("  "+dim("Add your first paying client with: ")+tc(C.TEAL,"/client new"))
        print()

    # Honor --client flag (validate existence, else fall back to last-active)
    if args.client:
        if client_exists(args.client):
            set_active_client_slug(args.client)
        else:
            print("  "+tc(C.AMBER,"⚠")+" Client "+tc(C.WHITE,args.client)+" not found — staying on last-active workspace.")

    # Show which client we're operating for (only if it's not _self — _self is the default)
    _active_slug = get_active_client_slug()
    if _active_slug != DEFAULT_CLIENT_SLUG:
        print(client_status_line(config)); print()

    # ─── Startup: show visible progress during the silent work ──────────────
    # DB inits + network calls can take several seconds on first launch or
    # on weeks with skill updates. Keep the user informed with an animated
    # indicator that evolves through each phase.
    _indicator.start("Opening the memory shelves…")
    memory_init(); perf_db_init(); vector_db_init(); feedback_db_init()

    if semantic_available(): threading.Thread(target=_get_embed_model,daemon=True).start()

    history=ConversationHistory(max_pairs=MAX_HISTORY)

    _auto_result=[]
    _auto_thread=threading.Thread(target=lambda:_auto_result.append(auto_update_skills(config)),daemon=True)
    _auto_thread.start()

    _indicator.update("Checking for updates…")
    pending_update=None
    if mode_allows(mode,"update"):
        try:
            pending_update=check_for_updates(config)
        except Exception: pass

    _indicator.update("Connecting to the model…")
    client,provider,model_id=build_client(config)

    # ── MCP client bootstrap ───────────────────────────────────────────────
    # Goes through ensure_mcp_manager so CLI + web UI + /mcp restart share
    # one init code path. Silent no-op when SDK missing / non-anthropic /
    # no servers configured. Any failure is journaled and surfaces in the
    # connect summary below.
    _, _mcp_connect_summary = ensure_mcp_manager(
        provider,
        on_about_to_start=lambda: _indicator.update("Starting MCP servers…"),
    )

    # First-party artifact tools — xlsx now, docx/pptx as they ship.
    # Safe no-op when no artifact modules imported (see FIRST_PARTY_TOOLS).
    try:
        _register_first_party_tools()
    except Exception as _fpr_e:
        _log_error("first_party_tool_register_failed", error=str(_fpr_e))

    _indicator.update("Fetching any new skills…")
    _auto_thread.join(timeout=4)

    # All startup work done — stop spinner before printing completion lines
    _indicator.stop()

    if pending_update: print_update_notification(pending_update)

    if client:
        ver=mode_version(mode); sem_note=" · semantic search" if semantic_available() else ""
        print("  "+tc(C.GREEN,"✓")+"  "+tbc(model_id)+" "+dim("["+provider.upper()+"]")+" "+dim("— streaming enabled · "+ver+sem_note))
    else:
        print("  "+tc(C.AMBER,"⚠")+"  No API client — check your key with /provider add")

    # MCP summary — visible only when something actually connected
    if _mcp_connect_summary:
        _ok=sum(1 for s in _mcp_connect_summary.values() if s.get("status")=="connected")
        _fail=sum(1 for s in _mcp_connect_summary.values() if s.get("status")=="error")
        if _ok>0:
            _tools_total=sum(s.get("tools",0) for s in _mcp_connect_summary.values() if s.get("status")=="connected")
            print("  "+tc(C.GREEN,"✓")+"  MCP: "+tc(C.TEAL,str(_ok))+dim(" server"+("s" if _ok!=1 else "")+" · "+str(_tools_total)+" tool"+("s" if _tools_total!=1 else "")+" available"))
        if _fail>0:
            print("  "+tc(C.AMBER,"⚠")+"  MCP: "+str(_fail)+" server(s) failed to start — see /errors")

    if _auto_result and _auto_result[0]>0:
        count=_auto_result[0]
        print("  "+tc(C.GREEN,"✓")+"  "+tc(C.TEAL,str(count))+dim(" skill"+("s" if count!=1 else "")+" updated automatically."))

    files=memory_list_files()
    if files:
        names=", ".join(tc(C.TEAL,f["name"]) for f in files[:5])
        print("  "+tc(C.TEAL,"📄")+" "+str(len(files))+" file(s) in memory: "+names)

    print("  "+dim("/model to switch · /help for all commands")); print()

    agents={}
    if AGENTS_DIR.exists():
        for f in AGENTS_DIR.glob("*.json"):
            try:
                with open(f,"r",encoding="utf-8") as fh: a=json.load(fh); agents[a.get("name",f.stem).lower()]=a
            except Exception: pass

    print(dim("Type /help for commands, or just tell the tavern what you need.")); print()

    # ── Batch mode setup ────────────────────────────────────────────────────
    # If --batch <file> was provided, read the file into a list of commands.
    # We'll pull from this list instead of input() inside the loop below.
    # Blank lines and lines starting with '#' are treated as comments.
    batch_lines = None
    batch_idx   = 0
    if args.batch:
        try:
            batch_path = Path(args.batch).expanduser()
            if not batch_path.exists():
                print("  "+tc(C.RED,"✗")+" Batch file not found: "+str(batch_path)); return
            with open(batch_path, encoding="utf-8") as f:
                batch_lines = [ln.rstrip("\n") for ln in f.readlines()]
            executable = sum(1 for ln in batch_lines if ln.strip() and not ln.strip().startswith("#"))
            print("  "+tc(C.TEAL,"⟳")+" Batch mode — "+tbc(str(executable))+" command"+("s" if executable!=1 else "")
                  +" queued from "+tc(C.WHITE,str(batch_path)))
            print("  "+dim("Interactive commands (/client new, /model, /provider add) are not supported in batch mode.")); print()
        except Exception as e:
            print("  "+tc(C.RED,"✗")+" Couldn't read batch file: "+str(e)); return

    while True:
        try:
            if batch_lines is not None:
                # Skip blank lines and '#' comments
                while batch_idx < len(batch_lines) and (
                    not batch_lines[batch_idx].strip()
                    or batch_lines[batch_idx].strip().startswith("#")
                ):
                    batch_idx += 1
                if batch_idx >= len(batch_lines):
                    print(); print("  "+tc(C.GREEN,"✓")+" Batch complete."); break
                raw = batch_lines[batch_idx].strip()
                batch_idx += 1
                # Echo the command so batch output reads clearly
                print(tc(C.TEAL,"❯")+" "+tc(C.WHITE,raw))
            else:
                if mode==Mode.DEV:       prompt=tc(C.AMBER,"[DEV] ")+tc(C.TEAL,"❯")
                elif mode==Mode.STAGING: prompt=tc(C.TEAL,"[STG] ❯")
                else:                    prompt=tc(C.TEAL,"❯")
                # Optional [slug] prefix — enable via config: "show_client_in_prompt": true
                if config.get("show_client_in_prompt"):
                    _s = get_active_client_slug()
                    if _s and _s != DEFAULT_CLIENT_SLUG:
                        prompt = tc(C.TEAL,"["+_s+"] ") + prompt
                raw=input(prompt+" ").strip()
        except (EOFError,KeyboardInterrupt): print(); print(dim("Closing the tavern...")); break

        if not raw: continue
        cmd=raw.lower()
        _touch_active_client()  # keep last_active current for /client list sorting

        if cmd in ["exit","quit"]: print(dim("Closing the tavern... See you next time.")); break
        elif cmd=="/help":    print(_build_help(mode))
        elif cmd=="/history": history.display()
        elif cmd=="/files":   list_files()
        elif cmd=="/clear":   history.clear(); print("  "+tc(C.GREEN,"✓")+" Conversation history cleared."); print()
        elif cmd=="/errors":  show_errors()
        elif cmd=="/scores" or cmd=="/scores --global":
            if mode_allows(mode,"scores"): show_scores(global_view=(cmd=="/scores --global"))
            else: print("  "+tc(C.AMBER,"⚠")+" "+_blocked_msg("scores"))
        elif cmd=="/scores --deliverables":
            if mode_allows(mode,"scores"): show_deliverable_scores()
            else: print("  "+tc(C.AMBER,"⚠")+" "+_blocked_msg("scores"))
        elif cmd=="/eval" or cmd=="/eval last":
            # Show the most recent scored deliverable
            if _evaluator is None:
                print("  "+tc(C.AMBER,"⚠")+" Evaluator module unavailable.")
            else:
                recent = _evaluator.list_recent_scores(_perf_db_path(), limit=1)
                if not recent: print("  "+dim("No deliverable scores yet."))
                else: show_eval_detail(recent[0]["filename"])
        elif cmd == "/eval calibrate":
            handle_eval_calibrate("")
        elif cmd.startswith("/eval calibrate "):
            handle_eval_calibrate(raw[len("/eval calibrate "):].strip())
        elif cmd == "/eval calibration":
            show_calibration_report()
        elif cmd == "/eval mode":
            current = _get_eval_mode(config)
            print()
            print("  "+dim("Current evaluation mode: ")+tc(C.TEAL, current))
            print("  "+dim("  async — fire-and-forget, no regen (default)"))
            print("  "+dim("  sync  — block for eval, auto-regen up to 2× below threshold"))
            print("  "+dim("Switch: ")+tc(C.TEAL,"/eval mode async")+dim(" or ")+tc(C.TEAL,"/eval mode sync"))
            print()
        elif cmd.startswith("/eval mode "):
            new_mode = raw[len("/eval mode "):].strip().lower()
            if new_mode not in ("async", "sync"):
                print("  "+tc(C.AMBER,"⚠")+" Mode must be 'async' or 'sync'.")
            else:
                config["eval_mode"] = new_mode
                try:
                    save_config(config, mode)
                    print("  "+tc(C.GREEN,"✓")+" Eval mode: "+tc(C.TEAL, new_mode))
                    if new_mode == "sync":
                        print("  "+dim("  Deliverables now block for evaluation + auto-regen (up to 2×)."))
                    else:
                        print("  "+dim("  Deliverables ship immediately; eval runs in background."))
                except Exception as _ce:
                    print("  "+tc(C.RED,"✗")+" Could not save config: "+str(_ce))
        elif cmd.startswith("/eval "):
            show_eval_detail(raw[len("/eval "):].strip())
        elif cmd.startswith("/save "):
            handle_save_command(raw, history)
        elif cmd=="/export" or cmd.startswith("/export "):
            handle_export_command(raw, history)
        elif cmd=="/who":                        show_who()
        elif cmd in ("/client","/client info"):  show_client_info()
        elif cmd=="/client summary":             show_client_summary()
        elif cmd=="/client list":                show_client_list()
        elif cmd=="/client switch":              print("  "+tc(C.AMBER,"⚠")+" Usage: "+tc(C.TEAL,"/client switch <slug>")+dim("   (try /client list to see slugs)"))
        elif cmd.startswith("/client switch "):  _switch_client(raw[len("/client switch "):].strip(), history)
        elif cmd=="/client new":                 interactive_client_create()
        elif cmd=="/client edit":                edit_client_manifest()
        elif cmd=="/client archive":             print("  "+tc(C.AMBER,"⚠")+" Usage: "+tc(C.TEAL,"/client archive <slug>"))
        elif cmd.startswith("/client archive "): client_archive_action(raw[len("/client archive "):].strip())
        elif cmd=="/client restore":             print("  "+tc(C.AMBER,"⚠")+" Usage: "+tc(C.TEAL,"/client restore <slug>"))
        elif cmd.startswith("/client restore "): client_restore_action(raw[len("/client restore "):].strip())
        elif cmd=="/client deliver":             list_deliverables()
        elif cmd=="/client package":             package_current_client()
        elif cmd=="/note" or cmd.startswith("/note "): handle_note_command(raw)
        elif cmd=="/notes":                      show_notes()
        elif cmd=="/client scan":                scan_intake_interactive()
        elif cmd=="/update":
            if not mode_allows(mode,"update"): print("  "+tc(C.AMBER,"⚠")+" "+_blocked_msg("update"))
            else:
                do_update(config,pending_update); pending_update=None
                if AGENTS_DIR.exists():
                    for f in AGENTS_DIR.glob("*.json"):
                        try:
                            with open(f,"r",encoding="utf-8") as fh: a=json.load(fh); agents[a.get("name",f.stem).lower()]=a
                        except Exception: pass
        elif cmd=="/whats-new":
            if mode_allows(mode,"update"): show_whats_new(config,pending_update)
            else: print("  "+tc(C.TEAL,"✓")+" You're on the latest version.")
        elif cmd.startswith("/skill list"):
            files_s=list(SKILLS_DIR.glob("*.skill.md")) if SKILLS_DIR.exists() else []
            if files_s:
                print(); print("  "+tbc("Installed skills ("+str(len(files_s))+"):"))
                for slug in sorted(skill_display_name(f) for f in files_s): print("  "+tc(C.TEAL,"★")+" "+slug)
                print()
            else: print("  "+dim("No skills yet. Try /skill search or: sam create a new skill called X that does Y"))
        elif cmd.startswith("/skill search "): skill_search(raw[len("/skill search "):].strip(),config)
        elif cmd.startswith("/skill install "): skill_install(raw[len("/skill install "):].strip(),config)
        elif cmd.startswith("/open ") or cmd.startswith("/reveal "):
            _is_reveal = cmd.startswith("/reveal ")
            _arg = raw[len("/reveal " if _is_reveal else "/open "):].strip()
            if not _arg:
                print("  "+tc(C.AMBER,"⚠")+" Usage: "+tc(C.TEAL,"/open <filename>")+dim("  or  ")+tc(C.TEAL,"/reveal <filename>"))
            else:
                # Accept bare filename, relative path, or absolute path.
                # For bare filenames, search the active client's deliverables
                # tree for the first match.
                _target = None
                _p = Path(_arg)
                if _p.is_absolute() and _p.exists():
                    _target = _p
                else:
                    _base = client_deliverables_dir()
                    _candidate = _base / _arg
                    if _candidate.exists():
                        _target = _candidate
                    else:
                        # Walk the deliverables tree for a filename match
                        _matches = [p for p in _base.rglob("*") if p.is_file() and p.name == _arg]
                        if len(_matches) == 1:
                            _target = _matches[0]
                        elif len(_matches) > 1:
                            print("  "+tc(C.AMBER,"⚠")+" Multiple matches. Be more specific:")
                            for _m in _matches[:10]:
                                try: _rel = _m.relative_to(_base).as_posix()
                                except ValueError: _rel = str(_m)
                                print("    "+dim(_rel))
                if _target is None:
                    print("  "+tc(C.AMBER,"⚠")+" File not found: "+tc(C.WHITE,_arg))
                    print("  "+dim("Searched: ")+str(client_deliverables_dir()))
                    print("  "+dim("Try /client deliver to list available files."))
                else:
                    import subprocess as _sp, platform as _plat
                    _sys = _plat.system()
                    try:
                        if _is_reveal:
                            # Reveal in OS file manager (select the file)
                            if _sys == "Windows":
                                _sp.run(["explorer.exe", "/select,", str(_target)], check=False)
                            elif _sys == "Darwin":
                                _sp.run(["open", "-R", str(_target)], check=False)
                            else:
                                _sp.run(["xdg-open", str(_target.parent)], check=False)
                            print("  "+tc(C.GREEN,"✓")+"  Revealed: "+tbc(_target.name))
                        else:
                            # Open in OS default handler (Excel for xlsx, etc.)
                            if _sys == "Windows":
                                os.startfile(str(_target))
                            elif _sys == "Darwin":
                                _sp.run(["open", str(_target)], check=False)
                            else:
                                _sp.run(["xdg-open", str(_target)], check=False)
                            print("  "+tc(C.GREEN,"✓")+"  Opened: "+tbc(_target.name))
                    except Exception as _oe:
                        print("  "+tc(C.AMBER,"⚠")+" Couldn't "+("reveal" if _is_reveal else "open")+": "+str(_oe))
                        print("  "+dim("Path: ")+str(_target))
        elif cmd=="/tools":
            if not FIRST_PARTY_TOOLS:
                print("  "+dim("No first-party tools registered."))
            else:
                print(); print("  "+tbc("First-party tools ("+str(len(FIRST_PARTY_TOOLS))+"):"))
                for name, entry in sorted(FIRST_PARTY_TOOLS.items()):
                    allowed = ", ".join(sorted(entry["allowed_agents"]))
                    print("  "+tc(C.TEAL,"★")+" "+name+dim("  → "+allowed))
                print()
        elif cmd=="/mcp" or cmd=="/mcp list":
            _handle_mcp_list_cmd(_MCP_MANAGER)
        elif cmd=="/mcp add":
            _handle_mcp_add_cmd()
        elif cmd.startswith("/mcp remove "):
            _handle_mcp_remove_cmd(raw[len("/mcp remove "):].strip())
        elif cmd=="/mcp tools":
            _handle_mcp_tools_cmd(_MCP_MANAGER)
        elif cmd=="/mcp restart":
            # Uses the same ensure_mcp_manager as CLI startup + web UI, so
            # there's one init code path for the whole process. The explicit
            # messaging below is kept local to this handler because the CLI
            # wants specific guidance per failure mode (install SDK, switch
            # provider, add servers) that shouldn't leak into the generic
            # library function.
            shutdown_mcp_manager()
            if MCPManager is None:
                print("  "+tc(C.AMBER,"⚠")+" MCP SDK not installed. Run: "+tc(C.TEAL,"pip install mcp"))
            elif provider!="anthropic":
                print("  "+dim("MCP is Anthropic-only in Phase 1 — switch provider with /model."))
            elif not load_mcp_config().get("servers"):
                print("  "+dim("No MCP servers configured. Use ")+tc(C.TEAL,"/mcp add")+dim(" to add one."))
            else:
                _mgr, _sum = ensure_mcp_manager(provider)
                if _mgr is None or not _sum:
                    print("  "+tc(C.AMBER,"⚠")+" MCP failed to start — see "+tc(C.TEAL,"/errors")+" for details.")
                else:
                    _ok=sum(1 for s in _sum.values() if s.get("status")=="connected")
                    _tot=sum(s.get("tools",0) for s in _sum.values() if s.get("status")=="connected")
                    print("  "+tc(C.GREEN,"✓")+" MCP restarted: "+tc(C.TEAL,str(_ok))+dim(" server(s) · "+str(_tot)+" tool(s)"))
                    for _n,_s in _sum.items():
                        if _s.get("status")=="error":
                            print("    "+tc(C.AMBER,"⚠")+" "+_n+": "+_s.get("error",""))
        elif cmd.startswith("/feedback"): handle_feedback(raw,history,agents,config)
        elif cmd.startswith("/model"):
            changed=handle_model_command(raw,config,mode)
            if changed: client,provider,model_id=build_client(config)
        elif cmd=="/provider add": add_provider(config,mode); client,provider,model_id=build_client(config)
        elif cmd.startswith("/"):
            aname=cmd[1:].strip().lower()
            if aname in agents: print_agent(agents[aname])
            else: print("  "+dim("Sorry, I don't know that regular yet. Type /help to see all commands."))
        elif cmd.startswith("search "): handle_search(raw[7:].strip())
        elif "grill me" in cmd:
            print(); print(tc(C.AMBER,"🔥")+" "+tbc("Grill Me skill activated!"))
            if client:
                history.add_user(raw); agent_thinking_header("Carla","Ruthless but constructive critique")
                file_context=memory_build_file_context()
                result=call_execute_streaming(client,provider,model_id,agents.get("carla",{}),"Ruthlessly but constructively critique this: "+raw,file_context=file_context,history=history)
                if mode==Mode.DEV: perf_score_async(client,provider,model_id,agent="Carla",skill="grill-me",task=raw,response=result)
                history.add_assistant(result)
            else: print("  "+dim("No API client. Add a key with /provider add"))
        elif "sam" in cmd and "create" in cmd:
            print(); print(tc(C.TEAL,"Sam says:")+" Let's build a new skill.")
            if "called" in cmd and "that" in cmd:
                try:
                    name=cmd.split("called")[1].split("that")[0].strip().replace("a new skill","").strip()
                    desc=cmd.split("that")[1].strip(); fn=create_skill_file(name,desc)
                    print("  "+tc(C.GREEN,"✓")+" Skill created: "+tbc(skill_display_name(Path(fn))))
                except Exception as e: print("  "+tc(C.AMBER,"Sam says:")+" Didn't catch that ("+str(e)+").")
            else: print("  "+dim("Example: sam create a new skill called Proposal Helper that helps write proposals"))
        else:
            detected_paths=extract_file_paths(raw)
            for fp in detected_paths:
                print(); print("  "+tc(C.TEAL,"📎")+" "+dim("Detected: ")+tc(C.WHITE,fp.name)); ingest_file(fp)
            if client:
                print(); history.add_user(raw); _indicator.start("Sam is reading the room…")
                plan=call_router(client,provider,model_id,history,raw)
                if plan:
                    steps=plan.get("steps",[])
                    if steps:
                        first=agents.get(steps[0].get("agent","?"),{}).get("name",steps[0].get("agent","?").title())
                        _indicator.update(first+" is on it…")
                    execute_plan(client,provider,model_id,agents,plan,raw,history,mode)
                else:
                    _indicator.stop(); print("  "+dim("You said: ")+raw)
                    history.add_assistant("I couldn't route that request. Could you rephrase?")
                    memory_save_conversation(raw)
            else:
                print("  "+dim("You said: ")+raw); memory_save_conversation(raw)


if __name__=="__main__":
    main()