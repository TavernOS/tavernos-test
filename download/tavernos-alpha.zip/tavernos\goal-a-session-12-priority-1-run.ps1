#
# Session 12 priority 1 — run + verify script.
#
# Rule 2: every run command starts with `cd` to the working directory.
# Operator's PowerShell working directory is C:\Tavernos\tavernos.
#
# Order:
#   1. cd to workspace.
#   2. Drop in the six files from /mnt/user-data/outputs/.
#   3. Run Tier 0 — expect 113/113 green.
#   4. Production CLI spot-check per Rule 3 — three prompts (Lilith audit,
#      Rebecca-Deck QBR, Rebecca-MBR monthly) verifying that (a) the file
#      saves and (b) client.json gets the right latest_<template>_path.
#
# If any step fails: stop, report which step, attach the output, and we
# re-propose.
#

cd C:\Tavernos\tavernos

# ─── Step 1 — Drop-in files ───────────────────────────────────────────────────
# The six files in /mnt/user-data/outputs/ are drop-in overwrites per Rule 1.
# New file: tavernos\artifact_gate.py
# Modified: tavernos\artifact_docx.py
# Modified: tavernos\artifact_pptx.py
# Modified: tavernos\artifact_xlsx.py
# Modified: tavernos\norm.py
# Modified: tavernos\test_layer1_mechanism.py

# Copy them into the package directory (adjust the source path to wherever
# you downloaded the outputs):
# Copy-Item <download_dir>\artifact_gate.py tavernos\artifact_gate.py -Force
# Copy-Item <download_dir>\artifact_docx.py tavernos\artifact_docx.py -Force
# Copy-Item <download_dir>\artifact_pptx.py tavernos\artifact_pptx.py -Force
# Copy-Item <download_dir>\artifact_xlsx.py tavernos\artifact_xlsx.py -Force
# Copy-Item <download_dir>\norm.py tavernos\norm.py -Force
# Copy-Item <download_dir>\test_layer1_mechanism.py tavernos\test_layer1_mechanism.py -Force


# ─── Step 2 — Tier 0 (test_layer1_mechanism) ─────────────────────────────────
#
# Expected: 113/113 passed. Breakdown:
#   Contracts 1-17  — 95 tests (session-11 baseline, unchanged)
#   Contract 16 ext — 1 test  (docx harmonized bypass preamble pin)
#   Contract 19     — 7 tests (auto-link on save across all five templates,
#                               plus bypass-still-auto-links + second-save-
#                               overwrites)
#   Contract 20     — 3 tests (5-field sentinel + back-compat 4-field)
#   Contract 21     — 5 tests (artifact_gate formatters)
#   Contract 22     — 2 tests (tmp-workspace discipline)
#
# Sandbox verified: 113/113 passed with no ~/.tavernos residue.
# Rule 6 retires: no more leaked real files during Tier 0.

cd C:\Tavernos\tavernos
python -m tavernos.test_layer1_mechanism -v


# ─── Step 3 — Production CLI spot-check per Rule 3 ───────────────────────────
#
# Rule 3: Phase A + Tier 2 green ≠ production-CLI green. Required before
# declaring any agent-resolution or tool-dispatch change production-ready.
# This session touched _dispatch_first_party_tool (sub-item 2 auto-link)
# and all three _tool_handler sentinels (sub-item 2 format), so spot-check
# is mandatory.
#
# Three surfaces, each exercises one template's auto-link end-to-end:
#
# 3a) Lilith ops-audit — exercises latest_operational_audit_path.
#     Launch CLI, /client switch to a test client (create one if needed
#     via /client init <slug>), then prompt Lilith:
#
#       Prompt: "Audit our client onboarding process. Three stages:
#                intake form (5 min, no validation), manual CRM import
#                (15 min per record, high error rate), welcome email
#                (manual send, sometimes forgotten)."
#
#     Verify:
#       - Banner: [LILITH]
#       - Indicator: "Lilith is on it" or equivalent
#       - Tool invoked (generate_docx_report)
#       - Real .docx file appears in C:\Users\<you>\.tavernos\clients\<slug>\deliverables\audits\
#     Then:
#       cat "$env:USERPROFILE\.tavernos\clients\<slug>\client.json"
#     Must contain: "latest_operational_audit_path": "audits\\..."
#
# 3b) Rebecca-Deck QBR — exercises latest_executive_review_deck_path.
#     Prompt: "Make a QBR deck for Meridian Labs. Q1 highlights:
#              ARR up 22% to $4.8M, NRR 118%, three enterprise logos,
#              ops cost down 8%. Risks: competitor pricing pressure,
#              one champion left at biggest account."
#
#     Verify:
#       - Banner: [REBECCA-DECK], indicator: "Rebecca is on it"
#       - Real .pptx file in ...\deliverables\reports\
#       - One file per run (not 2-3 — session-11 Meridian multi-save
#         fix held)
#     Then check client.json for:
#       "latest_executive_review_deck_path": "reports\\..."
#
# 3c) Rebecca-MBR — exercises latest_monthly_business_review_path.
#     Prompt: "Build a March MBR for Acme. Revenue: plan 420K actual
#              445K; costs: plan 310K actual 298K. One commentary:
#              enterprise deal closed 6 days early, drove the 6% beat."
#
#     Verify:
#       - Banner: [REBECCA-MBR], indicator: "Rebecca is on it"
#       - Real .xlsx file in ...\deliverables\reports\
#       - Preflight gates don't fire (commentary is present)
#     Then check client.json for:
#       "latest_monthly_business_review_path": "reports\\..."
#
# All three client.json checks can be combined after the three runs:
#
#   cd C:\Tavernos\tavernos
#   cat "$env:USERPROFILE\.tavernos\clients\<slug>\client.json"
#
# Expected shape (after all three spot-checks against the same client):
#   {
#     ...,
#     "latest_operational_audit_path": "audits\\...",
#     "latest_executive_review_deck_path": "reports\\...",
#     "latest_monthly_business_review_path": "reports\\...",
#     "last_active": "2026-04-24T..."
#   }
#
# Non-success triggers:
#   - Tier 0 < 113 → something drifted in the extraction or wiring. Rollback.
#   - A spot-check produces a banner but no file → dispatcher->handler path
#     regressed. Rollback.
#   - A spot-check saves a file but client.json lacks the key → auto-link
#     wiring broken; dispatcher's 5-field parse probably failed. Inspect
#     the sentinel's emitted shape.
#   - Meridian QBR produces 2+ files per run → session-11 bypass-preamble
#     Contract 16 drift. Check that pptx + xlsx + docx bypass preambles
#     still carry the three Contract 16 tokens (tests would also have
#     caught this — likely a tool-dispatch path regression instead).
