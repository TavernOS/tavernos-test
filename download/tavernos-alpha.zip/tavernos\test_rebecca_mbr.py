"""
test_rebecca_mbr.py — Pipeline regression test for Rebecca's monthly_business_review.

Thin wrapper over test_harness.py. Edit this file to change Rebecca-MBR's
test scenarios; the harness handles all the plumbing.

Run:
  python -u test_rebecca_mbr.py                    # tier 1 only, n=1
  python -u test_rebecca_mbr.py --tier 1 --n 3     # tier 1, 3 iterations
  python -u test_rebecca_mbr.py --tier 2 --n 3     # tiers 2a + 2b
  python -u test_rebecca_mbr.py --tier all --n 3   # all implemented tiers
  python -u test_rebecca_mbr.py --verbose          # dump plans + tool captures
  python -u test_rebecca_mbr.py --tier 2 --n 3 --force-2b  # session-7 forcing arm

Baseline expectations (carried from session-1 pattern, validated for
Lilith/Woody/Cliff in sessions 7+9):
  Tier 1:  should track other deliverable agents at ~100% — ROUTER_SYSTEM
           routing rules (session 10 Rebecca split) direct MBR-shaped
           prompts to rebecca-mbr.
  Tier 2a: should track other deliverable agents' ~100% CLARIFY — same
           grounding discipline applies.
  Tier 2b: session-9 production conjunction + force_tool='generate_xlsx_report'
           should lift invocation rate to ≥10/12 on rich MBR prompts. M-prefix
           preflight gate (M2 + M3) will reject partial specs; bypass at N=2
           saves with warning preamble.

Rebecca-MBR-specific note: the rubric's formula_correctness (0.25, 5.0 hard
floor — strictest in any rubric) is a POST-build check. The gate cannot
prevent a zero-value there; formula-guard warnings surface via
result['warnings'] and feed evaluator regen triggers after save. Rich
prompts should frame questions where Rebecca can produce real numeric
MBR data (revenue rows, cost rows, commentary on variances).
"""

from test_harness import AgentTestConfig, run_tests


# ═══════════════════════════════════════════════════════════════════════════════
#  TEST SCENARIOS — rebecca-mbr + monthly_business_review
#
#  SHORT prompts (Mode 3 / CLARIFY target): vague MBR requests with no
#  specific period, no client context, no numeric anchors. Expected: no
#  tool invocation, substantive prose asking what specifically to review.
#
#  RICH prompts (Mode 2 / BOUND target): 4-6 sentences naming a specific
#  client, period, and enough numeric anchors (revenue / costs / targets /
#  variances) to produce a grounded MBR. Expected: generate_xlsx_report
#  call with template=monthly_business_review, and a file saved to disk.
#
#  NEGATIVE prompts: must NOT route to rebecca-mbr. Board-deck requests
#  route to rebecca-deck; research requests to cliff; proposals to woody;
#  audits to lilith.
# ═══════════════════════════════════════════════════════════════════════════════

SHORT_PROMPTS = [
    "pull together an MBR",
    "I need a monthly business review",
    "look at our numbers for the month",
    "build me a KPI dashboard",
    "put together a variance analysis",
]

RICH_PROMPTS = [
    # Standard MBR — specific client, period, numbers, variance story
    ("Pull together a March 2026 MBR for Acme Corp (B2B SaaS, $1.2M ARR, 28 "
     "headcount). Revenue targets: Jan $400K / Feb $420K / Mar $448K. "
     "Actuals: Jan $380K, Feb $395K, Mar $412K — so 8% March miss. Two "
     "drivers: Meridian Labs churned March 18 ($14K MRR), Greenshoot "
     "contract slipped from March 29 to April 4 ($22K). Costs: COGS "
     "tracking plan, opex $12K over in March due to pulled-forward "
     "engineering hire. Board wants the March MBR by end of this week."),

    # Multi-segment revenue — variance across segments, specific commentary
    ("Need an MBR for Q1 2026 for Meridian Finance (Series B fintech, "
     "$14M ARR, 85 FTE). Revenue breakdown by segment: Enterprise "
     "$3.2M actual vs $3.5M plan (8.6% miss — two delayed close dates), "
     "Mid-market $1.8M actual vs $1.6M plan (12.5% beat — expansion "
     "into Greenshoot's Q4 pipeline), SMB $420K actual vs $480K plan "
     "(12.5% miss — self-serve conversion dropped from 3.2% to 2.4% "
     "per February signup cohort). Costs in line across categories. "
     "Headcount ended at 85, up 4 FTE in engineering. CFO wants this "
     "for the Q1 board pre-read by Friday."),

    # Cost-focused MBR — opex overage, specific line-item commentary
    ("Draft a February 2026 MBR for Greenshoot Robotics ($8M ARR, "
     "42 FTE, Series A hardware). Revenue on plan at $720K. Costs "
     "overrun: COGS 18% over plan driven by component shortage (ST "
     "Micro lead time blew out from 4 weeks to 14 weeks, had to "
     "source from secondary distributors at 1.4x markup). Opex also "
     "5% over — unplanned $40K legal spend on the NDA refresh for "
     "the partnership discussions. Burn for the month was $280K vs "
     "$210K budget — 33% over. CEO is presenting to the board next "
     "week and wants the MBR to lead with the burn variance story."),

    # KPI-forward MBR — product metrics, cohort commentary
    ("Put together the March 2026 MBR for Lattice Labs ($4M ARR, "
     "31 FTE, dev tools). Standard revenue + cost sections, but the "
     "board specifically wants: (1) MoM DAU/MAU trend — 8,400 MAU "
     "March vs 7,900 Feb, 38% DAU/MAU ratio, (2) Net revenue "
     "retention by cohort — 2024H1 cohort at 118% NRR, 2024H2 at "
     "124%, 2025H1 tracking to 131% at 9-month mark, (3) CAC "
     "payback — 14 months current vs 18 months target, improving. "
     "Commentary on the cohort improvement (driven by the quarterly-"
     "review program's expansion motion). Due to CFO by Tuesday."),
]

NEGATIVE_PROMPTS = [
    ("build a board deck for our Q1 results",                     "rebecca-deck"),
    ("research the latest SaaS benchmark data from KeyBanc",      "cliff"),
    ("write me a proposal for a new prospect",                    "woody"),
    ("audit operations at our 30-person agency",                  "lilith"),
]


CONFIG = AgentTestConfig(
    agent_name="rebecca-mbr",
    tool_name="generate_xlsx_report",
    template_key="monthly_business_review",
    short_prompts=SHORT_PROMPTS,
    rich_prompts=RICH_PROMPTS,
    negative_prompts=NEGATIVE_PROMPTS,
)


if __name__ == "__main__":
    run_tests(CONFIG)
