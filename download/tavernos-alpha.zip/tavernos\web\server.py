"""
TavernOS Web UI — server.py
============================
FastAPI backend for the browser interface.
Runs on http://127.0.0.1:7777

Endpoints:
  GET  /                   → serves index.html
  GET  /api/status         → mode, model, agents, files summary
  GET  /api/agents         → list of all agents
  GET  /api/skills         → list of installed skills
  GET  /api/files          → list of ingested files
  GET  /api/history        → conversation history
  POST /api/clear          → clear conversation history
  POST /api/chat           → SSE streaming chat endpoint
  POST /api/upload         → file upload + ingest
  POST /api/search         → search ingested files
  DELETE /api/history      → clear history
"""

import os
import sys
import json
import asyncio
import sqlite3
import re
import struct
import threading
import email as email_lib
from pathlib import Path
from datetime import datetime, timezone
from typing import AsyncIterator

from fastapi import FastAPI, Request, UploadFile, File, Form
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

# ── Add the tavernos package to path so we can reuse norm's internals ─────────
PKG_DIR = Path(__file__).parent.parent   # tavernos/
sys.path.insert(0, str(PKG_DIR.parent))  # project root

# ── Paths (mirror norm.py) ────────────────────────────────────────────────────
USER_DIR    = Path.home() / ".tavernos"
CONFIG_FILE = USER_DIR / "config.json"
STAGING_CONFIG_FILE = USER_DIR / "staging_config.json"
MEMORY_DIR  = USER_DIR / "memory"
DIAG_DIR    = USER_DIR / "diagnostics"
ERRORS_JOURNAL = DIAG_DIR / "errors.jsonl"
AGENTS_DIR  = PKG_DIR / "agents"
SKILLS_DIR  = PKG_DIR / "skills"
VECTOR_DB   = MEMORY_DIR / "vectors.db"
PERF_DB     = MEMORY_DIR / "skill_performance.db"

CHUNK_SIZE    = 2048
CHUNK_OVERLAP = 200
SUPPORTED_EXT = {".txt", ".md", ".pdf", ".docx", ".xlsx", ".pptx", ".msg", ".eml"}

FILE_TYPE_LABELS = {
    ".txt": "Plain text", ".md": "Markdown",   ".pdf": "PDF",
    ".docx": "Word",      ".xlsx": "Excel",    ".pptx": "PowerPoint",
    ".msg": "Outlook email", ".eml": "Email",
}

FILE_ICONS = {
    ".pdf": "📄", ".docx": "📝", ".xlsx": "📊",
    ".pptx": "📋", ".msg": "📧", ".eml": "📧",
    ".txt": "📃", ".md": "📃",
}

FALLBACK_MODELS = [
    {"provider": "anthropic", "id": "claude-opus-4-5",   "name": "Claude Opus 4.5",   "tier": 1},
    {"provider": "anthropic", "id": "claude-sonnet-4-6", "name": "Claude Sonnet 4.6", "tier": 2},
    {"provider": "anthropic", "id": "claude-haiku-4-5",  "name": "Claude Haiku 4.5",  "tier": 3},
]

ROUTER_MAX_TOKENS  = 1000
EXECUTE_MAX_TOKENS = 4000

ROUTER_SYSTEM = (
    "You are Sam, the Chief of Staff and orchestrator of TavernOS.\n"
    "Return ONLY valid JSON — no markdown, no explanation:\n"
    '{"intent":"brief description","steps":[{"agent":"agent_name","task":"what to do","skill":null}],'
    '"needs_new_skill":false,"new_skill_name":null,"new_skill_description":null}\n'
    "Agents: sam(orchestration), norm(general), coach(meetings/PRDs), carla(QA/editing),\n"
    "woody(proposals/content), cliff(research/PDFs/data), frasier(strategy), rebecca(Excel/slides/charts)\n"
    "\nRouting rules:\n"
    "- Route document/file questions to cliff\n"
    "- Route chart/graph/visualization requests to rebecca\n"
    "- Route ANY request involving a spreadsheet, workbook, .xlsx file, MBR,\n"
    "  monthly business review, KPI dashboard, variance analysis, financial\n"
    "  model, P&L, revenue/cost reporting, or budget-vs-actual analysis to\n"
    "  rebecca. These are her core deliverables — do NOT route them to\n"
    "  frasier (strategy) or norm (general) even if the request mentions\n"
    "  business planning or numbers in the abstract.\n"
    "- Use conversation history to understand follow-ups."
)

# ═══════════════════════════════════════════════════════════════════════════════
#  OUTPUT CONTRACT — global formatting rules appended to every agent's system
#  prompt. Mirrors the constant in norm.py so CLI and web UI stay in sync.
#  If a specific skill needs to deviate, the skill file can override inline.
# ═══════════════════════════════════════════════════════════════════════════════

OUTPUT_CONTRACT = (
    "Format all output as Markdown:\n"
    "- Use ## and ### for section headings (not underlines or ASCII rules)\n"
    "- Use | table syntax for any structured/tabular data\n"
    "- Use - or * for bullet lists\n"
    "- Use --- for horizontal rules\n"
    "- Use **bold** and *italic* for emphasis\n"
    "- Use `backticks` for inline code and ``` fences for code blocks\n"
    "Do NOT use ASCII art boxes, rule characters (║ ═ ╔ ╗ ╚ ╝ ─ │ ┌ ┐ └ ┘ ├ ┤ ┬ ┴ ┼), "
    "or hand-drawn dividers for visual structure. These do not render correctly in "
    "variable-width contexts (web UI, email, docs) and make output look broken.\n\n"
    "Deliverables — when your response IS a substantive artifact the user will "
    "keep, reuse, or share (proposal, audit, report, guide, spec, PRD, brief, "
    "plan, strategy doc, analysis) AND is longer than ~400 words, end your "
    "response with exactly one marker line on its own:\n"
    "DELIVERABLE_SAVED: <category>/<filename>.md\n"
    "Where <category> is one of: reports, audits, blueprints, content. "
    "Filename is kebab-case and descriptive (e.g. proposal-brightwave-q2.md, "
    "audit-ops-acme.md). Do NOT emit this marker for: short responses, chat "
    "replies, Q&A, critiques, grill-me responses, clarifications, status "
    "updates, or anything under ~400 words. Skill files may specify their own "
    "save paths that take priority over these defaults."
)


# ═══════════════════════════════════════════════════════════════════════════════
#  DELIVERABLE AUTO-SAVE — mirrors norm.py. Detects the DELIVERABLE_SAVED
#  marker in agent output, writes the file into the active client's workspace
#  (sandboxed), and emits a `deliverable_saved` SSE event so the UI can render
#  a preview card.
# ═══════════════════════════════════════════════════════════════════════════════

import urllib.parse as _urlparse

CLIENTS_DIR         = USER_DIR / "clients"
ACTIVE_CLIENT_FILE  = CLIENTS_DIR / "_active"
DEFAULT_CLIENT_SLUG = "_self"

DELIVERABLE_MARKER_RE        = re.compile(r'^DELIVERABLE_SAVED:\s*(.+?)\s*$', re.MULTILINE)
VALID_DELIVERABLE_CATEGORIES = {"reports", "audits", "blueprints", "content"}


def _active_slug() -> str:
    """Read active client slug from disk. Falls back to _self."""
    try:
        if ACTIVE_CLIENT_FILE.exists():
            slug = ACTIVE_CLIENT_FILE.read_text(encoding="utf-8").strip()
            if slug:
                return slug
    except Exception:
        pass
    return DEFAULT_CLIENT_SLUG


def _client_deliverables_dir(slug: str = None) -> Path:
    return CLIENTS_DIR / (slug or _active_slug()) / "deliverables"


def _resolve_deliverable_path(marker_path: str, slug: str = None):
    """Resolve a marker path to an absolute Path inside the active client's
    workspace. Returns None if the path is invalid or escapes the sandbox."""
    if not marker_path:
        return None
    marker_path = marker_path.lstrip("/\\").strip()
    if not marker_path or ".." in Path(marker_path).parts:
        return None
    if not marker_path.lower().endswith(".md"):
        marker_path += ".md"
    parts = Path(marker_path).parts
    if parts[0] not in VALID_DELIVERABLE_CATEGORIES:
        marker_path = "reports/" + marker_path
    base = _client_deliverables_dir(slug).resolve()
    try:
        final = (base / marker_path).resolve()
        final.relative_to(base)
    except (ValueError, OSError):
        return None
    return final


def _process_deliverable_marker(text: str, agent_name: str):
    """If text contains a DELIVERABLE_SAVED marker, write the file (marker
    stripped) and return a dict describing what was saved. Returns None otherwise."""
    if not text:
        return None
    match = DELIVERABLE_MARKER_RE.search(text)
    if not match:
        return None
    marker_path = match.group(1).strip()
    final_path = _resolve_deliverable_path(marker_path)
    if not final_path:
        return None
    cleaned = DELIVERABLE_MARKER_RE.sub("", text).rstrip() + "\n"
    try:
        final_path.parent.mkdir(parents=True, exist_ok=True)
        final_path.write_text(cleaned, encoding="utf-8")
    except Exception:
        return None
    try:
        rel = final_path.relative_to(USER_DIR).as_posix()
    except ValueError:
        rel = final_path.as_posix()
    preview_lines = [ln for ln in cleaned.splitlines() if ln.strip()][:3]
    return {
        "filename": final_path.name,
        "path":     rel,
        "category": final_path.parent.name,
        "agent":    agent_name,
        "bytes":    final_path.stat().st_size,
        "preview":  "\n".join(preview_lines),
        "view_url": "/api/deliverable?path=" + _urlparse.quote(rel, safe=""),
    }


# ═══════════════════════════════════════════════════════════════════════════════
#  RESILIENCE — error journal + JSON extraction. Mirrors norm.py.
#  Every failure lands in ERRORS_JOURNAL (one JSON object per line). Use
#  /errors in the CLI or GET /api/errors in the web UI to review.
# ═══════════════════════════════════════════════════════════════════════════════

def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _log_error(kind: str, **context):
    """Append an error record to the diagnostics journal. Never raises."""
    try:
        DIAG_DIR.mkdir(parents=True, exist_ok=True)
        rec = {"ts": _now_iso(), "kind": kind, **context}
        with open(ERRORS_JOURNAL, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception:
        pass


def _try_extract_json(text: str):
    """Progressively strip noise and extract a JSON object. Returns dict or None."""
    if not text:
        return None
    try:
        return json.loads(text)
    except Exception:
        pass
    cleaned = re.sub(r"^```[a-zA-Z]*\n?", "", text.strip())
    cleaned = re.sub(r"\n?```\s*$", "", cleaned)
    try:
        return json.loads(cleaned)
    except Exception:
        pass
    start = cleaned.find("{")
    if start < 0:
        return None
    depth = 0
    in_string = False
    escape = False
    for i in range(start, len(cleaned)):
        c = cleaned[i]
        if escape:
            escape = False
            continue
        if c == "\\":
            escape = True
            continue
        if c == '"':
            in_string = not in_string
            continue
        if in_string:
            continue
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                try:
                    return json.loads(cleaned[start:i+1])
                except Exception:
                    return None
    return None


# ═══════════════════════════════════════════════════════════════════════════════
#  APP SETUP
# ═══════════════════════════════════════════════════════════════════════════════

app = FastAPI(title="TavernOS Web UI", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# Serve static files from the web/ directory if they exist
_web_dir = Path(__file__).parent
if (_web_dir / "static").exists():
    app.mount("/static", StaticFiles(directory=str(_web_dir / "static")), name="static")


# ═══════════════════════════════════════════════════════════════════════════════
#  SESSION STATE — in-memory, reset on server restart
# ═══════════════════════════════════════════════════════════════════════════════

class SessionState:
    def __init__(self):
        self.history: list[tuple[str, str]] = []   # (user, assistant) pairs
        self.max_pairs = 10
        self.pending_user = ""

    def add_user(self, msg: str):
        self.pending_user = msg

    def add_assistant(self, msg: str):
        if self.pending_user:
            self.history.append((self.pending_user, msg))
            if len(self.history) > self.max_pairs:
                self.history = self.history[-self.max_pairs:]
            self.pending_user = ""

    def to_messages(self) -> list[dict]:
        msgs = []
        for u, a in self.history:
            msgs.append({"role": "user",      "content": u})
            msgs.append({"role": "assistant", "content": a})
        return msgs

    def clear(self):
        self.history = []
        self.pending_user = ""

    def to_list(self) -> list[dict]:
        result = []
        for i, (u, a) in enumerate(self.history):
            result.append({"index": i+1, "user": u, "assistant": a})
        return result


_session = SessionState()


# ═══════════════════════════════════════════════════════════════════════════════
#  CONFIG HELPERS
# ═══════════════════════════════════════════════════════════════════════════════

def _load_config() -> dict:
    for path in [CONFIG_FILE, STAGING_CONFIG_FILE]:
        if path.exists():
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
    return {}


def _get_mode() -> str:
    if STAGING_CONFIG_FILE.exists() and not CONFIG_FILE.exists():
        return "staging"
    cfg = _load_config()
    # Detect by presence of registry_token
    if cfg.get("registry_token"):
        return "dev"
    return "customer"


def _get_providers(config: dict) -> dict:
    if "providers" in config: return config["providers"]
    if "api_key"   in config: return {"anthropic": config["api_key"]}
    return {}


def _get_active_model(config: dict) -> tuple[str, str]:
    active = config.get("active_model", {})
    if active:
        return active.get("provider", "anthropic"), active.get("model_id", "claude-opus-4-5")
    return "anthropic", config.get("model", "claude-opus-4-5")


def _build_client(config: dict):
    provider, model_id = _get_active_model(config)
    providers = _get_providers(config)
    api_key   = providers.get(provider, "")
    if not api_key:
        return None, provider, model_id
    try:
        if provider == "anthropic":
            import anthropic
            return anthropic.Anthropic(api_key=api_key), provider, model_id
        else:
            import openai
            return openai.OpenAI(api_key=api_key), provider, model_id
    except Exception:
        return None, provider, model_id


# ═══════════════════════════════════════════════════════════════════════════════
#  MEMORY / FILE HELPERS — reads the same SQLite as norm.py
# ═══════════════════════════════════════════════════════════════════════════════

def _memory_db() -> Path:
    return MEMORY_DIR / "tavern_memory.db"


def _list_files() -> list[dict]:
    db = _memory_db()
    if not db.exists():
        return []
    try:
        con  = sqlite3.connect(db)
        rows = con.execute(
            "SELECT path,name,type,word_count,page_count,indexed_at FROM files ORDER BY indexed_at DESC"
        ).fetchall()
        con.close()
    except Exception:
        return []
    # Check vector coverage
    vec_paths: set[str] = set()
    if VECTOR_DB.exists():
        try:
            con = sqlite3.connect(VECTOR_DB)
            vec_paths = set(r[0] for r in con.execute("SELECT DISTINCT file_path FROM chunks").fetchall())
            con.close()
        except Exception:
            pass
    result = []
    for r in rows:
        result.append({
            "path": r[0], "name": r[1], "type": r[2],
            "word_count": r[3], "page_count": r[4], "indexed_at": r[5],
            "icon": FILE_ICONS.get(r[2], "📄"),
            "label": FILE_TYPE_LABELS.get(r[2], r[2]),
            "semantic": r[0] in vec_paths,
        })
    return result


def _fts_search(query: str, limit: int = 6) -> list[dict]:
    db = _memory_db()
    if not db.exists():
        return []
    try:
        con  = sqlite3.connect(db)
        rows = con.execute("""
            SELECT f.path, f.name, f.type, f.word_count, f.page_count,
                   snippet(files_fts, 2, '[', ']', '...', 20) as excerpt
            FROM files_fts JOIN files f ON files_fts.path = f.path
            WHERE files_fts MATCH ? ORDER BY rank LIMIT ?
        """, (query, limit)).fetchall()
        con.close()
        return [{"path": r[0], "name": r[1], "type": r[2], "word_count": r[3],
                 "page_count": r[4], "excerpt": r[5], "source": "keyword"} for r in rows]
    except Exception:
        return []


def _build_file_context(query: str = "") -> str:
    db = _memory_db()
    if not db.exists():
        return ""
    try:
        con   = sqlite3.connect(db)
        files = con.execute(
            "SELECT path,name,type,word_count,page_count FROM files ORDER BY indexed_at DESC"
        ).fetchall()
        con.close()
    except Exception:
        return ""
    if not files:
        return ""
    context = "\n\nINGESTED DOCUMENTS IN MEMORY:\n"
    if query:
        results = _fts_search(query, limit=3)
        if results:
            context += "\nRelevant sections for this query:\n"
            for r in results:
                context += "\n--- " + r["name"] + " ---\n" + r["excerpt"] + "\n"
            context += "\nAll available files: " + ", ".join(r[1] for r in files)
            return context
    for path, name, ftype, wc, pc in files[:3]:
        try:
            con = sqlite3.connect(_memory_db())
            rec = con.execute("SELECT content FROM files WHERE path=?", (path,)).fetchone()
            con.close()
        except Exception:
            rec = None
        if rec:
            pages = str(pc) + " pages" if pc else str(wc) + " words"
            context += "\n--- " + name + " (" + pages + ") ---\n"
            context += (rec[0] or "")[:6000] + "\n[end excerpt]\n"
    if len(files) > 3:
        context += "\n... and " + str(len(files)-3) + " more files."
    return context


def _load_agents() -> dict:
    agents = {}
    if not AGENTS_DIR.exists():
        return agents
    for f in AGENTS_DIR.glob("*.json"):
        try:
            with open(f, "r", encoding="utf-8") as fh:
                a = json.load(fh)
                agents[a.get("name", f.stem).lower()] = a
        except Exception:
            pass
    return agents


def _list_skills() -> list[dict]:
    if not SKILLS_DIR.exists():
        return []
    skills = []
    for f in SKILLS_DIR.glob("*.skill.md"):
        slug = f.name[:-len(".skill.md")]
        # Parse frontmatter
        name = slug.replace("-", " ").title()
        agent = ""
        description = ""
        try:
            content = f.read_text(encoding="utf-8")
            if content.startswith("---"):
                end = content.find("---", 3)
                if end > 0:
                    fm = content[3:end]
                    for line in fm.splitlines():
                        if line.startswith("name:"):
                            name = line[5:].strip()
                        elif line.startswith("agent:"):
                            agent = line[6:].strip()
                        elif line.startswith("description:"):
                            description = line[12:].strip()
        except Exception:
            pass
        skills.append({"slug": slug, "name": name, "agent": agent, "description": description})
    skills.sort(key=lambda s: s["name"])
    return skills


# ═══════════════════════════════════════════════════════════════════════════════
#  FILE INGESTION — replicates norm.py extractors
# ═══════════════════════════════════════════════════════════════════════════════

def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _save_file_to_memory(data: dict):
    MEMORY_DIR.mkdir(parents=True, exist_ok=True)
    db = _memory_db()
    con = sqlite3.connect(db)
    # Ensure tables exist
    con.execute("""CREATE TABLE IF NOT EXISTS files (
        path TEXT PRIMARY KEY, name TEXT, type TEXT,
        word_count INTEGER, page_count INTEGER,
        content TEXT, preview TEXT, toc TEXT,
        indexed_at TEXT, file_mtime REAL)""")
    try:
        con.execute("ALTER TABLE files ADD COLUMN file_mtime REAL")
    except Exception:
        pass
    try:
        con.execute("CREATE VIRTUAL TABLE IF NOT EXISTS files_fts USING fts5(path, name, content, tokenize='porter ascii')")
    except Exception:
        pass
    con.execute("""INSERT OR REPLACE INTO files
        (path,name,type,word_count,page_count,content,preview,toc,indexed_at,file_mtime)
        VALUES (?,?,?,?,?,?,?,?,?,?)""",
        (data["path"], data["name"], data["type"],
         data.get("word_count", 0), data.get("page_count", 0),
         data.get("content", ""), data.get("preview", ""),
         json.dumps(data.get("toc", [])), _now_iso(), data.get("file_mtime", 0)))
    try:
        con.execute("DELETE FROM files_fts WHERE path=?", (data["path"],))
        con.execute("INSERT INTO files_fts (path,name,content) VALUES (?,?,?)",
                    (data["path"], data["name"], data.get("content", "")))
    except Exception:
        pass
    con.commit()
    con.close()


def _ingest_bytes(filename: str, content_bytes: bytes, suffix: str) -> dict:
    """Ingest file bytes and return summary. Saves to SQLite."""
    tmp = Path("/tmp") / filename
    tmp.write_bytes(content_bytes)

    try:
        if suffix == ".pdf":
            data = _extract_pdf(tmp)
        elif suffix == ".docx":
            data = _extract_docx(tmp)
        elif suffix == ".xlsx":
            data = _extract_xlsx(tmp)
        elif suffix == ".pptx":
            data = _extract_pptx(tmp)
        elif suffix in (".txt", ".md"):
            data = _extract_text(tmp)
        elif suffix == ".msg":
            data = _extract_msg(tmp)
        elif suffix == ".eml":
            data = _extract_eml(tmp)
        else:
            return {"error": "Unsupported file type: " + suffix}

        if "error" in data:
            return data

        _save_file_to_memory({
            "path": "/uploaded/" + filename,
            "name": filename, "type": suffix,
            "word_count": data["word_count"],
            "page_count": data.get("page_count", 0),
            "content": data["content"],
            "preview": data["preview"],
            "toc": data.get("toc", []),
            "file_mtime": tmp.stat().st_mtime,
        })

        # Background semantic indexing
        _vector_index_bg("/uploaded/" + filename, filename, data["content"])

        return {
            "name": filename, "type": suffix,
            "word_count": data["word_count"],
            "page_count": data.get("page_count", 0),
            "toc": data.get("toc", [])[:5],
            "preview": data["preview"][:300],
        }
    finally:
        try:
            tmp.unlink()
        except Exception:
            pass


def _extract_text(path: Path) -> dict:
    content = path.read_text(encoding="utf-8", errors="replace")
    lines = content.splitlines(); toc = []
    if path.suffix.lower() == ".md":
        for line in lines:
            if line.startswith("#"):
                lv = len(line) - len(line.lstrip("#"))
                toc.append({"level": lv, "title": line.lstrip("# ").strip()})
    return {"content": content[:100000], "preview": "\n".join(lines[:15]),
            "toc": toc, "word_count": len(content.split()), "page_count": 0}


def _extract_pdf(path: Path) -> dict:
    try:
        import fitz
    except ImportError:
        return {"error": "pymupdf not installed"}
    doc = fitz.open(str(path)); page_count = len(doc); all_text = []; toc_entries = []
    for level, title, page in doc.get_toc()[:15]:
        toc_entries.append({"level": level, "title": title, "page": page})
    for i in range(page_count):
        text = doc[i].get_text("text")
        if text.strip(): all_text.append("[Page " + str(i+1) + "]\n" + text.strip())
    doc.close()
    full = "\n\n".join(all_text)
    return {"content": full[:100000], "preview": "\n".join(all_text[:3])[:500],
            "toc": toc_entries, "word_count": len(full.split()), "page_count": page_count}


def _extract_docx(path: Path) -> dict:
    try:
        from docx import Document
    except ImportError:
        return {"error": "python-docx not installed"}
    doc = Document(str(path)); paras = []; headings = []; tables = []
    for p in doc.paragraphs:
        if p.style.name.startswith("Heading"):
            lv = int(p.style.name.split()[-1]) if p.style.name.split()[-1].isdigit() else 1
            if p.text.strip(): headings.append({"level": lv, "title": p.text.strip()})
        if p.text.strip(): paras.append(p.text.strip())
    for i, t in enumerate(doc.tables):
        rows = [[c.text.strip() for c in r.cells] for r in t.rows if any(c.text.strip() for c in r.cells)]
        if rows: tables.append(rows)
    content = "\n\n".join(paras)
    for i, t in enumerate(tables):
        content += "\n\n[TABLE " + str(i+1) + "]\n" + "\n".join(" | ".join(r) for r in t)
    return {"content": content[:100000], "preview": "\n".join(paras[:10]),
            "toc": headings, "word_count": len(content.split()), "page_count": 0}


def _extract_xlsx(path: Path) -> dict:
    try:
        import openpyxl
    except ImportError:
        return {"error": "openpyxl not installed"}
    wb = openpyxl.load_workbook(str(path), read_only=True, data_only=True)
    content = ""; toc = []
    for sname in wb.sheetnames:
        ws = wb[sname]
        rows = [[str(c) if c is not None else "" for c in row]
                for row in ws.iter_rows(max_row=500, values_only=True)
                if any(c is not None for c in row)]
        if not rows: continue
        toc.append({"level": 1, "title": sname + " (" + str(len(rows)) + " rows)"})
        content += "\n\n[SHEET: " + sname + "]\n"
        if rows:
            content += " | ".join(rows[0]) + "\n" + "-"*30 + "\n"
            for row in rows[1:30]: content += " | ".join(row) + "\n"
    wb.close()
    return {"content": content[:100000], "preview": content[:300],
            "toc": toc, "word_count": len(content.split()), "page_count": len(toc)}


def _extract_pptx(path: Path) -> dict:
    try:
        from pptx import Presentation
    except ImportError:
        return {"error": "python-pptx not installed"}
    prs = Presentation(str(path)); content = ""; toc = []
    for i, slide in enumerate(prs.slides, 1):
        title = ""; body = []
        for shape in slide.shapes:
            if shape.has_text_frame:
                if shape.shape_type == 13: title = shape.text_frame.text.strip()
                else:
                    for p in shape.text_frame.paragraphs:
                        if p.text.strip(): body.append(p.text.strip())
        if title: toc.append({"level": 1, "title": "Slide " + str(i) + ": " + title})
        content += "\n[SLIDE " + str(i) + "]" + (" — " + title if title else "") + "\n"
        if body: content += "\n".join(body) + "\n"
    return {"content": content[:100000], "preview": content[:300],
            "toc": toc, "word_count": len(content.split()), "page_count": len(prs.slides)}


def _extract_msg(path: Path) -> dict:
    try:
        import extract_msg
        msg = extract_msg.Message(str(path))
    except ImportError:
        return {"error": "extract-msg not installed"}
    except Exception as e:
        return {"error": str(e)}
    content = "FROM: " + (msg.sender or "") + "\nSUBJECT: " + (msg.subject or "") + "\n\n" + (msg.body or "")
    return {"content": content[:50000], "preview": content[:300],
            "toc": [{"level": 1, "title": "Subject: " + (msg.subject or "")}],
            "word_count": len(content.split()), "page_count": 0}


def _extract_eml(path: Path) -> dict:
    with open(str(path), "rb") as f:
        msg = email_lib.message_from_bytes(f.read())
    body = ""
    if msg.is_multipart():
        for part in msg.walk():
            if part.get_content_type() == "text/plain":
                try: body = part.get_payload(decode=True).decode("utf-8", errors="replace"); break
                except Exception: pass
    else:
        try: body = msg.get_payload(decode=True).decode("utf-8", errors="replace")
        except Exception: body = str(msg.get_payload())
    content = "FROM: " + msg.get("From","") + "\nSUBJECT: " + msg.get("Subject","") + "\n\n" + body
    return {"content": content[:50000], "preview": content[:300],
            "toc": [{"level": 1, "title": "Subject: " + msg.get("Subject","")}],
            "word_count": len(content.split()), "page_count": 0}


# ═══════════════════════════════════════════════════════════════════════════════
#  VECTOR INDEXING — background thread, mirrors norm.py
# ═══════════════════════════════════════════════════════════════════════════════

_embed_model  = None
_embed_lock   = threading.Lock()


def _get_embed_model():
    global _embed_model
    if _embed_model is not None:
        return _embed_model
    with _embed_lock:
        if _embed_model is not None:
            return _embed_model
        try:
            from sentence_transformers import SentenceTransformer
            _embed_model = SentenceTransformer("all-MiniLM-L6-v2")
            return _embed_model
        except Exception:
            return None


def _chunk_text(text: str) -> list[str]:
    chunks = []; start = 0
    while start < len(text):
        end   = start + CHUNK_SIZE
        chunk = text[start:end]
        if chunk.strip(): chunks.append(chunk)
        if end >= len(text): break
        start = end - CHUNK_OVERLAP
    return chunks


def _vec_to_blob(vec: list) -> bytes:
    return struct.pack(f"{len(vec)}f", *vec)


def _vector_index_bg(file_path: str, file_name: str, content: str):
    def _run():
        try:
            model = _get_embed_model()
            if model is None: return
            chunks = _chunk_text(content)
            if not chunks: return
            MEMORY_DIR.mkdir(parents=True, exist_ok=True)
            con = sqlite3.connect(VECTOR_DB)
            con.execute("""CREATE TABLE IF NOT EXISTS chunks (
                id INTEGER PRIMARY KEY AUTOINCREMENT, file_path TEXT, file_name TEXT,
                chunk_idx INTEGER, text TEXT, embedding BLOB, indexed_at TEXT)""")
            con.execute("CREATE INDEX IF NOT EXISTS idx_chunks_path ON chunks(file_path)")
            con.execute("DELETE FROM chunks WHERE file_path=?", (file_path,))
            embeddings = model.encode(chunks, normalize_embeddings=True, show_progress_bar=False)
            rows = [(file_path, file_name, i, chunk, _vec_to_blob(emb.tolist()), _now_iso())
                    for i, (chunk, emb) in enumerate(zip(chunks, embeddings))]
            con.executemany(
                "INSERT INTO chunks (file_path,file_name,chunk_idx,text,embedding,indexed_at) VALUES (?,?,?,?,?,?)",
                rows)
            con.commit(); con.close()
        except Exception:
            pass
    threading.Thread(target=_run, daemon=True).start()


# ═══════════════════════════════════════════════════════════════════════════════
#  SSE STREAMING CHAT
# ═══════════════════════════════════════════════════════════════════════════════

def _sse(event: str, data: dict) -> str:
    """Format a Server-Sent Event."""
    return "event: " + event + "\ndata: " + json.dumps(data) + "\n\n"


async def _stream_plan(config: dict, client, provider: str, model_id: str,
                       user_input: str, target_agent: str | None,
                       agents: dict) -> AsyncIterator[str]:
    """
    Core streaming generator.
    Yields SSE events:
      plan_start  — Sam's routing decision
      step_start  — which agent is about to work
      token       — streaming text token
      step_end    — step complete
      plan_end    — all done
      error       — something went wrong
    """
    file_context = _build_file_context(query=user_input)
    history_msgs = _session.to_messages()

    # ── Route ──────────────────────────────────────────────────────────────────
    if target_agent:
        # Direct agent invocation — skip Sam's routing
        plan = {
            "intent": user_input,
            "steps":  [{"agent": target_agent, "task": user_input, "skill": None}],
        }
    else:
        # Sam routes — resilient: 3 attempts with stricter prompting + JSON
        # extraction, then falls back to a minimal Norm plan so the user
        # always gets a response. Every failure and recovery is journaled.
        yield _sse("status", {"message": "Sam is reading the room…"})
        stricter = ("\n\nYour previous response was not parseable JSON. "
                    "Return ONLY the JSON object — no markdown fences, no "
                    "commentary, nothing before or after the closing brace.")
        raw_responses = []
        last_error = None
        plan = None

        for attempt in range(3):
            try:
                messages = history_msgs + [{"role": "user", "content": user_input}]
                router_sys = ROUTER_SYSTEM if attempt == 0 else ROUTER_SYSTEM + stricter
                if provider == "anthropic":
                    r   = client.messages.create(model=model_id, max_tokens=ROUTER_MAX_TOKENS,
                            system=router_sys, messages=messages)
                    raw = r.content[0].text.strip()
                else:
                    r   = client.chat.completions.create(model=model_id, max_tokens=ROUTER_MAX_TOKENS,
                            messages=[{"role":"system","content":router_sys}] + messages)
                    raw = r.choices[0].message.content.strip()
                raw_responses.append(raw[:500])

                candidate = _try_extract_json(raw)
                if candidate and isinstance(candidate, dict) and "steps" in candidate:
                    plan = candidate
                    if attempt > 0:
                        _log_error("router_recovered",
                                   user_input=user_input,
                                   attempts=attempt+1,
                                   recovery_strategy=("retry_strict" if attempt == 1 else "json_extract"))
                        yield _sse("status", {"message": "Sam recovered — planning…"})
                    break
                last_error = "unparseable or malformed plan"
                if attempt < 2:
                    yield _sse("status", {"message": "Sam had trouble — retrying…"})
                    await asyncio.sleep(0.3)
            except Exception as e:
                last_error = str(e)
                if attempt < 2:
                    yield _sse("status", {"message": "Sam had trouble — retrying…"})
                    await asyncio.sleep(0.4 * (attempt + 1))

        if plan is None:
            # All 3 attempts exhausted — fall back so user gets SOMETHING
            _log_error("router_failed_all_retries",
                       user_input=user_input,
                       last_error=last_error,
                       raw_responses=raw_responses)
            yield _sse("status", {"message": "Router had trouble — routing to Norm as fallback."})
            plan = {
                "intent": user_input,
                "steps":  [{"agent": "norm", "task": user_input, "skill": None}],
                "needs_new_skill": False,
                "new_skill_name": None,
                "new_skill_description": None,
            }

    yield _sse("plan_start", {
        "intent": plan.get("intent", user_input),
        "steps":  [{"agent": s.get("agent","?"), "task": s.get("task","")} for s in plan.get("steps",[])],
        "model":  model_id, "provider": provider,
    })

    steps        = plan.get("steps", [])
    step_context = ""
    full_response = ""

    for i, step in enumerate(steps):
        aname  = step.get("agent", "norm").lower()
        task   = step.get("task", "")
        agent  = agents.get(aname, agents.get("norm", {}))
        name   = agent.get("name", aname.title())

        yield _sse("step_start", {"step": i+1, "total": len(steps), "agent": name, "task": task})

        # Build system prompt
        system = (
            "You are " + name + ", a character from TavernOS.\n"
            "Personality: " + agent.get("personality","") + "\n"
            "Quip style: " + agent.get("quip_style","") + "\n"
            "Skills: " + ", ".join(agent.get("skills",[])) + "\n\n"
            "Stay in character. Lead with a brief quip, then do the work."
            + (("\n\n" + file_context) if file_context else "")
            + "\n\n" + OUTPUT_CONTRACT
        )
        content = task
        if step_context:
            content += "\n\nContext from previous steps:\n" + step_context

        messages = history_msgs + [{"role": "user", "content": content}]

        step_text = ""
        first_token_sent = False
        last_error = None

        for attempt in range(3):
            try:
                if provider == "anthropic":
                    with client.messages.stream(
                        model=model_id, max_tokens=EXECUTE_MAX_TOKENS,
                        system=system, messages=messages
                    ) as stream:
                        for chunk in stream.text_stream:
                            first_token_sent = True
                            step_text    += chunk
                            full_response += chunk
                            yield _sse("token", {"text": chunk, "agent": name})
                            await asyncio.sleep(0)   # yield to event loop
                else:
                    stream = client.chat.completions.create(
                        model=model_id, max_tokens=EXECUTE_MAX_TOKENS,
                        messages=[{"role":"system","content":system}] + messages,
                        stream=True
                    )
                    for chunk in stream:
                        delta = chunk.choices[0].delta
                        if hasattr(delta, "content") and delta.content:
                            first_token_sent = True
                            step_text     += delta.content
                            full_response += delta.content
                            yield _sse("token", {"text": delta.content, "agent": name})
                            await asyncio.sleep(0)
                if attempt > 0:
                    _log_error("agent_recovered",
                               agent=name, attempts=attempt+1, task=task[:200])
                break
            except Exception as e:
                last_error = e
                if first_token_sent:
                    # Already streaming partial output — can't retry cleanly
                    _log_error("agent_stream_interrupted",
                               agent=name, error=str(e),
                               partial_text_bytes=len(step_text))
                    yield _sse("error", {"message": "Stream interrupted mid-response — partial output above. (logged for review)"})
                    break
                if attempt < 2:
                    yield _sse("status", {"message": name + " is retrying…"})
                    await asyncio.sleep(0.6 * (attempt + 1))
                    continue
                # All retries exhausted before first token — log and give up this step
                _log_error("agent_failed_all_retries",
                           agent=name, error=str(e), task=task[:200])
                yield _sse("error", {"message": "Stream error after 3 retries: " + str(e) + "  (logged — check /api/errors)"})
                return

        # Check for deliverable marker — if present, save file + notify UI
        deliverable = _process_deliverable_marker(step_text, name)
        if deliverable:
            yield _sse("deliverable_saved", deliverable)
            # Strip marker from step_text so next step's context doesn't carry it
            step_text     = DELIVERABLE_MARKER_RE.sub("", step_text).rstrip()
            full_response = DELIVERABLE_MARKER_RE.sub("", full_response).rstrip()

        step_context = "Step " + str(i+1) + " (" + aname + "):\n" + step_text
        yield _sse("step_end", {"step": i+1, "agent": name})

        # Brief separator between steps
        if i < len(steps) - 1:
            next_name = agents.get(steps[i+1].get("agent","?"), {}).get("name", steps[i+1].get("agent","?").title())
            yield _sse("status", {"message": next_name + " is reading the above…"})

    _session.add_assistant(full_response)
    yield _sse("plan_end", {"message": "All steps complete. Round's on the house."})


# ═══════════════════════════════════════════════════════════════════════════════
#  API ROUTES
# ═══════════════════════════════════════════════════════════════════════════════

@app.get("/", response_class=HTMLResponse)
async def serve_ui():
    """Serve the web UI."""
    html_file = Path(__file__).parent / "index.html"
    if html_file.exists():
        return HTMLResponse(content=html_file.read_text(encoding="utf-8"))
    return HTMLResponse(content="<h1>TavernOS Web UI</h1><p>index.html not found.</p>")


@app.get("/api/status")
async def get_status():
    config   = _load_config()
    mode     = _get_mode()
    provider, model_id = _get_active_model(config)
    company  = config.get("company_name", "TavernOS")
    files    = _list_files()
    agents   = _load_agents()
    skills   = _list_skills()
    return JSONResponse({
        "mode":       mode,
        "company":    company,
        "provider":   provider,
        "model_id":   model_id,
        "agents":     len(agents),
        "files":      len(files),
        "skills":     len(skills),
        "history":    len(_session.history),
        "semantic":   _get_embed_model() is not None,
        "version":    "v0.1.0",
    })


@app.get("/api/agents")
async def get_agents():
    agents = _load_agents()
    result = []
    for key, a in agents.items():
        result.append({
            "id":          key,
            "name":        a.get("name", key.title()),
            "personality": a.get("personality", ""),
            "quip_style":  a.get("quip_style", ""),
            "skills":      a.get("skills", []),
        })
    result.sort(key=lambda x: x["name"])
    return JSONResponse(result)


@app.get("/api/skills")
async def get_skills():
    return JSONResponse(_list_skills())


@app.get("/api/files")
async def get_files():
    return JSONResponse(_list_files())


@app.get("/api/history")
async def get_history():
    return JSONResponse(_session.to_list())


@app.delete("/api/history")
async def clear_history():
    _session.clear()
    return JSONResponse({"status": "ok", "message": "History cleared"})


@app.post("/api/search")
async def search_files(request: Request):
    body  = await request.json()
    query = body.get("query", "").strip()
    if not query:
        return JSONResponse({"results": []})
    results = _fts_search(query, limit=8)
    return JSONResponse({"results": results, "query": query})


@app.post("/api/upload")
async def upload_file(file: UploadFile = File(...)):
    filename = file.filename or "upload"
    suffix   = Path(filename).suffix.lower()
    if suffix not in SUPPORTED_EXT:
        return JSONResponse(
            {"error": "Unsupported file type: " + suffix +
             ". Supported: " + ", ".join(sorted(SUPPORTED_EXT))},
            status_code=400
        )
    content_bytes = await file.read()
    result = _ingest_bytes(filename, content_bytes, suffix)
    if "error" in result:
        return JSONResponse(result, status_code=422)
    return JSONResponse({"status": "ok", "file": result})


@app.post("/api/chat")
async def chat(request: Request):
    body         = await request.json()
    user_input   = body.get("message", "").strip()
    target_agent = body.get("agent", None)   # None = Sam routes; "cliff" = direct

    if not user_input:
        return JSONResponse({"error": "Empty message"}, status_code=400)

    config = _load_config()
    if not config:
        return JSONResponse({"error": "No config found. Run norm --setup first."}, status_code=503)

    client, provider, model_id = _build_client(config)
    if not client:
        return JSONResponse({"error": "No API client. Check your API key in config."}, status_code=503)

    agents = _load_agents()
    _session.add_user(user_input)

    async def generate():
        async for event in _stream_plan(config, client, provider, model_id,
                                        user_input, target_agent, agents):
            yield event

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control":  "no-cache",
            "X-Accel-Buffering": "no",
            "Connection":     "keep-alive",
        }
    )


@app.get("/api/deliverable")
async def get_deliverable(path: str):
    """Serve a saved deliverable as a rendered HTML page.

    Security: the resolved path must stay inside USER_DIR/clients/. Anything
    outside is rejected with 400. Only .md files are served."""
    try:
        rel = Path(path)
        abs_path = (USER_DIR / rel).resolve()
        clients_base = CLIENTS_DIR.resolve()
        abs_path.relative_to(clients_base)  # raises ValueError if outside
    except (ValueError, OSError):
        return HTMLResponse("<h1>Invalid path</h1>", status_code=400)

    if not abs_path.exists() or not abs_path.is_file():
        return HTMLResponse("<h1>Not found</h1>", status_code=404)
    if abs_path.suffix.lower() != ".md":
        return HTMLResponse("<h1>Not a markdown file</h1>", status_code=400)

    try:
        content = abs_path.read_text(encoding="utf-8")
    except Exception as e:
        return HTMLResponse("<h1>Read error</h1><p>" + str(e) + "</p>", status_code=500)

    # Build breadcrumbs from the path relative to clients/
    try:
        crumb_parts = abs_path.relative_to(clients_base).parts
    except ValueError:
        crumb_parts = (abs_path.name,)
    breadcrumbs = " / ".join(crumb_parts)
    return HTMLResponse(_render_deliverable_viewer(abs_path.name, breadcrumbs, content))


def _render_deliverable_viewer(title: str, breadcrumbs: str, content: str) -> str:
    """Return a minimal HTML page that renders the deliverable's Markdown
    using marked.js on the client side. Uses the same brand palette as the
    main chat UI. Content is embedded as a safely-serialized JS string."""
    import html as _html
    # Embed content as JSON so any special chars are safely encoded for JS
    content_js = json.dumps(content)
    t = _html.escape(title)
    b = _html.escape(breadcrumbs)
    return (
        '<!DOCTYPE html>\n<html lang="en"><head>\n'
        '<meta charset="UTF-8">\n'
        '<title>' + t + ' · TavernOS</title>\n'
        '<link rel="preconnect" href="https://fonts.googleapis.com">\n'
        '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>\n'
        '<link href="https://fonts.googleapis.com/css2?family=DM+Mono:wght@300;400;500'
        '&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">\n'
        '<script src="https://cdnjs.cloudflare.com/ajax/libs/marked/12.0.2/marked.min.js"></script>\n'
        '<style>\n'
        ':root{--teal:#00d4c8;--teal3:#007972;--navy:#060f1a;--navy2:#0b1929;'
        '--navy3:#0f2236;--navy4:#162d47;--white:#f0f6ff;--gray:#7a9ab5;--gray2:#4a6a85;}\n'
        '*{box-sizing:border-box;margin:0;padding:0;}\n'
        'body{font-family:"DM Sans",sans-serif;background:var(--navy);color:var(--white);'
        'font-size:15px;line-height:1.7;min-height:100vh;}\n'
        '.wrap{max-width:820px;margin:0 auto;padding:40px 32px 80px;}\n'
        '.hdr{border-bottom:1px solid var(--navy4);padding-bottom:20px;margin-bottom:32px;}\n'
        '.crumbs{font-family:"DM Mono",monospace;font-size:11px;color:var(--gray2);'
        'letter-spacing:.05em;margin-bottom:8px;}\n'
        '.title{font-size:28px;font-weight:600;color:var(--white);letter-spacing:-.02em;}\n'
        '.actions{margin-top:14px;display:flex;gap:10px;}\n'
        '.btn{background:transparent;border:1px solid var(--navy4);color:var(--gray);'
        'padding:7px 14px;font-family:"DM Mono",monospace;font-size:11px;cursor:pointer;'
        'border-radius:4px;text-decoration:none;display:inline-block;}\n'
        '.btn:hover{color:var(--teal);border-color:var(--teal3);}\n'
        '.doc{color:var(--white);}\n'
        '.doc h1,.doc h2,.doc h3,.doc h4{color:var(--teal);font-weight:600;'
        'margin:26px 0 10px;letter-spacing:-.01em;line-height:1.3;}\n'
        '.doc h1{font-size:26px;}.doc h2{font-size:21px;}.doc h3{font-size:17px;}\n'
        '.doc h1:first-child,.doc h2:first-child{margin-top:0;}\n'
        '.doc p{margin:0 0 14px;}\n'
        '.doc strong{color:var(--white);font-weight:600;}\n'
        '.doc em{color:var(--white);font-style:italic;}\n'
        '.doc ul,.doc ol{margin:10px 0 18px;padding-left:26px;}\n'
        '.doc li{margin:4px 0;}.doc li::marker{color:var(--teal);}\n'
        '.doc code{background:var(--navy3);padding:2px 6px;border-radius:3px;'
        'font-family:"DM Mono",monospace;font-size:13px;color:var(--teal);}\n'
        '.doc pre{background:var(--navy3);border-left:3px solid var(--teal);'
        'padding:14px 18px;border-radius:4px;overflow-x:auto;margin:14px 0;}\n'
        '.doc pre code{background:transparent;padding:0;color:var(--white);}\n'
        '.doc blockquote{border-left:3px solid var(--teal3);padding-left:16px;'
        'margin:14px 0;color:var(--gray);font-style:italic;}\n'
        '.doc hr{border:none;border-top:1px solid var(--navy4);margin:24px 0;}\n'
        '.doc table{border-collapse:collapse;margin:16px 0;width:100%;font-size:14px;}\n'
        '.doc th,.doc td{border:1px solid var(--navy4);padding:10px 14px;'
        'text-align:left;vertical-align:top;}\n'
        '.doc th{background:var(--navy3);color:var(--teal);font-weight:600;'
        'font-size:12px;text-transform:uppercase;letter-spacing:.05em;}\n'
        '.doc tr:nth-child(even) td{background:var(--navy3);}\n'
        '.doc a{color:var(--teal);text-decoration:none;'
        'border-bottom:1px solid var(--teal3);}\n'
        '.doc a:hover{color:var(--white);}\n'
        '@media print{body{background:white;color:#1a1a1a;}\n'
        '.wrap{padding:20px 30px;}.crumbs,.actions,.btn{display:none;}\n'
        '.title,.doc,.doc strong,.doc em{color:#1a1a1a;}\n'
        '.doc h1,.doc h2,.doc h3,.doc h4{color:#00796b;}\n'
        '.doc code{background:#f7fafc;color:#00796b;}\n'
        '.doc pre{background:#f7fafc;color:#1a1a1a;border-left-color:#00796b;}\n'
        '.doc th{background:#f7fafc;color:#00796b;}\n'
        '.doc tr:nth-child(even) td{background:#f7fafc;}\n'
        '.doc a{color:#00796b;}\n'
        'h1,h2,h3{page-break-after:avoid;}.hdr{border-bottom-color:#e2e8f0;}\n'
        '}\n'
        '::-webkit-scrollbar{width:8px;}\n'
        '::-webkit-scrollbar-track{background:var(--navy);}\n'
        '::-webkit-scrollbar-thumb{background:var(--navy4);border-radius:4px;}\n'
        '</style></head>\n<body>\n'
        '<div class="wrap">\n'
        '  <div class="hdr">\n'
        '    <div class="crumbs">' + b + '</div>\n'
        '    <div class="title">' + t + '</div>\n'
        '    <div class="actions">\n'
        '      <a class="btn" href="javascript:window.close()">Close</a>\n'
        '      <a class="btn" href="javascript:window.print()">Print / Save PDF</a>\n'
        '    </div>\n'
        '  </div>\n'
        '  <div class="doc" id="doc"></div>\n'
        '</div>\n'
        '<script>\n'
        'const raw = ' + content_js + ';\n'
        'if (typeof marked !== "undefined") {\n'
        '  marked.setOptions({gfm:true,breaks:true,headerIds:false,mangle:false});\n'
        '  document.getElementById("doc").innerHTML = marked.parse(raw);\n'
        '} else {\n'
        '  const pre = document.createElement("pre");\n'
        '  pre.textContent = raw;\n'
        '  document.getElementById("doc").appendChild(pre);\n'
        '}\n'
        '</script>\n'
        '</body></html>\n'
    )


@app.get("/api/errors")
async def get_errors(limit: int = 20):
    """Return the last N entries from the error journal as JSON.
    Used by /errors in the UI to show recent failures + recoveries."""
    if not ERRORS_JOURNAL.exists():
        return JSONResponse({"entries": [], "total": 0,
                             "journal_path": str(ERRORS_JOURNAL),
                             "message": "No errors logged. All clear."})
    records = []
    try:
        with open(ERRORS_JOURNAL, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    records.append(json.loads(line))
                except Exception:
                    pass
    except Exception as e:
        return JSONResponse({"error": "Could not read journal: " + str(e)}, status_code=500)
    recent = records[-max(1, min(limit, 100)):]
    return JSONResponse({
        "entries":      recent,
        "total":        len(records),
        "journal_path": str(ERRORS_JOURNAL),
    })


@app.post("/api/errors/note")
async def post_error_note(request: Request):
    """Append a user-supplied note to the error journal. Lets you flag
    an issue in the moment — 'I noticed X is happening and it's annoying' —
    and have the note show up alongside the auto-captured errors when you
    review the journal later."""
    body = await request.json()
    note = (body.get("note") or "").strip()
    context = body.get("context") or {}
    if not note:
        return JSONResponse({"error": "Empty note"}, status_code=400)
    _log_error("user_note",
               note=note[:2000],
               user_input=(context.get("user_input") or "")[:500],
               related_error=(context.get("related_error") or "")[:500])
    return JSONResponse({"status": "ok", "message": "Note logged."})


@app.get("/health")
def health():
    return {"status": "ok", "service": "TavernOS Web UI", "version": "0.1.0"}


# ═══════════════════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════════

def start():
    """Called by norm.py --web"""
    uvicorn.run(app, host="127.0.0.1", port=7777, log_level="warning")


if __name__ == "__main__":
    print("TavernOS Web UI starting on http://127.0.0.1:7777")
    uvicorn.run(app, host="127.0.0.1", port=7777, log_level="info")