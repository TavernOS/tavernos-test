"""
TavernOS Web UI — server.py
============================
FastAPI backend for the browser interface.
Runs on http://127.0.0.1:7777

Endpoints:
  GET  /                   → serves index.html
  GET  /api/status         → mode, model, agents, files summary
  GET  /api/agents         → list of all agents
  GET  /api/skills         → list of installed skills
  GET  /api/files          → list of ingested files
  GET  /api/history        → conversation history
  POST /api/clear          → clear conversation history
  POST /api/chat           → SSE streaming chat endpoint
  POST /api/upload         → file upload + ingest
  POST /api/search         → search ingested files
  DELETE /api/history      → clear history
"""

import os
import sys
import json
import asyncio
import sqlite3
import re
import struct
import threading
import tempfile
import email as email_lib
from pathlib import Path
from datetime import datetime, timezone
from typing import AsyncIterator

from fastapi import FastAPI, Request, UploadFile, File, Form
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

# ── Add the tavernos package to path so we can reuse norm's internals ─────────
PKG_DIR = Path(__file__).parent.parent   # tavernos/
sys.path.insert(0, str(PKG_DIR.parent))  # project root

# ── Paths (mirror norm.py) ────────────────────────────────────────────────────
USER_DIR    = Path.home() / ".tavernos"
CONFIG_FILE = USER_DIR / "config.json"
STAGING_CONFIG_FILE = USER_DIR / "staging_config.json"
MEMORY_DIR  = USER_DIR / "memory"
DIAG_DIR    = USER_DIR / "diagnostics"
ERRORS_JOURNAL = DIAG_DIR / "errors.jsonl"
AGENTS_DIR  = PKG_DIR / "agents"
SKILLS_DIR  = PKG_DIR / "skills"
VECTOR_DB   = MEMORY_DIR / "vectors.db"
PERF_DB     = MEMORY_DIR / "skill_performance.db"

CHUNK_SIZE    = 2048
CHUNK_OVERLAP = 200
SUPPORTED_EXT = {".txt", ".md", ".pdf", ".docx", ".xlsx", ".pptx", ".msg", ".eml"}

FILE_TYPE_LABELS = {
    ".txt": "Plain text", ".md": "Markdown",   ".pdf": "PDF",
    ".docx": "Word",      ".xlsx": "Excel",    ".pptx": "PowerPoint",
    ".msg": "Outlook email", ".eml": "Email",
}

FILE_ICONS = {
    ".pdf": "📄", ".docx": "📝", ".xlsx": "📊",
    ".pptx": "📋", ".msg": "📧", ".eml": "📧",
    ".txt": "📃", ".md": "📃",
}

FALLBACK_MODELS = [
    {"provider": "anthropic", "id": "claude-opus-4-5",   "name": "Claude Opus 4.5",   "tier": 1},
    {"provider": "anthropic", "id": "claude-sonnet-4-6", "name": "Claude Sonnet 4.6", "tier": 2},
    {"provider": "anthropic", "id": "claude-haiku-4-5",  "name": "Claude Haiku 4.5",  "tier": 3},
]

ROUTER_MAX_TOKENS  = 1000
EXECUTE_MAX_TOKENS = 4000

# Web search — mirror of norm.py's constants. Cliff is the only agent with
# web search in Phase 1; the tool itself is a server-tool (Anthropic executes
# server-side, we ACK with empty content).
WEB_SEARCH_AGENTS = {"cliff"}
WEB_SEARCH_TOOL   = {"type": "web_search_20250305", "name": "web_search"}

# Session 22 — norm module reference for shared state and helpers. Pre-
# session-22 this file imported nothing from norm and defined its own
# (heavily drifted) ROUTER_SYSTEM, OUTPUT_CONTRACT, and inline system-
# prompt assembly. Three sessions of routing/grounding/MBR-gate work in
# norm.py never reached the web because of this. Session-22 wires the web
# UI through norm's helpers so they share a single source of truth — same
# pattern that session-19 did for the CLI-side server.py file (which, per
# the session-22 handoff, turned out to be unused in production).
from tavernos import norm as _norm

# Use norm.py's ROUTER_SYSTEM as the single source of truth (session 22).
# The previous local copy had drifted across many sessions — it was missing
# the rebecca-mbr/rebecca-deck slug split, the Files-in-memory rule, the
# BOUND/CLARIFY mode classification, lilith routing, diane routing, and the
# session-22 SINGLE-AGENT DEFAULT rule. To update routing rules going
# forward, edit ROUTER_SYSTEM in norm.py only — this import pulls the live
# constant.
ROUTER_SYSTEM = _norm.ROUTER_SYSTEM

# Session 22 startup diagnostic — writes to a file rather than stderr because
# `norm --web` swallows or redirects stderr in a way we couldn't trace, so the
# session-19/20/21 stderr-based diagnostics we deployed in tavernos/server.py
# were never visible to the operator. The diagnostics directory exists by
# install convention (see DIAG_DIR above). This line writes ONCE at module
# import; the per-request diagnostic is added inside _stream_plan below.
# Remove both diagnostics once the session-22 deploy is trusted; harmless
# to leave.
try:
    DIAG_DIR.mkdir(parents=True, exist_ok=True)
    with open(DIAG_DIR / "web_startup.log", "a", encoding="utf-8") as _f:
        _f.write(
            f"[{datetime.now(timezone.utc).isoformat()}] "
            f"[web/server.py session 22] ROUTER_SYSTEM loaded: "
            f"len={len(ROUTER_SYSTEM)}, "
            f"has_rebecca-deck={'rebecca-deck' in ROUTER_SYSTEM}, "
            f"has_lilith={'lilith' in ROUTER_SYSTEM}, "
            f"has_diane={'diane' in ROUTER_SYSTEM}, "
            f"has_files_in_memory={'files in memory' in ROUTER_SYSTEM}, "
            f"has_single_agent_default={'SINGLE-AGENT DEFAULT' in ROUTER_SYSTEM}, "
            f"has_build_agent_system_prompt={hasattr(_norm, 'build_agent_system_prompt')}, "
            f"has_postprocess_router_plan={hasattr(_norm, 'postprocess_router_plan')}, "
            f"has_intermediate_output_contract={hasattr(_norm, 'INTERMEDIATE_OUTPUT_CONTRACT')}\n"
        )
except Exception:
    pass

# Use norm.py's OUTPUT_CONTRACT as the single source of truth (session 22).
# Pre-session-22 the local copy lacked the entire grounding-discipline
# section — no BOUND/CLARIFY framework, no HARD GROUNDING RULE, no
# anti-fabrication language at all. That fully explains the financial-
# fabrication bug seen in earlier web-UI tests. After this import the web
# inherits norm's session-21 OUTPUT_CONTRACT including the HARD GROUNDING
# RULE for financial figures, market data, and named third parties.
# Note: after the session-22 _stream_plan refactor below, this constant
# is not directly referenced from this file (system-prompt assembly is
# delegated to _norm.build_agent_system_prompt, which uses norm's
# OUTPUT_CONTRACT internally). Kept as a defensive import in case future
# code in this file re-introduces an OUTPUT_CONTRACT reference.
OUTPUT_CONTRACT = _norm.OUTPUT_CONTRACT


# ═══════════════════════════════════════════════════════════════════════════════
#  DELIVERABLE AUTO-SAVE — mirrors norm.py. Detects the DELIVERABLE_SAVED
#  marker in agent output, writes the file into the active client's workspace
#  (sandboxed), and emits a `deliverable_saved` SSE event so the UI can render
#  a preview card.
# ═══════════════════════════════════════════════════════════════════════════════

import urllib.parse as _urlparse

CLIENTS_DIR         = USER_DIR / "clients"
ACTIVE_CLIENT_FILE  = CLIENTS_DIR / "_active"
DEFAULT_CLIENT_SLUG = "_self"

DELIVERABLE_MARKER_RE        = re.compile(r'^DELIVERABLE_SAVED:\s*(.+?)\s*$', re.MULTILINE)
VALID_DELIVERABLE_CATEGORIES = {"reports", "audits", "blueprints", "content"}


def _active_slug() -> str:
    """Read active client slug from disk. Falls back to _self."""
    try:
        if ACTIVE_CLIENT_FILE.exists():
            slug = ACTIVE_CLIENT_FILE.read_text(encoding="utf-8").strip()
            if slug:
                return slug
    except Exception:
        pass
    return DEFAULT_CLIENT_SLUG


def _client_deliverables_dir(slug: str = None) -> Path:
    return CLIENTS_DIR / (slug or _active_slug()) / "deliverables"


def _resolve_deliverable_path(marker_path: str, slug: str = None):
    """Resolve a marker path to an absolute Path inside the active client's
    workspace. Returns None if the path is invalid or escapes the sandbox."""
    if not marker_path:
        return None
    marker_path = marker_path.lstrip("/\\").strip()
    if not marker_path or ".." in Path(marker_path).parts:
        return None
    if not marker_path.lower().endswith(".md"):
        marker_path += ".md"
    parts = Path(marker_path).parts
    if parts[0] not in VALID_DELIVERABLE_CATEGORIES:
        marker_path = "reports/" + marker_path
    base = _client_deliverables_dir(slug).resolve()
    try:
        final = (base / marker_path).resolve()
        final.relative_to(base)
    except (ValueError, OSError):
        return None
    return final


def _process_deliverable_marker(text: str, agent_name: str):
    """If text contains a DELIVERABLE_SAVED marker, write the file (marker
    stripped) and return a dict describing what was saved. Returns None otherwise."""
    if not text:
        return None
    match = DELIVERABLE_MARKER_RE.search(text)
    if not match:
        return None
    marker_path = match.group(1).strip()
    final_path = _resolve_deliverable_path(marker_path)
    if not final_path:
        return None
    cleaned = DELIVERABLE_MARKER_RE.sub("", text).rstrip() + "\n"
    try:
        final_path.parent.mkdir(parents=True, exist_ok=True)
        final_path.write_text(cleaned, encoding="utf-8")
    except Exception:
        return None
    try:
        rel = final_path.relative_to(USER_DIR).as_posix()
    except ValueError:
        rel = final_path.as_posix()
    preview_lines = [ln for ln in cleaned.splitlines() if ln.strip()][:3]
    return {
        "filename": final_path.name,
        "path":     rel,
        "category": final_path.parent.name,
        "agent":    agent_name,
        "bytes":    final_path.stat().st_size,
        "preview":  "\n".join(preview_lines),
        "view_url": "/api/deliverable?path=" + _urlparse.quote(rel, safe=""),
    }


def _enrich_first_party_banner(banner: dict, agent_name: str) -> dict:
    """Augment a first-party tool banner into the dict shape that
    renderDeliverableCard (in index.html) expects.

    Input shape (from norm._dispatch_first_party_tool):
        {filename, path, bytes}
    Output shape (matches _process_deliverable_marker's return):
        {filename, path, bytes, agent, category, view_url, preview}

    Path handling
    -------------
    The bridge can't trust banner['path'] because the artifact handlers
    emit either a client-relative form or an absolute one depending on
    their author (see norm.py:713 — "Path from parts[1] is whatever the
    handler returned"). We re-resolve from disk by walking the active
    client's deliverables subfolders in the same priority order
    norm._resolve_banner_eval_context uses (reports → content → audits →
    blueprints), so the workspace-relative `path` field returned here is
    always USER_DIR-relative posix — exactly what /api/deliverable expects
    to see in its `path` query arg, and what the markdown-marker path
    already produces for visual parity.

    Failure mode
    ------------
    On disk-resolution failure we still return a renderable dict — the
    file may have been deleted between save and SSE emit (unlikely but
    possible), and the user should still see SOMETHING in the chat
    rather than a silent dropped banner. category and view_url degrade
    cleanly to '' which renderDeliverableCard handles (no link, no
    category chip).

    Preview
    -------
    Intentionally empty. Artifact tools today produce binary outputs
    (xlsx/docx/pptx); dumping bytes into the card is useless. The
    front-end's `(preview ? ... : '')` guard skips the dc-preview block
    entirely when preview is empty, so the card stays clean. If a
    future first-party tool emits text, this helper can grow a
    text-extension branch that mirrors _process_deliverable_marker's
    first-3-non-blank-lines logic.
    """
    out = {
        "filename": banner.get("filename", "") or "",
        "path":     banner.get("path", "") or "",
        "bytes":    banner.get("bytes", 0) or 0,
        "agent":    agent_name or "Agent",
        "category": "",
        "view_url": "",
        "preview":  "",
    }
    fname = out["filename"]
    if not fname:
        return out
    base = _client_deliverables_dir().resolve()
    abs_path = None
    category = ""
    # Same iteration order as norm._resolve_banner_eval_context. xlsx
    # writes default to reports/, docx to content/, pptx to reports/;
    # the loop covers all four DELIVERABLE_DIRS so a future template
    # variant that lands elsewhere still resolves.
    for sub in ("reports", "content", "audits", "blueprints"):
        cand = base / sub / fname
        if cand.exists():
            abs_path = cand
            category = sub
            break
    if abs_path is not None:
        try:
            rel = abs_path.relative_to(USER_DIR).as_posix()
        except ValueError:
            rel = abs_path.as_posix()
        out["path"]     = rel
        out["category"] = category
        out["view_url"] = "/api/deliverable?path=" + _urlparse.quote(rel, safe="")
    return out


# ═══════════════════════════════════════════════════════════════════════════════
#  RESILIENCE — error journal + JSON extraction. Mirrors norm.py.
#  Every failure lands in ERRORS_JOURNAL (one JSON object per line). Use
#  /errors in the CLI or GET /api/errors in the web UI to review.
# ═══════════════════════════════════════════════════════════════════════════════

def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _log_error(kind: str, **context):
    """Append an error record to the diagnostics journal. Never raises."""
    try:
        DIAG_DIR.mkdir(parents=True, exist_ok=True)
        rec = {"ts": _now_iso(), "kind": kind, **context}
        with open(ERRORS_JOURNAL, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception:
        pass


def _try_extract_json(text: str):
    """Progressively strip noise and extract a JSON object. Returns dict or None."""
    if not text:
        return None
    try:
        return json.loads(text)
    except Exception:
        pass
    cleaned = re.sub(r"^```[a-zA-Z]*\n?", "", text.strip())
    cleaned = re.sub(r"\n?```\s*$", "", cleaned)
    try:
        return json.loads(cleaned)
    except Exception:
        pass
    start = cleaned.find("{")
    if start < 0:
        return None
    depth = 0
    in_string = False
    escape = False
    for i in range(start, len(cleaned)):
        c = cleaned[i]
        if escape:
            escape = False
            continue
        if c == "\\":
            escape = True
            continue
        if c == '"':
            in_string = not in_string
            continue
        if in_string:
            continue
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                try:
                    return json.loads(cleaned[start:i+1])
                except Exception:
                    return None
    return None


# ═══════════════════════════════════════════════════════════════════════════════
#  APP SETUP
# ═══════════════════════════════════════════════════════════════════════════════

app = FastAPI(title="TavernOS Web UI", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# Serve static files from the web/ directory if they exist
_web_dir = Path(__file__).parent
if (_web_dir / "static").exists():
    app.mount("/static", StaticFiles(directory=str(_web_dir / "static")), name="static")


# ═══════════════════════════════════════════════════════════════════════════════
#  SESSION STATE — in-memory, reset on server restart
# ═══════════════════════════════════════════════════════════════════════════════

class SessionState:
    def __init__(self):
        self.history: list[tuple[str, str]] = []   # (user, assistant) pairs
        self.max_pairs = 10
        self.pending_user = ""

    def add_user(self, msg: str):
        self.pending_user = msg

    def add_assistant(self, msg: str):
        if self.pending_user:
            self.history.append((self.pending_user, msg))
            if len(self.history) > self.max_pairs:
                self.history = self.history[-self.max_pairs:]
            self.pending_user = ""

    def to_messages(self) -> list[dict]:
        msgs = []
        for u, a in self.history:
            msgs.append({"role": "user",      "content": u})
            msgs.append({"role": "assistant", "content": a})
        return msgs

    def clear(self):
        self.history = []
        self.pending_user = ""

    def to_list(self) -> list[dict]:
        result = []
        for i, (u, a) in enumerate(self.history):
            result.append({"index": i+1, "user": u, "assistant": a})
        return result


_session = SessionState()


# ═══════════════════════════════════════════════════════════════════════════════
#  CONFIG HELPERS
# ═══════════════════════════════════════════════════════════════════════════════

def _load_config() -> dict:
    for path in [CONFIG_FILE, STAGING_CONFIG_FILE]:
        if path.exists():
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
    return {}


def _get_mode() -> str:
    if STAGING_CONFIG_FILE.exists() and not CONFIG_FILE.exists():
        return "staging"
    cfg = _load_config()
    # Detect by presence of registry_token
    if cfg.get("registry_token"):
        return "dev"
    return "customer"


def _get_providers(config: dict) -> dict:
    if "providers" in config: return config["providers"]
    if "api_key"   in config: return {"anthropic": config["api_key"]}
    return {}


def _get_active_model(config: dict) -> tuple[str, str]:
    active = config.get("active_model", {})
    if active:
        return active.get("provider", "anthropic"), active.get("model_id", "claude-opus-4-5")
    return "anthropic", config.get("model", "claude-opus-4-5")


def _build_client(config: dict):
    provider, model_id = _get_active_model(config)
    providers = _get_providers(config)
    api_key   = providers.get(provider, "")
    if not api_key:
        return None, provider, model_id
    try:
        if provider == "anthropic":
            import anthropic
            return anthropic.Anthropic(api_key=api_key), provider, model_id
        else:
            import openai
            return openai.OpenAI(api_key=api_key), provider, model_id
    except Exception:
        return None, provider, model_id


# ═══════════════════════════════════════════════════════════════════════════════
#  MEMORY / FILE HELPERS — reads the same SQLite as norm.py
# ═══════════════════════════════════════════════════════════════════════════════

def _memory_db() -> Path:
    return MEMORY_DIR / "tavern_memory.db"


def _list_files() -> list[dict]:
    db = _memory_db()
    if not db.exists():
        return []
    try:
        con  = sqlite3.connect(db)
        rows = con.execute(
            "SELECT path,name,type,word_count,page_count,indexed_at FROM files ORDER BY indexed_at DESC"
        ).fetchall()
        con.close()
    except Exception:
        return []
    # Check vector coverage
    vec_paths: set[str] = set()
    if VECTOR_DB.exists():
        try:
            con = sqlite3.connect(VECTOR_DB)
            vec_paths = set(r[0] for r in con.execute("SELECT DISTINCT file_path FROM chunks").fetchall())
            con.close()
        except Exception:
            pass
    result = []
    for r in rows:
        result.append({
            "path": r[0], "name": r[1], "type": r[2],
            "word_count": r[3], "page_count": r[4], "indexed_at": r[5],
            "icon": FILE_ICONS.get(r[2], "📄"),
            "label": FILE_TYPE_LABELS.get(r[2], r[2]),
            "semantic": r[0] in vec_paths,
        })
    return result


def _fts_search(query: str, limit: int = 6) -> list[dict]:
    db = _memory_db()
    if not db.exists():
        return []
    try:
        con  = sqlite3.connect(db)
        rows = con.execute("""
            SELECT f.path, f.name, f.type, f.word_count, f.page_count,
                   snippet(files_fts, 2, '[', ']', '...', 20) as excerpt
            FROM files_fts JOIN files f ON files_fts.path = f.path
            WHERE files_fts MATCH ? ORDER BY rank LIMIT ?
        """, (query, limit)).fetchall()
        con.close()
        return [{"path": r[0], "name": r[1], "type": r[2], "word_count": r[3],
                 "page_count": r[4], "excerpt": r[5], "source": "keyword"} for r in rows]
    except Exception:
        return []


def _build_file_context(query: str = "") -> str:
    db = _memory_db()
    if not db.exists():
        return ""
    try:
        con   = sqlite3.connect(db)
        files = con.execute(
            "SELECT path,name,type,word_count,page_count FROM files ORDER BY indexed_at DESC"
        ).fetchall()
        con.close()
    except Exception:
        return ""
    if not files:
        return ""
    context = "\n\nINGESTED DOCUMENTS IN MEMORY:\n"
    if query:
        results = _fts_search(query, limit=3)
        if results:
            context += "\nRelevant sections for this query:\n"
            for r in results:
                context += "\n--- " + r["name"] + " ---\n" + r["excerpt"] + "\n"
            context += "\nAll available files: " + ", ".join(r[1] for r in files)
            return context
    for path, name, ftype, wc, pc in files[:3]:
        try:
            con = sqlite3.connect(_memory_db())
            rec = con.execute("SELECT content FROM files WHERE path=?", (path,)).fetchone()
            con.close()
        except Exception:
            rec = None
        if rec:
            pages = str(pc) + " pages" if pc else str(wc) + " words"
            context += "\n--- " + name + " (" + pages + ") ---\n"
            context += (rec[0] or "")[:6000] + "\n[end excerpt]\n"
    if len(files) > 3:
        context += "\n... and " + str(len(files)-3) + " more files."
    return context


def _load_agents() -> dict:
    """Load agents/*.json into a dict keyed by SLUG (filename stem).

    Session 22 bugfix: pre-fix this used `a.get("name", f.stem).lower()` as
    the dict key. That broke for agents whose filename and `name` field
    differ — most importantly rebecca-deck.json and rebecca-mbr.json, both
    of which have name="Rebecca". They (a) collided with each other under
    key "rebecca" and (b) never matched when the router emitted slugs like
    "rebecca-deck" or "rebecca-mbr" as the agent name in plans. The lookup
    fell through to Norm's persona, which is why "rebecca-deck" steps in
    web-UI plans were executed under Norm's voice.

    Now keyed by filename stem (the slug). Each agent dict also gets a
    `slug` field added if not already present, so build_agent_system_prompt
    and other slug-aware helpers can rely on it.
    """
    agents = {}
    if not AGENTS_DIR.exists():
        return agents
    for f in AGENTS_DIR.glob("*.json"):
        try:
            with open(f, "r", encoding="utf-8") as fh:
                a = json.load(fh)
                slug = f.stem.lower()
                # Make slug available on the agent dict itself — the per-step
                # refactor in _stream_plan reads `agent.get("slug")` to derive
                # agent_slug, and previously fell back to display_key. With
                # slug populated here, that fallback path becomes a defensive
                # backstop rather than a frequent code path.
                a.setdefault("slug", slug)
                agents[slug] = a
        except Exception:
            pass
    return agents


def _list_skills() -> list[dict]:
    if not SKILLS_DIR.exists():
        return []
    skills = []
    for f in SKILLS_DIR.glob("*.skill.md"):
        slug = f.name[:-len(".skill.md")]
        # Parse frontmatter
        name = slug.replace("-", " ").title()
        agent = ""
        description = ""
        try:
            content = f.read_text(encoding="utf-8")
            if content.startswith("---"):
                end = content.find("---", 3)
                if end > 0:
                    fm = content[3:end]
                    for line in fm.splitlines():
                        if line.startswith("name:"):
                            name = line[5:].strip()
                        elif line.startswith("agent:"):
                            agent = line[6:].strip()
                        elif line.startswith("description:"):
                            description = line[12:].strip()
        except Exception:
            pass
        skills.append({"slug": slug, "name": name, "agent": agent, "description": description})
    skills.sort(key=lambda s: s["name"])
    return skills


# ═══════════════════════════════════════════════════════════════════════════════
#  FILE INGESTION — replicates norm.py extractors
# ═══════════════════════════════════════════════════════════════════════════════

def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _save_file_to_memory(data: dict):
    MEMORY_DIR.mkdir(parents=True, exist_ok=True)
    db = _memory_db()
    con = sqlite3.connect(db)
    # Ensure tables exist
    con.execute("""CREATE TABLE IF NOT EXISTS files (
        path TEXT PRIMARY KEY, name TEXT, type TEXT,
        word_count INTEGER, page_count INTEGER,
        content TEXT, preview TEXT, toc TEXT,
        indexed_at TEXT, file_mtime REAL)""")
    try:
        con.execute("ALTER TABLE files ADD COLUMN file_mtime REAL")
    except Exception:
        pass
    try:
        con.execute("CREATE VIRTUAL TABLE IF NOT EXISTS files_fts USING fts5(path, name, content, tokenize='porter ascii')")
    except Exception:
        pass
    con.execute("""INSERT OR REPLACE INTO files
        (path,name,type,word_count,page_count,content,preview,toc,indexed_at,file_mtime)
        VALUES (?,?,?,?,?,?,?,?,?,?)""",
        (data["path"], data["name"], data["type"],
         data.get("word_count", 0), data.get("page_count", 0),
         data.get("content", ""), data.get("preview", ""),
         json.dumps(data.get("toc", [])), _now_iso(), data.get("file_mtime", 0)))
    try:
        con.execute("DELETE FROM files_fts WHERE path=?", (data["path"],))
        con.execute("INSERT INTO files_fts (path,name,content) VALUES (?,?,?)",
                    (data["path"], data["name"], data.get("content", "")))
    except Exception:
        pass
    con.commit()
    con.close()


def _ingest_bytes(filename: str, content_bytes: bytes, suffix: str) -> dict:
    """Ingest file bytes and return summary. Saves to SQLite.

    Session 24: temp directory now resolves via tempfile.gettempdir()
    instead of a hardcoded "/tmp". The hardcode worked on Linux/macOS
    but failed on Windows with `[Errno 2] No such file or directory:
    '\\tmp\\<filename>'` because Path("/tmp") resolves to the drive
    root + "tmp" which doesn't exist by default. gettempdir() returns
    the platform-correct location (TEMP/TMP env var on Windows,
    /tmp on Unix). Affected both /api/upload and /api/chat→/ingest
    because both route through here."""
    tmp = Path(tempfile.gettempdir()) / filename
    tmp.write_bytes(content_bytes)

    try:
        if suffix == ".pdf":
            data = _extract_pdf(tmp)
        elif suffix == ".docx":
            data = _extract_docx(tmp)
        elif suffix == ".xlsx":
            data = _extract_xlsx(tmp)
        elif suffix == ".pptx":
            data = _extract_pptx(tmp)
        elif suffix in (".txt", ".md"):
            data = _extract_text(tmp)
        elif suffix == ".msg":
            data = _extract_msg(tmp)
        elif suffix == ".eml":
            data = _extract_eml(tmp)
        else:
            return {"error": "Unsupported file type: " + suffix}

        if "error" in data:
            return data

        _save_file_to_memory({
            "path": "/uploaded/" + filename,
            "name": filename, "type": suffix,
            "word_count": data["word_count"],
            "page_count": data.get("page_count", 0),
            "content": data["content"],
            "preview": data["preview"],
            "toc": data.get("toc", []),
            "file_mtime": tmp.stat().st_mtime,
        })

        # Background semantic indexing
        _vector_index_bg("/uploaded/" + filename, filename, data["content"])

        return {
            "name": filename, "type": suffix,
            "word_count": data["word_count"],
            "page_count": data.get("page_count", 0),
            "toc": data.get("toc", [])[:5],
            "preview": data["preview"][:300],
        }
    finally:
        try:
            tmp.unlink()
        except Exception:
            pass


def _extract_text(path: Path) -> dict:
    content = path.read_text(encoding="utf-8", errors="replace")
    lines = content.splitlines(); toc = []
    if path.suffix.lower() == ".md":
        for line in lines:
            if line.startswith("#"):
                lv = len(line) - len(line.lstrip("#"))
                toc.append({"level": lv, "title": line.lstrip("# ").strip()})
    return {"content": content[:100000], "preview": "\n".join(lines[:15]),
            "toc": toc, "word_count": len(content.split()), "page_count": 0}


def _extract_pdf(path: Path) -> dict:
    try:
        import fitz
    except ImportError:
        return {"error": "pymupdf not installed"}
    doc = fitz.open(str(path)); page_count = len(doc); all_text = []; toc_entries = []
    for level, title, page in doc.get_toc()[:15]:
        toc_entries.append({"level": level, "title": title, "page": page})
    for i in range(page_count):
        text = doc[i].get_text("text")
        if text.strip(): all_text.append("[Page " + str(i+1) + "]\n" + text.strip())
    doc.close()
    full = "\n\n".join(all_text)
    return {"content": full[:100000], "preview": "\n".join(all_text[:3])[:500],
            "toc": toc_entries, "word_count": len(full.split()), "page_count": page_count}


def _extract_docx(path: Path) -> dict:
    try:
        from docx import Document
    except ImportError:
        return {"error": "python-docx not installed"}
    doc = Document(str(path)); paras = []; headings = []; tables = []
    for p in doc.paragraphs:
        # Session 24: see norm.py:_extract_docx for the rationale. python-docx
        # returns None for `p.style` when the paragraph has no style reference,
        # and None for `p.style.name` when the style is unnamed. getattr
        # collapses both cases to "" so .startswith never sees None.
        # NB: this is a duplicate of norm.py's _extract_docx — both code paths
        # need the same fix because /api/upload and /ingest on web go through
        # this copy, while the CLI's handle_ingest_command goes through the
        # other. Consolidating the two is post-alpha cleanup.
        style_name = getattr(p.style, "name", None) or ""
        if style_name.startswith("Heading"):
            last = style_name.split()[-1]
            lv = int(last) if last.isdigit() else 1
            if p.text.strip(): headings.append({"level": lv, "title": p.text.strip()})
        if p.text.strip(): paras.append(p.text.strip())
    for i, t in enumerate(doc.tables):
        rows = [[c.text.strip() for c in r.cells] for r in t.rows if any(c.text.strip() for c in r.cells)]
        if rows: tables.append(rows)
    content = "\n\n".join(paras)
    for i, t in enumerate(tables):
        content += "\n\n[TABLE " + str(i+1) + "]\n" + "\n".join(" | ".join(r) for r in t)
    return {"content": content[:100000], "preview": "\n".join(paras[:10]),
            "toc": headings, "word_count": len(content.split()), "page_count": 0}


def _extract_xlsx(path: Path) -> dict:
    try:
        import openpyxl
    except ImportError:
        return {"error": "openpyxl not installed"}
    wb = openpyxl.load_workbook(str(path), read_only=True, data_only=True)
    content = ""; toc = []
    for sname in wb.sheetnames:
        ws = wb[sname]
        rows = [[str(c) if c is not None else "" for c in row]
                for row in ws.iter_rows(max_row=500, values_only=True)
                if any(c is not None for c in row)]
        if not rows: continue
        toc.append({"level": 1, "title": sname + " (" + str(len(rows)) + " rows)"})
        content += "\n\n[SHEET: " + sname + "]\n"
        if rows:
            content += " | ".join(rows[0]) + "\n" + "-"*30 + "\n"
            for row in rows[1:30]: content += " | ".join(row) + "\n"
    wb.close()
    return {"content": content[:100000], "preview": content[:300],
            "toc": toc, "word_count": len(content.split()), "page_count": len(toc)}


def _extract_pptx(path: Path) -> dict:
    try:
        from pptx import Presentation
    except ImportError:
        return {"error": "python-pptx not installed"}
    prs = Presentation(str(path)); content = ""; toc = []
    for i, slide in enumerate(prs.slides, 1):
        title = ""; body = []
        for shape in slide.shapes:
            if shape.has_text_frame:
                if shape.shape_type == 13: title = shape.text_frame.text.strip()
                else:
                    for p in shape.text_frame.paragraphs:
                        if p.text.strip(): body.append(p.text.strip())
        if title: toc.append({"level": 1, "title": "Slide " + str(i) + ": " + title})
        content += "\n[SLIDE " + str(i) + "]" + (" — " + title if title else "") + "\n"
        if body: content += "\n".join(body) + "\n"
    return {"content": content[:100000], "preview": content[:300],
            "toc": toc, "word_count": len(content.split()), "page_count": len(prs.slides)}


def _extract_msg(path: Path) -> dict:
    try:
        import extract_msg
        msg = extract_msg.Message(str(path))
    except ImportError:
        return {"error": "extract-msg not installed"}
    except Exception as e:
        return {"error": str(e)}
    content = "FROM: " + (msg.sender or "") + "\nSUBJECT: " + (msg.subject or "") + "\n\n" + (msg.body or "")
    return {"content": content[:50000], "preview": content[:300],
            "toc": [{"level": 1, "title": "Subject: " + (msg.subject or "")}],
            "word_count": len(content.split()), "page_count": 0}


def _extract_eml(path: Path) -> dict:
    with open(str(path), "rb") as f:
        msg = email_lib.message_from_bytes(f.read())
    body = ""
    if msg.is_multipart():
        for part in msg.walk():
            if part.get_content_type() == "text/plain":
                try: body = part.get_payload(decode=True).decode("utf-8", errors="replace"); break
                except Exception: pass
    else:
        try: body = msg.get_payload(decode=True).decode("utf-8", errors="replace")
        except Exception: body = str(msg.get_payload())
    content = "FROM: " + msg.get("From","") + "\nSUBJECT: " + msg.get("Subject","") + "\n\n" + body
    return {"content": content[:50000], "preview": content[:300],
            "toc": [{"level": 1, "title": "Subject: " + msg.get("Subject","")}],
            "word_count": len(content.split()), "page_count": 0}


# ═══════════════════════════════════════════════════════════════════════════════
#  VECTOR INDEXING — background thread, mirrors norm.py
# ═══════════════════════════════════════════════════════════════════════════════

_embed_model  = None
_embed_lock   = threading.Lock()


def _get_embed_model():
    global _embed_model
    if _embed_model is not None:
        return _embed_model
    with _embed_lock:
        if _embed_model is not None:
            return _embed_model
        try:
            from sentence_transformers import SentenceTransformer
            _embed_model = SentenceTransformer("all-MiniLM-L6-v2")
            return _embed_model
        except Exception:
            return None


def _chunk_text(text: str) -> list[str]:
    chunks = []; start = 0
    while start < len(text):
        end   = start + CHUNK_SIZE
        chunk = text[start:end]
        if chunk.strip(): chunks.append(chunk)
        if end >= len(text): break
        start = end - CHUNK_OVERLAP
    return chunks


def _vec_to_blob(vec: list) -> bytes:
    return struct.pack(f"{len(vec)}f", *vec)


def _vector_index_bg(file_path: str, file_name: str, content: str):
    def _run():
        try:
            model = _get_embed_model()
            if model is None: return
            chunks = _chunk_text(content)
            if not chunks: return
            MEMORY_DIR.mkdir(parents=True, exist_ok=True)
            con = sqlite3.connect(VECTOR_DB)
            con.execute("""CREATE TABLE IF NOT EXISTS chunks (
                id INTEGER PRIMARY KEY AUTOINCREMENT, file_path TEXT, file_name TEXT,
                chunk_idx INTEGER, text TEXT, embedding BLOB, indexed_at TEXT)""")
            con.execute("CREATE INDEX IF NOT EXISTS idx_chunks_path ON chunks(file_path)")
            con.execute("DELETE FROM chunks WHERE file_path=?", (file_path,))
            embeddings = model.encode(chunks, normalize_embeddings=True, show_progress_bar=False)
            rows = [(file_path, file_name, i, chunk, _vec_to_blob(emb.tolist()), _now_iso())
                    for i, (chunk, emb) in enumerate(zip(chunks, embeddings))]
            con.executemany(
                "INSERT INTO chunks (file_path,file_name,chunk_idx,text,embedding,indexed_at) VALUES (?,?,?,?,?,?)",
                rows)
            con.commit(); con.close()
        except Exception:
            pass
    threading.Thread(target=_run, daemon=True).start()


# ═══════════════════════════════════════════════════════════════════════════════
#  SSE STREAMING CHAT
# ═══════════════════════════════════════════════════════════════════════════════

def _sse(event: str, data: dict) -> str:
    """Format a Server-Sent Event."""
    return "event: " + event + "\ndata: " + json.dumps(data) + "\n\n"


# ── /ingest <path> slash command ───────────────────────────────────────────
#
# Session 23. The web UI's smallest file-binding solution: detect /ingest in
# chat input, resolve a server-side path, drive the existing _ingest_bytes
# pipeline (same one /api/upload uses).
#
# Why server-side dispatch (in /api/chat) and not a separate endpoint:
#   - single chat input is the user's mental model — same box, slash to act
#   - frontend needs zero new event handlers; we emit step_start/token/
#     step_end and the existing message-bubble flow renders it
#   - keeps history coherent — the /ingest line and its result land as a
#     normal user/assistant pair via SessionState
#
# Why this path differs from CLI's handle_ingest_command (norm.py:2713):
#   the CLI version is interactive — TTY prompts for folder when given a
#   bare name, asks before re-indexing a cached file. None of that survives
#   a stateless HTTP request, so the web version requires a full path with
#   extension and always re-ingests (matches /api/upload semantics).
#
# Why "Tavern" as the agent label: this isn't an agent response; the system
# is reporting on a filesystem action. "Tavern" is theme-consistent with
# the welcome card and plan-end message ("Round's on the house") without
# attributing a deliverable-shaped output to Norm or another persona.
async def _stream_ingest_command(user_input: str) -> AsyncIterator[str]:
    """Handle a /ingest <path> slash command. Yields SSE events.

    Frontend-visible event sequence on success:
        step_start (agent="Tavern")
        token      (markdown summary of what was ingested)
        step_end
    On error: a single `error` event (renders as an error card).

    Commits the user/assistant pair to _session at the end so the line
    appears in conversation history alongside regular chat turns.
    """
    arg = user_input[len("/ingest"):].strip().strip('"\'')

    def _commit(reply_text: str):
        # Pair the /ingest line with its assistant-side reply in session
        # history. _session.add_user has already run in /api/chat; this
        # closes the pair. Keep the reply short — full body is in chat.
        try:
            _session.add_assistant(reply_text)
        except Exception:
            pass

    # Bare /ingest with no argument — emit a usage hint as a normal bubble.
    if not arg:
        usage = (
            "**Usage:** `/ingest <full-path-to-file>`\n\n"
            "Provide an absolute path with extension. Examples:\n\n"
            "- `/ingest C:\\TavernOS\\samples\\Q1-MBR.xlsx`\n"
            "- `/ingest ~/Documents/proposal.docx`\n\n"
            "Supported types: " + ", ".join(sorted(SUPPORTED_EXT))
        )
        yield _sse("step_start", {"step": 1, "total": 1, "agent": "Tavern", "task": "/ingest"})
        yield _sse("token", {"text": usage, "agent": "Tavern"})
        yield _sse("step_end", {"step": 1, "agent": "Tavern"})
        _commit("(/ingest usage shown)")
        return

    # Path resolution — expand ~ for parity with CLI. On a local TavernOS
    # deploy (the supported config) the web server and the user share a
    # filesystem, so absolute paths and ~-expansion both behave as the
    # user expects from a terminal.
    try:
        p = Path(arg).expanduser()
    except Exception as e:
        yield _sse("error", {"message": "Could not parse path: " + str(e)})
        _commit("(/ingest failed: bad path)")
        return

    if not p.exists():
        yield _sse("error", {"message": "File not found: " + str(p)})
        _commit("(/ingest failed: not found)")
        return

    if p.is_dir():
        yield _sse("error", {"message":
            "That's a directory. /ingest takes a single file path with "
            "extension. (Bare-name and folder pickers are CLI-only — for "
            "now, drop the full file path.)"})
        _commit("(/ingest failed: directory)")
        return

    suffix = p.suffix.lower()
    if suffix not in SUPPORTED_EXT:
        yield _sse("error", {"message":
            "Unsupported file type: " + suffix + ". Supported: " +
            ", ".join(sorted(SUPPORTED_EXT))})
        _commit("(/ingest failed: unsupported type)")
        return

    # Open the bubble before the read+ingest so the user sees the agent
    # bar appear immediately for large files (xlsx/pdf parsing can take
    # a few seconds; otherwise the UI looks frozen between request and
    # response).
    yield _sse("step_start", {
        "step": 1, "total": 1, "agent": "Tavern",
        "task": "ingesting " + p.name,
    })

    try:
        content_bytes = p.read_bytes()
    except Exception as e:
        yield _sse("error", {"message": "Could not read file: " + str(e)})
        _commit("(/ingest failed: read error)")
        return

    try:
        result = _ingest_bytes(p.name, content_bytes, suffix)
    except Exception as e:
        try: _norm._log_error("web_ingest_command_failed",
                              path=str(p), error=str(e))
        except Exception: pass
        yield _sse("error", {"message": "Ingest failed: " + str(e)})
        _commit("(/ingest failed: pipeline error)")
        return

    if isinstance(result, dict) and "error" in result:
        yield _sse("error", {"message": str(result["error"])})
        _commit("(/ingest failed: " + str(result["error"]) + ")")
        return

    # Build a markdown summary for the chat bubble. Mirrors what the
    # upload card surfaces, formatted as prose so live-render markdown
    # picks it up cleanly.
    parts = [
        "**Ingested:** `" + result.get("name", p.name) + "`",
        "",
        "- Type: `" + result.get("type", suffix) + "`",
        "- Words: " + str(result.get("word_count", 0)),
    ]
    if result.get("page_count"):
        parts.append("- Pages: " + str(result["page_count"]))
    preview = (result.get("preview") or "").strip()
    if preview:
        # Quote each line so it renders as a blockquote, not a single
        # blob. Cap is already 300 chars from _ingest_bytes.
        quoted = "\n".join("> " + ln for ln in preview.splitlines() if ln.strip())
        parts.append("")
        parts.append("**Preview:**")
        parts.append(quoted)

    body = "\n".join(parts)
    yield _sse("token", {"text": body, "agent": "Tavern"})
    yield _sse("step_end", {"step": 1, "agent": "Tavern"})
    _commit("Ingested: " + result.get("name", p.name))


# Session 27a — _resolve_umbrella_agent moved to norm.py so CLI's manual-target
# /agent <task> syntax shares the same resolver as web's dropdown→Rebecca path.
# Both surfaces produce the same routing decision for the same prompt. Imported
# as _norm._resolve_umbrella_agent at the call site below in _stream_plan.


async def _stream_plan(config: dict, client, provider: str, model_id: str,
                       user_input: str, target_agent: str | None,
                       agents: dict) -> AsyncIterator[str]:
    """
    Core streaming generator.
    Yields SSE events:
      plan_start  — Sam's routing decision
      step_start  — which agent is about to work
      token       — streaming text token
      step_end    — step complete
      plan_end    — all done
      error       — something went wrong
    """
    # Session 22 per-request diagnostic — writes to a file, NOT stderr,
    # because `norm --web` doesn't surface stderr from this process in a
    # way the operator can see. This line writes once per chat request and
    # confirms which session-22 code path is actually running. Truncate
    # user_input to 80 chars to keep log lines bounded. Remove this once
    # session-22 deploy is trusted; harmless to leave.
    try:
        with open(DIAG_DIR / "web_stream_plan.log", "a", encoding="utf-8") as _f:
            _f.write(
                f"[{_now_iso()}] [stream_plan session 22] "
                f"user_input={user_input[:80]!r}, target_agent={target_agent!r}\n"
            )
    except Exception:
        pass

    file_context = _build_file_context(query=user_input)
    history_msgs = _session.to_messages()

    # ── Route ──────────────────────────────────────────────────────────────────
    if target_agent:
        # Session 25 — resolve umbrella ids (e.g. "rebecca") to a concrete
        # slug ("rebecca-deck" or "rebecca-mbr") before building the plan.
        # No-op for inputs that are already concrete slugs.
        target_agent = _norm._resolve_umbrella_agent(target_agent, user_input, agents)
        # Direct agent invocation — skip Sam's routing
        plan = {
            "intent": user_input,
            "steps":  [{"agent": target_agent, "task": user_input, "skill": None}],
        }
    else:
        # Sam routes — resilient: 3 attempts with stricter prompting + JSON
        # extraction, then falls back to a minimal Norm plan so the user
        # always gets a response. Every failure and recovery is journaled.
        yield _sse("status", {"message": "Sam is reading the room…"})
        stricter = ("\n\nYour previous response was not parseable JSON. "
                    "Return ONLY the JSON object — no markdown fences, no "
                    "commentary, nothing before or after the closing brace.")
        raw_responses = []
        last_error = None
        plan = None

        for attempt in range(3):
            try:
                messages = history_msgs + [{"role": "user", "content": user_input}]
                router_sys = ROUTER_SYSTEM if attempt == 0 else ROUTER_SYSTEM + stricter
                if provider == "anthropic":
                    r   = client.messages.create(model=model_id, max_tokens=ROUTER_MAX_TOKENS,
                            system=router_sys, messages=messages)
                    raw = r.content[0].text.strip()
                else:
                    r   = client.chat.completions.create(model=model_id, max_tokens=ROUTER_MAX_TOKENS,
                            messages=[{"role":"system","content":router_sys}] + messages)
                    raw = r.choices[0].message.content.strip()
                raw_responses.append(raw[:500])

                candidate = _try_extract_json(raw)
                if candidate and isinstance(candidate, dict) and "steps" in candidate:
                    # Session 22: route the parsed plan through norm's
                    # post-processor so the web UI gets the same step["mode"]
                    # normalization and the same rebecca-deck MBR-context
                    # CLARIFY override the CLI gets. Pre-session-22 this
                    # line was just `plan = candidate` — modes propagated
                    # unchecked and the MBR gate never fired on the web.
                    plan = _norm.postprocess_router_plan(candidate, user_input)
                    if attempt > 0:
                        _log_error("router_recovered",
                                   user_input=user_input,
                                   attempts=attempt+1,
                                   recovery_strategy=("retry_strict" if attempt == 1 else "json_extract"))
                        yield _sse("status", {"message": "Sam recovered — planning…"})
                    break
                last_error = "unparseable or malformed plan"
                if attempt < 2:
                    yield _sse("status", {"message": "Sam had trouble — retrying…"})
                    await asyncio.sleep(0.3)
            except Exception as e:
                last_error = str(e)
                if attempt < 2:
                    yield _sse("status", {"message": "Sam had trouble — retrying…"})
                    await asyncio.sleep(0.4 * (attempt + 1))

        if plan is None:
            # All 3 attempts exhausted — fall back so user gets SOMETHING
            _log_error("router_failed_all_retries",
                       user_input=user_input,
                       last_error=last_error,
                       raw_responses=raw_responses)
            yield _sse("status", {"message": "Router had trouble — routing to Norm as fallback."})
            plan = {
                "intent": user_input,
                "steps":  [{"agent": "norm", "task": user_input, "skill": None}],
                "needs_new_skill": False,
                "new_skill_name": None,
                "new_skill_description": None,
            }

    yield _sse("plan_start", {
        "intent": plan.get("intent", user_input),
        "steps":  [{"agent": s.get("agent","?"), "task": s.get("task","")} for s in plan.get("steps",[])],
        "model":  model_id, "provider": provider,
    })

    steps        = plan.get("steps", [])
    step_context = ""
    full_response = ""
    total_steps  = len(steps)

    for i, step in enumerate(steps):
        # Session 22: identity split — three keys per agent, mirroring the
        # session-11-P3 fix in norm.call_execute_streaming.
        #   agent_display_name — user-facing string ("Rebecca")
        #   agent_display_key  — lookup for name-keyed maps (WEB_SEARCH_AGENTS)
        #   agent_slug         — routing/gating/skill-binding key ("rebecca-deck")
        # `aname` is preserved as an alias for the slug so existing
        # references (step_context, deliverable processing) keep working
        # without further edits. For non-Rebecca agents all three values
        # collapse to the same string.
        raw_aname          = step.get("agent", "norm").lower()
        task               = step.get("task", "")
        agent              = agents.get(raw_aname, agents.get("norm", {}))
        agent_display_name = agent.get("name", raw_aname.title())
        agent_display_key  = agent_display_name.lower()
        agent_slug         = (agent.get("slug") or agent_display_key).lower()
        aname              = agent_slug
        name               = agent_display_name

        # Session 22: is this the FINAL step in the plan? Only the final
        # step gets the full OUTPUT_CONTRACT (user-facing prose, deliverable
        # marker permitted). Earlier steps get the brief-handoff contract.
        # Single-step plans always get the full contract (the only step IS
        # the final step).
        is_final_step = (i == total_steps - 1)

        yield _sse("step_start", {"step": i+1, "total": total_steps, "agent": name, "task": task})

        # Skill playbooks — slug-first with display_key fallback. Mirrors
        # norm.call_execute_streaming (norm.py ~line 4985). The display_key
        # fallback covers skills that still bind `agent: rebecca` (pre-split
        # binding) so rebecca-mbr and rebecca-deck both pick them up; remove
        # the fallback once all skill files migrate to slug-form binding.
        # Loader is _norm.load_skill_bodies_for_agent — globs *.skill.md
        # only, parses YAML frontmatter, matches the case-insensitive
        # `agent:` field. Files named *_skill.md are invisible to the
        # loader (typo, not a glob bug — rename on disk to fix).
        # Session 23: was `skill_bodies = ""` pre-port. The function lives
        # in _norm and was always importable; the "port" is just calling it.
        skill_bodies = _norm.load_skill_bodies_for_agent(agent_slug)
        if not skill_bodies and agent_display_key != agent_slug:
            skill_bodies = _norm.load_skill_bodies_for_agent(agent_display_key)

        # Per-agent tool/search enumeration. Session 24 introduced the
        # fp_tools_list / read_tools_list split; session 26 (below)
        # generalizes the gating to two sets so artifact builders can
        # ride alongside read_ingested_file. WEB_SEARCH_AGENTS check
        # uses display_key for parity with call_execute_streaming.
        # Session 26 — Priority 3a. Two sets, two purposes:
        #   _WEB_ENABLED_FP_TOOLS — union of all FP tools available on
        #       the web path. Filters what we pass to Anthropic's `tools`
        #       parameter. Expanded from session-24's read-only set to
        #       include the three artifact builders.
        #   _WEB_ARTIFACT_FP_TOOLS — the artifact-builder subset. Drives
        #       fp_tools_list, which build_agent_system_prompt uses to
        #       decide whether to inject the ARTIFACT TOOLS block ("you
        #       MUST call the tool to generate binary deliverables").
        #       read_ingested_file is excluded from the prompt list:
        #       it's a reader, not a builder, and the artifact-tools
        #       language doesn't apply to it. The agent picks up "when
        #       to use read_ingested_file" from the tool's description
        #       field plus the MBR CONTEXT GATE in rebecca-deck's prompt.
        #
        # Per-agent gating is still enforced by allowed_agents on each
        # FIRST_PARTY_TOOLS entry; the sets here are the web-side
        # second filter on top of that. An agent with no overlap
        # against either set ends up with both lists empty and the
        # tool-loop bridge isn't entered (the `if read_tools_list`
        # branch below handles that).
        _WEB_ARTIFACT_FP_TOOLS = {"generate_xlsx_report",
                                  "generate_docx_report",
                                  "generate_pptx_deck"}
        _WEB_ENABLED_FP_TOOLS  = {"read_ingested_file"} | _WEB_ARTIFACT_FP_TOOLS
        _agent_fp_tools = (_norm._first_party_tools_for_agent(agent_slug)
                           if _norm.FIRST_PARTY_TOOLS else [])
        fp_tools_list   = [t for t in _agent_fp_tools
                           if t.get("name") in _WEB_ARTIFACT_FP_TOOLS]
        read_tools_list = [t for t in _agent_fp_tools
                           if t.get("name") in _WEB_ENABLED_FP_TOOLS]
        use_search_web = (provider == "anthropic" and agent_display_key in WEB_SEARCH_AGENTS)

        # Session 22: prompt assembly delegated to norm.build_agent_system_prompt.
        # Pre-session-22 the web UI inlined a stripped-down 8-line assembly
        # that omitted _client_context_block (no active-client surfacing,
        # including the `Latest MBR at:` line), the rebecca-deck MBR
        # CONTEXT GATE, the anti-exfiltration block, and the proactive
        # web-search instruction — and used a heavily-drifted local
        # OUTPUT_CONTRACT with no grounding-discipline section. All of
        # those now apply on the web path. is_final_step toggles between
        # the full OUTPUT_CONTRACT and the brief INTERMEDIATE_OUTPUT_CONTRACT.
        system = _norm.build_agent_system_prompt(
            agent, agent_slug, skill_bodies, file_context,
            use_search_web, fp_tools_list,
            is_final=is_final_step,
        )

        content = task
        if step_context:
            content += "\n\nContext from previous steps:\n" + step_context

        messages = history_msgs + [{"role": "user", "content": content}]

        step_text = ""
        first_token_sent = False
        last_error = None

        for attempt in range(3):
            try:
                # Session 24 — Priority 2 tool-loop bridge. When read_tools_list
                # is non-empty (currently when read_ingested_file is available
                # to this agent), delegate to norm.run_tool_use_loop via a
                # worker thread so we share the CLI's tool-dispatch code path.
                # The loop is sync (uses client.messages.create); we run it in
                # asyncio.to_thread and use an asyncio.Queue as the bridge —
                # callbacks push events from the worker thread, this generator
                # drains them and yields SSE.
                #
                # No retry on this path: tool side effects (file reads, MCP
                # calls in the future) make a second pass dangerous. If the
                # loop raises, we yield an error SSE and break out of the
                # retry-attempt loop entirely.
                if provider == "anthropic" and read_tools_list:
                    event_q: asyncio.Queue = asyncio.Queue()
                    main_loop = asyncio.get_event_loop()
                    _LOOP_DONE = object()  # sentinel

                    def _push(item):
                        # Thread-safe schedule onto the asyncio loop.
                        main_loop.call_soon_threadsafe(event_q.put_nowait, item)

                    def _on_token(txt):     _push(("token", txt))
                    def _on_first_response(): _push(("first_response", None))
                    def _on_tool_call(tn, ta): _push(("tool_call", {"tool": tn, "args": ta}))
                    def _on_tool_result(tn, rt, ie): _push(("tool_result",
                                                            {"tool": tn, "is_error": bool(ie)}))
                    def _on_banner(b):      _push(("banner", b))

                    tools_param_anth = (
                        ([_norm.WEB_SEARCH_TOOL] if use_search_web else []) + read_tools_list
                    )

                    # Session 26 — Priority 3b. Compute tool_choice override
                    # using the same conjunction the CLI uses
                    # (norm._compute_force_tool_override): forcing applies
                    # only when (a) the agent's config declares `force_tool`
                    # AND (b) the router classified this step as BOUND.
                    #
                    # Manual-route plans skip postprocess_router_plan so
                    # `step["mode"]` is absent → step.get("mode") is None →
                    # _compute_force_tool_override returns None → no forcing.
                    # That preserves the operator decision recorded in the
                    # session-25 handoff: manual route stays "operator told
                    # me what to do, don't second-guess." Sam-routed plans
                    # carry the normalized mode field through and inherit
                    # the same forcing behavior the CLI gets.
                    _mode_hint = step.get("mode") if isinstance(step, dict) else None
                    _tool_choice_override = _norm._compute_force_tool_override(
                        agent, _mode_hint)

                    def _run_loop():
                        try:
                            _norm.run_tool_use_loop(
                                client, model_id, system, messages,
                                tools_param_anth, EXECUTE_MAX_TOKENS, agent_slug,
                                tool_choice_override=_tool_choice_override,
                                on_token=_on_token,
                                on_first_response=_on_first_response,
                                on_tool_call=_on_tool_call,
                                on_tool_result=_on_tool_result,
                                on_banner=_on_banner,
                            )
                        except Exception as _e:
                            _push(("error", str(_e)))
                        finally:
                            _push((_LOOP_DONE, None))

                    worker = asyncio.create_task(asyncio.to_thread(_run_loop))

                    # Drain events as they arrive. Loop exits when the
                    # worker pushes _LOOP_DONE (always reached via finally).
                    while True:
                        kind, payload = await event_q.get()
                        if kind is _LOOP_DONE:
                            break
                        if kind == "token":
                            first_token_sent = True
                            step_text    += payload
                            full_response += payload
                            yield _sse("token", {"text": payload, "agent": name})
                        elif kind == "tool_call":
                            # Emit but frontend doesn't render today — visible
                            # in browser dev tools / network panel for debug.
                            # Frontend rendering is a session-25 polish task.
                            yield _sse("tool_call", {"agent": name, **payload})
                        elif kind == "tool_result":
                            yield _sse("tool_result", {"agent": name, **payload})
                        elif kind == "banner":
                            # Session 26 — Priority 3c. Now reachable: the
                            # artifact builders (xlsx/docx/pptx) joined
                            # _WEB_ENABLED_FP_TOOLS in 3a, and 3b ensures
                            # they're forced when the agent declares
                            # force_tool and Sam classifies BOUND.
                            #
                            # The raw banner from norm._dispatch_first_party_tool
                            # is just {filename, path, bytes}; renderDeliverableCard
                            # in index.html needs {filename, path, bytes, agent,
                            # category, view_url, preview}. Enrich here so the
                            # frontend stays simple and the SSE wire shape
                            # matches the one the markdown-marker path emits
                            # (visual parity in the chat for both deliverable
                            # types).
                            enriched = _enrich_first_party_banner(payload, name)
                            yield _sse("deliverable_saved", enriched)
                        elif kind == "error":
                            _log_error("agent_failed_tool_loop",
                                       agent=name, error=str(payload),
                                       task=task[:200])
                            yield _sse("error", {
                                "message": "Tool loop error: " + str(payload) +
                                           "  (logged — check /api/errors)"
                            })
                        elif kind == "first_response":
                            # Commit point — informational only. The
                            # `first_token_sent` flag is set when the
                            # first text token arrives, not here.
                            pass

                    # Make sure the worker has fully finished before we
                    # leave this attempt. If the worker raised, the error
                    # event was already yielded above; we just consume the
                    # exception silently here.
                    try: await worker
                    except Exception: pass
                    break  # tool path: no retry, exit attempt loop

                if provider == "anthropic":
                    with client.messages.stream(
                        model=model_id, max_tokens=EXECUTE_MAX_TOKENS,
                        system=system, messages=messages
                    ) as stream:
                        for chunk in stream.text_stream:
                            first_token_sent = True
                            step_text    += chunk
                            full_response += chunk
                            yield _sse("token", {"text": chunk, "agent": name})
                            await asyncio.sleep(0)   # yield to event loop
                else:
                    stream = client.chat.completions.create(
                        model=model_id, max_tokens=EXECUTE_MAX_TOKENS,
                        messages=[{"role":"system","content":system}] + messages,
                        stream=True
                    )
                    for chunk in stream:
                        delta = chunk.choices[0].delta
                        if hasattr(delta, "content") and delta.content:
                            first_token_sent = True
                            step_text     += delta.content
                            full_response += delta.content
                            yield _sse("token", {"text": delta.content, "agent": name})
                            await asyncio.sleep(0)
                if attempt > 0:
                    _log_error("agent_recovered",
                               agent=name, attempts=attempt+1, task=task[:200])
                break
            except Exception as e:
                last_error = e
                if first_token_sent:
                    # Already streaming partial output — can't retry cleanly
                    _log_error("agent_stream_interrupted",
                               agent=name, error=str(e),
                               partial_text_bytes=len(step_text))
                    yield _sse("error", {"message": "Stream interrupted mid-response — partial output above. (logged for review)"})
                    break
                if attempt < 2:
                    yield _sse("status", {"message": name + " is retrying…"})
                    await asyncio.sleep(0.6 * (attempt + 1))
                    continue
                # All retries exhausted before first token — log and give up this step
                _log_error("agent_failed_all_retries",
                           agent=name, error=str(e), task=task[:200])
                yield _sse("error", {"message": "Stream error after 3 retries: " + str(e) + "  (logged — check /api/errors)"})
                return

        # Session 22: deliverable marker handling, gated on is_final_step.
        # FINAL agents: same behavior as pre-session-22 — if the marker is
        # present, save the file and emit the SSE event. INTERMEDIATE agents:
        # the INTERMEDIATE_OUTPUT_CONTRACT explicitly forbids the marker, but
        # we apply belt-and-suspenders here — if a non-final agent emits the
        # marker against instructions, strip it from the text without saving
        # a file or emitting the event. This prevents the pre-session-22
        # multi-deliverable bug where a 3-agent plan saved 3 markdown files
        # to clients/_self/deliverables/, none of which represented the user's
        # actual answer.
        if is_final_step:
            deliverable = _process_deliverable_marker(step_text, name)
            if deliverable:
                yield _sse("deliverable_saved", deliverable)
                # Strip marker from step_text so the assistant's recorded
                # response doesn't include the bare marker line.
                step_text     = DELIVERABLE_MARKER_RE.sub("", step_text).rstrip()
                full_response = DELIVERABLE_MARKER_RE.sub("", full_response).rstrip()
        else:
            # Intermediate agent — strip any marker without saving. Log if
            # one appeared so we can see how often agents violate the
            # INTERMEDIATE_OUTPUT_CONTRACT instruction.
            if DELIVERABLE_MARKER_RE.search(step_text):
                _log_error("intermediate_agent_emitted_deliverable_marker",
                           agent=name, step=i+1, total_steps=total_steps)
                step_text     = DELIVERABLE_MARKER_RE.sub("", step_text).rstrip()
                full_response = DELIVERABLE_MARKER_RE.sub("", full_response).rstrip()

        step_context = "Step " + str(i+1) + " (" + aname + "):\n" + step_text
        yield _sse("step_end", {"step": i+1, "agent": name})

        # Brief separator between steps
        if i < len(steps) - 1:
            next_name = agents.get(steps[i+1].get("agent","?"), {}).get("name", steps[i+1].get("agent","?").title())
            yield _sse("status", {"message": next_name + " is reading the above…"})

    _session.add_assistant(full_response)
    yield _sse("plan_end", {"message": "All steps complete. Round's on the house."})


# ═══════════════════════════════════════════════════════════════════════════════
#  FIRST-PARTY TOOL: read_ingested_file
# ═══════════════════════════════════════════════════════════════════════════════
# Session 24 — Priority 2 from the session-23 handoff. Lets agents (Rebecca
# in particular) consume the actual content of files the operator has
# previously ingested, rather than just seeing the file referenced in
# _client_context_block. Without this, "drop the MBR, ask Rebecca for a
# deck" produced a deck with TBD-shaped placeholders because Rebecca had
# no way to read the underlying spreadsheet.
#
# Storage scope: reads from server.py's _memory_db() (the single shared
# tavern_memory.db that /api/files queries). CLI's per-client memory DB
# is NOT accessed by this handler — that's a session-25+ consolidation
# task. For the alpha, web is the primary surface and reads from web's
# store; the inconsistency is documented but not yet fixed.
#
# Registration: at module-import time, we mutate _norm.FIRST_PARTY_TOOLS
# directly. Because server.py is only imported when running `norm --web`,
# this tool is invisible to pure-CLI invocations — which is correct,
# because pure-CLI runs hit a different storage path that this handler
# can't reach.

def _read_ingested_file_handler(args, agent_name, active_client_slug):
    """First-party tool handler. Returns the extracted text content of
    a file in this client's web-side ingest store. Errors are returned
    as strings beginning with "Error:" — the tool-use loop wraps those
    as is_error=True tool_results so the agent can self-correct (e.g.,
    retry with a corrected filename based on the listed available files).

    Signature matches the FIRST_PARTY_TOOLS contract at norm.py:688.
    active_client_slug is accepted for signature compatibility but not
    used today — server-side storage is currently global, not per-client.
    """
    filename = (args.get("filename") if isinstance(args, dict) else "") or ""
    filename = filename.strip()
    if not filename:
        return "Error: missing required 'filename' argument."

    # Defensive: if the model passes a path-shaped value (e.g.,
    # "/uploaded/Q1-MBR.xlsx" because it copied the path field from
    # _client_context_block), reduce to the basename so the SQLite
    # name-column lookup works.
    if "/" in filename or "\\" in filename:
        filename = Path(filename).name

    # Optional cap for cheaper turns. Default matches the extractor's
    # 100k-char content cap; smaller values just slice the prefix.
    max_chars = 100000
    if isinstance(args, dict) and "max_chars" in args:
        try:
            max_chars = max(1, int(args["max_chars"]))
        except (TypeError, ValueError):
            pass

    db = _memory_db()
    if not db.exists():
        return ("Error: no files ingested yet. The operator needs to drag a "
                "file onto the chat window or run /ingest <path> first.")

    try:
        con = sqlite3.connect(db)
        # Case-insensitive name match — matches what the user sees in
        # the right-rail Files panel.
        row = con.execute(
            "SELECT name, type, content, word_count FROM files "
            "WHERE LOWER(name) = LOWER(?) LIMIT 1",
            (filename,),
        ).fetchone()
        con.close()
    except Exception as e:
        try: _norm._log_error("read_ingested_file_db_failed",
                              filename=filename, error=str(e))
        except Exception: pass
        return "Error: failed to read files index: " + str(e)

    if not row:
        # Surface the available filenames so the model can recover by
        # retrying with the correct name (typo, wrong case, etc.).
        try:
            available = [f["name"] for f in _list_files()][:20]
        except Exception:
            available = []
        avail_str = ", ".join(available) if available else "(none)"
        return ("Error: no file named '" + filename + "' is currently "
                "ingested for this client. Available files: " + avail_str)

    name, ftype, content, word_count = row
    content = content or ""
    truncated = len(content) > max_chars
    if truncated:
        content = content[:max_chars]

    header_bits = [
        name,
        (ftype or "file"),
        str(word_count or 0) + " words",
    ]
    if truncated:
        header_bits.append("truncated to " + str(max_chars) + " chars")
    header = "[" + " — ".join(header_bits) + "]\n\n"
    return header + content


def _register_web_first_party_tools():
    """Slot read_ingested_file into norm.FIRST_PARTY_TOOLS at import time.
    Idempotent — overwriting an existing entry with the same handler is
    a no-op in practice. Allowed-agents list is conservative; expand as
    new agents demonstrate need."""
    _norm.FIRST_PARTY_TOOLS["read_ingested_file"] = {
        "name": "read_ingested_file",
        "schema": {
            "name": "read_ingested_file",
            "description": (
                "Read the full extracted text content of a file the operator "
                "has previously ingested into this client's workspace (via "
                "drag-and-drop, the paperclip button, or /ingest). Use this "
                "to consume documents the operator references in their "
                "request — for example, when they say 'use the MBR I just "
                "uploaded' or 'pull from the proposal'. The list of "
                "currently-ingested filenames is surfaced in your system "
                "context under 'Files in memory'. Returns the file's "
                "content as plain text, with a one-line header showing the "
                "filename, type, and word count."
            ),
            "input_schema": {
                "type": "object",
                "properties": {
                    "filename": {
                        "type": "string",
                        "description": (
                            "The file's name as it appears in the Files "
                            "panel (e.g. 'Q1-MBR.xlsx'). Pass the basename "
                            "only — no path prefix."
                        ),
                    },
                    "max_chars": {
                        "type": "integer",
                        "description": (
                            "Maximum characters of file content to return. "
                            "Default 100000 (the extractor's cap, i.e. the "
                            "full file). Pass a smaller value (e.g. 20000) "
                            "for a cheaper turn when only a sample is "
                            "needed to answer."
                        ),
                        "default": 100000,
                    },
                },
                "required": ["filename"],
            },
        },
        # Allowed agents: anyone likely to want to consume an uploaded
        # document. Conservative initial list — expand as needs surface.
        # All Rebecca slugs included since Path 2 alpha is the trigger.
        "allowed_agents": [
            "rebecca-deck", "rebecca-mbr",
            "cliff",      # competitive analysis, lead intel from sources
            "frasier",    # decision frameworks from uploaded data
            "lilith",     # ops architecture from uploaded specs
            "woody",      # proposal/blog/email drafting from sources
            "coach",      # action items from meeting transcripts
            "carla",      # copy editing of uploaded text
            "diane",      # support KB building from uploaded sources
            "norm",       # general-purpose
        ],
        "handler": _read_ingested_file_handler,
    }


_register_web_first_party_tools()


# ═══════════════════════════════════════════════════════════════════════════════
#  API ROUTES
# ═══════════════════════════════════════════════════════════════════════════════

@app.get("/", response_class=HTMLResponse)
async def serve_ui():
    """Serve the web UI."""
    html_file = Path(__file__).parent / "index.html"
    if html_file.exists():
        return HTMLResponse(content=html_file.read_text(encoding="utf-8"))
    return HTMLResponse(content="<h1>TavernOS Web UI</h1><p>index.html not found.</p>")


@app.get("/api/status")
async def get_status():
    config   = _load_config()
    mode     = _get_mode()
    provider, model_id = _get_active_model(config)
    company  = config.get("company_name", "TavernOS")
    files    = _list_files()
    agents   = _load_agents()
    skills   = _list_skills()
    return JSONResponse({
        "mode":       mode,
        "company":    company,
        "provider":   provider,
        "model_id":   model_id,
        "agents":     len(agents),
        "files":      len(files),
        "skills":     len(skills),
        "history":    len(_session.history),
        "semantic":   _get_embed_model() is not None,
        "version":    "v0.1.0",
    })


@app.get("/api/agents")
async def get_agents():
    agents = _load_agents()
    result = []
    for key, a in agents.items():
        result.append({
            "id":          key,
            "name":        a.get("name", key.title()),
            "personality": a.get("personality", ""),
            "quip_style":  a.get("quip_style", ""),
            "skills":      a.get("skills", []),
        })
    result.sort(key=lambda x: x["name"])
    return JSONResponse(result)


@app.get("/api/skills")
async def get_skills():
    return JSONResponse(_list_skills())


@app.get("/api/files")
async def get_files():
    return JSONResponse(_list_files())


@app.get("/api/history")
async def get_history():
    return JSONResponse(_session.to_list())


@app.delete("/api/history")
async def clear_history():
    _session.clear()
    return JSONResponse({"status": "ok", "message": "History cleared"})


@app.post("/api/search")
async def search_files(request: Request):
    body  = await request.json()
    query = body.get("query", "").strip()
    if not query:
        return JSONResponse({"results": []})
    results = _fts_search(query, limit=8)
    return JSONResponse({"results": results, "query": query})


@app.post("/api/upload")
async def upload_file(file: UploadFile = File(...)):
    filename = file.filename or "upload"
    suffix   = Path(filename).suffix.lower()
    if suffix not in SUPPORTED_EXT:
        return JSONResponse(
            {"error": "Unsupported file type: " + suffix +
             ". Supported: " + ", ".join(sorted(SUPPORTED_EXT))},
            status_code=400
        )
    content_bytes = await file.read()
    result = _ingest_bytes(filename, content_bytes, suffix)
    if "error" in result:
        return JSONResponse(result, status_code=422)
    return JSONResponse({"status": "ok", "file": result})


@app.post("/api/chat")
async def chat(request: Request):
    body         = await request.json()
    user_input   = body.get("message", "").strip()
    target_agent = body.get("agent", None)   # None = Sam routes; "cliff" = direct

    if not user_input:
        return JSONResponse({"error": "Empty message"}, status_code=400)

    # Session 23: /ingest <path> short-circuit. Local file work — no API
    # client or model config required, so detect before config loading so
    # users without a configured API key can still bring files in. The
    # user-line lands in session history here (rather than below with the
    # chat path) and _stream_ingest_command pairs it via _session
    # .add_assistant on each terminal branch.
    #
    # The startswith check requires whitespace after "/ingest" so commands
    # like "/ingestplease" don't accidentally match. Bare "/ingest" hits
    # the equality branch and surfaces a usage hint.
    if user_input == "/ingest" or user_input.startswith("/ingest "):
        _session.add_user(user_input)
        return StreamingResponse(
            _stream_ingest_command(user_input),
            media_type="text/event-stream",
            headers={
                "Cache-Control":  "no-cache",
                "X-Accel-Buffering": "no",
                "Connection":     "keep-alive",
            }
        )

    config = _load_config()
    if not config:
        return JSONResponse({"error": "No config found. Run norm --setup first."}, status_code=503)

    client, provider, model_id = _build_client(config)
    if not client:
        return JSONResponse({"error": "No API client. Check your API key in config."}, status_code=503)

    agents = _load_agents()
    _session.add_user(user_input)

    async def generate():
        async for event in _stream_plan(config, client, provider, model_id,
                                        user_input, target_agent, agents):
            yield event

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control":  "no-cache",
            "X-Accel-Buffering": "no",
            "Connection":     "keep-alive",
        }
    )


# Session 26 — Priority 3d. Binary content types served by /api/deliverable.
# Whitelist, not blacklist: anything not in this dict (other than .md, which
# falls through to the rendered viewer) is rejected with 400. Each entry is
# (media_type, content_disposition_type).
#
# Office formats use `attachment` so the browser triggers a download dialog —
# rendering a .docx in the browser is not a thing, and Excel/PowerPoint
# round-trip much better through the native app.
#
# PDFs use `inline` so the browser's built-in viewer takes over (most modern
# browsers have one). The user can still save via the viewer's controls if
# they want a local copy. If we ever need to force-download PDFs (e.g. for a
# handoff workflow), flip `inline` to `attachment` here.
_BINARY_DELIVERABLE_TYPES = {
    ".xlsx": ("application/vnd.openxmlformats-officedocument."
              "spreadsheetml.sheet", "attachment"),
    ".docx": ("application/vnd.openxmlformats-officedocument."
              "wordprocessingml.document", "attachment"),
    ".pptx": ("application/vnd.openxmlformats-officedocument."
              "presentationml.presentation", "attachment"),
    ".pdf":  ("application/pdf", "inline"),
}


@app.get("/api/deliverable")
async def get_deliverable(path: str):
    """Serve a saved deliverable.

    Routing by extension:
      .md                  → rendered HTML viewer (existing behavior)
      .xlsx/.docx/.pptx    → FileResponse with Office MIME, `attachment`
                             disposition (browser triggers download)
      .pdf                 → FileResponse with `inline` disposition
                             (browser's built-in PDF viewer)
      anything else        → 400

    Security: the resolved path must stay inside USER_DIR/clients/. The
    containment check runs BEFORE the extension dispatch so a path-traversal
    attempt with an allowed extension (e.g. `?path=../../../../etc/passwd.pdf`
    on a system where someone planted such a file) still gets rejected at
    the same gate that protects the markdown path. The CLIENTS_DIR resolve
    is what stops `..` from escaping the sandbox.
    """
    try:
        rel = Path(path)
        abs_path = (USER_DIR / rel).resolve()
        clients_base = CLIENTS_DIR.resolve()
        abs_path.relative_to(clients_base)  # raises ValueError if outside
    except (ValueError, OSError):
        return HTMLResponse("<h1>Invalid path</h1>", status_code=400)

    if not abs_path.exists() or not abs_path.is_file():
        return HTMLResponse("<h1>Not found</h1>", status_code=404)

    suffix = abs_path.suffix.lower()

    # Binary path — serve the bytes via FileResponse. The explicit
    # Content-Disposition header is set rather than relying on
    # FileResponse's `filename=` kwarg because we need to choose between
    # `attachment` and `inline` per type, and the explicit header is the
    # portable way to do that across Starlette versions. The filename is
    # quoted to handle any spaces or special chars in deliverable names.
    if suffix in _BINARY_DELIVERABLE_TYPES:
        media_type, disposition = _BINARY_DELIVERABLE_TYPES[suffix]
        # RFC 6266: filename="..." with a backslash-escaped quote handles
        # the simple ASCII case. Deliverable filenames are agent-generated
        # and currently don't contain quotes; if that changes, switch to
        # the filename*= UTF-8 form.
        safe_name = abs_path.name.replace('"', '\\"')
        return FileResponse(
            path=str(abs_path),
            media_type=media_type,
            headers={"Content-Disposition":
                     disposition + '; filename="' + safe_name + '"'},
        )

    # Markdown path — unchanged from session 22.
    if suffix != ".md":
        return HTMLResponse("<h1>Unsupported type</h1>", status_code=400)

    try:
        content = abs_path.read_text(encoding="utf-8")
    except Exception as e:
        return HTMLResponse("<h1>Read error</h1><p>" + str(e) + "</p>", status_code=500)

    # Build breadcrumbs from the path relative to clients/
    try:
        crumb_parts = abs_path.relative_to(clients_base).parts
    except ValueError:
        crumb_parts = (abs_path.name,)
    breadcrumbs = " / ".join(crumb_parts)
    return HTMLResponse(_render_deliverable_viewer(abs_path.name, breadcrumbs, content))


def _render_deliverable_viewer(title: str, breadcrumbs: str, content: str) -> str:
    """Return a minimal HTML page that renders the deliverable's Markdown
    using marked.js on the client side. Uses the same brand palette as the
    main chat UI. Content is embedded as a safely-serialized JS string."""
    import html as _html
    # Embed content as JSON so any special chars are safely encoded for JS
    content_js = json.dumps(content)
    t = _html.escape(title)
    b = _html.escape(breadcrumbs)
    return (
        '<!DOCTYPE html>\n<html lang="en"><head>\n'
        '<meta charset="UTF-8">\n'
        '<title>' + t + ' · TavernOS</title>\n'
        '<link rel="preconnect" href="https://fonts.googleapis.com">\n'
        '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>\n'
        '<link href="https://fonts.googleapis.com/css2?family=DM+Mono:wght@300;400;500'
        '&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">\n'
        '<script src="https://cdnjs.cloudflare.com/ajax/libs/marked/12.0.2/marked.min.js"></script>\n'
        '<style>\n'
        ':root{--teal:#00d4c8;--teal3:#007972;--navy:#060f1a;--navy2:#0b1929;'
        '--navy3:#0f2236;--navy4:#162d47;--white:#f0f6ff;--gray:#7a9ab5;--gray2:#4a6a85;}\n'
        '*{box-sizing:border-box;margin:0;padding:0;}\n'
        'body{font-family:"DM Sans",sans-serif;background:var(--navy);color:var(--white);'
        'font-size:15px;line-height:1.7;min-height:100vh;}\n'
        '.wrap{max-width:820px;margin:0 auto;padding:40px 32px 80px;}\n'
        '.hdr{border-bottom:1px solid var(--navy4);padding-bottom:20px;margin-bottom:32px;}\n'
        '.crumbs{font-family:"DM Mono",monospace;font-size:11px;color:var(--gray2);'
        'letter-spacing:.05em;margin-bottom:8px;}\n'
        '.title{font-size:28px;font-weight:600;color:var(--white);letter-spacing:-.02em;}\n'
        '.actions{margin-top:14px;display:flex;gap:10px;}\n'
        '.btn{background:transparent;border:1px solid var(--navy4);color:var(--gray);'
        'padding:7px 14px;font-family:"DM Mono",monospace;font-size:11px;cursor:pointer;'
        'border-radius:4px;text-decoration:none;display:inline-block;}\n'
        '.btn:hover{color:var(--teal);border-color:var(--teal3);}\n'
        '.doc{color:var(--white);}\n'
        '.doc h1,.doc h2,.doc h3,.doc h4{color:var(--teal);font-weight:600;'
        'margin:26px 0 10px;letter-spacing:-.01em;line-height:1.3;}\n'
        '.doc h1{font-size:26px;}.doc h2{font-size:21px;}.doc h3{font-size:17px;}\n'
        '.doc h1:first-child,.doc h2:first-child{margin-top:0;}\n'
        '.doc p{margin:0 0 14px;}\n'
        '.doc strong{color:var(--white);font-weight:600;}\n'
        '.doc em{color:var(--white);font-style:italic;}\n'
        '.doc ul,.doc ol{margin:10px 0 18px;padding-left:26px;}\n'
        '.doc li{margin:4px 0;}.doc li::marker{color:var(--teal);}\n'
        '.doc code{background:var(--navy3);padding:2px 6px;border-radius:3px;'
        'font-family:"DM Mono",monospace;font-size:13px;color:var(--teal);}\n'
        '.doc pre{background:var(--navy3);border-left:3px solid var(--teal);'
        'padding:14px 18px;border-radius:4px;overflow-x:auto;margin:14px 0;}\n'
        '.doc pre code{background:transparent;padding:0;color:var(--white);}\n'
        '.doc blockquote{border-left:3px solid var(--teal3);padding-left:16px;'
        'margin:14px 0;color:var(--gray);font-style:italic;}\n'
        '.doc hr{border:none;border-top:1px solid var(--navy4);margin:24px 0;}\n'
        '.doc table{border-collapse:collapse;margin:16px 0;width:100%;font-size:14px;}\n'
        '.doc th,.doc td{border:1px solid var(--navy4);padding:10px 14px;'
        'text-align:left;vertical-align:top;}\n'
        '.doc th{background:var(--navy3);color:var(--teal);font-weight:600;'
        'font-size:12px;text-transform:uppercase;letter-spacing:.05em;}\n'
        '.doc tr:nth-child(even) td{background:var(--navy3);}\n'
        '.doc a{color:var(--teal);text-decoration:none;'
        'border-bottom:1px solid var(--teal3);}\n'
        '.doc a:hover{color:var(--white);}\n'
        '@media print{body{background:white;color:#1a1a1a;}\n'
        '.wrap{padding:20px 30px;}.crumbs,.actions,.btn{display:none;}\n'
        '.title,.doc,.doc strong,.doc em{color:#1a1a1a;}\n'
        '.doc h1,.doc h2,.doc h3,.doc h4{color:#00796b;}\n'
        '.doc code{background:#f7fafc;color:#00796b;}\n'
        '.doc pre{background:#f7fafc;color:#1a1a1a;border-left-color:#00796b;}\n'
        '.doc th{background:#f7fafc;color:#00796b;}\n'
        '.doc tr:nth-child(even) td{background:#f7fafc;}\n'
        '.doc a{color:#00796b;}\n'
        'h1,h2,h3{page-break-after:avoid;}.hdr{border-bottom-color:#e2e8f0;}\n'
        '}\n'
        '::-webkit-scrollbar{width:8px;}\n'
        '::-webkit-scrollbar-track{background:var(--navy);}\n'
        '::-webkit-scrollbar-thumb{background:var(--navy4);border-radius:4px;}\n'
        '</style></head>\n<body>\n'
        '<div class="wrap">\n'
        '  <div class="hdr">\n'
        '    <div class="crumbs">' + b + '</div>\n'
        '    <div class="title">' + t + '</div>\n'
        '    <div class="actions">\n'
        '      <a class="btn" href="javascript:window.close()">Close</a>\n'
        '      <a class="btn" href="javascript:window.print()">Print / Save PDF</a>\n'
        '    </div>\n'
        '  </div>\n'
        '  <div class="doc" id="doc"></div>\n'
        '</div>\n'
        '<script>\n'
        'const raw = ' + content_js + ';\n'
        'if (typeof marked !== "undefined") {\n'
        '  marked.setOptions({gfm:true,breaks:true,headerIds:false,mangle:false});\n'
        '  document.getElementById("doc").innerHTML = marked.parse(raw);\n'
        '} else {\n'
        '  const pre = document.createElement("pre");\n'
        '  pre.textContent = raw;\n'
        '  document.getElementById("doc").appendChild(pre);\n'
        '}\n'
        '</script>\n'
        '</body></html>\n'
    )


@app.get("/api/errors")
async def get_errors(limit: int = 20):
    """Return the last N entries from the error journal as JSON.
    Used by /errors in the UI to show recent failures + recoveries."""
    if not ERRORS_JOURNAL.exists():
        return JSONResponse({"entries": [], "total": 0,
                             "journal_path": str(ERRORS_JOURNAL),
                             "message": "No errors logged. All clear."})
    records = []
    try:
        with open(ERRORS_JOURNAL, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    records.append(json.loads(line))
                except Exception:
                    pass
    except Exception as e:
        return JSONResponse({"error": "Could not read journal: " + str(e)}, status_code=500)
    recent = records[-max(1, min(limit, 100)):]
    return JSONResponse({
        "entries":      recent,
        "total":        len(records),
        "journal_path": str(ERRORS_JOURNAL),
    })


@app.post("/api/errors/note")
async def post_error_note(request: Request):
    """Append a user-supplied note to the error journal. Lets you flag
    an issue in the moment — 'I noticed X is happening and it's annoying' —
    and have the note show up alongside the auto-captured errors when you
    review the journal later."""
    body = await request.json()
    note = (body.get("note") or "").strip()
    context = body.get("context") or {}
    if not note:
        return JSONResponse({"error": "Empty note"}, status_code=400)
    _log_error("user_note",
               note=note[:2000],
               user_input=(context.get("user_input") or "")[:500],
               related_error=(context.get("related_error") or "")[:500])
    return JSONResponse({"status": "ok", "message": "Note logged."})


@app.get("/health")
def health():
    return {"status": "ok", "service": "TavernOS Web UI", "version": "0.1.0"}


# ═══════════════════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════════

def start():
    """Called by norm.py --web"""
    uvicorn.run(app, host="127.0.0.1", port=7777, log_level="warning")


if __name__ == "__main__":
    print("TavernOS Web UI starting on http://127.0.0.1:7777")
    uvicorn.run(app, host="127.0.0.1", port=7777, log_level="info")